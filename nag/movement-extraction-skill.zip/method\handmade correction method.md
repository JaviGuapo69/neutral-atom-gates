> ### Note for this handover package
>
> This document was written inside the original working project and refers to folders there. In this
> package they are:
>
> | referred to as | here |
> |---|---|
> | run book in `HANDOVER.md`'s top box | `..\RUN_BOOK.md` §A, and `skills\se-cycle-blocks\SKILL.md` §"Procedure — A NEW MOVIE, END TO END" |
> | `run_c780_s31\` (the reference implementation) | `..\worked sessions\4aod_c780_s31\` |
> | `run_c540_s28\apply_s28.py`, `deliver_s28.ps1`, `dump_sched.py`, `list_moves.py` | `templates\` |
> | `run_c780_s31\crop.py`, `emit_s31.py`, `make_list_s31.py`, `alt_s30.py` | `templates\` |
> | `run_c540_v3\cmp_full.py` | `templates\cmp_full.py` |
> | `run_c630_s30\`, `run_c500_s29\`, `run_c975_s32\` (earlier sessions) | not shipped; their written accounts are in `..\reference\SESSION_29/30/32*.md` |
> | `closed videos\` | `..\..\closed videos\` |
> | `$SB` | `<project>\.claude\skills\se-cycle-blocks\tools` |
> | the user / Javier | whoever is reviewing your rebuild videos |
>
> Start with `..\README.md` if you have not read it.

# Handmade correction method — how a movie is closed after the skill has run

**Written for: the next Claude session (and Javier), before starting the hand correction of any
SE-cycle movie.** This is the standard procedure from session 28 (2026-09-16), the session that
closed c540. It assumes the official skill `.claude/skills/se-cycle-blocks/` has ALREADY been run
on the movie (run book in `HANDOVER.md`'s top box) and produced a book, `moves_full.json`,
`rests_full.json`, and a side-by-side rebuild video.

**The premise (the user's decision, 2026-09-16): the skill is final and its analysis will not get
better. Its remaining mistakes are found by the user watching the movie and corrected BY HAND.
A session never changes `tools/` for this.** It edits the move list, re-emits the book through the
skill's own emitter, re-runs the skill's own checks, and renders once at the end.

The reference implementation is `run_c780_s31/` (session 31, the first movie done the current
way): `apply_s31.py`, `make_list_s31.py`, `emit_s31.py`, `crop.py`, `deliver_s31.ps1`. `run_c540_s28/`
and `run_c630_s30/` are the earlier templates.

---

## 0. The division of labour — THE DEFAULT SINCE SESSION 31 (the user, 2026-09-17)

> "You solved all the mistakes correctly without me having to tell you what to do. I want that to be
> the default way of working for the handmade correction method. From now on, when I want to apply
> the method, you have to deliver a report with all the mistakes that you found in the video, propose
> solutions for each mistake of the workbook, apply them and then deliver a new rebuild video to me.
> That new video is where I will make my corrections by hand."

| who | does |
|---|---|
| the session, first pass | reads the WHOLE rebuild against the movie's pixels, finds every mistake it can, proposes the correct move for each with its measured residual, **applies them all without waiting**, re-emits, checks, renders once, delivers the report + the new video |
| the user | watches the movie against the NEW rebuild video, names the movements that are still wrong (by frame), approves or overrides the session's proposal for each, declares the movie closed |
| the session, second pass | for each movement the user names: the fixed "wrong movement between frames A and B" dialogue of §3 — check the pixels, propose, **apply only on approval** |

Two rules survive from the older form: never "improve" a movement the user has named differently
without saying so (the pixels decide, and the disagreement goes into the Notes), and never touch the
skill's `tools/`. Everything the session applies on its own must be MEASURED (`verify`, free per-frame
error) and listed with its evidence in `sNN_correction_list.md`, so the user can overrule any item.

---

## 1. Set up a session folder

```powershell
# NN = this session's number; PREV = the folder of the automatic run (or the previous hand session)
New-Item -ItemType Directory run_<movie>_sNN
Copy-Item run_<movie>_<PREV>\calib.json, ...\blocks.json, ...\events.json, ...\extra.json,
          ...\moves_full.json, ...\rests_full.json   run_<movie>_sNN\
Copy-Item run_<movie>_<PREV>\moves_full.json run_<movie>_sNN\moves_full_<PREV>_original.json  # the apply script READS these
Copy-Item run_<movie>_<PREV>\rests_full.json run_<movie>_sNN\rests_full_<PREV>_original.json  # untouched originals
Copy-Item run_c540_s28\dump_sched.py, run_c540_s28\list_moves.py, run_c540_s28\apply_s28.py,
          run_c540_s28\deliver_s28.ps1  run_<movie>_sNN\
```

Rename `apply_s28.py` → `apply_sNN.py` and `deliver_s28.ps1` → `deliver_sNN.ps1`; in the deliver
script replace every `s28`/`c540` and the `-MovieFrames` path. The previous book and its videos are
never overwritten; the corrected book gets the new session's name.

---

## 2. The first pass: find every mistake yourself, in FRAMES, and apply the fixes

Frame = t_ms / `dt_ms` (`dt_ms` is in `calib.json`). The user checks frames, not milliseconds.

**2a. Before reading any move, run `se_sim` on the automatic book** and read the check3/check4 lines.
On c780 the two hand-measured readout rows of `extra.json` named the departing block's OLD columns,
so half its atoms stayed alive and every later move on that site "claimed two atoms" — a fault that
looks like a dozen bad maps. Readout/load rows must name the block's position AT the readout.

**2b. Read the whole movie interval by interval** (pulse run to pulse run):
* `sb_probe --peaks` on both axes for every block over the interval, and look at the OUTLINE classes
  (each colour is one rigid group; its tones on the first moving frame are `src`, on the last `dst`);
* `crop.py OUT f0 f1 c0 c1 r0 r1` montages (in `run_c780_s31\`) of the block's region, frame by frame,
  when the classes are not clear from the profile — this is how the scrambled descents and the
  four-group exchanges of c780 were read;
* the movie PNG vs the rebuild PNG (`run_<movie>\frames\p_NNN.png` vs `run_<movie>_<PREV>\rframes\p_NNN.png`)
  for a frame in the middle of every move, and for every frame where the book has NO move but the
  movie's markers bunch (a never-enumerated movement, rule 36).
Look for the recurring fault kinds (c630, c780): the third block of a batch rotating OPPOSITE (or the
same way where the report guessed the inverse); a small permutation or 3-cycle read as a whole-block
rotation with static rows dragged in; the same movement done by two blocks written for one only
(join them on one rectangle); duplicated batches; phantoms (rows on their tones on every frame);
four-group exchanges (+2/+4 with −2/−4) written as 8-part reads or "relocations"; relocations that
are SCRAMBLED (rigid groups with different offsets) refused as "undetermined" because the plain
translation reads 0.18; a false rest one column into the motion; the 0.1-0.6-frame overlaps between a
block's consecutive moves that inflate the AOM count.

**2c. For each mistake, decide the map by MEASUREMENT** (`sb_compose.verify` mean and the free
per-frame error; compare alternatives side by side as `alt_s30.py` did), write it into `apply_sNN.py`
with the evidence in its `how`, and go on. Do not stop to ask. Then §4-§6: apply, check, render once.

**2d. Deliver** the report (the compact table `# | frames | block | what the book has / what is wrong |
applied | mean / free`, the checks table automatic vs corrected, every `sb_watch` run named), the full
list `sNN_correction_list.md` (generated; one entry per corrected/added move with the old and new rows),
the book and both videos at the root under the session's name. Say plainly what is measured and what
is a convention, and which watch runs are unverified.

The priorities below still order the reading — they are where the mistakes hide — but nothing waits
for the user any more:

1. **Known wrong or missing.** If a hand book exists, the `cmp_full.py` lines that say
   `no hand-book change` (minus readouts/loads the hand book omits) and the REVERSE-DIRECTION list
   (hand-book displacements no sheet movement accounts for). Anything the previous session's report
   left open.
2. **UNDETERMINED** transitions (`moves_full.json` → `undetermined`; the log).
3. **Moves over the 0.10 guideline** (`OVER 0.10` in the `sb_full` log; `mean` in the move list;
   `list_moves.py moves_full.json` prints all of them with frames). Mark the ones where the log also
   shows the patch detector REFUSING its own read (`NOT written, left UNDETERMINED (gate 4)`) or an
   S2.1 competition `NOT taken`.
4. **Judgment calls**: `REPLACES` notes (a 3-part read replaced by a 2-group rotation within 0.03),
   `TIE` notes.
5. **Not defects, say so**: the readout/load/carry-in rows (`extra.json`) and any known comparator
   artefact.

The standing answers (sessions 28-31) to "how are corrections applied and where does the output go":
edit the move list and re-emit; new folder `run_<movie>_sNN`; render once at the end; book and
videos copied to the root as `<movie>_sNN_*`.

---

## 3. The second pass: the dialogue for one movement the USER names

After watching the new video the user says:

> **wrong movement between frames A and B**

The session then does, in this order:

1. **Look at both sides.** `Read` the movie frame `run_<movie>\frames\p_<f>.png` and the rebuilt
   frame `run_<movie>_<PREV>\rframes\p_<f>.png` for a frame in the middle of A..B. The mp4 cannot
   be watched here; the PNGs can. Bunched markers in the movie and a still block in the rebuild is a
   missing permutation; the reverse is a phantom one.
2. **Profile the peaks**, both axes if the axis is not obvious, two frames each side:
   ```powershell
   python $SB\sb_probe.py --calib calib.json --peaks --sp <SP> --axis 0 --f0 A-2 --f1 B+2
   python $SB\sb_probe.py --calib calib.json --peaks --sp <SP> --axis 1 --f0 A-2 --f1 B+2
   ```
   Read the partition from the OUTLINE colour classes on the first moving frame (each colour is one
   rigid group, rule 3z): its tones at the first moving frame are `src`, at the last frame `dst`.
   Check that the FILL peaks at mid-progress are explained: a row the book holds static must show a
   peak on its tone on the moving frames, and a wrong map predicts peaks where the profile has none
   (c540 f154: the book predicted peaks at 12 and 15; the fill showed 11.26 and 14.35).
3. **Fix the timing under rule 9.** No move crosses a pulse (`gate_frames` in `calib.json`; the
   gate's instant is the run's FIRST frame). Clip the move to its neighbours on the same atoms: start
   when the previous move of that block finishes, finish when the next one starts, so no atom ever
   carries two motions at once (render.ps1 picks atoms up by rounding their position at batch time).
   Quote the frame the free fit wanted if the clipping moved it.
4. **Dump the workbook rows** for the window, so the user sees what the book has now:
   ```powershell
   python dump_sched.py <PREV book>.xlsx  t_lo_ms  t_hi_ms
   ```
5. **Reply in this fixed format**, then STOP and wait:

   > **Wrong movement between frames A and B** (species, axis, block position)
   >
   > one paragraph: what the movie shows, what the rebuild shows, the peak evidence
   >
   > table: the Schedule rows the workbook has for that window (move, slot, event, t_start,
   > t_finish, x_start, y_start, x_finish, y_finish, note)
   >
   > table: the suggested correct rows (slot, event, t_start, t_finish, x_start, y_start,
   > x_finish, y_finish, displacement) — one row per rigid group

   The user answers "apply your correction" or gives the map to use instead.

---

## 4. Apply the approved corrections — `apply_sNN.py`

Edit the MOVE LIST, never the xlsx cells: `Combined`, the AOM colouring and `Notes` are derived from
the move list by `sb_emit.emit`, and a hand-edited cell makes them drift. `run_c540_s28/apply_s28.py`
is the template; it does, for every approved correction:

* **Replace a map**: find the move by `sp`, `axis`, `f0`, `f1`; set `parts` (one `[src_list,
  dst_list]` per rigid group), `src`, `dst` (dst[i] is where src[i] goes), `A/A2/B/B2` (the first
  two parts), and a `how` string beginning `HAND CORRECTION (session NN, date, user-confirmed
  against the movie)` that states the evidence. Keep `t0/t1/fa/fb` unless the timing was part of
  the correction. Same-site permutations keep `comb`; a relocation also changes the transition.
* **Add a movement the skill never enumerated**: build a complete move record (copy a neighbour's
  fields: `for_tr`, `sp`, `axis`, `kind`, `f0`, `f1`, `iv`, `parts`, `src`, `dst`, `A..B2`, `fa`,
  `fb` = t/dt, `lo`, `hi` = the pulse bounds, `t0`, `t1`, `joins`, `comb`, `how`,
  `sub_comb_lines`, `ok`) and insert it in time order. Then make `rests_full.json` ENUMERATE it, or
  `sb_audit` reports an IDLE move: split the transition it hides inside (`f1` of the previous one
  := the movement's first frame), append a transition `{sp, f0, f1, x0, y0, x1, y1, kind}` and a
  rest `[f, f, xs, ys]` at the frame between. Point the previous move's `for_tr` at its shortened
  transition.
* **Measure, do not assert.** `sb_compose.verify(P, sp, axis, src, dst, fa, fb, frames, M)` gives
  `mean`/`worst` and, per species, the join `detail`; `sb_compose.progress_per_frame` gives the
  per-frame free progress and error. Write those into the record and print them. A correct map
  explains every moving frame to a few hundredths of a site on the free fit; the smoothstep `mean`
  may still read over 0.10 on a fast wrap (SESSION_27_LAST_RESORT.md §1.3) — quote both honestly.
  On an involution (rotation by n/2) the free `p` is arbitrary between p and 1−p; that is not a
  fault.
* **Append a note** per correction to `mv["notes"]`, then save `moves_full.json` and
  `rests_full.json`, and **re-emit** with `sb_emit.emit(xlsx, M, mv, rests, runs, P, 0, nf-1,
  extra="extra.json", scope_note=...)` — the same call `sb_full.py` makes at its end.

Run it with `python -u apply_sNN.py | Tee-Object apply_sNN.log` from the session folder.

---

## 5. Prove the corrected book — the skill's own checks, unchanged

```powershell
python $SB\sb_audit.py --moves moves_full.json --rests rests_full.json     # must print AUDIT CLEAN, 0 IDLE, 0 SILENT
python ..\.claude\skills\se-cycle-movies\tools\se_sim.py <book>.xlsx         # validation clean, census conserved
python $SB\cmp_tol.py ..\run_<movie>_<PREV>\moves_full.json moves_full.json   # EXACTLY the intended differences, nothing else
python ..\run_c540_v3\cmp_full.py --moves moves_full.json --extra extra.json  # only if a hand book exists (c540)
```

`cmp_tol` is the important one: it must show the replaced maps as `MAP DIFFERS`, the added moves as
"in the NEW run with no counterpart", and every other move `matched exactly`. Anything else means the
edit touched a move it should not have. Keep the outputs (`audit_sNN.txt`, `sim_sNN.txt`,
`sNN_vs_<PREV>.txt`, `sNN_vs_shayne.txt`).

---

## 6. Render once, at the end — `deliver_sNN.ps1`

The user's choice in session 28: one render after all corrections, not one per correction (~14 min
for a 384-frame movie: calibtxt → render.ps1 → sb_score → sb_video). Launch it detached so the
tool timeout cannot kill it, and poll the log:

```powershell
Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-Command',
  "Set-Location '<abs path>\run_<movie>_sNN'; .\deliver_sNN.ps1 *> deliver_sNN.log" -WindowStyle Hidden
Get-Content run_<movie>_sNN\deliver_sNN.log -Tail 20
```

Then check: 384 frames in `rframes\`, `render_log.csv` has only its header (0 validation entries),
`score_sNN.txt` (quote the raw number and remember rule 27: the score cannot see a same-site
permutation), and the two mp4s exist. Copy the book and both videos to the project root under the
session's name. ffmpeg is not on PATH in a fresh shell; the deliver script adds it.

---

## 7. Close the movie

1. The user watches the new video. If they name another wrong movement, go back to §3 (same folder,
   same `apply_sNN.py` extended — it always starts from the copied PREV move list, so re-running it
   re-applies every correction). Those items are applied only on the user's approval.
2. When the user declares the movie closed and correct: write `SESSION_NN_<...>.md` (what was
   corrected, the evidence, the check results), copy the book and both videos to `closed videos\`
   (MD5-verified) and add the movie to `closed videos\MANIFEST.md`, put a new top box in `HANDOVER.md`
   saying the movie is CLOSED and which book and videos are final, and update the memory notes.
3. Say plainly what was measured and what is a convention (readout destinations, reservoir staging)
   — the corrected book inherits the automatic run's conventions unchanged.

---

## 8. Traps met while doing this

* **A never-enumerated movement is in no list** (rule 36). Only the user's eyes or a hand book find
  it; expect at least one per pipelined movie. After adding it, `rests_full.json` must enumerate it
  or the audit calls the move IDLE.
* **Two motions on the same atoms must not overlap in time.** Clip the corrected move to its
  neighbours; a free fit's flat easing tails will otherwise run into the next move.
* **The smoothstep `mean` over-reads on fast wraps** (0.15 on c540's f348-355 with the free per-frame
  error at 0.03). Judge a hand map on the free per-frame fit and the outline classes, not on `mean`.
* **`sb_probe --peaks` without `--win` uses the whole panel**, so the outline classes it prints are
  every species' at once; read the ones on the block's tones.
* **`.xlsx` open in Excel → PermissionError** on write; PowerShell 5.1 has no `&&`; `$s` and `$S`
  are one variable; `python -u` for anything logged to a file.
* **A hand-written move record must list EVERY tone of the block on the moving axis, static ones as
  identity** (`src 1:5, dst 1,4,5,2,3`, as the solver writes them). With only the moving tones the
  symmetric `verify` charges each static row a full site: c500's right maps read 0.27–0.43 until this
  was fixed, then 0.03–0.15 (session 29, `apply_s29.set_map(m, parts, block)`).
* **The two halves of an exchange (A 26:30→21:25 while B 21:25→26:30) must share one `t_start`.**
  se_sim and render.ps1 pick atoms up by position at batch time; B's own fit began 0.6 frame before A's
  and every later move on those rows picked up twice its atoms (c500 f244-251). Mirror the partner's
  timing and quote the own fit in `how`.
* **When the user's frame reading and the pixels disagree, the pixels decide** and the disagreement goes
  into the Notes (c500: a direction at f105-109, a comb one column over at f297-310).
* **Do not "fix" the other over-0.10 moves** because their number looks bad. In c540 29 of the 31
  over-guideline moves matched the hand book; the two real faults were one at 0.161 and one that
  had no number at all.
* **`cmp_full.py` compares displacement SETS at a time boundary, not maps.** Two blocks doing
  DIFFERENT movements with the same set of displacements both read MATCH (c540 f140-144: X0's
  `13:17->14:18 | 18->13` and X1's `13:14,16:17->14:15,17:18 | 15,18->13,16` are both {−2,+1}).
  The user found it by seeing D3 and D4 move differently in the rebuild. When two blocks of the
  same species pair move at the same time, check that their maps are the same, not just their
  displacement sets — and if they are the same, join them on one rectangle (fewer AOMs).
* **The apply script must start from the UNTOUCHED previous files** (copies named
  `*_<PREV>_original.json`), so that re-running it after a new correction re-applies all of them
  from scratch and `cmp_tol` against PREV shows the whole set of intended changes.
