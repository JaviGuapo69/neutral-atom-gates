"""permscan.py -- rank EVERY permutation of a named set of moving tones, the way rotscan.py ranks every
cyclic rotation.  For the windows where no rotation fits and the map has to be read from a small set of
columns that `gaps.py` has already isolated.

The tones not named are carried as identity (verify otherwise charges every static tone a full site).
Each candidate gets the skill's own fit_timing inside [f0-1, f1+1] and then verify + the FREE per-frame
progress error, and the table is sorted on the free error, which is the measure that does not depend on
the smoothstep shape.

    python permscan.py SP AXIS F0 F1 T0 T1 MOVERS [SUB]
      MOVERS  comma-separated, e.g. 2,3,5,6,7,12
      SUB     comma-separated lines on the other axis, or "-" for the whole block
"""
import itertools, os, sys
sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_build, sb_compose
from sb_read import Movie

sp, axis, f0, f1 = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
t0, t1 = int(sys.argv[5]), int(sys.argv[6])
mov = [int(v) for v in sys.argv[7].split(",")]
sub = None
if len(sys.argv) > 8 and sys.argv[8] != "-":
    sub = [int(v) for v in sys.argv[8].split(",")]

M = Movie("calib.json")
wins = sb_compose.species_windows(M, 0, M.nf - 1)
frames = list(range(max(0, f0 - 1), min(M.nf - 1, f1 + 1) + 1))
P = sb_build.SubPeaks(M, wins, (1 - axis, sub), frames) if sub else sb_compose.Peaks(M, wins, frames[0], frames[-1])
lo, hi = float(f0 - 1), float(f1 + 1)
src = list(range(t0, t1 + 1))

out = []
for perm in itertools.permutations(mov):
    if any(a == b for a, b in zip(mov, perm)):        # a named mover that does not move
        continue
    mp = dict(zip(mov, perm))
    dst = [mp.get(s, s) for s in src]
    best = sb_build.fit_timing(P, M, sp, axis, src, dst, frames, lo, hi)
    if best is None:
        continue
    _, a, b = best
    mean, worst, nn = sb_compose.verify(P, sp, axis, src, dst, a, b, frames, M)
    seq = sb_compose.progress_per_frame(P, sp, axis, src, dst, frames, M)
    free = [s[2] for s in seq if 0.02 < s[1] < 0.98]
    out.append(((sum(free) / len(free)) if free else 9.9, round(mean, 4), worst, a, b, len(free), perm))

out.sort()
print("%s %s f%03d-%03d tones %d:%d, movers %s%s -- %d candidates"
      % (sp, "cols" if axis == 0 else "rows", f0, f1, t0, t1, mov,
         (" on sub %s" % sub) if sub else "", len(out)))
for free, mean, worst, a, b, nf, perm in out[:15]:
    print("   FREE %.4f  mean %.4f worst %.3f  f%.2f-%.2f (%d fr)  %s"
          % (free, mean, worst, a, b, nf, " | ".join("%d->%d" % (s, d) for s, d in zip(mov, perm))))
