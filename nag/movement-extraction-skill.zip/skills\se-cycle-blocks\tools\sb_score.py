"""sb_score.py -- score a rebuild against the movie by 1-D COLOUR PROFILE PEAKS.

    python ..\\se-cycle-movies\\tools\\se_calibtxt.py --calib calib.json \
           --out-txt movie_calib.txt --out-json render_calib.json \
           --render-frames rframes --tone-divisor 1
    ..\\se-cycle-movies\\tools\\render.ps1 -Xlsx out.xlsx -OutDir rframes \
           -LogCsv log.csv -MatchCalib movie_calib.txt
    python sb_score.py --movie-calib calib.json --render-calib render_calib.json --out score.txt

NOT `se_compare.py`.  That works from `se_extract.py`'s marker lists, whose 0.62-pitch non-maximum
suppression deletes the crossing frames on BOTH sides and so flatters the result -- and the
crossings are exactly what this skill exists to get right.

Each side is masked with ITS OWN palette.  `render.ps1` assigns its own fixed colours in sorted
species order, and c150's Z0 differs by 47 RGB between movie and render, more than the 34 RGB mask
tolerance, so extracting the render with the movie's colours finds nothing at all.
`se_calibtxt.py --out-json` builds the render's calibration for you and also zeroes
`marker_offset`, which matters -- see below.

RULE 17, and the correction session 13 found.  Score against a registration bias measured on a
species that is STATIC in some window, never against zero: such a species' schedule is right by
construction, so whatever offset it shows is the renderer's.  This tool finds that control itself --
the longest run of frames over which any species holds one rectangle -- and reports the bias with
its spread, plus a cross-check over every closely matched pair in the movie.

**The bias is ~0 when the render is extracted with `--out-json`** (c150: x +0.005, y +0.009 site,
and the raw and corrected means agreed to 0.0001).  Session 12's -0.084 / +0.081 is the MOVIE
calibration's own `marker_offset`, and it appears only if both sides are extracted with the movie's
calibration, where it nearly doubles the reported error.  So: always measure it, always say which
calibration each side used, and never carry a bias forward from another session as a constant.

The auto-detected control is the LONGEST static run, which may be a block parked off panel with
only one column visible -- on c150 it picks X0 at cols -5:0 over f237-328.  That is still a valid
control (its schedule is right by construction) but a fully visible block is a better one, so if
you know of one, name it: `--control Z1:0-49`.  Either way the tool prints which it used and the
spread, and if the raw and corrected means differ by more than ~0.005 site the bias is real and
worth understanding before you quote either number.
"""
import argparse, os, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sb_read import Movie

TOL = 0.12              # site: on-tone tolerance when hunting for a static control
GONE = 9.99             # sentinel: one side has the block and the other does not


def find_control(M, win, frames):
    """the longest run of frames over which some species holds ONE rectangle -- rule 17's control"""
    best = None
    for nm in M.species:
        rect, start = None, None
        for f in frames + [None]:
            cur = None
            if f is not None:
                xs = M.peaks(M.fill[nm], win, f, 0)
                ys = M.peaks(M.fill[nm], win, f, 1)
                if xs and ys and all(abs(v - round(v)) <= TOL for v in xs + ys):
                    cur = (tuple(int(round(v)) for v in xs), tuple(int(round(v)) for v in ys))
            if cur is not None and cur == rect:
                continue
            if rect is not None and start is not None:
                run = [g for g in frames if start <= g < (f if f is not None else frames[-1] + 1)]
                if best is None or len(run) > len(best[1]):
                    best = (nm, run)
            rect, start = cur, f
    return best or (M.species[0], frames[:min(40, len(frames))])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--movie-calib", required=True)
    ap.add_argument("--render-calib", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--control", default="", help="species:f0-f1 to override the auto-detected "
                                                  "static control")
    a = ap.parse_args()

    MM = Movie(a.movie_calib)
    RR = Movie(a.render_calib)
    vc, vr = MM.K["visible_col"], MM.K["visible_row"]
    win = (vc[0] - 0.45, vc[1] + 0.45, vr[0] - 0.45, vr[1] + 0.45)
    frames = [f for f in range(MM.nf) if f not in MM.gate]
    missing = [f for f in frames if not os.path.exists(os.path.join(RR.dir, "p_%03d.png" % f))]
    if missing:
        print("WARNING: %d render frames missing (first %s) -- did render.ps1 finish?"
              % (len(missing), missing[:5]))
        frames = [f for f in frames if f not in set(missing)]

    print("movie palette : %s" % {k: tuple(int(x) for x in v) for k, v in MM.fill.items()})
    print("render palette: %s" % {k: tuple(int(x) for x in v) for k, v in RR.fill.items()})

    pk = lambda side, nm, f, ax: sorted(side.peaks(side.fill[nm], win, f, ax))

    if a.control:
        nm, rng = a.control.split(":")
        lo, hi = (int(v) for v in rng.split("-"))
        ctrl = (nm, [f for f in frames if lo <= f <= hi])
    else:
        ctrl = find_control(MM, win, frames)
    cn, cf = ctrl
    bias, spread = [0.0, 0.0], [0.0, 0.0]
    for axis in (0, 1):
        d = []
        for f in cf:
            m, r = pk(MM, cn, f, axis), pk(RR, cn, f, axis)
            if len(m) == len(r) and m:
                d += [b - c for c, b in zip(m, r)]
        if d:
            bias[axis], spread[axis] = float(np.median(d)), float(np.std(d))
    print("static control: %s over %d frames (f%d..f%d) -- its schedule is right by construction"
          % (cn, len(cf), cf[0], cf[-1]))
    print("registration bias: x %+.3f (sd %.3f)   y %+.3f (sd %.3f) site"
          % (bias[0], spread[0], bias[1], spread[1]))

    allsig = [[], []]
    for f in frames:
        for nm in MM.species:
            for axis in (0, 1):
                m, r = pk(MM, nm, f, axis), pk(RR, nm, f, axis)
                if len(m) == len(r) and m:
                    dd = [b - c for c, b in zip(m, r)]
                    if max(abs(v) for v in dd) < 0.35:
                        allsig[axis] += dd
    print("cross-check, median signed offset over every closely matched pair: x %+.3f  y %+.3f "
          "(%d, %d pairs)"
          % (float(np.median(allsig[0])) if allsig[0] else float("nan"),
             float(np.median(allsig[1])) if allsig[1] else float("nan"),
             len(allsig[0]), len(allsig[1])))

    def err(m, r, b):
        r = [v - b for v in r]
        if not m and not r:
            return []
        if not m or not r:
            return [GONE] * max(len(m), len(r))
        return ([min(abs(x - y) for y in r) for x in m] +
                [min(abs(y - x) for x in m) for y in r])

    tot = n = raw_tot = raw_n = 0.0
    # A MISSING-BLOCK cell is not a positional error and its GONE penalty swamps everything around
    # it, so also report the mean with exactly those cells dropped -- never instead of the headline
    # mean, always beside it, and only as a way of saying how much of the headline they are.
    # On c300 three frames of movie-side occlusion (Z0 hidden behind Z1 while the two blocks cross
    # through each other on the same rows, so Z0's fill mask reads zero peaks) carry ~10 site each
    # and are the whole of Z0's elevated per-species figure.  They are not fixable rows: the block
    # is where the sheet says, it just cannot be measured on those frames.
    ex_tot = ex_n = 0.0
    ex_sp = {}
    worst, worst_at = 0.0, None
    per_frame, per_sp, gone = {}, {}, []
    for f in frames:
        ef = []
        for nm in MM.species:
            for axis in (0, 1):
                m, r = pk(MM, nm, f, axis), pk(RR, nm, f, axis)
                e, e0 = err(m, r, bias[axis]), err(m, r, 0.0)
                if not e:
                    continue
                if max(e) >= GONE:
                    gone.append((f, nm, "cols" if axis == 0 else "rows", len(m), len(r)))
                else:
                    ex_tot += sum(e); ex_n += len(e)
                    d = ex_sp.setdefault(nm, [0.0, 0]); d[0] += sum(e); d[1] += len(e)
                tot += sum(e); n += len(e)
                raw_tot += sum(e0); raw_n += len(e0)
                d = per_sp.setdefault(nm, [0.0, 0]); d[0] += sum(e); d[1] += len(e)
                ef += e
                if max(e) > worst:
                    worst = max(e)
                    worst_at = (f, nm, "cols" if axis == 0 else "rows",
                                [round(v, 2) for v in m], [round(v, 2) for v in r])
        if ef:
            per_frame[f] = (float(np.mean(ef)), max(ef))

    mean, raw = tot / n, raw_tot / raw_n
    clean = sum(1 for _f, (mu, wo) in per_frame.items() if wo <= 0.25)
    print("\n%d comparisons over %d non-pulse frames" % (n, len(per_frame)))
    print("MEAN peak-matching error: %.4f site  (raw, before removing the bias: %.4f)" % (mean, raw))
    print("worst %.3f at f%03d %s %s\n   movie %s\n   render %s"
          % (worst, worst_at[0], worst_at[1], worst_at[2], worst_at[3], worst_at[4]))
    print("frames with every peak within 0.25 site: %d of %d" % (clean, len(per_frame)))
    print("per species: %s" % {k: round(v[0] / v[1], 4) for k, v in sorted(per_sp.items())})
    if gone:
        print("\n*** %d species/axis/frame cases where ONE SIDE HAS THE BLOCK AND THE OTHER DOES "
              "NOT. This is not a positional error, it is a missing or mistimed row -- usually a "
              "load whose birth time rounded PAST its frame, or an unload that retires too early. "
              "Fix these before reading the mean:" % len(gone))
        for g in gone[:20]:
            print("    f%03d %-3s %-4s  movie %d peaks, render %d" % g)
        if ex_n:
            print("    with just those %d cells dropped: MEAN %.4f site over %d comparisons, "
                  "per species %s" % (len(gone), ex_tot / ex_n, int(ex_n),
                                      {k: round(v[0] / v[1], 4) for k, v in sorted(ex_sp.items())}))

    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write("movie palette : %s\n" % {k: tuple(int(x) for x in v) for k, v in MM.fill.items()})
        fh.write("render palette: %s\n" % {k: tuple(int(x) for x in v) for k, v in RR.fill.items()})
        fh.write("static control %s over f%d..f%d; registration bias x %+.3f (sd %.3f) "
                 "y %+.3f (sd %.3f)\n" % (cn, cf[0], cf[-1], bias[0], spread[0],
                                          bias[1], spread[1]))
        fh.write("%d comparisons over %d non-pulse frames\n" % (n, len(per_frame)))
        fh.write("MEAN %.4f site (raw %.4f); worst %.3f at f%03d %s %s\n"
                 % (mean, raw, worst, worst_at[0], worst_at[1], worst_at[2]))
        fh.write("frames with every peak within 0.25 site: %d of %d\n" % (clean, len(per_frame)))
        fh.write("per species mean: %s\n" % {k: round(v[0] / v[1], 4)
                                             for k, v in sorted(per_sp.items())})
        if gone:
            fh.write("MISSING-BLOCK cases: %s\n" % (gone[:40],))
            if ex_n:
                fh.write("with just those cells dropped: MEAN %.4f site over %d comparisons; "
                         "per species %s\n"
                         % (ex_tot / ex_n, int(ex_n),
                            {k: round(v[0] / v[1], 4) for k, v in sorted(ex_sp.items())}))
        fh.write("\nper-frame mean / worst peak-matching error (site):\n")
        for f in sorted(per_frame):
            mu, wo = per_frame[f]
            fh.write("   f%03d  mean %.3f  worst %.3f  %s\n" % (f, mu, wo, "#" * int(round(wo * 40))))
    print("\nwrote %s" % a.out)


if __name__ == "__main__":
    main()
