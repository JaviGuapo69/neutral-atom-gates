﻿"""aom_where.py -- where does the candidate book's AOM count peak, and which moves are over the 0.10 guideline"""
import json, sys, os
sys.path.insert(0, os.path.join('..', '.claude', 'skills', 'se-cycle-blocks', 'tools'))
import sb_compose
mv = json.load(open('moves_full.json', encoding='utf-8'))
ex = json.load(open('extra.json', encoding='utf-8'))
rows = sb_compose.schedule_rows(mv['moves'])


def pc(s):
    out = []
    for tok in str(s).replace(' ', '').split(','):
        if ':' in tok:
            a, b = tok.split(':'); out += list(range(int(a), int(b) + 1))
        elif tok:
            out.append(int(tok))
    return out


xr = [dict(mi='x', mv=None, tag=e['event'], t0=float(e['t_start']), t1=float(e['t_finish']), xs=pc(e['x_start']),
           xf=pc(e['x_finish']), ys=pc(e['y_start']), yf=pc(e['y_finish'])) for e in ex]
ng, peak = sb_compose.allocate_aom(rows + xr)
print('AOM groups', ng, 'peak', peak)
allr = rows + xr
edges = sorted({r['t0'] for r in allr} | {r['t1'] for r in allr})
dt = 0.03854166666666667
seen = set()
for i in range(len(edges) - 1):
    mid = (edges[i] + edges[i + 1]) / 2
    live = [r for r in allr if r['t0'] < mid < r['t1']]
    k = len({r['aom'] for r in live})
    if k >= 5:
        key = tuple(sorted((str(r['mi']), r['tag']) for r in live))
        if key in seen:
            continue
        seen.add(key)
        print('t %.4f (f%.1f): %d groups' % (mid, mid / dt, k))
        for r in live:
            m = r['mv']
            lab = ('%s %s f%03d-%03d' % ('+'.join(m['joins']), m['axis'], m['f0'], m['f1'])) if m else ('extra ' + r['tag'])
            print('    aom%d  %-28s x %s->%s y %s->%s' % (r['aom'], lab, (r['xs'][0], r['xs'][-1]), (r['xf'][0], r['xf'][-1]),
                                                        (r['ys'][0], r['ys'][-1]), (r['yf'][0], r['yf'][-1])))
print()
print('moves over 0.10 in the candidate book:')


def rg(a):
    a = list(a)
    return '%d:%d' % (a[0], a[-1]) if len(a) > 1 and a == list(range(a[0], a[-1] + 1)) else ','.join(map(str, a))


for m in mv['moves']:
    if m['mean'] is not None and m['mean'] > 0.10:
        parts = ' | '.join('%s->%s' % (rg(a), rg(b)) for a, b in m['parts'])
        origin = ('HAND s31' if 'session 31' in str(m.get('how')) else 'sub-comb' if m.get('sub_comb_lines') else
                  'S2.1' if 'S2.1' in str(m.get('how')) else 'last resort' if 'LAST-RESORT' in str(m.get('how')) else '')
        print('  %-8s %-4s f%03d-%03d t %.3f-%.3f  comb %-8s %-40s mean %.4f free %-6s %s'
              % ('+'.join(m['joins']), m['axis'], m['f0'], m['f1'], m['t0'], m['t1'], rg(m['sub_comb_lines']) if m.get('sub_comb_lines') else rg(m['comb']),
                 parts[:40], m['mean'], m.get('free_err', ''), origin))

