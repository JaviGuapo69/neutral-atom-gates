"""se_score.py -- THE acceptance test: a workbook against the movie itself, at every frame.

`se_compare.py` renders a workbook to PNGs, extracts those, and compares the two at HELD frames.
That is a true end-to-end test but it is slow and it only ever looks at the handful of frames where
the whole array happens to be at rest -- 22 of c540's 384.  A workbook can pass it and still be
visibly wrong in motion, which is precisely the failure mode the handover warns about.

This compares the workbook's SIMULATED atom positions against the movie's DETECTED marker positions
at every one of the 384 frames, matching species by species with the Hungarian assignment.  No
rendering, no second extraction, and nothing is averaged over frames the test declined to look at.

Two things it deliberately does:

  * ON SCREEN ONLY.  An atom the workbook puts outside the panel cannot be checked, because the
    movie does not draw it.  Where a block goes after it leaves is not a defect.
  * MID-MOVE MARKER LOSS IS NOT A DEFECT.  While a dense block translates, adjacent markers merge
    and the detector legitimately reports fewer of them than there are atoms -- c540 drops from 432
    to 297 in the middle of move 2.  So an unmatched PREDICTION is only counted when the movie has
    a marker of that species going spare; the headline number is the position error of the atoms
    that did match, plus the count of markers the workbook cannot explain at all.

Read `matched-atom RMS` first.  Under about 0.1 site the schedule is following the movie; a tenth
of a site is a couple of pixels.
"""
import argparse, collections, csv, json, os, sys
import numpy as np
from scipy.optimize import linear_sum_assignment

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import se_sim


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", required=True)
    ap.add_argument("--calib", required=True, help="se_calib.py JSON for the movie")
    ap.add_argument("--marks", required=True, help="se_extract.py markers for the movie")
    ap.add_argument("--tol", type=float, default=0.30,
                    help="how near, in data sites, a prediction must be to count as that marker")
    ap.add_argument("--label", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--worst", type=int, default=12)
    args = ap.parse_args()

    K = json.load(open(args.calib, encoding="utf-8"))
    NF = K["n_frames"]
    S = se_sim.from_workbook(args.xlsx)
    D = S._const("tone_divisor", 1) or 1

    def to_data(v):
        return (v - 1.0) / D + 1.0

    # the movie's own visible window, in data sites -- the region where a comparison means anything
    vc, vr = K["visible_col"], K["visible_row"]

    def visible(x, y):
        return vc[0] - 0.45 <= x <= vc[1] + 0.45 and vr[0] - 0.45 <= y <= vr[1] + 0.45

    # Keyed by (species, state).  Matching must be state-aware or it is nonsense: the movie draws
    # the reservoir stock FADED from frame 0, while every workbook -- the hand-written one included
    # -- only brings that stock into existence at the load, some 150 frames later (handover 4.3;
    # the stock is inert until then, so nothing about the cycle is wrong).  Pooling states makes
    # the assignment pair live atoms in the bottom-left of the array against faded stock markers in
    # the top-right, twenty sites away, and the RMS is then dominated by an artefact of the model
    # rather than by anything the schedule got wrong.
    obs = [collections.defaultdict(list) for _ in range(NF)]
    with open(args.marks, encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            obs[int(r["frame"])][(r["species"], r["state"])].append((float(r["x"]), float(r["y"])))

    rows = []
    all_err = []
    tot_unexpl = 0
    for f in range(min(NF, S.n_frames)):
        pred = collections.defaultdict(list)
        for sp, x, y, faded in S.frame(f, onscreen_only=False):
            dx, dy = to_data(x), to_data(y)
            if visible(dx, dy):
                pred[(sp, "faded" if faded else "solid")].append((dx, dy))
        errs, matched, unexpl, unexpl_faded = [], 0, 0, 0
        nobs = 0
        for sp in set(pred) | set(obs[f]):
            P = pred.get(sp, []); O = [p for p in obs[f].get(sp, []) if visible(*p)]
            nobs += len(O)
            if not P or not O:
                if sp[1] == "faded":
                    unexpl_faded += len(O)
                else:
                    unexpl += len(O)
                continue
            A = np.array(P); B = np.array(O)
            C = np.sqrt(((A[:, None, :] - B[None, :, :]) ** 2).sum(axis=2))
            n = max(len(A), len(B))
            big = np.full((n, n), 1e6)
            big[:len(A), :len(B)] = C
            ri, ci = linear_sum_assignment(big)
            # Every assigned pair counts, with NO tolerance cut.  Thresholding first made the score
            # lie: on a frame where the schedule is a whole site out, nothing passed the threshold,
            # the error list came out empty and the frame scored a perfect RMS of 0.
            for r0, c0 in zip(ri, ci):
                if r0 < len(A) and c0 < len(B):
                    errs.append(float(C[r0, c0])); matched += 1
            # a marker with no prediction at all is unexplained; a prediction with no marker is not
            # counted, because mid-move the detector merges neighbours and legitimately loses some
            if sp[1] == "faded":
                unexpl_faded += max(0, len(O) - len(A))
            else:
                unexpl += max(0, len(O) - len(A))
        all_err.extend(errs)
        tot_unexpl += unexpl
        rows.append(dict(frame=f, predicted=sum(len(v) for v in pred.values()),
                         observed=nobs, matched=matched, unexplained=unexpl,
                         unexplained_faded=unexpl_faded,
                         rms=round(float(np.sqrt(np.mean(np.square(errs)))) if errs else 0.0, 4),
                         worst=round(max(errs) if errs else 0.0, 4)))

    e = np.array(all_err) if all_err else np.zeros(1)
    lab = args.label or os.path.basename(args.xlsx)
    print("=" * 74)
    print("%s   vs the movie, all %d frames" % (lab, len(rows)))
    print("=" * 74)
    print("atoms paired to markers  : %d" % len(all_err))
    print("PAIRED-ATOM RMS          : %.4f data sites   (median %.4f, p95 %.4f, worst %.4f)"
          % (float(np.sqrt(np.mean(e ** 2))), float(np.median(e)),
             float(np.percentile(e, 95)), float(e.max())))
    print("   within 0.15 site      : %.2f%% of atom-frames" % (100.0 * float((e <= 0.15).mean())))
    print("   within 0.50 site      : %.2f%% of atom-frames" % (100.0 * float((e <= 0.50).mean())))
    tf = sum(r["unexplained_faded"] for r in rows)
    print("solid markers unexplained: %d total, %.1f per frame"
          % (tot_unexpl, tot_unexpl / max(1, len(rows))))
    print("faded markers unexplained: %d total, %.1f per frame   (reservoir stock the workbook "
          "does not model until it loads it -- inert, see handover 4.3)"
          % (tf, tf / max(1, len(rows))))
    clean = sum(1 for r in rows if r["unexplained"] == 0 and r["worst"] <= 0.15)
    print("frames fully explained   : %d / %d   (every solid marker paired, worst atom within "
          "0.15 site)" % (clean, len(rows)))
    print("\nworst frames:")
    print("   frame  predicted  observed  matched  unexpl  faded    rms   worst")
    for r in sorted(rows, key=lambda r: -(r["unexplained"] * 10 + r["worst"]))[:args.worst]:
        print("   %5d %10d %9d %8d %7d %6d  %6.3f  %6.3f"
              % (r["frame"], r["predicted"], r["observed"], r["matched"],
                 r["unexplained"], r["unexplained_faded"], r["rms"], r["worst"]))
    if args.out:
        with open(args.out, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, list(rows[0].keys()))
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print("wrote %s" % args.out)


if __name__ == "__main__":
    main()
