"""se_diffwb.py -- compare two schedule workbooks by what they DO, not by how they are written.

The division of a batch into rows is not unique and the move/slot columns carry no meaning, so a
row-by-row diff of two workbooks says almost nothing.  This walks both sheets with the renderer's
own semantics -- rows grouped by t_start into batches, each batch evaluated against the state
before it, atoms picked up by position and not by species -- and reports, per frame, which traps
the two disagree about.

That is the only comparison that means anything: if it reports no differences, the two workbooks
render identically and are the same schedule however differently they are laid out.
"""
import argparse, collections
import openpyxl


def split_elements(cell):
    txt = str(cell or "").replace(" ", "")
    out = []
    for tok in txt.split(","):
        if not tok:
            continue
        if ":" in tok:
            a, b = tok.split(":")
            out.extend(range(int(a), int(b) + 1))
        else:
            out.append(int(tok))
    return out


def smoothstep(u):
    u = min(1.0, max(0.0, u))
    return 10 * u ** 3 - 15 * u ** 4 + 6 * u ** 5


def sheets(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    out = {}
    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        hdr = [str(h) if h is not None else "" for h in rows[0]]
        out[ws.title] = [dict(zip(hdr, r)) for r in rows[1:]]
    return out


def simulate(path):
    sh = sheets(path)
    K = {str(r["key"]): r["value"] for r in sh["Constants"] if r.get("key")}
    nfr = int(float(K["frames"]))
    dt = float(K["dt_ms"])
    atoms = []                                   # (species, x, y, born, dies)
    for r in sh["Seed"]:
        if not r.get("species"):
            continue
        for x in split_elements(r["x_tones"]):
            for y in split_elements(r["y_tones"]):
                atoms.append(dict(sp=str(r["species"]), x=float(x), y=float(y),
                                  bx=float(x), by=float(y), born=0.0, dies=float("inf"),
                                  moves=[]))
    parsed = []
    for r in sh["Schedule"]:
        if r.get("t_start") is None or r.get("t_start") == "":
            continue
        ev = str(r.get("event") or "move")
        sx = split_elements(r["x_start"]); fx = split_elements(r["x_finish"])
        sy = split_elements(r["y_start"]); fy = split_elements(r["y_finish"])
        if len(sx) != len(fx) or len(sy) != len(fy):
            continue
        parsed.append(dict(ev=ev, sp=str(r.get("species") or ""),
                           t0=float(r["t_start"]), t1=float(r["t_finish"]),
                           xm=dict(zip(sx, fx)), ym=dict(zip(sy, fy)), fx=fx, fy=fy))
    for t0, batch in sorted(collections.Counter(p["t0"] for p in parsed).items()):
        pass
    for t0 in sorted(set(p["t0"] for p in parsed)):
        born, retire = [], []
        for p in [q for q in parsed if q["t0"] == t0]:
            if p["ev"] == "load":
                for x in p["fx"]:
                    for y in p["fy"]:
                        born.append(dict(sp=p["sp"], x=float(x), y=float(y), bx=float(x),
                                         by=float(y), born=p["t0"], dies=float("inf"), moves=[]))
                continue
            for a in atoms:
                if a["dies"] < float("inf"):
                    continue
                ix, iy = int(round(a["x"])), int(round(a["y"]))
                if ix in p["xm"] and iy in p["ym"]:
                    a["moves"].append((p["t0"], p["t1"], a["x"], a["y"],
                                       float(p["xm"][ix]), float(p["ym"][iy])))
                    a["x"], a["y"] = float(p["xm"][ix]), float(p["ym"][iy])
                    if p["ev"] == "unload":
                        retire.append((a, p["t0"], p["t1"]))
        for a, ta, tb in retire:
            a["dies"] = tb
        atoms.extend(born)

    per = []
    for f in range(nfr):
        t = f * dt
        cfg = {}
        for a in atoms:
            if t < a["born"] or t >= a["dies"]:
                continue
            x, y = a["bx"], a["by"]
            for (t0, t1, x0, y0, x1, y1) in a["moves"]:
                if t >= t1:
                    x, y = x1, y1
                elif t >= t0:
                    s = smoothstep((t - t0) / (t1 - t0)) if t1 > t0 else 1.0
                    x = x0 + (x1 - x0) * s
                    y = y0 + (y1 - y0) * s
                    break
            if abs(x - round(x)) < 0.02 and abs(y - round(y)) < 0.02:
                cfg[(int(round(x)), int(round(y)))] = a["sp"]
            else:
                cfg[("flight", round(x, 2), round(y, 2))] = a["sp"]
        per.append(cfg)
    return per, nfr, dt, len(atoms)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True, help="reference workbook")
    ap.add_argument("--b", required=True, help="workbook to compare")
    ap.add_argument("--label-a", default="A")
    ap.add_argument("--label-b", default="B")
    args = ap.parse_args()

    A, nfa, dta, na = simulate(args.a)
    B, nfb, dtb, nb = simulate(args.b)
    print("%-22s %d frames, dt %.6f, %d atoms ever alive" % (args.label_a, nfa, dta, na))
    print("%-22s %d frames, dt %.6f, %d atoms ever alive" % (args.label_b, nfb, dtb, nb))
    n = min(nfa, nfb)

    same = 0
    rest_same = rest_tot = 0
    worst = []
    for f in range(n):
        a = {k: v for k, v in A[f].items() if k[0] != "flight"}
        b = {k: v for k, v in B[f].items() if k[0] != "flight"}
        af = sum(1 for k in A[f] if k[0] == "flight")
        bf = sum(1 for k in B[f] if k[0] == "flight")
        miss = [k for k in a if k not in b]
        phan = [k for k in b if k not in a]
        wrong = [k for k in a if k in b and a[k] != b[k]]
        if not miss and not phan and not wrong and af == bf:
            same += 1
        if af == 0:                       # a frame where the reference holds still
            rest_tot += 1
            if not miss and not phan and not wrong:
                rest_same += 1
        worst.append((len(miss) + len(phan) + len(wrong), f, len(miss), len(phan), len(wrong)))
    print("\nframes identical                    : %d / %d" % (same, n))
    print("frames where %-10s is at rest : %d, of which identical: %d"
          % (args.label_a, rest_tot, rest_same))
    print("\nworst frames (missing = in %s not %s, phantom = the reverse):" % (args.label_a, args.label_b))
    for tot, f, m, p, w in sorted(worst, reverse=True)[:14]:
        print("   frame %3d  missing %3d  phantom %3d  mislabelled %3d" % (f, m, p, w))
    first = next((f for tot, f, m, p, w in sorted(worst, key=lambda t: t[1]) if tot), None)
    if first is not None:
        print("\nfirst frame that differs at all: %d" % first)


if __name__ == "__main__":
    main()
