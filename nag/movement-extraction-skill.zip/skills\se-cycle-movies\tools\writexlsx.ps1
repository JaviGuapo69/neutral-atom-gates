<#
  writexlsx.ps1 -- minimal multi-sheet .xlsx writer.

  Dot-source this, then:
      Write-Xlsx -Path out.xlsx -Sheets @( @{ name='S1'; rows=@( @('a',1), @('b',2) ) } )

  Values that are [double]/[int] are written as numbers; everything else as an inline string, so
  no sharedStrings part is needed.

  Two OOXML traps the handover records are avoided here: zip entries are created explicitly with
  forward slashes (ZipFile::CreateFromDirectory writes backslashes, which is invalid OOXML), and
  [Content_Types].xml is never touched through a wildcard-expanding cmdlet.
#>
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function ColName([int]$i) {   # 1 -> A
  $s = ''
  while ($i -gt 0) { $m = ($i - 1) % 26; $s = [char](65 + $m) + $s; $i = [int](($i - 1) / 26) }
  return $s
}
function Esc([string]$t) {
  return ($t -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;')
}

function Write-Xlsx {
  param([Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][object[]]$Sheets)

  $cul = [System.Globalization.CultureInfo]::InvariantCulture
  if ([System.IO.Path]::IsPathRooted($Path)) { $full = $Path }
  else { $full = [System.IO.Path]::GetFullPath((Join-Path (Get-Location).Path $Path)) }
  $fs = [System.IO.File]::Open($full, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
  $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Create)

  function AddEntry($name, $text) {
    $e = $zip.CreateEntry($name, [System.IO.Compression.CompressionLevel]::Optimal)
    $w = New-Object System.IO.StreamWriter($e.Open(), (New-Object System.Text.UTF8Encoding($false)))
    $w.Write($text); $w.Flush(); $w.Dispose()
  }

  $n = $Sheets.Count
  $ov = ''
  for ($i = 1; $i -le $n; $i++) {
    $ov += "<Override PartName=""/xl/worksheets/sheet$i.xml"" ContentType=""application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml""/>"
  }
  AddEntry '[Content_Types].xml' (@"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>$ov</Types>
"@)

  AddEntry '_rels/.rels' @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>
"@

  $sh = ''; $rel = ''
  for ($i = 1; $i -le $n; $i++) {
    $nm = Esc $Sheets[$i-1].name
    $sh  += "<sheet name=""$nm"" sheetId=""$i"" r:id=""rId$i""/>"
    $rel += "<Relationship Id=""rId$i"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"" Target=""worksheets/sheet$i.xml""/>"
  }
  AddEntry 'xl/workbook.xml' @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>$sh</sheets></workbook>
"@
  AddEntry 'xl/_rels/workbook.xml.rels' @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$rel</Relationships>
"@

  for ($i = 1; $i -le $n; $i++) {
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
    [void]$sb.Append('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>')
    $r = 0
    foreach ($row in $Sheets[$i-1].rows) {
      $r++
      [void]$sb.Append("<row r=""$r"">")
      $c = 0
      foreach ($v in $row) {
        $c++
        if ($null -eq $v -or "$v" -eq '') { continue }
        $ref = (ColName $c) + $r
        if ($v -is [double] -or $v -is [int] -or $v -is [long] -or $v -is [decimal]) {
          $num = ([double]$v).ToString('0.############', $cul)
          [void]$sb.Append("<c r=""$ref""><v>$num</v></c>")
        } else {
          [void]$sb.Append("<c r=""$ref"" t=""inlineStr""><is><t xml:space=""preserve"">" + (Esc "$v") + "</t></is></c>")
        }
      }
      [void]$sb.Append('</row>')
    }
    [void]$sb.Append('</sheetData></worksheet>')
    AddEntry "xl/worksheets/sheet$i.xml" $sb.ToString()
  }

  $zip.Dispose(); $fs.Dispose()
}
