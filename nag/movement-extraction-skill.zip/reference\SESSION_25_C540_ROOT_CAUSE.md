# Session 25 (2026-09-15) — why the PRODUCTION skill fails on c540, and a minimal repair tested

**Written for: the user (Javier), returning after an hour away.** Starting point, as instructed:
`.claude/skills/se-cycle-blocks/` exactly as it stands — the reset target that reproduces c150
55/55 and c300 64/64 (with `--events`). Not the test fork, not the archive. Everything below is
about THAT code and the book it produced for c540 (`run_c540/c540_full_blocks.xlsx`,
`run_c540/sbfull_final.log`, session 16).

Sections 1–3 are the analysis. Section 4 is the experiment run this session. Section 5 is what
was done to the folder. Section 6 is what I would do next and the questions still open.

---

## 1. What the production skill produces on c540, in one table

| | production book (session 16) | hand book (Shayne) |
|---|---|---|
| moves | 78 | 53 non-gate events (≈97 displacement rows) |
| undetermined | 7 | — |
| segments whose net permutation agrees (`cmp_struct`) | **17 of 41** | — |
| moves over the 0.10 guideline | 40 of 78 | — |
| cycle closes on the seed | **no** | yes |

So more than half the segments carry at least one wrong or missing movement, and the score,
`sb_audit`, the census and render validation are all quiet about it (rule 27).

---

## 2. The mechanisms, mapped to the production code

The session-17 report `c540_faults_vs_shayne.md` listed the symptoms. Here each one is tied to
the line of code that produces it and to why c150/c200/c300 never trigger it.

### 2.1 "One tone short" — 13 wrong maps, the largest fault

**Symptom.** A cyclic rotation of a contiguous run is written with one end tone left static and
the rest shifted one less. `X0 cols f002-010` comes out `2:8→6:12 | 9:12→2:5` (col 1 static)
where the movie and hand book do `1:7→6:12 | 8:12→1:5`. The production log prints it with
`mean 0.1786 OVER 0.10`, so the route itself knew it had not explained the pixels.

**Code path.** `sb_build.build()` → the appearance route (`partition`, line ~1576) →
`complete_partition` (line ~764) → `emit` (line ~1585), and it **commits without competing**:
the measured-displacement route at line ~1592 runs only `if not done`.

1. `partition_on` reads each outline colour's class with `sb_rigid.rigid_displacement`. In a
   12-tone rotation the wrap marker travels 5–7 sites in 6–8 frames, so on the very first moving
   frame it is already within `MERGE_SEP` of its neighbour: its class is rejected (`NOT RIGID` or
   rule 24's modal-count test — both appear in the segment-0 notes) and the surviving class covers
   the run one short.
2. `complete_partition` then supplies the missing tone by the complement rule `B = S \ A`, which
   pairs it with itself — a legal static sub-block. Every guard in `emit` passes: the map covers the
   block, it is a bijection, `MIN_SPAN` is met.
3. `verify`'s mean is diluted in the tone dimension (rule 31): the static tone agrees with the wrong
   map on every frame by construction, so the wrong map scores 0.2432 against the right map's
   0.2126 — a difference inside crossing noise. **The right map was never generated, so scoring
   never got to choose.**

**Why not on c150/c300.** Their rotations move at most 3–4 sites per move over 8–15 frames, so the
outline classes stay resolved through the first moving frames and the appearance read covers the
whole run. c540 is pipelined: the same rotation is done in half the frames.

### 2.2 Ten movements never enumerated at all — the sub-comb batches

**Symptom.** Nine of the hand book's moves on column pairs `{14,20} {15,21} {16,22} {17,23}
{18,24}` are absent from every list — moves, notes, undetermined. The tenth (`f348-355`, a
12-column rotation on `13:24 × 1:9`) is a six-frame same-site permutation lost to rest detection.

**Code path.** `sb_build.settled()` (line ~314) enumerates transitions from `sb_compose.rect_at`,
i.e. **whole-block occupancy per species**. A move of 2 of 12 columns leaves 10 columns on their
tones and the two moving columns' peaks merge into the static ones, so the block reads "at rest"
and no transition exists. Rule 40's `sub_comb` / `sub_window` (lines ~1113, ~1163) can only
re-derive the window of a transition that WAS enumerated. The batch drives one column coset over
all 27 rows, i.e. three species' bands; the per-species tell catches one band (usually the one
whose profile happened to resolve) and never looks at the other two — see the production log's
segment 6: `Z0 rows f206-214 comb 14,20` found, Z1's and X1's halves of the same batch not.

**Why not on c150/c300.** Their codes have two factors, one per block axis, so every batch drives a
block's full extent (`c540_v3_diagnosis.md` §1). `extend_comb` reading the comb off the rest
configuration is never wrong there.

### 2.3 A relocation composed with a rotation is structurally inexpressible

**Symptom.** `Z0/Z1 cols 13:24 → 1:12` at f315–328 is UNDETERMINED (both), and everything after
f328 is twelve columns out.

**Code path.** The hand-book map is `13:22→3:12 | 23:24→1:2`, i.e. per-tone displacements of −10
and −22. `uniform_displacement` requires one D. `measured_partition` → `_measured_from` enumerates
integer scales only up to `MAX_SPAN = 16` (line ~758): a part with |D| = 22 **cannot be
generated**. `rotation_candidates` requires `S == S2` (same-site) and so is silent on a
relocation. No candidate family reaches `translate + wrap`. (The v2 fork added exactly such a
family and it misfired on c300 — see §3.)

### 2.4 The same movement solved differently for two species — measurement luck at a threshold

**Symptom.** At f017–025 X0 and X1 do the same double swap. `X0 rows f017-025 13:15↔16:18` is
right (0.0903); `X1 rows f018-025 17:18→14:15 | 14:16→16:18` is wrong (0.1092, row 13 static).

**Code path.** `sb_compose.TOL_ONGRID = 0.14` decides whether f025 is a rest: X0's worst marker is
0.130 off (rest), X1's 0.160 (not a rest). X1's transition window therefore runs into the next
movement, the appearance read fails on that window, and the fallback route has less expressive
power than the appearance route (`SESSION_23_PATCH_ROUTE.md` §1). The hypothesis space collapses
silently; nothing reports it.

### 2.5 Phantom joins, duplicates, double-driven atoms

* `sb_compose.extend_comb` (line ~519) joins a second species when `verify` over ALL its peaks is
  under `max(0.10, 1.3 × best)` and `moves_on_axis` says it left its tones somewhere. Two
  rotations differing only in the wrap position pass this, so `X1+Z0 cols f002-010` shares one
  rectangle where the hand book has +5 and +6 (`c540_faults_vs_shayne.md` §2.3).
  `drop_conflicting_joins` (line ~1353) only fires when both species have their OWN move on that
  axis.
* Rule 14's `reconcile_bounded` reconciles boundaries within a species/axis chain but not across the
  chain of consecutive moves acting on the same atoms on different axes or under different species
  labels, so at f043/f067/f077 one atom is on two live rectangles and the AOM peak reads 6.

### 2.6 The unit mismatch that underlies 2.2, 2.4 and 2.5

The batch is one column coset × 27 rows × three species. The skill's unit is the species: windows
(`species_windows`), rests, transitions, partitions, timing fits and joins are all per species.
Every c540 failure is a consequence of that mismatch, and no amount of per-species patching makes
the batch visible to a per-species enumerator.

---

## 3. Why the previous repairs created new errors (so the same mistake is not made again)

| repair | what it fixed on c540 | what it broke | root of the breakage |
|---|---|---|---|
| v2 rules 41–47 (sessions 17–21) | 13 short maps, the f315 relocation | c300 `X0 cols f246-261` became a rotation by +1 (a plain translation) + 3 spurious transitions | the "relocation may carry a rotation" family fires on any relocation; the rule-43 propagation invents transitions |
| hybrid gap rules (session 23) | segment 6 19/19, segment 0 6/9→8/9 | c150 seg 8 got a map at mean 2.12 displacing a 0.045 one | a route that commits a gap-fill without scoring it |
| patch route windows | movements with no rest frame | c300 `X1 rows` windowed f293-308 where motion is f308-312 | a patch's first visible frame is the AOM RING appearing, not the motion starting |

The pattern in all three: a new candidate family or route added **without a gate that keeps it
silent where the old route was right**, verified on c540 and c150 only.

---

## 4. THE EXPERIMENT: the S2.1 competition on the production baseline

**Design.** Copy of production `sb_build.py` in the session scratchpad with ONE change inside
`build()`: after the appearance read is completed by the complement rule, measure which tones
actually leave their site (`moving_tones`: the worst over the moving frames of the distance from a
tone to the nearest peak; a tone is "moving" if no peak sits within 0.30 of it; off-panel tones are
skipped per rule 21). **If the appearance read holds none of those tones static, the production
code runs unchanged.** Only when it is CONTRADICTED does the appearance map compete against the
rotations of the measured moving run (and its convex hull) and the measured-displacement
candidates, ranked by `mean_moving`, the same statistic the measured route already uses.

This is the session-17 §2.1 idea (later ported to the test fork and switched off), but:

* built on the production code, with no `FIT_PAD`, no restructuring of the measured route;
* gated so that c150/c300 are untouched wherever the measurement confirms the appearance read;
* NO "relocation + rotation" family (the thing that broke c300 in v2);
* NO sub-comb propagation (the thing that made spurious transitions in v2).

**Regression run with the production `sb_full.py` (with `--events`) on all three movies in
parallel, compared move by move against the accepted books with the user's criterion (maps
identical, window may shift ≈1 frame).**

RESULTS — see section 4.1 below (filled in when the runs finished).

---

## 4.1 Results

### The closed movies: IDENTICAL

| movie | accepted book | S2.1 run | verdict (`cmp_tol.py`, maps identical, ≤1 frame window tolerance) |
|---|---|---|---|
| c150 | `reg_c150\fix\moves_full.json`, 55 moves | 55 moves, 0 undetermined, 73 transitions | **55/55 matched exactly — maps AND windows. The competition fired 0 times.** |
| c300 | `reg_c300_fix\moves_full.json`, 64 moves | 64 moves, 0 undetermined, 78 transitions | **64/64 matched exactly — maps AND windows. The competition fired 0 times.** |

So on the two movies that define "correct", the gate did what it was built to do: the appearance
read was never contradicted, so not one candidate was generated and the output is byte-for-byte the
production answer. (c200 was not run this session; it should be, but it is on the same route.)

### c540, segments 0–5 (frames 0–190), against the hand book — `run_c540_v3\cmp_full.py --t1 5.85`

| | production book | S2.1 variant |
|---|---|---|
| sheet movements matching the hand book on displacement + timing | 39 of 54 | **47 of 53** |
| hand-book events fully / partly / not accounted for (30 events) | 25 / 5 / 0 | **28 / 2 / 0** |
| hand-book displacement entries unaccounted (of 120) | 12 | **4** |

Every one of the nine maps that changed is a §2.1 "one tone short" case, and every one now reads
as the hand book has it:

| segment | production | S2.1 variant = hand book |
|---|---|---|
| f002-010 X0 cols | `2:8→6:12 \| 9:12→2:5` | **`1:7→6:12 \| 8:12→1:5`** |
| f002-010 X1 cols | `14:20→18:24 \| 21:24→14:17`, phantom join with Z0 | **`13:19→18:24 \| 20:24→13:17`**, X1 alone |
| f018-025 X1 rows | `17:18→14:15 \| 14:16→16:18` | **`13:15↔16:18`**, now one X0+X1 rectangle |
| f026-032 X0+X1 rows | 5-cycle on 10:14 | **8-cycle `10→17 \| 11:17→10:16`** |
| f044-050 X0 rows | `15:17→13:15 \| 13:14→16:17` | **`13:15↔16:18`**, one X0+X1 rectangle |
| f053-057 X0+X1 rows | 4-cycle on 13:16 | **`12:14↔15:17`** |
| f098-106 X0 / X1 / Z1 cols | 9 columns static, garbled | **rotate +6 / +6 / +7**, exactly Shayne's three maps |
| f108-114 Z1 rows | `22:24→24:26 \| 25:26→22:23` | **`21:23↔24:26`** |
| f140-146 X0 rows | `15→12 \| 12:14→13:15` | **`13:17→14:18 \| 18→13`** — the same map X1 has, as the hand book's gate layer pattern requires |

Two things got WORSE, and both are understood:

1. **`Z0 permutation f001-007` (the y 19:27 block's rotation by +6) is now UNDETERMINED.** In
   production it was hidden inside the phantom `X1+Z0` join with X1's wrong map, i.e. it was wrong
   but silent; now it is honestly reported. Z0 has no usable appearance read there, so the
   competition (which is triggered by a contradicted appearance read) never runs for it. A
   **last-resort variant** (`prod_s21r`: try the rotations of the measured moving run only after
   every route failed) recovers it as `13:18→19:24 | 19:24→13:18` at 0.0917 — the hand book's map —
   BUT it also fires on `X1 f023-026`, a transition production correctly treats as *carried by X0's
   rectangle*, and invents a 5-cycle for it at 0.0995. The "carried" test happens after the loop,
   so the last resort has to move there. Not shipped; documented in the fork's `SKILL.md`.
2. **`X0 rows f093-095`**: production rejected X0's own read (`MIN_SPAN`) and correctly carried X0
   on X1's rectangle (`1,4,6,8→2,5,7,9 | 2→1 | 5,7,9→4,6,8`, a hand-book MATCH). Ungated, the
   competition committed the best of a bad set — a rotation at **0.2193** on the moving frames —
   and X0 got its own wrong move. **Fixed with a gate**: a generated candidate replaces the
   production answer only if it meets the 0.10 guideline on the moving frames; otherwise the
   production path runs. Every genuine correction above scored 0.043–0.097, so the gate costs none
   of them. The gated code is what is in the fork; segment 2 was re-run with it to confirm (see 4.2).

Unchanged disagreements with the hand book in this range (production and variant alike):
`X0 rows f081-088` (the rows 5/6 question, `c540_faults_vs_shayne.md` §5.2), `X0+X1 rows
f104-114` and `f131-141` (timing/label only — the maps match), and `X0+X1 rows f152-154` (hand
book has +2 on rows 10,13,16; neither book has it right).

### 4.2 The whole movie — `run_c540_s25\c540_s25_blocks.xlsx` (also copied to the project root)

Segment 2 re-solved with the gate: `X0+X1 rows f093-095 1,4,6,8→2,5,7,9 | 2→1 | 5,7,9→4,6,8`
is back (the rejected candidate is logged: "scores 0.2193 ... NOT taken"), the rest of the segment
identical to the ungated run. Segments 6–11: the competition fired **0 times**, so they are
byte-for-byte the production answer — as expected, because those segments fail for the sub-comb
and relocation reasons of §2.2 and §2.3, not for short rotations. Merged (`tools/merge_halves.py`):

| | production book | **S25 book** |
|---|---|---|
| moves / undetermined | 78 / 7 | 76 / 8 (Z0 f001-007 now honest) |
| sheet movements matching the hand book on displacement + timing | 61 of 82 | **69 of 80** |
| hand-book events fully / partly / not accounted for (53) | 34 / 12 / 7 | **37 / 9 / 7** |
| hand-book displacement entries accounted (of 217) | 162 | **170** |
| against production (`cmp_tol`): identical / changed map / window shifts | — | 64 / **9 (all corrections)** / **0** |
| `se_sim` | check3 ×2 at f315-328 (the hole) | same 2, census conserved |
| `sb_audit` | fails on the f315-328 hole | **same 2 problems** (`Z0/Z1 relocation f315..f328 has no cols move`), 0 SILENT holes, 0 idle moves, 0 rest clashes over 87,696 claims |

The 7 hand-book events still "NOT AT ALL" accounted for are the same seven as production's: the
five column-pair sub-comb batches in f199–245 and f265–303 that occupancy never enumerates (§2.2),
and the two f315–336 relocations (§2.3). **This change repairs the appearance route's wrong answers;
it does not add the movements the enumerator never sees.** That is the next piece of work (§6).

Files: `run_c540_s25\` holds the inputs (copied from `run_c540_v3`), `moves_full.json`,
`rests_full.json`, the workbook, `s25_vs_shayne.txt`, `s25_vs_production.txt`, `audit_s25.txt`,
`sim_s25.txt`, the run logs (`logs\`, including both regressions and the last-resort test), and
`deliver_s25.ps1` which rendered, scored and cut the side-by-side videos.

**Render and video:** 384 frames rendered, 2 validation entries (the same `check3` pair at the
f315-328 hole). Profile score 0.2748 site raw, **0.0978 site with the hole's 67 cells dropped**
(X0 0.046, X1 0.051, Z0 0.101, Z1 0.200 — the Z species carry the twelve-column offset downstream
of f328). Rule 27 applies: this number is not evidence of correct movements; the hand-book
comparison above is. The videos `c540_s25_original_vs_rebuild_panels.mp4` and `_full.mp4` are in
`run_c540_s25\` and copied to the project root beside the c150/c200/c300 ones. **Watch the first
190 frames** — that is where the nine corrected maps are; after f190 the book is production's.
**c540 is NOT closed**: everything after f315 is still twelve columns out, and the sub-comb
batches of segments 6–7 are still missing.

---

## 5. Folder tidy-up and where the code is

* **New fork: `.claude/skills/se-cycle-blocks-s25/`** = production `se-cycle-blocks` (SKILL.md,
  RUN_TEST.md, every tool) with `tools/sb_build.py` replaced by the gated S2.1 variant, plus
  `tools/cmp_tol.py` (the comparator for the user's criterion) and `tools/merge_halves.py`. A
  SESSION 25 box at the top of its `SKILL.md` says exactly what differs. **Production is
  untouched.** The test fork is untouched.
* **Archive `..\SE_cycle_ARCHIVE_2026-09-15\`** (sibling of the project, beside the 09-08 one), with
  `ARCHIVE_MANIFEST_2026-09-15.md` naming every item and why. Moved, not deleted: the August
  se-cycle-movies era documents, the closed `SB_COMPOSE_BUG_*` files, the early c150 window tests,
  **the c540 v3 book and its videos (made by the archived v2 skill, wrong in 13 of 42 segments)**,
  all `c540_v2_*`, the session-16 `c540_vs_shayne*` comparison, and the directories `regh_c150`,
  `regh_c300`, `reg_c300` (the failing v2 regression), `reg_c300_parent`, `run_c540_v2`. The
  project root went from 55 files and 13 directories to 22 files and 8 directories.
* Memory notes updated: handover (read this file first), a new note on the S2.1 competition, the
  directory-cleanup note, and the index.

---

## 6. What next, and open questions

**In order of value, for c540:**

1. **Regress c200** with the fork (`reg_c200\` has calib, blocks, events, accepted book) — same
   route as c150/c300, ~10 min, and the closed-movie set should be complete before promotion.
2. **Move the last-resort rotation to after the "carried by another species' rectangle" test** and
   regress all three. It recovers Z0's f001-007 exactly; the ordering is the only defect.
3. **The sub-comb batches** (§2.2, 10 missing moves) — the part no per-species enumerator can see.
   The patch route measured them well on segment 6 (19/19, `run_c540_v3\SEG6_PATCH_REPORT.md`);
   the batch-level read (`c540_v3_diagnosis.md` §2: profile the detected column comb over the FULL
   lattice height, split into bands afterwards) is the principled version. Either way it must be
   gated the same way this session's change is: silent wherever whole-block occupancy already
   produced a transition.
4. **f315-328 `Z0/Z1 cols 13:24 → 1:12`**: raise `MAX_SPAN` from 16 to cover |D| = 22 and let
   `measured_partition` generate the two-part map; verify it does not fire on c300's relocations
   (that is the family that broke v2 — but here it is the *measured-displacement* route, whose
   candidates are pinned by the destination set, not an enumerated rotation).
5. **Speed**: the competition makes c540 ~3× slower because `fit_timing` sweeps the whole
   pulse-free interval per candidate. A transition-bounded search (`FIT_PAD` in the test fork) would
   fix it and must be regressed on its own.

**Questions for you:**

* Do you want the fork promoted to production once c200 also regresses identical, or kept as a
  separate skill until c540 is closed end to end?
* The gate accepts a generated candidate only under 0.10 on the moving frames. Do you want that bar
  tied to the appearance map's own score instead (e.g. "must beat it by 0.03") when the appearance
  map itself is over 0.10?
* Segment 2's `X0 rows f081-088` (rows 5 and 6) and `X0+X1 rows f152-154` disagree with the hand
  book in both books. Shall I adjudicate those two on the pixels next session?
