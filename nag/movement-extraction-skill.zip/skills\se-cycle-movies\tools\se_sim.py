"""se_sim.py -- an exact Python replica of render.ps1's schedule semantics.

This is the module every other stage measures itself against.  It is not a drawing tool: it answers
"where is every atom at frame f, and what did each row actually pick up", with the SAME rules the
proven renderer uses.  Composition uses it as its own conscience -- a row is only emitted once this
simulator agrees the row picks up exactly the atoms it claims -- which is what makes render.ps1's
`check3` zero by construction instead of something to chase.

The rules, transcribed from render.ps1 line by line:

  * A batch is every schedule row sharing one `t_start`, and batches run in `t_start` order.
  * Inside a batch, EVERY row is matched against the state BEFORE the batch: render.ps1 collects
    all the pick-ups first and only then writes the new positions.  Two rows in one batch therefore
    cannot chain, and a row that reaches for atoms another row in the same batch delivers picks up
    nothing.
  * A row matches an atom by POSITION ONLY -- `round(x)` in the row's x-map and `round(y)` in its
    y-map.  The `species` column is not consulted for `move` or `unload`; only `load` uses it.
  * `load` atoms are created AFTER the batch's moves are applied, so a load must be in a strictly
    earlier batch than the move that carries the batch in.
  * `unload` sets fadeFrom = t_start and dies = t_finish: the atoms still travel, drawn faded, and
    cease to exist at t_finish.
  * An atom's position at t: walk its motions in t_start order; a motion wholly in the past sets
    the position to its finish, the first motion containing t is interpolated and wins.

check1 / check3 / check4 are reported with render.ps1's own meanings so the two logs can be
compared directly.
"""
import collections
import openpyxl

INF = float("inf")


def split_elements(cell):
    """The guide's tone-list grammar: '1:3,5,9:11' -> [1,2,3,5,9,10,11]."""
    txt = str(cell if cell is not None else "").replace(" ", "")
    out = []
    for tok in txt.split(","):
        if not tok:
            continue
        if ":" in tok:
            a, b = tok.split(":")
            out.extend(range(int(a), int(b) + 1))
        else:
            out.append(int(tok))
    return out


def compact(vals):
    """The inverse: [1,2,3,5,6,9] -> '1:3,5:6,9'."""
    v = sorted(set(int(x) for x in vals))
    out, i = [], 0
    while i < len(v):
        j = i
        while j + 1 < len(v) and v[j + 1] == v[j] + 1:
            j += 1
        out.append(str(v[i]) if j == i else "%d:%d" % (v[i], v[j]))
        i = j + 1
    return ",".join(out)


def smoothstep(u):
    u = 0.0 if u < 0.0 else (1.0 if u > 1.0 else u)
    return 10 * u ** 3 - 15 * u ** 4 + 6 * u ** 5


def read_sheets(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    out = {}
    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            out[ws.title] = []
            continue
        hdr = [str(h) if h is not None else "" for h in rows[0]]
        out[ws.title] = [dict(zip(hdr, r)) for r in rows[1:]]
    return out


def rectangles(pts):
    """Split a point set into exact x-list x y-list rectangles.

    Rows sharing an identical x-set become one rectangle, so the Cartesian product it denotes is
    EXACTLY the point set -- never a superset.  That is what keeps a row from reaching for a trap
    whose atom belongs to a different motion.
    """
    byy = collections.defaultdict(set)
    for x, y in pts:
        byy[y].add(x)
    groups = collections.defaultdict(list)
    for y, xs in byy.items():
        groups[tuple(sorted(xs))].append(y)
    return [(list(xs), sorted(ys)) for xs, ys in groups.items()]


class Sim(object):
    """The simulated schedule.  `atoms` is the identity list; `log` mirrors render.ps1's."""

    def __init__(self, constants, seed_rows, sched_rows):
        self.K = {str(r["key"]): r["value"] for r in constants if r.get("key") not in (None, "")}
        self.n_frames = int(float(self.K["frames"]))
        self.dt = float(self.K["dt_ms"])
        self.ncol = int(float(self.K["lattice_cols"]))
        self.nrow = int(float(self.K["lattice_rows"]))
        self.vcmin = self._const("visible_col_min", 1)
        self.vcmax = self._const("visible_col_max", self.ncol)
        self.vrmin = self._const("visible_row_min", 1)
        self.vrmax = self._const("visible_row_max", self.nrow)
        self.log = []
        self.atoms = []                     # dicts: sp, bx, by, born, dies, fade, moves
        for r in seed_rows:
            if not r.get("species"):
                continue
            for x in split_elements(r["x_tones"]):
                for y in split_elements(r["y_tones"]):
                    self._new_atom(str(r["species"]), x, y, 0.0)
        self.rows = self._parse(sched_rows)
        self._run()

    def _const(self, key, dflt):
        v = self.K.get(key)
        if v is None or str(v) == "":
            return dflt
        return int(float(v))

    def _new_atom(self, sp, x, y, born):
        self.atoms.append(dict(sp=sp, bx=float(x), by=float(y), x=float(x), y=float(y),
                               born=float(born), dies=INF, fade=INF, moves=[]))
        return len(self.atoms) - 1

    def _parse(self, sched_rows):
        out = []
        for r in sched_rows:
            if r.get("t_start") is None or str(r.get("t_start")) == "":
                continue
            ev = str(r.get("event") or "move")
            sx = split_elements(r["x_start"]); fx = split_elements(r["x_finish"])
            sy = split_elements(r["y_start"]); fy = split_elements(r["y_finish"])
            tag = "move %s slot %s" % (r.get("move"), r.get("slot"))
            if len(sx) != len(fx):
                self.log.append(("check1", "%s: x tone counts differ" % tag))
                continue
            if len(sy) != len(fy):
                self.log.append(("check1", "%s: y tone counts differ" % tag))
                continue
            out.append(dict(move=r.get("move"), slot=r.get("slot"), ev=ev,
                            sp=str(r.get("species") or ""),
                            t0=float(r["t_start"]), t1=float(r["t_finish"]),
                            fx=fx, fy=fy, xm=dict(zip(sx, fx)), ym=dict(zip(sy, fy)),
                            want=len(sx) * len(sy), tag=tag))
        return out

    def _run(self):
        for t0 in sorted(set(p["t0"] for p in self.rows)):
            claim, moves, retire, born = {}, [], {}, []
            for p in [q for q in self.rows if q["t0"] == t0]:
                if p["ev"] == "load":
                    for x in p["fx"]:
                        for y in p["fy"]:
                            born.append((p["sp"], x, y, p["t0"]))
                    continue
                got = 0
                for k, a in enumerate(self.atoms):
                    if a["dies"] < INF:
                        continue
                    ix, iy = int(round(a["x"])), int(round(a["y"]))
                    if ix in p["xm"] and iy in p["ym"]:
                        if k in claim:
                            self.log.append(("check4", "t=%s %s: atom (%d,%d) already claimed by %s"
                                             % (t0, p["tag"], ix, iy, claim[k])))
                        claim[k] = p["tag"]
                        moves.append((k, p["t0"], p["t1"], float(ix), float(iy),
                                      float(p["xm"][ix]), float(p["ym"][iy])))
                        if p["ev"] == "unload":
                            retire[k] = p
                        got += 1
                if got != p["want"]:
                    self.log.append(("check3", "%s t=%s: picked up %d of %d sites"
                                     % (p["tag"], t0, got, p["want"])))
            for k, ta, tb, x0, y0, x1, y1 in moves:
                self.atoms[k]["moves"].append((ta, tb, x0, y0, x1, y1))
                self.atoms[k]["x"], self.atoms[k]["y"] = x1, y1
            for k, p in retire.items():
                self.atoms[k]["fade"] = p["t0"]
                self.atoms[k]["dies"] = p["t1"]
            for sp, x, y, tb in born:
                self._new_atom(sp, x, y, tb)
        for a in self.atoms:
            a["moves"].sort(key=lambda m: m[0])

    # ------------------------------------------------------------------ queries
    def position(self, a, t):
        x, y = a["bx"], a["by"]
        for (t0, t1, x0, y0, x1, y1) in a["moves"]:
            if t >= t1:
                x, y = x1, y1
            elif t >= t0:
                if t1 <= t0:
                    x, y = x1, y1
                else:
                    s = smoothstep((t - t0) / (t1 - t0))
                    x = x0 + (x1 - x0) * s
                    y = y0 + (y1 - y0) * s
                break
        return x, y

    def on_screen(self, x, y):
        return (self.vcmin - 0.4 <= x <= self.vcmax + 0.4
                and self.vrmin - 0.4 <= y <= self.vrmax + 0.4)

    def frame(self, f, onscreen_only=True):
        """[(species, x, y, faded)] for one frame, in the renderer's own draw order."""
        t = f * self.dt
        out = []
        for a in self.atoms:
            if t < a["born"] or t >= a["dies"]:
                continue
            x, y = self.position(a, t)
            if onscreen_only and not self.on_screen(x, y):
                continue
            out.append((a["sp"], x, y, t >= a["fade"]))
        return out

    def state_at(self, t):
        """trap -> (atom index, species) for every atom standing still on a whole tone at t."""
        st = {}
        for k, a in enumerate(self.atoms):
            if t < a["born"] or t >= a["dies"]:
                continue
            x, y = self.position(a, t)
            if abs(x - round(x)) < 1e-6 and abs(y - round(y)) < 1e-6:
                st[(int(round(x)), int(round(y)))] = (k, a["sp"])
        return st

    def counts(self):
        return collections.Counter(kind for kind, _ in self.log)

    def census(self, tol_frames=4):
        """How many atoms are alive at each frame, against the seed count.

        THE CHEAPEST CHECK THAT CATCHES THE EXPENSIVE MISTAKE.  A cycle measures a species and
        replaces it, so the live population returns to the seed count after every readout.  If it
        does not, either a readout retired fewer atoms than the block holds or a fresh batch was
        created too small -- and BOTH are invisible to a score against the movie, because the
        atoms involved are off screen at the moment they go missing.

        That is exactly how c540's v11 lost 51 of its 432: the fresh batches were sized from the
        one or two reservoir columns the panel actually shows (25:35 for 25:36, -6:0 for -8:0) and
        a readout retired only the single visible column of a block parked off panel.  Nothing
        flagged it.  The workbook rendered clean, and simply ran the last third of the cycle with
        holes in every block.

        A DEFICIT is the defect: atoms that should exist do not.  A SURPLUS is not -- a block being
        read out is still travelling, drawn faded, and stays alive until its `t_finish`, so it
        legitimately coexists with the fresh batch that replaces it for the length of that
        descent.  The two are reported separately; only the deficit means something is wrong.

        Returns (seed_count, deficit_frames, surplus_frames), each a list of (frame, alive).
        """
        seed = sum(1 for a in self.atoms if a["born"] == 0.0)
        short, over = [], []
        for f in range(self.n_frames):
            t = f * self.dt
            alive = sum(1 for a in self.atoms if a["born"] <= t < a["dies"])
            if alive < seed:
                short.append((f, alive))
            elif alive > seed:
                over.append((f, alive))
        return seed, short, over


def from_workbook(path):
    sh = read_sheets(path)
    for need in ("Constants", "Seed", "Schedule", "Gates"):
        if need not in sh:
            raise SystemExit("%s has no sheet named %s" % (path, need))
    return Sim(sh["Constants"], sh["Seed"], sh["Schedule"])


def from_csvs(constants, seed, schedule):
    """The same, from the in-memory row dicts the composer builds, so it can check itself."""
    return Sim(constants, seed, schedule)


if __name__ == "__main__":
    import sys
    for p in sys.argv[1:]:
        s = from_workbook(p)
        print("%-58s %d atoms ever alive, %d rows, %d motions"
              % (p, len(s.atoms), len(s.rows), sum(len(a["moves"]) for a in s.atoms)))
        c = s.counts()
        print("   validation: %s" % (dict(c) if c else "clean"))
        for kind, detail in s.log[:12]:
            print("      %-7s %s" % (kind, detail))
        seed, short, over = s.census()
        if short:
            lo = min(n for _, n in short)
            print("   CENSUS FAILED: seeded %d, but %d frames are SHORT (worst %d, %d missing), "
                  "frames %d..%d" % (seed, len(short), lo, seed - lo, short[0][0], short[-1][0]))
            print("      a readout retired fewer atoms than its block holds, or a fresh batch was"
                  " created too small.  Both are off screen and invisible to a score.")
        else:
            print("   census: never short of %d atoms -- conserved across every readout" % seed)
        if over:
            print("   (%d frames carry extra atoms, max %d -- a block still descending while its "
                  "replacement exists; expected)" % (len(over), max(n for _, n in over)))
