"""Montage the movie's HEADER STRIP for a range of frames, so you can read the text.

Step 1 of the procedure requires you to verify `calib.json`'s `gate_frames` against the movie's
own header, frame by frame -- se_calib derives them from the gate TINT, and a movie can have
1-frame gate runs that are easy to miss and that are exactly what pins the "no move crosses a
pulse" bound.  Nothing else in the toolkit crops the header.

Run from the movie's run folder (the one holding `frames/`):

    python hdr.py 325 332                 # frames 325..332, header strip, 2x
    python hdr.py 0 5 --out t.png         # different output file
    python hdr.py 325 332 --width 900     # wider crop, if the header text is long
    python hdr.py 325 332 --height 30 --scale 3

Then open the .png (or Read it, if you are an agent).  The header of a mitten_codes movie reads

    t 6.17/7.22 ms . phase 2 X:D5 || Z:D1-4 . global pulse

and it may carry one or BOTH of these trailing tokens:

    global pulse    a Rydberg pulse fires on this frame -- this is a GATE FRAME
    reset           the phase flips here.  An ordinary frame can carry it (c300 f329), and so can
                    a gate frame (c300 f383 reads "global pulse . reset").  It says nothing about
                    whether a pulse fired

So the gate-frame test is the presence of `global pulse`, and nothing else.  Check that the set of
frames whose header says `global pulse` is exactly `calib.json`'s `gate_frames`.  If it is not,
stop -- every downstream timing will be wrong.

Watch for 1-frame gate runs.  Most runs are 2 frames (4 on a 2-AOD movie), but c300 has two runs
of a single frame, at f328 and f383, and they are the ones that pin the pulse bound.
"""
import argparse
import os
from PIL import Image

ap = argparse.ArgumentParser()
ap.add_argument("f0", type=int, help="first frame")
ap.add_argument("f1", type=int, help="last frame (inclusive)")
ap.add_argument("--frames", default="frames", help="frame directory (default: frames)")
ap.add_argument("--width", type=int, default=640, help="crop width in px (default: 640)")
ap.add_argument("--height", type=int, default=30, help="crop height in px (default: 30)")
ap.add_argument("--scale", type=int, default=2, help="upscale factor (default: 2)")
ap.add_argument("--out", default="hdr.png")
a = ap.parse_args()

crops = []
for f in range(a.f0, a.f1 + 1):
    p = os.path.join(a.frames, "p_%03d.png" % f)
    if not os.path.exists(p):
        raise SystemExit("missing %s" % p)
    crops.append((f, Image.open(p).crop((0, 0, a.width, a.height))))

w = max(c.width for _, c in crops)
h = sum(c.height + 2 for _, c in crops)
out = Image.new("RGB", (w, h), "white")
y = 0
for _, c in crops:
    out.paste(c, (0, y))
    y += c.height + 2
out = out.resize((w * a.scale, h * a.scale), Image.LANCZOS)
out.save(a.out)
print("wrote %s  (%d frames: %s)" % (a.out, len(crops), ", ".join("f%03d" % f for f, _ in crops)))
print("rows are in frame order, top to bottom")
