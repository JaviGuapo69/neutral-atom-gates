"""se_compare.py -- the acceptance test.  Movie frames against rendered frames, at held frames.

A transcription is a fit, not a measurement, so the test is not "does the sheet look like some
other sheet" -- two workbooks that move the same atoms at the same times are the same workbook.
The test is whether the RENDER of it puts the atoms where the movie does.

Comparison happens only at HELD frames: frames where the movie's own configuration is on the tone
grid and unchanged from the previous frame.  Anywhere else a comparison is meaningless, because a
block in flight is legitimately between sites and the two sides need not sample the easing curve at
exactly the same sub-pixel phase.

Both sides are extracted with the same rule.  Run se_extract.py on the movie frames and on the
rendered frames (the render writes its own calib.txt), then point this at the two marker files.
"""
import argparse, collections, csv, json
import numpy as np


def load(path, calib, tone_divisor=1):
    K = json.load(open(calib, encoding="utf-8")) if calib.endswith(".json") else None
    per = collections.defaultdict(list)
    with open(path, encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            per[int(r["frame"])].append((r["species"], r["state"], float(r["x"]), float(r["y"])))
    return per, K


def snap(rows, tol, solid_only=True):
    out = {}
    for sp, st, x, y in rows:
        if solid_only and st != "solid":
            continue
        if abs(x - round(x)) > tol or abs(y - round(y)) > tol:
            return None                      # something is in flight: not a held frame
        out[(int(round(x)), int(round(y)))] = sp
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reference", required=True, help="markers csv extracted from the MOVIE frames")
    ap.add_argument("--candidate", required=True, help="markers csv extracted from the RENDER")
    ap.add_argument("--tol", type=float, default=0.16)
    ap.add_argument("--out", default=None, help="per-frame csv to write")
    args = ap.parse_args()

    ref, _ = load(args.reference, "x.json" if False else args.reference)
    cnd, _ = load(args.candidate, args.candidate)
    NF = max(max(ref) if ref else 0, max(cnd) if cnd else 0) + 1

    held, rows = [], []
    prev = None
    for f in range(NF):
        cfg = snap(ref.get(f, []), args.tol)
        if cfg is not None and prev is not None and cfg == prev:
            held.append(f)
        prev = cfg

    exact = 0
    tot_missing = tot_phantom = tot_wrong = 0
    for f in held:
        R = snap(ref.get(f, []), args.tol) or {}
        C = snap(cnd.get(f, []), args.tol)
        if C is None:
            C = {}
            for sp, st, x, y in cnd.get(f, []):
                if st == "solid":
                    C[(int(round(x)), int(round(y)))] = sp
        missing = [k for k in R if k not in C]
        phantom = [k for k in C if k not in R]
        wrong = [k for k in R if k in C and C[k] != R[k]]
        if not missing and not phantom and not wrong:
            exact += 1
        tot_missing += len(missing); tot_phantom += len(phantom); tot_wrong += len(wrong)
        rows.append(dict(frame=f, movie_atoms=len(R), render_atoms=len(C),
                         missing=len(missing), phantom=len(phantom), mislabelled=len(wrong)))

    print("held frames in the movie      : %d" % len(held))
    print("reproduced exactly            : %d / %d" % (exact, len(held)))
    if len(held):
        print("per held frame, on average    : %.1f missing, %.1f phantom, %.1f mislabelled"
              % (tot_missing / len(held), tot_phantom / len(held), tot_wrong / len(held)))
    print("\nworst frames:")
    for r in sorted(rows, key=lambda r: -(r["missing"] + r["phantom"] + r["mislabelled"]))[:12]:
        print("   frame %3d  movie %3d  render %3d  missing %3d  phantom %3d  mislabelled %3d"
              % (r["frame"], r["movie_atoms"], r["render_atoms"], r["missing"], r["phantom"],
                 r["mislabelled"]))
    if args.out:
        with open(args.out, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, ["frame", "movie_atoms", "render_atoms", "missing", "phantom",
                                    "mislabelled"])
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print("wrote %s" % args.out)
    print("\nA pass is exact agreement at every held frame.  It is necessary, not sufficient: a "
          "block drawn faded is absent from both extracts, so no error about a readout can show up "
          "here.  Watch the side by side as well.")


if __name__ == "__main__":
    main()
