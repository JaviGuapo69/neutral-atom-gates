# probes batch B -- segments 3-5 (f107-215)
$env:PYTHONIOENCODING = "utf-8"
$SB = "..\.claude\skills\se-cycle-blocks\tools"
function P($name, $sp, $ax, $f0, $f1, $win) {
  cmd /c "python $SB\sb_probe.py --calib calib.json --peaks --sp $sp --axis $ax --f0 $f0 --f1 $f1 --win=$win > logs\probe_$name.txt 2>&1"
  Write-Output "done $name $(Get-Date -Format HH:mm:ss)"
}
P "X0_rows_112_124"  X0 1 112 124 "0.4,13.6,12.4,24.6"
P "X0_rows_128_137"  X0 1 128 137 "0.4,13.6,12.4,24.6"
P "X1_rows_128_137"  X1 1 128 137 "13.4,26.6,12.4,24.6"
P "X0_cols_136_148"  X0 0 136 148 "0.4,13.6,12.4,24.6"
P "X0_rows_143_173"  X0 1 143 173 "0.4,13.6,12.4,24.6"
P "X1_rows_143_173"  X1 1 143 173 "13.4,26.6,12.4,24.6"
P "Z1_rows_143_171"  Z1 1 143 171 "0.4,13.6,24.4,36.6"
P "X1_rows_195_209"  X1 1 195 209 "13.4,26.6,12.4,36.6"
