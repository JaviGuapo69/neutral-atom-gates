<#
sb_video.ps1 -- the side-by-side comparison videos: movie on the left, rebuild on the right.

    .\sb_video.ps1 -MovieFrames ..\run_x\frames -RenderFrames .\rframes `
                   -Calib .\calib.json -OutPanels panels.mp4 -OutFull full.mp4

The panel crop is derived from the calibration's own `panel` rectangle, so it follows the movie
rather than being hard-coded; both dimensions are forced even because libx264 requires it.

Two things that will otherwise waste your time:

  * ffmpeg 9 REMOVED -vsync. Use -fps_mode passthrough.
  * `render.ps1` draws bunched atoms mid-crossing as SOLID BARS, not discrete markers. That looks
    like a broken render and is not -- the movie shows the same bars at the same frames, because
    that is what a crossing looks like at this resolution. Compare against an existing pair before
    chasing it.

Watch the whole thing once. The score is a mean, so it hides exactly the things that matter most:
a block that never arrives, a readout that descends at the wrong moment, a load that appears a
frame late.
#>
param(
  [Parameter(Mandatory=$true)][string]$MovieFrames,
  [Parameter(Mandatory=$true)][string]$RenderFrames,
  [Parameter(Mandatory=$true)][string]$Calib,
  [Parameter(Mandatory=$true)][string]$OutPanels,
  [Parameter(Mandatory=$true)][string]$OutFull,
  [int]$Fps = 8
)

$K = Get-Content $Calib -Raw | ConvertFrom-Json
$px0 = [int]$K.panel[0]; $px1 = [int]$K.panel[1]
$py0 = [int]$K.panel[2]; $py1 = [int]$K.panel[3]
$iw  = [int]$K.image_w;  $ih  = [int]$K.image_h
$nf  = [int]$K.n_frames

# a small margin so a block parked just off the array edge stays visible, then force even
$m = 14
$cx = [Math]::Max(0, $px0 - $m); $cy = [Math]::Max(0, $py0 - $m)
$cw = [Math]::Min($iw - $cx, ($px1 - $px0) + 2 * $m); $ch = [Math]::Min($ih - $cy, ($py1 - $py0) + 2 * $m)
if ($cw % 2 -ne 0) { $cw -= 1 }
if ($ch % 2 -ne 0) { $ch -= 1 }
$fw = [int]($iw / 2); $fh = [int]($ih / 2)
if ($fw % 2 -ne 0) { $fw -= 1 }
if ($fh % 2 -ne 0) { $fh -= 1 }
Write-Output "panel crop ${cw}x${ch} at ${cx},${cy}  ->  $(2*$cw)x${ch} side by side"
Write-Output "full frame at half scale ${fw}x${fh}  ->  $(2*$fw)x${fh}"

$stage = Join-Path ([System.IO.Path]::GetDirectoryName($OutPanels)) "sb_video_stage"
Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force "$stage\panels" | Out-Null
New-Item -ItemType Directory -Force "$stage\full"   | Out-Null

$n = 0
for ($f = 0; $f -lt $nf; $f++) {
  $a = Join-Path $MovieFrames  ("p_{0:d3}.png" -f $f)
  $b = Join-Path $RenderFrames ("p_{0:d3}.png" -f $f)
  if (-not (Test-Path $a)) { continue }
  if (-not (Test-Path $b)) { Write-Output "no render frame for f$f -- skipped"; continue }
  & ffmpeg -y -v error -i $a -i $b -filter_complex `
    "[0:v]crop=${cw}:${ch}:${cx}:${cy}[l];[1:v]crop=${cw}:${ch}:${cx}:${cy}[r];[l][r]hstack=inputs=2" `
    (Join-Path "$stage\panels" ("f_{0:d3}.png" -f $n))
  & ffmpeg -y -v error -i $a -i $b -filter_complex `
    "[0:v]scale=${fw}:${fh}[l];[1:v]scale=${fw}:${fh}[r];[l][r]hstack=inputs=2" `
    (Join-Path "$stage\full" ("f_{0:d3}.png" -f $n))
  $n++
}
Write-Output "staged $n frame pairs"
& ffmpeg -y -v error -framerate $Fps -i "$stage\panels\f_%03d.png" -c:v libx264 -pix_fmt yuv420p -fps_mode passthrough $OutPanels
& ffmpeg -y -v error -framerate $Fps -i "$stage\full\f_%03d.png"   -c:v libx264 -pix_fmt yuv420p -fps_mode passthrough $OutFull
Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue
Write-Output "wrote $OutPanels"
Write-Output "wrote $OutFull"
