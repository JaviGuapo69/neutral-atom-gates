# c780 -- the mistakes of the automatic book, in FRAMES, and the corrections APPLIED (session 31, 2026-09-17)

Written for: Javier, checking the c780 movie against the run_c780_s31 rebuild video.

Automatic book: `run_c780\c780_blocks.xlsx` (video `run_c780\c780_original_vs_rebuild_panels.mp4`, session 28, the "delivering the rest of videos" session). Frame = t_ms / 0.038541667. Every item below was read from the pixels (`run_c780_s31\logs\probe_*.txt`, 61 probes, and the frame crops `logs\crop_*.png`) and applied to `run_c780_s31\c780_s31_blocks.xlsx` by `apply_s31.py`, on the user's one-time instruction of 2026-09-17 ("apply the solutions to the problems that you find right away without consulting me, but only for this one time"). Each move carries a measured residual from the skill's own `verify` ('free' = the per-frame free-progress error, the statistic the last resort ranks on; the smoothstep mean over-reads on fast wraps). The s31 video is the starting point for the ordinary hand-correction dialogue: name a wrong movement between frames A and B and it is checked against the pixels.

## A. The corrections, in frame order (one entry per corrected or added move)

Recurring patterns, as on c630: (i) the third block of a batch rotating its columns the OPPOSITE way to the other two (items at f001-008, f138-145, f248-254, f334-340) or the SAME way where the report guessed the inverse (f001-008 X1, f071-077 X1); (ii) small permutations of one block read as whole-block rotations, 3-cycles read as 4-cycles with a static row dragged in (Z0 f008-034, X rows f063-066, f162-165, Z1 f079-084, f091-095, f160-166, f310-314, Z0 f379-383); (iii) the same movement done by two blocks written for one of them only (X0/X1 rows f043-050, f055-058, f127-137, f145-172, Z cols f070-079, f333-340); (iv) the FOUR-GROUP EXCHANGES (+2/+4 with -2/-4, or +3/+5 with -3/-5) that every block does once its columns have landed (Z1 f108-114, f289-294, f345-349; Z0 f294-298, f340-345; X1 f340-345) -- the solver never described one; (v) the descent of X0 to its parking rows in TWO scrambled steps (f178-198) where X1 descends as a plain translation.

### A1. frames 001-008 -- X1 cols f001-008 `14:15->25:26 \| 16:26->14:24`

UNDETERMINED X1 cols f001-008 on rows 1:12: the SAME rotation as X0's written 1:2->12:13 | 3:13->1:11, not its inverse. Gold outline cols 14,15 -> 25,26 (15.33 16.29 on f002, 19.47 20.54 on f004, 23.56 24.77 on f006, 25.00 26.00 on f008) and mauve cols 16:26 -> 14:24 (15.97..25.77 on f002, 14.01..23.99 on f008).

Measured: smoothstep mean 0.0672 (worst 0.345), moving-frame mean 0.075, free per-frame 0.0713, monotone 0.1203; window f0.00-f8.23 (t 0.0000-0.3172 ms); per species {'X1': 0.0672, 'X0': 7.4786, 'Z1': 0.1881, 'Z0': 7.4628}.

**Rows the automatic book had for X1 in f001-008:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 1 | X1 rows a | f8.23-f12.04 | 0.3172 | 0.4640 | 1:26 | 8 | 1:26 | 11 |
| 2 | 2 | X1 rows b | f8.23-f12.04 | 0.3172 | 0.4640 | 1:26 | 9:11 | 1:26 | 8:10 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 3 | X1 cols a | f0.00-f8.23 | 0.0000 | 0.3172 | 14:15 | 1:12 | 25:26 | 1:12 |
| 2 | 4 | X1 cols b | f0.00-f8.23 | 0.0000 | 0.3172 | 16:26 | 1:12 | 14:24 | 1:12 |
| 5 | 3 | X1 rows a | f8.23-f12.04 | 0.3172 | 0.4640 | 1:26 | 8 | 1:26 | 11 |
| 5 | 4 | X1 rows b | f8.23-f12.04 | 0.3172 | 0.4640 | 1:26 | 9:11 | 1:26 | 8:10 |

### A2. frames 001-008 -- Z0 cols f001-008 `1:11->3:13 \| 12:13->1:2`

UNDETERMINED Z0 cols f001-008 on rows 25:36: the INVERSE of X0's rotation. Gold outline cols 12,13 -> 1,2 (10.66 11.69 on f002, 6.59 7.62 on f004, 2.32 3.37 on f006, 1.01 2.02 on f008) and mauve cols 1:11 -> 3:13 (1.21..11.17 on f002, 2.99..12.93 on f008). The user's item 'f1-8 missed transition in D5'. |  end moved from f8.13 to f8.07, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0394 (worst 0.506), moving-frame mean 0.0333, free per-frame 0.0316, monotone 0.1203; window f0.00-f8.07 (t 0.0000-0.3110 ms); per species {'X1': 7.5088, 'X0': 0.1736, 'Z1': 7.2417, 'Z0': 0.0382}.

**Rows the automatic book had for Z0 in f001-008:**

_(no rows)_

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Z0 cols a | f0.00-f8.07 | 0.0000 | 0.3110 | 1:11 | 25:36 | 3:13 | 25:36 |
| 1 | 2 | Z0 cols b | f0.00-f8.07 | 0.0000 | 0.3110 | 12:13 | 25:36 | 1:2 | 25:36 |
| 4 | 1 | Z0 rows a | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 26 | 1:13 | 36 |
| 4 | 2 | Z0 rows b | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 28 | 1:13 | 26 |
| 4 | 2 | Z0 rows c | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 36 | 1:13 | 28 |

### A3. frames 008-016 -- Z0 rows f008-016 `26->36 \| 28->26 \| 36->28`

the S2.1 read 26:34->28:36 | 35:36->26:27 (rotation of 26:36 by 2) is wrong: rows 27, 29:35 sit on their tones on every frame f009-015. Three rows move: gold row 26 -> 36 (26.26 f009, 27.24 f010, 31.13 f012, 33.58 f013, 35.79 f015), mauve row 36 -> 28 (35.78, 34.97, 33.63, 31.76, 30.03, 28.82, 28.13 on f009-015) and mauve row 28 -> 26 (27.93, 27.81, 27.49, 26.43, 26.19, 26.04). Rest at f016 (all twelve rows on tones). The user's 'f9-15 missed transition in D5'. |  start moved from f8.00 to f8.07, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0382 (worst 0.509), moving-frame mean 0.0305, free per-frame 0.0278, monotone 0.0988; window f8.07-f15.77 (t 0.3110-0.6078 ms); per species {'X1': 18.4761, 'X0': 18.4665, 'Z1': 0.0725, 'Z0': 0.0348}.

**Rows the automatic book had for Z0 in f008-016:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 3 | 1 | Z0 rows a | f12.04-f13.04 | 0.4640 | 0.5026 | 1:13 | 26:34 | 1:13 | 28:36 |
| 3 | 2 | Z0 rows b | f12.04-f13.04 | 0.4640 | 0.5026 | 1:13 | 35:36 | 1:13 | 26:27 |
| 5 | 1 | Z0 rows a | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 25 | 1:13 | 32 |
| 5 | 1 | Z0 rows b | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 31 | 1:13 | 33 |
| 5 | 2 | Z0 rows c | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 32 | 1:13 | 31 |
| 5 | 5 | Z0 rows d | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 33 | 1:13 | 25 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | Z0 cols a | f0.00-f8.07 | 0.0000 | 0.3110 | 1:11 | 25:36 | 3:13 | 25:36 |
| 1 | 2 | Z0 cols b | f0.00-f8.07 | 0.0000 | 0.3110 | 12:13 | 25:36 | 1:2 | 25:36 |
| 4 | 1 | Z0 rows a | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 26 | 1:13 | 36 |
| 4 | 2 | Z0 rows b | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 28 | 1:13 | 26 |
| 4 | 2 | Z0 rows c | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 36 | 1:13 | 28 |
| 7 | 1 | Z0 rows a | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 25 | 1:13 | 31 |
| 7 | 1 | Z0 rows b | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 31 | 1:13 | 33 |
| 7 | 2 | Z0 rows c | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 33 | 1:13 | 25 |

### A4. frames 016-022 -- Z0 rows f016-022 `25->31 \| 31->33 \| 33->25`

the read 25->32 | 31->33 | 32->31 | 33->25 moves row 32, which the fill holds at 31.99 on every frame f017-022 (the user: 'row 32 should not move'). Gold row 33 -> 25 (32.43 f017, 31.27 f018, 29.31 f019, 27.21 f020, 25.84 f021, 25.08 f022), mauve row 25 -> 31 (25.38, 26.27, 27.61, 29.36, 30.50, 30.89) and mauve row 31 -> 33 (31.14, 31.54, 31.9, 32.58, 32.80, 32.96). |  end moved from f22.54 to f22.50, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0483 (worst 0.566), moving-frame mean 0.0308, free per-frame 0.0283, monotone 0.1219; window f16.00-f22.50 (t 0.6167-0.8672 ms); per species {'X1': 18.7409, 'X0': 18.7522, 'Z1': 0.0756, 'Z0': 0.0397}.

**Rows the automatic book had for Z0 in f016-022:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 5 | 1 | Z0 rows a | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 25 | 1:13 | 32 |
| 5 | 1 | Z0 rows b | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 31 | 1:13 | 33 |
| 5 | 2 | Z0 rows c | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 32 | 1:13 | 31 |
| 5 | 5 | Z0 rows d | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 33 | 1:13 | 25 |
| 8 | 3 | Z0 rows a | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 27 | 1:13 | 35 |
| 8 | 4 | Z0 rows b | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 29 | 1:13 | 27 |
| 8 | 4 | Z0 rows c | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 34 | 1:13 | 29 |
| 8 | 4 | Z0 rows d | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 35 | 1:13 | 34 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 1 | Z0 rows a | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 26 | 1:13 | 36 |
| 4 | 2 | Z0 rows b | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 28 | 1:13 | 26 |
| 4 | 2 | Z0 rows c | f8.07-f15.77 | 0.3110 | 0.6078 | 1:13 | 36 | 1:13 | 28 |
| 7 | 1 | Z0 rows a | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 25 | 1:13 | 31 |
| 7 | 1 | Z0 rows b | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 31 | 1:13 | 33 |
| 7 | 2 | Z0 rows c | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 33 | 1:13 | 25 |
| 10 | 1 | Z0 rows a | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 27 | 1:13 | 35 |
| 10 | 2 | Z0 rows b | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 29 | 1:13 | 27 |
| 10 | 2 | Z0 rows c | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 35 | 1:13 | 29 |

### A5. frames 022-030 -- Z0 rows f022-030 `27->35 \| 29->27 \| 35->29`

the read 27->35 | 29->27 | 34->29 | 35->34 moves row 34, which the fill holds at 33.99 on every frame f023-029 (the user: 'row 34 should not move'). Gold row 27 -> 35 (27.06 f023, 27.48 f024, 29.09 f025, 30.91 f026, 32.91 f027, 34.47 f028, 34.92 f029), mauve row 29 -> 27 (28.94, 28.82, 28.58, ~28, 27.38, 27.16, 27.00) and mauve row 35 -> 29 (34.97, 34.50, 33.53, 32.03, 30.53, 29.48, 29.01). |  start moved from f22.50 to f22.50, the boundary with the block's previous move (chosen by measurement). |  end moved from f29.56 to f29.50, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0439 (worst 0.863), moving-frame mean 0.0206, free per-frame 0.0206, monotone 0.0988; window f22.50-f29.50 (t 0.8672-1.1370 ms); per species {'X1': 18.4378, 'X0': 18.4662, 'Z1': 0.063, 'Z0': 0.0436}.

**Rows the automatic book had for Z0 in f022-030:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 5 | 1 | Z0 rows a | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 25 | 1:13 | 32 |
| 5 | 1 | Z0 rows b | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 31 | 1:13 | 33 |
| 5 | 2 | Z0 rows c | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 32 | 1:13 | 31 |
| 5 | 5 | Z0 rows d | f15.52-f22.04 | 0.5982 | 0.8495 | 1:13 | 33 | 1:13 | 25 |
| 8 | 3 | Z0 rows a | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 27 | 1:13 | 35 |
| 8 | 4 | Z0 rows b | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 29 | 1:13 | 27 |
| 8 | 4 | Z0 rows c | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 34 | 1:13 | 29 |
| 8 | 4 | Z0 rows d | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 35 | 1:13 | 34 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 7 | 1 | Z0 rows a | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 25 | 1:13 | 31 |
| 7 | 1 | Z0 rows b | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 31 | 1:13 | 33 |
| 7 | 2 | Z0 rows c | f16.00-f22.50 | 0.6167 | 0.8672 | 1:13 | 33 | 1:13 | 25 |
| 10 | 1 | Z0 rows a | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 27 | 1:13 | 35 |
| 10 | 2 | Z0 rows b | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 29 | 1:13 | 27 |
| 10 | 2 | Z0 rows c | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 35 | 1:13 | 29 |
| 12 | 1 | Z0 rows a | f29.50-f34.19 | 1.1370 | 1.3177 | 1:13 | 30 | 1:13 | 34 |
| 12 | 2 | Z0 rows b | f29.50-f34.19 | 1.1370 | 1.3177 | 1:13 | 32,34 | 1:13 | 30,32 |

### A6. frames 030-034 -- Z0 rows f030-034 `30->34 \| 32,34->30,32`

UNDETERMINED Z0 rows f030-034 on 25:36: gold row 30 -> 34 (30.12 f030, 30.71 f031, 32.22 f032, 33.45 f033, 33.95 f034) and mauve rows 32,34 -> 30,32 (31.95 33.96 f030; 31.57 33.62 f031; 30.87 32.96 f032; 30.25 32.26 f033; 30.02 32.03 f034); the other nine rows on their tones. The user's 'f30-34 missed transition in D5'. |  start moved from f29.50 to f29.50, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0366 (worst 1.000), moving-frame mean 0.0185, free per-frame 0.0167, monotone 0.1725; window f29.50-f34.19 (t 1.1370-1.3177 ms); per species {'X1': 18.9181, 'X0': 18.9687, 'Z1': 0.0599, 'Z0': 0.0236}.

**Rows the automatic book had for Z0 in f030-034:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 8 | 3 | Z0 rows a | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 27 | 1:13 | 35 |
| 8 | 4 | Z0 rows b | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 29 | 1:13 | 27 |
| 8 | 4 | Z0 rows c | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 34 | 1:13 | 29 |
| 8 | 4 | Z0 rows d | f22.04-f29.82 | 0.8495 | 1.1493 | 1:13 | 35 | 1:13 | 34 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 10 | 1 | Z0 rows a | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 27 | 1:13 | 35 |
| 10 | 2 | Z0 rows b | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 29 | 1:13 | 27 |
| 10 | 2 | Z0 rows c | f22.50-f29.50 | 0.8672 | 1.1370 | 1:13 | 35 | 1:13 | 29 |
| 12 | 1 | Z0 rows a | f29.50-f34.19 | 1.1370 | 1.3177 | 1:13 | 30 | 1:13 | 34 |
| 12 | 2 | Z0 rows b | f29.50-f34.19 | 1.1370 | 1.3177 | 1:13 | 32,34 | 1:13 | 30,32 |

### A7. frames 037-045 -- X1 cols f037-045 `14:17->23:26 \| 18:26->14:22`

rotation of the MEASURED moving run 14:26 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  end moved from f43.21 to f43.21, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0664 (worst 0.393), moving-frame mean 0.071, free per-frame 0.0722, monotone 0.0; window f35.44-f43.21 (t 1.3659-1.6654 ms); per species {'X1': 0.0652, 'X0': 7.6501, 'Z1': 0.2454, 'Z0': 7.7265}.

**Rows the automatic book had for X1 in f037-045:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 12 | 1 | X1 cols a | f35.44-f43.21 | 1.3659 | 1.6654 | 14:17 | 1:12 | 23:26 | 1:12 |
| 12 | 2 | X1 cols b | f35.44-f43.21 | 1.3659 | 1.6654 | 18:26 | 1:12 | 14:22 | 1:12 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 15 | 1 | X1 cols a | f35.44-f43.21 | 1.3659 | 1.6654 | 14:17 | 1:12 | 23:26 | 1:12 |
| 15 | 2 | X1 cols b | f35.44-f43.21 | 1.3659 | 1.6654 | 18:26 | 1:12 | 14:22 | 1:12 |

### A8. frames 043-050 -- X0+X1 rows f043-050 `1:3->10:12 \| 4:12->1:9`

UNDETERMINED X0 and X1 rows f043-050 (the last resort offered 1:6->7:12 | 7:12->1:6). Both blocks rotate by +9: gold outline rows 1:3 -> 10:12 (X0: 1.07-3.70 f044, 2.15-4.58 f045, 4.47-6.48 f046, 6.71-8.80 f047, 8.03-10.65 f048, 9.19-11.81 f049, 9.73-12.15 f050) and mauve rows 4:12 -> 1:9 (3.97..11.89 f044, 2.23..10.22 f047, 1.01..8.98 f050); X1 identical (mauve 4.00..12.01 -> 1.00..9.06, gold 0.98-3.03 -> 9.73-12.28). One rectangle over cols 1:26. The user's 'f43-50 missed transition in D1 and 2'. |  start moved from f43.00 to f43.21, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0925 (worst 0.813), moving-frame mean 0.0524, free per-frame 0.0496, monotone 0.0938; window f43.21-f50.37 (t 1.6654-1.9413 ms); per species {'X1': 0.0808, 'X0': 0.073, 'Z1': 18.7268, 'Z0': 18.754}.

**Rows the automatic book had for X0+X1 in f043-050:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 11 | 1 | X0 cols a | f35.44-f43.21 | 1.3659 | 1.6654 | 5:13 | 1:12 | 1:9 | 1:12 |
| 11 | 2 | X0 cols b | f35.44-f43.21 | 1.3659 | 1.6654 | 1:4 | 1:12 | 10:13 | 1:12 |
| 12 | 1 | X1 cols a | f35.44-f43.21 | 1.3659 | 1.6654 | 14:17 | 1:12 | 23:26 | 1:12 |
| 12 | 2 | X1 cols b | f35.44-f43.21 | 1.3659 | 1.6654 | 18:26 | 1:12 | 14:22 | 1:12 |
| 15 | 1 | X1 rows a | f49.15-f54.99 | 1.8943 | 2.1194 | 1:26 | 4:7 | 1:26 | 5:8 |
| 15 | 2 | X1 rows b | f49.15-f54.99 | 1.8943 | 2.1194 | 1:26 | 8 | 1:26 | 4 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 14 | 1 | X0 cols a | f35.44-f43.21 | 1.3659 | 1.6654 | 5:13 | 1:12 | 1:9 | 1:12 |
| 14 | 2 | X0 cols b | f35.44-f43.21 | 1.3659 | 1.6654 | 1:4 | 1:12 | 10:13 | 1:12 |
| 15 | 1 | X1 cols a | f35.44-f43.21 | 1.3659 | 1.6654 | 14:17 | 1:12 | 23:26 | 1:12 |
| 15 | 2 | X1 cols b | f35.44-f43.21 | 1.3659 | 1.6654 | 18:26 | 1:12 | 14:22 | 1:12 |
| 18 | 3 | X0 rows a | f43.21-f50.37 | 1.6654 | 1.9413 | 1:26 | 1:3 | 1:26 | 10:12 |
| 18 | 4 | X0 rows b | f43.21-f50.37 | 1.6654 | 1.9413 | 1:26 | 4:12 | 1:26 | 1:9 |
| 19 | 1 | X1 rows a | f50.41-f54.50 | 1.9429 | 2.1005 | 1:26 | 4:7 | 1:26 | 5:8 |
| 19 | 2 | X1 rows b | f50.41-f54.50 | 1.9429 | 2.1005 | 1:26 | 8 | 1:26 | 4 |

### A9. frames 051-057 -- X1+X0 rows f051-057 `4:7->5:8 \| 8->4`

rotation of the MEASURED moving run 4:8 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  start clipped to f50.41, after the f043-050 rotation.

Measured: smoothstep mean 0.0563 (worst 0.501), moving-frame mean 0.0313, free per-frame 0.0322, monotone 0.1521; window f50.41-f54.50 (t 1.9429-2.1005 ms); per species {'X1': 0.0563, 'X0': 0.0537, 'Z1': 18.4871, 'Z0': 18.4844}.

**Rows the automatic book had for X1+X0 in f051-057:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 15 | 1 | X1 rows a | f49.15-f54.99 | 1.8943 | 2.1194 | 1:26 | 4:7 | 1:26 | 5:8 |
| 15 | 2 | X1 rows b | f49.15-f54.99 | 1.8943 | 2.1194 | 1:26 | 8 | 1:26 | 4 |
| 16 | 1 | X0 rows a | f54.99-f58.31 | 2.1194 | 2.2474 | 1:13 | 1:6 | 1:13 | 2:7 |
| 16 | 2 | X0 rows b | f54.99-f58.31 | 2.1194 | 2.2474 | 1:13 | 7 | 1:13 | 1 |
| 17 | 3 | X1 rows a | f54.99-f58.31 | 2.1194 | 2.2474 | 14:26 | 3,7 | 14:26 | 1,5 |
| 17 | 4 | X1 rows b | f54.99-f58.31 | 2.1194 | 2.2474 | 14:26 | 1:2,5:6 | 14:26 | 2:3,6:7 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 18 | 3 | X0 rows a | f43.21-f50.37 | 1.6654 | 1.9413 | 1:26 | 1:3 | 1:26 | 10:12 |
| 18 | 4 | X0 rows b | f43.21-f50.37 | 1.6654 | 1.9413 | 1:26 | 4:12 | 1:26 | 1:9 |
| 19 | 1 | X1 rows a | f50.41-f54.50 | 1.9429 | 2.1005 | 1:26 | 4:7 | 1:26 | 5:8 |
| 19 | 2 | X1 rows b | f50.41-f54.50 | 1.9429 | 2.1005 | 1:26 | 8 | 1:26 | 4 |
| 20 | 1 | X1 rows a | f54.99-f58.31 | 2.1194 | 2.2474 | 1:26 | 3,7 | 1:26 | 1,5 |
| 20 | 2 | X1 rows b | f54.99-f58.31 | 2.1194 | 2.2474 | 1:26 | 1:2,5:6 | 1:26 | 2:3,6:7 |

### A10. frames 055-060 -- X1+X0 rows f055-060 `3,7->1,5 \| 1,2,5,6->2,3,6,7`

appearance triple (rule 3z): the outline colours name the sub-blocks directly |  X0 does the same map in the same batch (X0 mauve rows 1,2,5,6 -> 2,3,6,7: 1.13 2.15 5.15 6.14 on f056, 1.64 2.60 5.33 6.64 on f057, 2.02 3.00 5.91 6.98 on f058; gold rows 3,7 -> 1,5: 2.81 6.80, 2.07 5.8, 0.76-1.25 4.78-5.27), so the rectangle spans cols 1:26 and X0's wrong 1:6->2:7 | 7->1 is deleted.

Measured: smoothstep mean 0.0731 (worst 0.784), moving-frame mean 0.0678, free per-frame 0.0594, monotone 0.1583; window f54.99-f58.31 (t 2.1194-2.2474 ms); per species {'X1': 0.0731, 'X0': 0.0633, 'Z1': 18.4529, 'Z0': 18.4502}.

**Rows the automatic book had for X1+X0 in f055-060:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 15 | 1 | X1 rows a | f49.15-f54.99 | 1.8943 | 2.1194 | 1:26 | 4:7 | 1:26 | 5:8 |
| 15 | 2 | X1 rows b | f49.15-f54.99 | 1.8943 | 2.1194 | 1:26 | 8 | 1:26 | 4 |
| 16 | 1 | X0 rows a | f54.99-f58.31 | 2.1194 | 2.2474 | 1:13 | 1:6 | 1:13 | 2:7 |
| 16 | 2 | X0 rows b | f54.99-f58.31 | 2.1194 | 2.2474 | 1:13 | 7 | 1:13 | 1 |
| 17 | 3 | X1 rows a | f54.99-f58.31 | 2.1194 | 2.2474 | 14:26 | 3,7 | 14:26 | 1,5 |
| 17 | 4 | X1 rows b | f54.99-f58.31 | 2.1194 | 2.2474 | 14:26 | 1:2,5:6 | 14:26 | 2:3,6:7 |
| 18 | 1 | X1 rows a | f58.31-f62.90 | 2.2474 | 2.4243 | 1:26 | 1:3 | 1:26 | 4:6 |
| 18 | 2 | X1 rows b | f58.31-f62.90 | 2.2474 | 2.4243 | 1:26 | 4:6 | 1:26 | 1:3 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 19 | 1 | X1 rows a | f50.41-f54.50 | 1.9429 | 2.1005 | 1:26 | 4:7 | 1:26 | 5:8 |
| 19 | 2 | X1 rows b | f50.41-f54.50 | 1.9429 | 2.1005 | 1:26 | 8 | 1:26 | 4 |
| 20 | 1 | X1 rows a | f54.99-f58.31 | 2.1194 | 2.2474 | 1:26 | 3,7 | 1:26 | 1,5 |
| 20 | 2 | X1 rows b | f54.99-f58.31 | 2.1194 | 2.2474 | 1:26 | 1:2,5:6 | 1:26 | 2:3,6:7 |
| 21 | 1 | X1 rows a | f58.31-f62.90 | 2.2474 | 2.4243 | 1:26 | 1:3 | 1:26 | 4:6 |
| 21 | 2 | X1 rows b | f58.31-f62.90 | 2.2474 | 2.4243 | 1:26 | 4:6 | 1:26 | 1:3 |

### A11. frames 063-068 -- X1+X0 rows f063-068 `8:9->9:10 \| 10->8`

the last-resort 9->10 | 10->9 is wrong: on both blocks row 8 moves too. Mauve rows 8,9 -> 9,10 (X0: 8.02 9.01 f063, 8.32 9.03 f064, 8.80 9.80 f065, 8.99 10.00 f066) and gold row 10 -> 8 (9.65-10.14 f063, 9.11-9.60 f064, 8.21 f065, 7.72-8.33 f066); X1 identical. The user's 'f63-66 wrong transition in D1, D2'.

Measured: smoothstep mean 0.0640 (worst 1.026), moving-frame mean 0.037, free per-frame 0.037, monotone 0.2875; window f62.92-f66.01 (t 2.4250-2.5441 ms); per species {'X1': 0.064, 'X0': 0.0634, 'Z1': 18.5044, 'Z0': 18.5017}.

**Rows the automatic book had for X1+X0 in f063-068:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 18 | 1 | X1 rows a | f58.31-f62.90 | 2.2474 | 2.4243 | 1:26 | 1:3 | 1:26 | 4:6 |
| 18 | 2 | X1 rows b | f58.31-f62.90 | 2.2474 | 2.4243 | 1:26 | 4:6 | 1:26 | 1:3 |
| 19 | 1 | X1 rows a | f62.90-f66.29 | 2.4243 | 2.5549 | 1:26 | 9 | 1:26 | 10 |
| 19 | 2 | X1 rows b | f62.90-f66.29 | 2.4243 | 2.5549 | 1:26 | 10 | 1:26 | 9 |
| 20 | 1 | X1 rows a | f66.29-f70.00 | 2.5549 | 2.6979 | 1:26 | 7:9 | 1:26 | 9:11 |
| 20 | 2 | X1 rows b | f66.29-f70.00 | 2.5549 | 2.6979 | 1:26 | 10:11 | 1:26 | 7:8 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 21 | 1 | X1 rows a | f58.31-f62.90 | 2.2474 | 2.4243 | 1:26 | 1:3 | 1:26 | 4:6 |
| 21 | 2 | X1 rows b | f58.31-f62.90 | 2.2474 | 2.4243 | 1:26 | 4:6 | 1:26 | 1:3 |
| 22 | 1 | X1 rows a | f62.92-f66.01 | 2.4250 | 2.5441 | 1:26 | 8:9 | 1:26 | 9:10 |
| 22 | 2 | X1 rows b | f62.92-f66.01 | 2.4250 | 2.5441 | 1:26 | 10 | 1:26 | 8 |
| 23 | 1 | X1 rows a | f66.29-f70.00 | 2.5549 | 2.6979 | 1:26 | 7:9 | 1:26 | 9:11 |
| 23 | 2 | X1 rows b | f66.29-f70.00 | 2.5549 | 2.6979 | 1:26 | 10:11 | 1:26 | 7:8 |

### A12. frames 070-079 -- Z0 cols f070-079 `1:13->-12:0`

FAULT C: the slide was written from the false rest 0:12; the block leaves 1:13 at the f070 gate (fill 0.08..12.11 on f072, -0.41..10.61 f073, -0.45..8.37 f074, 5.67 last visible f075 ... 0.01 on f079 and 0.00 from then on: only column 0 stays on panel). Uniform -13 to the parking cols -12:0, the same batch as Z1's slide.

Measured: smoothstep mean 0.0615 (worst 0.204), moving-frame mean 0.0408, free per-frame 0.0424, monotone 0.0; window f70.02-f79.43 (t 2.6987-3.0614 ms); per species {'X1': 13.6536, 'X0': 2.7326, 'Z1': 6.4847, 'Z0': 0.0615}.

**Rows the automatic book had for Z0 in f070-079:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 23 | 3 | Z0 cols a | f72.06-f77.78 | 2.7773 | 2.9978 | 0:12 | 25:36 | -12:0 | 25:36 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 25 | 1 | Z0 cols a | f70.02-f79.43 | 2.6987 | 3.0614 | 1:13 | 25:36 | -12:0 | 25:36 |

### A13. frames 070-079 -- Z1 cols f070-079 `14:26->1:13`

FAULT C: the solver read a false rest one column left (13:25) one frame into the motion and wrote the slide FROM it. The block leaves 14:26 at the f070 gate: fill 13.07..25.07 on f072 (-0.93), 11.61..23.60 f073, 9.45..21.45 f074, 6.68..18.70 f075, 4.25..16.25 f076, 2.49..14.48 f077, 1.40..13.39 f078, 1.01..13.00 f079 -- a uniform -13 landing on 1:13. |  end moved from f79.43 to f79.43, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0492 (worst 0.127), moving-frame mean 0.0219, free per-frame 0.0287, monotone 0.0; window f70.02-f79.43 (t 2.6987-3.0614 ms); per species {'X1': 3.942, 'X0': 2.3452, 'Z1': 0.0492, 'Z0': 6.5152}.

**Rows the automatic book had for Z1 in f070-079:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 22 | 3 | Z1 cols a | f70.04-f79.08 | 2.6995 | 3.0479 | 13:25 | 25:36 | 1:13 | 25:36 |
| 24 | 1 | Z1 rows a | f79.08-f83.59 | 3.0479 | 3.2217 | 1:13 | 28:30,34:36 | 1:13 | 25:27,31:33 |
| 24 | 2 | Z1 rows b | f79.08-f83.59 | 3.0479 | 3.2217 | 1:13 | 25:27,31:33 | 1:13 | 28:30,34:36 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 24 | 1 | Z1 cols a | f70.02-f79.43 | 2.6987 | 3.0614 | 14:26 | 25:36 | 1:13 | 25:36 |
| 29 | 1 | Z1 rows a | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 25:26 | 1:13 | 29:30 |
| 29 | 2 | Z1 rows b | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 27:30 | 1:13 | 25:28 |
| 29 | 1 | Z1 rows c | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 31:32 | 1:13 | 35:36 |
| 29 | 2 | Z1 rows d | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 33:36 | 1:13 | 31:34 |

### A14. frames 072-079 -- X0 cols f072-079 `1:5->9:13 \| 6:13->1:8`

rotation of the MEASURED moving run 1:13 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  end moved from f77.78 to f76.86, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.1877 (worst 0.704), moving-frame mean 0.0669, free per-frame 0.0612, monotone 0.0; window f70.04-f76.86 (t 2.6995-2.9623 ms); per species {'X1': 7.7818, 'X0': 0.0587, 'Z1': 2.3503, 'Z0': 2.4592}.

**Rows the automatic book had for X0 in f072-079:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 21 | 1 | X0 cols a | f70.04-f77.78 | 2.6995 | 2.9978 | 1:5 | 1:12 | 9:13 | 1:12 |
| 21 | 2 | X0 cols b | f70.04-f77.78 | 2.6995 | 2.9978 | 6:13 | 1:12 | 1:8 | 1:12 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 26 | 2 | X0 cols a | f70.04-f76.86 | 2.6995 | 2.9623 | 1:5 | 1:12 | 9:13 | 1:12 |
| 26 | 3 | X0 cols b | f70.04-f76.86 | 2.6995 | 2.9623 | 6:13 | 1:12 | 1:8 | 1:12 |
| 28 | 2 | X0 rows a | f76.86-f86.91 | 2.9623 | 3.3497 | 1:13 | 1,11 | 1:13 | 14,24 |
| 28 | 2 | X0 rows b | f76.86-f86.91 | 2.9623 | 3.3497 | 1:13 | 2:4,6:8 | 1:13 | 17:19,21:23 |
| 28 | 3 | X0 rows c | f76.86-f86.91 | 2.9623 | 3.3497 | 1:13 | 5,12 | 1:13 | 13,20 |
| 28 | 3 | X0 rows d | f76.86-f86.91 | 2.9623 | 3.3497 | 1:13 | 9:10 | 1:13 | 15:16 |

### A15. frames 071-077 -- X1 cols f071-077 `14:18->22:26 \| 19:26->14:21`

UNDETERMINED X1 cols f071-077 on rows 1:12: the SAME rotation as X0's written 1:5->9:13 | 6:13->1:8. Gold outline cols 14:18 -> 22:26 (14.97-18.92 f072, 18.72-22.50 f074, 20.30-24.31 f075, 21.50-25.49 f076, 21.97-26.01 f077) and mauve cols 19:26 -> 14:21 (18.42-25.40 f072, 15.01-21.78 f075, 14.01-21.07 f077). |  window synchronised with its twin in the same batch (own f70.04-77.78).

Measured: smoothstep mean 0.1921 (worst 0.700), moving-frame mean 0.0742, free per-frame 0.0742, monotone 0.1339; window f70.04-f76.86 (t 2.6995-2.9623 ms); per species {'X1': 0.0976, 'X0': 7.7755, 'Z1': 3.7171, 'Z0': 13.7908}.

**Rows the automatic book had for X1 in f071-077:**

_(no rows)_

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 27 | 2 | X1 cols a | f70.04-f76.86 | 2.6995 | 2.9623 | 14:18 | 1:12 | 22:26 | 1:12 |
| 27 | 3 | X1 cols b | f70.04-f76.86 | 2.6995 | 2.9623 | 19:26 | 1:12 | 14:21 | 1:12 |

### A16. frames 077-087 -- X0 rows f077-087 `1,11->14,24 \| 2,3,4,6,7,8->17,18,19,21,22,23 \| 5,12->13,20 \| 9:10->15:16`

FAULT A: the relocation 1:12 -> 13:24 had no rows move (the last resort's 1:11->14:24 | 12->13 was refused at 0.166), so the X blocks stayed on rows 1:12 in the rebuild to the end. It is NOT a plain +12 translation (that map reads 0.18 with a free error of 0.23; the fill spacing during the move is not one row -- 7.68 9.08 9.84 10.92 11.70 12.16 13.24 13.82 14.83 15.68 16.24 17.88 on f082): the block descends in FOUR rigid groups, read from the outline classes (logs\crop_X0_rows_077_088.png): mauve rows 5, 9, 10, 12 (4.96/5.40 8.80/9.26 10.09 11.98/12.43 on f078) land on 13, 15, 16, 20 (13.00 15.01 15.68/16.29 19.97 on f086), so 5,12 go +8 and 9,10 go +6; gold rows 1:4, 6:8, 11 land on 14, 17:19, 21:24 (13.59/14.08 16.61..19.23 20.55..24.06 on f086), so 1,11 go +13 and 2:4, 6:8 go +15. The fill on f082 matches this map at p 0.5 to 0.2 site (predicted 7.5 9 9.5 10.5 11.5 12 13 13.5 14.5 15.5 16 17.5). |  start moved from f76.86 to f76.86, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0697 (worst 0.409), moving-frame mean 0.0834, free per-frame 0.0834, monotone 0.0; window f76.86-f86.91 (t 2.9623-3.3497 ms); per species {'X1': 3.0423, 'X0': 0.0689, 'Z1': 12.2186, 'Z0': 12.0499}.

**Rows the automatic book had for X0 in f077-087:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 21 | 1 | X0 cols a | f70.04-f77.78 | 2.6995 | 2.9978 | 1:5 | 1:12 | 9:13 | 1:12 |
| 21 | 2 | X0 cols b | f70.04-f77.78 | 2.6995 | 2.9978 | 6:13 | 1:12 | 1:8 | 1:12 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 26 | 2 | X0 cols a | f70.04-f76.86 | 2.6995 | 2.9623 | 1:5 | 1:12 | 9:13 | 1:12 |
| 26 | 3 | X0 cols b | f70.04-f76.86 | 2.6995 | 2.9623 | 6:13 | 1:12 | 1:8 | 1:12 |
| 28 | 2 | X0 rows a | f76.86-f86.91 | 2.9623 | 3.3497 | 1:13 | 1,11 | 1:13 | 14,24 |
| 28 | 2 | X0 rows b | f76.86-f86.91 | 2.9623 | 3.3497 | 1:13 | 2:4,6:8 | 1:13 | 17:19,21:23 |
| 28 | 3 | X0 rows c | f76.86-f86.91 | 2.9623 | 3.3497 | 1:13 | 5,12 | 1:13 | 13,20 |
| 28 | 3 | X0 rows d | f76.86-f86.91 | 2.9623 | 3.3497 | 1:13 | 9:10 | 1:13 | 15:16 |

### A17. frames 079-084 -- Z1 rows f079-084 `25:26->29:30 \| 27:30->25:28 \| 31:32->35:36 \| 33:36->31:34`

the last-resort 28,29,30,34,35,36->25,26,27,31,32,33 | 25,26,27,31,32,33->28,29,30,34,35,36 (rotation by 3 within each half) is one row short: gold rows 25,26 -> 29,30 and 31,32 -> 35,36 (26.06 27.07 32.02 33.05 on f081, 28.83 29.71 34.82 35.71 on f083), green rows 27:30 -> 25:28 and 33:36 -> 31:34 (26.72..29.87 32.77..35.89 on f080, 25.61..28.63 31.64..34.66 on f082, 25.15..28.22 31.14..34.28 on f083); on tones at f084. |  start moved from f79.00 to f79.43, the boundary with the block's previous move (chosen by measurement). |  end moved from f84.06 to f83.59, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0684 (worst 0.389), moving-frame mean 0.0228, free per-frame 0.0228, monotone 0.1156; window f79.43-f83.59 (t 3.0614-3.2217 ms); per species {'X1': 18.6124, 'X0': 12.6121, 'Z1': 0.0445, 'Z0': 0.1504}.

**Rows the automatic book had for Z1 in f079-084:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 22 | 3 | Z1 cols a | f70.04-f79.08 | 2.6995 | 3.0479 | 13:25 | 25:36 | 1:13 | 25:36 |
| 24 | 1 | Z1 rows a | f79.08-f83.59 | 3.0479 | 3.2217 | 1:13 | 28:30,34:36 | 1:13 | 25:27,31:33 |
| 24 | 2 | Z1 rows b | f79.08-f83.59 | 3.0479 | 3.2217 | 1:13 | 25:27,31:33 | 1:13 | 28:30,34:36 |
| 25 | 1 | Z1 rows a | f83.59-f91.54 | 3.2217 | 3.5281 | 1:13 | 34 | 1:13 | 25 |
| 25 | 2 | Z1 rows b | f83.59-f91.54 | 3.2217 | 3.5281 | 1:13 | 25:33 | 1:13 | 26:34 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 24 | 1 | Z1 cols a | f70.02-f79.43 | 2.6987 | 3.0614 | 14:26 | 25:36 | 1:13 | 25:36 |
| 29 | 1 | Z1 rows a | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 25:26 | 1:13 | 29:30 |
| 29 | 2 | Z1 rows b | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 27:30 | 1:13 | 25:28 |
| 29 | 1 | Z1 rows c | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 31:32 | 1:13 | 35:36 |
| 29 | 2 | Z1 rows d | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 33:36 | 1:13 | 31:34 |
| 30 | 1 | Z1 rows a | f83.59-f91.06 | 3.2217 | 3.5096 | 1:13 | 34 | 1:13 | 25 |
| 30 | 2 | Z1 rows b | f83.59-f91.06 | 3.2217 | 3.5096 | 1:13 | 25:33 | 1:13 | 26:34 |

### A18. frames 084-093 -- Z1 rows f084-093 `34->25 \| 25:33->26:34`

appearance triple (rule 3z): the outline colours name the sub-blocks directly |  start moved from f83.59 to f83.59, the boundary with the block's previous move (chosen by measurement). |  end moved from f91.54 to f91.06, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.1061 (worst 1.375), moving-frame mean 0.0461, free per-frame 0.0672, monotone 0.0; window f83.59-f91.06 (t 3.2217-3.5096 ms); per species {'X1': 15.9871, 'X0': 6.8685, 'Z1': 0.0394, 'Z0': 0.1326}.

**Rows the automatic book had for Z1 in f084-093:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 24 | 1 | Z1 rows a | f79.08-f83.59 | 3.0479 | 3.2217 | 1:13 | 28:30,34:36 | 1:13 | 25:27,31:33 |
| 24 | 2 | Z1 rows b | f79.08-f83.59 | 3.0479 | 3.2217 | 1:13 | 25:27,31:33 | 1:13 | 28:30,34:36 |
| 25 | 1 | Z1 rows a | f83.59-f91.54 | 3.2217 | 3.5281 | 1:13 | 34 | 1:13 | 25 |
| 25 | 2 | Z1 rows b | f83.59-f91.54 | 3.2217 | 3.5281 | 1:13 | 25:33 | 1:13 | 26:34 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 29 | 1 | Z1 rows a | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 25:26 | 1:13 | 29:30 |
| 29 | 2 | Z1 rows b | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 27:30 | 1:13 | 25:28 |
| 29 | 1 | Z1 rows c | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 31:32 | 1:13 | 35:36 |
| 29 | 2 | Z1 rows d | f79.43-f83.59 | 3.0614 | 3.2217 | 1:13 | 33:36 | 1:13 | 31:34 |
| 30 | 1 | Z1 rows a | f83.59-f91.06 | 3.2217 | 3.5096 | 1:13 | 34 | 1:13 | 25 |
| 30 | 2 | Z1 rows b | f83.59-f91.06 | 3.2217 | 3.5096 | 1:13 | 25:33 | 1:13 | 26:34 |
| 32 | 1 | Z1 rows a | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 26 | 1:13 | 28 |
| 32 | 2 | Z1 rows b | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 27:28 | 1:13 | 26:27 |
| 32 | 1 | Z1 rows c | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 31 | 1:13 | 33 |
| 32 | 2 | Z1 rows d | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 32:33 | 1:13 | 31:32 |

### A19. frames 086-096 -- X1 rows f086-096 `1,11->14,24 \| 2,3,4,6,7,8->17,18,19,21,22,23 \| 5,12->13,20 \| 9:10->15:16`

FAULT A, X1's half nine frames later, the same four-group descent (logs\crop_X1_rows_086_097.png: mauve rows 5, 9, 10, 12 on f087 land on 13, 15, 16, 20 on f096; gold rows 1:4, 6:8, 11 land on 14, 17:19, 21:24). Fill 1.59..12.47 f088, 4.46 5.94 7.21 7.96 9.96 10.82 11.47 11.95 14.09 14.56 f090, 9.34..19.35 f092, on 13:24 from f096.

Measured: smoothstep mean 0.0632 (worst 0.426), moving-frame mean 0.0899, free per-frame 0.0849, monotone 0.0; window f86.22-f96.39 (t 3.3231-3.7150 ms); per species {'X1': 0.0632, 'X0': 2.7934, 'Z1': 12.5139, 'Z0': 12.3672}.

**Rows the automatic book had for X1 in f086-096:**

_(no rows)_

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 31 | 4 | X1 rows a | f86.22-f96.39 | 3.3231 | 3.7150 | 14:26 | 1,11 | 14:26 | 14,24 |
| 31 | 4 | X1 rows b | f86.22-f96.39 | 3.3231 | 3.7150 | 14:26 | 2:4,6:8 | 14:26 | 17:19,21:23 |
| 31 | 5 | X1 rows c | f86.22-f96.39 | 3.3231 | 3.7150 | 14:26 | 5,12 | 14:26 | 13,20 |
| 31 | 5 | X1 rows d | f86.22-f96.39 | 3.3231 | 3.7150 | 14:26 | 9:10 | 14:26 | 15:16 |

### A20. frames 091-095 -- Z1 rows f091-095 `26->28 \| 27:28->26:27 \| 31->33 \| 32:33->31:32`

the read 26:31->28:33 | 32:33->26:27 (rotation of 26:33 by 2, fitted f94.5-99.6 = the NEXT move's window) is wrong: rows 29 and 30 sit at 28.99 29.99 on every frame f092-094. Gold rows 26 -> 28 and 31 -> 33 (26.19 31.06 f092, 26.96 32.04 f093, 27.87 32.89 f094) and mauve rows 27,28 -> 26,27 and 32,33 -> 31,32 (27.46 31.91/32.88 f092, 26.43/27.49 31.42/32.11 f093, 26.49 31.52 f094); on tones at f095. |  start moved from f91.06 to f91.06, the boundary with the block's previous move (chosen by measurement). |  end moved from f94.83 to f94.52, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0575 (worst 0.633), moving-frame mean 0.0511, free per-frame 0.0577, monotone 0.1604; window f91.06-f94.52 (t 3.5096-3.6430 ms); per species {'X1': 9.8786, 'X0': 6.4909, 'Z1': 0.0466, 'Z0': 0.0793}.

**Rows the automatic book had for Z1 in f091-095:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 25 | 1 | Z1 rows a | f83.59-f91.54 | 3.2217 | 3.5281 | 1:13 | 34 | 1:13 | 25 |
| 25 | 2 | Z1 rows b | f83.59-f91.54 | 3.2217 | 3.5281 | 1:13 | 25:33 | 1:13 | 26:34 |
| 26 | 1 | Z1 rows a | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 28:31 | 1:13 | 30:33 |
| 26 | 2 | Z1 rows b | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 32:33 | 1:13 | 28:29 |
| 27 | 1 | Z1 rows a | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 26:31 | 1:13 | 28:33 |
| 27 | 3 | Z1 rows b | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 32:33 | 1:13 | 26:27 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 30 | 1 | Z1 rows a | f83.59-f91.06 | 3.2217 | 3.5096 | 1:13 | 34 | 1:13 | 25 |
| 30 | 2 | Z1 rows b | f83.59-f91.06 | 3.2217 | 3.5096 | 1:13 | 25:33 | 1:13 | 26:34 |
| 32 | 1 | Z1 rows a | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 26 | 1:13 | 28 |
| 32 | 2 | Z1 rows b | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 27:28 | 1:13 | 26:27 |
| 32 | 1 | Z1 rows c | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 31 | 1:13 | 33 |
| 32 | 2 | Z1 rows d | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 32:33 | 1:13 | 31:32 |
| 33 | 1 | Z1 rows a | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 28:31 | 1:13 | 30:33 |
| 33 | 2 | Z1 rows b | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 32:33 | 1:13 | 28:29 |

### A21. frames 095-101 -- Z1 rows f095-101 `28:31->30:33 \| 32:33->28:29`

rotation of the MEASURED moving run 28:33 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  start moved from f94.52 to f94.52, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0466 (worst 0.777), moving-frame mean 0.0448, free per-frame 0.0438, monotone 0.0; window f94.52-f99.62 (t 3.6430-3.8395 ms); per species {'X1': 6.5303, 'X0': 6.4897, 'Z1': 0.028, 'Z0': 0.1021}.

**Rows the automatic book had for Z1 in f095-101:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 26 | 1 | Z1 rows a | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 28:31 | 1:13 | 30:33 |
| 26 | 2 | Z1 rows b | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 32:33 | 1:13 | 28:29 |
| 27 | 1 | Z1 rows a | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 26:31 | 1:13 | 28:33 |
| 27 | 3 | Z1 rows b | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 32:33 | 1:13 | 26:27 |
| 28 | 1 | Z1 rows a | f99.62-f104.05 | 3.8395 | 4.0103 | 1:13 | 33:35 | 1:13 | 34:36 |
| 28 | 2 | Z1 rows b | f99.62-f104.05 | 3.8395 | 4.0103 | 1:13 | 36 | 1:13 | 33 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 32 | 1 | Z1 rows a | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 26 | 1:13 | 28 |
| 32 | 2 | Z1 rows b | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 27:28 | 1:13 | 26:27 |
| 32 | 1 | Z1 rows c | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 31 | 1:13 | 33 |
| 32 | 2 | Z1 rows d | f91.06-f94.52 | 3.5096 | 3.6430 | 1:13 | 32:33 | 1:13 | 31:32 |
| 33 | 1 | Z1 rows a | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 28:31 | 1:13 | 30:33 |
| 33 | 2 | Z1 rows b | f94.52-f99.62 | 3.6430 | 3.8395 | 1:13 | 32:33 | 1:13 | 28:29 |
| 34 | 1 | Z1 rows a | f99.62-f104.05 | 3.8395 | 4.0103 | 1:13 | 33:35 | 1:13 | 34:36 |
| 34 | 2 | Z1 rows b | f99.62-f104.05 | 3.8395 | 4.0103 | 1:13 | 36 | 1:13 | 33 |

### A22. frames 108-114 -- Z1 rows f108-114 `25,35->26,36 \| 26,27,28,30,31,32->29,30,31,33,34,35 \| 29,36->25,32 \| 33:34->27:28`

UNDETERMINED Z1 rows f108-114 (the candidate 25:30<->31:36 read 0.177). Four rigid groups: the dark-green class rows 29,33,34,36 -> 25,27,28,32 (28.79 32.48 33.57 35.65 f109; 26.81 29.75 30.75 34.13 f111; 25.15 27.24 28.35 32.14 f113; 24.99 27.00 28.01 31.99 f114) and the other eight rows +1 / +3 (25.07 26.19 27.20 28.29 30.17 31.17 32.05 35.00 f109; 25.80 28.46 29.54 30.40 32.28 33.42 34.42 35.82 f112; 26.00 29.02 29.98 30.98 32.99 34.00 35.00 35.97 f114). The fill on f113 (25.16 25.96 27.23 28.23 28.89 29.89 30.89 32.15 32.86 33.86 34.86 35.94) matches this map at p 0.95 to 0.05 site.

Measured: smoothstep mean 0.0275 (worst 0.165), moving-frame mean 0.0475, free per-frame 0.0403, monotone 0.1375; window f107.67-f114.10 (t 4.1498-4.3976 ms); per species {'X1': 7.0005, 'X0': 7.0169, 'Z1': 0.0275, 'Z0': 0.1881}.

**Rows the automatic book had for Z1 in f108-114:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 29 | 1 | Z1 rows a | f104.05-f107.00 | 4.0103 | 4.1240 | 1:13 | 31:32 | 1:13 | 34:35 |
| 29 | 2 | Z1 rows b | f104.05-f107.00 | 4.0103 | 4.1240 | 1:13 | 33:35 | 1:13 | 31:33 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 35 | 1 | Z1 rows a | f104.05-f107.00 | 4.0103 | 4.1240 | 1:13 | 31:32 | 1:13 | 34:35 |
| 35 | 2 | Z1 rows b | f104.05-f107.00 | 4.0103 | 4.1240 | 1:13 | 33:35 | 1:13 | 31:33 |
| 37 | 3 | Z1 rows a | f107.67-f114.10 | 4.1498 | 4.3976 | 1:13 | 25,35 | 1:13 | 26,36 |
| 37 | 3 | Z1 rows b | f107.67-f114.10 | 4.1498 | 4.3976 | 1:13 | 26:28,30:32 | 1:13 | 29:31,33:35 |
| 37 | 4 | Z1 rows c | f107.67-f114.10 | 4.1498 | 4.3976 | 1:13 | 29,36 | 1:13 | 25,32 |
| 37 | 4 | Z1 rows d | f107.67-f114.10 | 4.1498 | 4.3976 | 1:13 | 33:34 | 1:13 | 27:28 |

### A23. frames 114-119 -- X1+X0 rows f114-119 `22->24 \| 23:24->22:23`

appearance triple (rule 3z): the outline colours name the sub-blocks directly |  end moved from f117.33 to f117.00, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0708 (worst 0.520), moving-frame mean 0.0382, free per-frame 0.0549, monotone 0.0; window f114.08-f117.00 (t 4.3968-4.5094 ms); per species {'X1': 0.0311, 'X0': 0.0547, 'Z1': 6.5869, 'Z0': 6.5763}.

**Rows the automatic book had for X1+X0 in f114-119:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 30 | 1 | X0 rows a | f107.62-f114.08 | 4.1479 | 4.3968 | 1:26 | 13:18 | 1:26 | 19:24 |
| 30 | 2 | X0 rows b | f107.62-f114.08 | 4.1479 | 4.3968 | 1:26 | 19:24 | 1:26 | 13:18 |
| 31 | 1 | X1 rows a | f114.08-f117.33 | 4.3968 | 4.5221 | 1:26 | 22 | 1:26 | 24 |
| 31 | 2 | X1 rows b | f114.08-f117.33 | 4.3968 | 4.5221 | 1:26 | 23:24 | 1:26 | 22:23 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 36 | 1 | X0 rows a | f107.62-f114.08 | 4.1479 | 4.3968 | 1:26 | 13:18 | 1:26 | 19:24 |
| 36 | 2 | X0 rows b | f107.62-f114.08 | 4.1479 | 4.3968 | 1:26 | 19:24 | 1:26 | 13:18 |
| 38 | 1 | X1 rows a | f114.08-f117.00 | 4.3968 | 4.5094 | 1:26 | 22 | 1:26 | 24 |
| 38 | 2 | X1 rows b | f114.08-f117.00 | 4.3968 | 4.5094 | 1:26 | 23:24 | 1:26 | 22:23 |
| 39 | 1 | X1 rows a | f117.00-f119.37 | 4.5094 | 4.6007 | 1:26 | 22 | 1:26 | 23 |
| 39 | 2 | X1 rows b | f117.00-f119.37 | 4.5094 | 4.6007 | 1:26 | 23 | 1:26 | 22 |

### A24. frames 117-120 -- X1+X0 rows f117-120 `22->23 \| 23->22`

FAULT E, the SILENT hole: rows 22 and 23 swap on both X blocks -- X1 fill 22.13 23.02 on f117, 22.52 (the two merged) on f118, 22.17 22.87 on f119, on tones at f120; the outline classes cross between f118 and f119 on X1 AND X0 (mauve 22.18 -> 22.56-23.17, gold 22.87 -> 21.87-22.30 on both), X0's fill 22.23 22.93 f118, 22.17 22.81 f119. Verified on X0's peaks too (0.07). |  start moved from f117.00 to f117.00, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0473 (worst 0.577), moving-frame mean 0.0129, free per-frame 0.0129, monotone 0.07; window f117.00-f119.37 (t 4.5094-4.6007 ms); per species {'X1': 0.0473, 'X0': 0.0724, 'Z1': 6.5192, 'Z0': 6.5086}.

**Rows the automatic book had for X1+X0 in f117-120:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 31 | 1 | X1 rows a | f114.08-f117.33 | 4.3968 | 4.5221 | 1:26 | 22 | 1:26 | 24 |
| 31 | 2 | X1 rows b | f114.08-f117.33 | 4.3968 | 4.5221 | 1:26 | 23:24 | 1:26 | 22:23 |
| 32 | 1 | X0 rows a | f120.69-f122.48 | 4.6516 | 4.7206 | 1:26 | 23 | 1:26 | 14 |
| 32 | 2 | X0 rows b | f120.69-f122.48 | 4.6516 | 4.7206 | 1:26 | 14:22 | 1:26 | 15:23 |
| 33 | 3 | X0 rows a | f120.69-f126.52 | 4.6516 | 4.8763 | 1:26 | 14 | 1:26 | 22 |
| 33 | 4 | X0 rows b | f120.69-f126.52 | 4.6516 | 4.8763 | 1:26 | 15:22 | 1:26 | 14:21 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 38 | 1 | X1 rows a | f114.08-f117.00 | 4.3968 | 4.5094 | 1:26 | 22 | 1:26 | 24 |
| 38 | 2 | X1 rows b | f114.08-f117.00 | 4.3968 | 4.5094 | 1:26 | 23:24 | 1:26 | 22:23 |
| 39 | 1 | X1 rows a | f117.00-f119.37 | 4.5094 | 4.6007 | 1:26 | 22 | 1:26 | 23 |
| 39 | 2 | X1 rows b | f117.00-f119.37 | 4.5094 | 4.6007 | 1:26 | 23 | 1:26 | 22 |
| 40 | 1 | X0 rows a | f120.69-f126.52 | 4.6516 | 4.8763 | 1:26 | 14 | 1:26 | 22 |
| 40 | 2 | X0 rows b | f120.69-f126.52 | 4.6516 | 4.8763 | 1:26 | 15:22 | 1:26 | 14:21 |

### A25. frames 127-130 -- X1+X0 rows f127-130 `18->20 \| 19:20->18:19`

the S2.1 read 14:18->16:20 | 19:20->14:15 fitted to f132.7-134.5 is wrong; what happens at f127-130 on BOTH X blocks is a 3-cycle of rows 18,19,20: fill 18.19 18.94 19.90 f127, 18.65 19.64 f128 (18->18.65 merged with 19->18.65), 18.27 19.20 19.70 f129, on tones f130; gold row 18 -> 20 (17.77-18.26, 18.46-18.88, 19.81), mauve rows 19,20 -> 18,19 (18.33 19.60, 18.13 19.16). X0 identical (18.65 19.64 f128; 18.27 19.20 19.70 f129). |  end moved from f130.23 to f130.23, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0617 (worst 0.794), moving-frame mean 0.025, free per-frame 0.0526, monotone 0.1229; window f126.70-f130.23 (t 4.8832-5.0193 ms); per species {'X1': 0.0639, 'X0': 0.0732, 'Z1': 6.4921, 'Z0': 6.4814}.

**Rows the automatic book had for X1+X0 in f127-130:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 33 | 3 | X0 rows a | f120.69-f126.52 | 4.6516 | 4.8763 | 1:26 | 14 | 1:26 | 22 |
| 33 | 4 | X0 rows b | f120.69-f126.52 | 4.6516 | 4.8763 | 1:26 | 15:22 | 1:26 | 14:21 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 40 | 1 | X0 rows a | f120.69-f126.52 | 4.6516 | 4.8763 | 1:26 | 14 | 1:26 | 22 |
| 40 | 2 | X0 rows b | f120.69-f126.52 | 4.6516 | 4.8763 | 1:26 | 15:22 | 1:26 | 14:21 |
| 41 | 1 | X1 rows a | f126.70-f130.23 | 4.8832 | 5.0193 | 1:26 | 18 | 1:26 | 20 |
| 41 | 2 | X1 rows b | f126.70-f130.23 | 4.8832 | 5.0193 | 1:26 | 19:20 | 1:26 | 18:19 |
| 42 | 1 | X0 rows a | f130.23-f132.44 | 5.0193 | 5.1045 | 1:26 | 14,16,20 | 1:26 | 15,17,21 |
| 42 | 2 | X0 rows b | f130.23-f132.44 | 5.0193 | 5.1045 | 1:26 | 15,17,21 | 1:26 | 14,16,20 |

### A26. frames 130-133 -- X0+X1 rows f130-133 `14,16,20->15,17,21 \| 15,17,21->14,16,20`

UNDETERMINED X0 rows f130-133 (and X1's, never enumerated): three pair swaps 14<->15, 16<->17, 20<->21. Mauve rows 14,16,20 -> 15,17,21 (13.96 16.00 20.05 f130; 14.35 16.14 20.39 f131; 15.02 16.82 20.98 f132) and gold rows 15,17,21 -> 14,16,20 (14.68 16.69 20.71 f130; 14.90 16.68 20.90 f131; 13.75-14.24 15.76-16.37 19.78-20.39 f132); fill 14.38 14.83 16.45 20.29 20.82 on f131 = the pairs approaching; on tones f133. X1 identical. |  start moved from f130.10 to f130.23, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0835 (worst 0.790), moving-frame mean 0.0791, free per-frame 0.1033, monotone 0.06; window f130.23-f132.44 (t 5.0193-5.1045 ms); per species {'X1': 0.0749, 'X0': 0.0823, 'Z1': 6.4913, 'Z0': 6.4806}.

**Rows the automatic book had for X0+X1 in f130-133:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 34 | 1 | X1 rows a | f132.68-f134.50 | 5.1137 | 5.1839 | 14:26 | 14:18 | 14:26 | 16:20 |
| 34 | 2 | X1 rows b | f132.68-f134.50 | 5.1137 | 5.1839 | 14:26 | 19:20 | 14:26 | 14:15 |
| 35 | 3 | X0 rows a | f132.68-f137.00 | 5.1137 | 5.2802 | 1:13 | 14:15 | 1:13 | 18:19 |
| 35 | 4 | X0 rows b | f132.68-f137.00 | 5.1137 | 5.2802 | 1:13 | 16:19 | 1:13 | 14:17 |
| 36 | 5 | X1 rows a | f132.68-f137.00 | 5.1137 | 5.2802 | 14:26 | 14 | 14:26 | 19 |
| 36 | 6 | X1 rows b | f132.68-f137.00 | 5.1137 | 5.2802 | 14:26 | 15 | 14:26 | 18 |
| 36 | 7 | X1 rows c | f132.68-f137.00 | 5.1137 | 5.2802 | 14:26 | 17:18 | 14:26 | 14:15 |
| 36 | 7 | X1 rows d | f132.68-f137.00 | 5.1137 | 5.2802 | 14:26 | 19 | 14:26 | 17 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 41 | 1 | X1 rows a | f126.70-f130.23 | 4.8832 | 5.0193 | 1:26 | 18 | 1:26 | 20 |
| 41 | 2 | X1 rows b | f126.70-f130.23 | 4.8832 | 5.0193 | 1:26 | 19:20 | 1:26 | 18:19 |
| 42 | 1 | X0 rows a | f130.23-f132.44 | 5.0193 | 5.1045 | 1:26 | 14,16,20 | 1:26 | 15,17,21 |
| 42 | 2 | X0 rows b | f130.23-f132.44 | 5.0193 | 5.1045 | 1:26 | 15,17,21 | 1:26 | 14,16,20 |
| 43 | 1 | X0 rows a | f132.68-f137.00 | 5.1137 | 5.2802 | 1:26 | 14:15 | 1:26 | 18:19 |
| 43 | 2 | X0 rows b | f132.68-f137.00 | 5.1137 | 5.2802 | 1:26 | 16:19 | 1:26 | 14:17 |

### A27. frames 133-136 -- X0+X1 rows f133-136 `14:15->18:19 \| 16:19->14:17`

rotation of the MEASURED moving run 14:19 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  X1 does the same 14:15->18:19 | 16:19->14:17 in the same batch (X1 gold rows 14,15 -> 18,19: 14.92 16.08 f134, 16.37-17.28 f135, 17.77 18.48 f136; mauve rows 16:19 -> 14:17: 15.57..18.85 f134, 14.87..17.82 f135, 14.31..17.61 f136), so X1's 4-part 14->19 | 15->18 | 17:18->14:15 | 19->17 is deleted and this rectangle spans cols 1:26.

Measured: smoothstep mean 0.0711 (worst 0.732), moving-frame mean 0.0634, free per-frame 0.0557, monotone 0.0; window f132.68-f137.00 (t 5.1137-5.2802 ms); per species {'X1': 0.0567, 'X0': 0.0711, 'Z1': 6.4675, 'Z0': 6.4569}.

**Rows the automatic book had for X0+X1 in f133-136:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 34 | 1 | X1 rows a | f132.68-f134.50 | 5.1137 | 5.1839 | 14:26 | 14:18 | 14:26 | 16:20 |
| 34 | 2 | X1 rows b | f132.68-f134.50 | 5.1137 | 5.1839 | 14:26 | 19:20 | 14:26 | 14:15 |
| 35 | 3 | X0 rows a | f132.68-f137.00 | 5.1137 | 5.2802 | 1:13 | 14:15 | 1:13 | 18:19 |
| 35 | 4 | X0 rows b | f132.68-f137.00 | 5.1137 | 5.2802 | 1:13 | 16:19 | 1:13 | 14:17 |
| 36 | 5 | X1 rows a | f132.68-f137.00 | 5.1137 | 5.2802 | 14:26 | 14 | 14:26 | 19 |
| 36 | 6 | X1 rows b | f132.68-f137.00 | 5.1137 | 5.2802 | 14:26 | 15 | 14:26 | 18 |
| 36 | 7 | X1 rows c | f132.68-f137.00 | 5.1137 | 5.2802 | 14:26 | 17:18 | 14:26 | 14:15 |
| 36 | 7 | X1 rows d | f132.68-f137.00 | 5.1137 | 5.2802 | 14:26 | 19 | 14:26 | 17 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 42 | 1 | X0 rows a | f130.23-f132.44 | 5.0193 | 5.1045 | 1:26 | 14,16,20 | 1:26 | 15,17,21 |
| 42 | 2 | X0 rows b | f130.23-f132.44 | 5.0193 | 5.1045 | 1:26 | 15,17,21 | 1:26 | 14,16,20 |
| 43 | 1 | X0 rows a | f132.68-f137.00 | 5.1137 | 5.2802 | 1:26 | 14:15 | 1:26 | 18:19 |
| 43 | 2 | X0 rows b | f132.68-f137.00 | 5.1137 | 5.2802 | 1:26 | 16:19 | 1:26 | 14:17 |

### A28. frames 138-145 -- X0 cols f138-145 `1:4->10:13 \| 5:13->1:9`

UNDETERMINED X0 cols f138-145 on rows 13:24 (the report guessed X0 rides Z1's 1:9->5:13 | 10:13->1:4). It is the OPPOSITE: X0 rotates like X1 (14:17->23:26 | 18:26->14:22): gold cols 1:4 -> 10:13 (2.03-5.04 f139, 5.43-8.48 f141, 8.91-12.21 f143, 9.61-13.23 f144) and mauve cols 5:13 -> 1:9 (4.65..12.57 f139, 2.88..10.93 f141, 1.37..9.67 f143, 1.07..9.08 f144).

Measured: smoothstep mean 0.0607 (worst 0.341), moving-frame mean 0.0706, free per-frame 0.0683, monotone 0.1219; window f137.06-f144.79 (t 5.2825-5.5804 ms); per species {'X1': 7.7857, 'X0': 0.0607, 'Z1': 0.1837, 'Z0': 6.5214}.

**Rows the automatic book had for X0 in f138-145:**

_(no rows)_

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 44 | 1 | X0 cols a | f137.06-f144.79 | 5.2825 | 5.5804 | 1:4 | 13:24 | 10:13 | 13:24 |
| 44 | 2 | X0 cols b | f137.06-f144.79 | 5.2825 | 5.5804 | 5:13 | 13:24 | 1:9 | 13:24 |
| 48 | 3 | X0 rows a | f145.00-f147.89 | 5.5885 | 5.6999 | 1:26 | 20:21 | 1:26 | 21:22 |
| 48 | 4 | X0 rows b | f145.00-f147.89 | 5.5885 | 5.6999 | 1:26 | 22 | 1:26 | 20 |

### A29. frames 145-152 -- Z1 rows f145-152 `25->34 \| 34->35 \| 35->25`

UNDETERMINED Z1 rows f145-152 on 25:36: mauve row 25 -> 34 (25.48 f146, 26.67 f147, 28.54 f148, 30.66 f149, 32.49 f150, 33.66 f151, 34.00 f152), gold row 35 -> 25 (34.92 f145, 34.29 f146, 32.92 f147, 28.46 f149, 26.53 f150, 25.36 f151, 25.01 f152) and row 34 -> 35 (34.23, 34.39, 34.62, 34.85, 34.93, 35.00); rows 26:33 static. |  end moved from f152.09 to f152.08, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0412 (worst 1.011), moving-frame mean 0.019, free per-frame 0.018, monotone 0.1056; window f144.80-f152.08 (t 5.5808-5.8614 ms); per species {'X1': 6.7305, 'X0': 6.735, 'Z1': 0.0337, 'Z0': 0.0867}.

**Rows the automatic book had for Z1 in f145-152:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 38 | 3 | Z1 cols a | f137.06-f144.79 | 5.2825 | 5.5804 | 1:9 | 25:36 | 5:13 | 25:36 |
| 38 | 4 | Z1 cols b | f137.06-f144.79 | 5.2825 | 5.5804 | 10:13 | 25:36 | 1:4 | 25:36 |
| 42 | 3 | Z1 rows a | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 27 | 1:13 | 36 |
| 42 | 4 | Z1 rows b | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 31 | 1:13 | 27 |
| 42 | 4 | Z1 rows c | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 36 | 1:13 | 31 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 46 | 3 | Z1 cols a | f137.06-f144.79 | 5.2825 | 5.5804 | 1:9 | 25:36 | 5:13 | 25:36 |
| 46 | 4 | Z1 cols b | f137.06-f144.79 | 5.2825 | 5.5804 | 10:13 | 25:36 | 1:4 | 25:36 |
| 47 | 1 | Z1 rows a | f144.80-f152.08 | 5.5808 | 5.8614 | 1:13 | 25 | 1:13 | 34 |
| 47 | 1 | Z1 rows b | f144.80-f152.08 | 5.5808 | 5.8614 | 1:13 | 34 | 1:13 | 35 |
| 47 | 2 | Z1 rows c | f144.80-f152.08 | 5.5808 | 5.8614 | 1:13 | 35 | 1:13 | 25 |
| 51 | 3 | Z1 rows a | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 27 | 1:13 | 36 |
| 51 | 4 | Z1 rows b | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 31 | 1:13 | 27 |
| 51 | 4 | Z1 rows c | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 36 | 1:13 | 31 |

### A30. frames 145-148 -- X0+X1 rows f145-148 `20:21->21:22 \| 22->20`

UNDETERMINED X0 and X1 rows f145-148: a 3-cycle of rows 20,21,22 -- mauve rows 20,21 -> 21,22 (20.41 21.71 f146, 20.96 21.69/22.17 f147) and gold row 22 -> 20 (21.01-21.63 f146, 20.01 20.50 f147); fill 20.34 21.22 f146, 20.36 20.88 21.82 f147, on tones f148. X1 identical (20.28 21.28 f146; 20.30 20.86 21.75 f147). |  end moved from f147.89 to f147.89, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0583 (worst 0.351), moving-frame mean 0.0536, free per-frame 0.0443, monotone 0.2825; window f145.00-f147.89 (t 5.5885-5.6999 ms); per species {'X1': 0.0489, 'X0': 0.0583, 'Z1': 6.7728, 'Z0': 6.4806}.

**Rows the automatic book had for X0+X1 in f145-148:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 37 | 1 | X1 cols a | f137.06-f144.79 | 5.2825 | 5.5804 | 14:17 | 13:24 | 23:26 | 13:24 |
| 37 | 2 | X1 cols b | f137.06-f144.79 | 5.2825 | 5.5804 | 18:26 | 13:24 | 14:22 | 13:24 |
| 39 | 1 | X0 rows a | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |
| 39 | 2 | X0 rows b | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 40 | 2 | X1 rows a | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 40 | 1 | X1 rows b | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 44 | 1 | X0 cols a | f137.06-f144.79 | 5.2825 | 5.5804 | 1:4 | 13:24 | 10:13 | 13:24 |
| 44 | 2 | X0 cols b | f137.06-f144.79 | 5.2825 | 5.5804 | 5:13 | 13:24 | 1:9 | 13:24 |
| 45 | 1 | X1 cols a | f137.06-f144.79 | 5.2825 | 5.5804 | 14:17 | 13:24 | 23:26 | 13:24 |
| 45 | 2 | X1 cols b | f137.06-f144.79 | 5.2825 | 5.5804 | 18:26 | 13:24 | 14:22 | 13:24 |
| 48 | 3 | X0 rows a | f145.00-f147.89 | 5.5885 | 5.6999 | 1:26 | 20:21 | 1:26 | 21:22 |
| 48 | 4 | X0 rows b | f145.00-f147.89 | 5.5885 | 5.6999 | 1:26 | 22 | 1:26 | 20 |
| 49 | 3 | X1 rows a | f147.89-f152.08 | 5.6999 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 49 | 4 | X1 rows b | f147.89-f152.08 | 5.6999 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |

### A31. frames 148-154 -- X1+X0 rows f148-154 `19:21->21:23 \| 22:23->19:20`

rotation of the MEASURED moving run 19:23 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  start moved from f147.87 to f147.89, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0574 (worst 0.717), moving-frame mean 0.0571, free per-frame 0.041, monotone 0.0; window f147.89-f152.08 (t 5.6999-5.8614 ms); per species {'X1': 0.0501, 'X0': 0.0618, 'Z1': 6.7536, 'Z0': 6.4806}.

**Rows the automatic book had for X1+X0 in f148-154:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 39 | 1 | X0 rows a | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |
| 39 | 2 | X0 rows b | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 40 | 2 | X1 rows a | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 40 | 1 | X1 rows b | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |
| 41 | 1 | X0 rows a | f152.08-f156.47 | 5.8614 | 6.0306 | 1:26 | 15 | 1:26 | 18 |
| 41 | 2 | X0 rows b | f152.08-f156.47 | 5.8614 | 6.0306 | 1:26 | 16:18 | 1:26 | 15:17 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 48 | 3 | X0 rows a | f145.00-f147.89 | 5.5885 | 5.6999 | 1:26 | 20:21 | 1:26 | 21:22 |
| 48 | 4 | X0 rows b | f145.00-f147.89 | 5.5885 | 5.6999 | 1:26 | 22 | 1:26 | 20 |
| 49 | 3 | X1 rows a | f147.89-f152.08 | 5.6999 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 49 | 4 | X1 rows b | f147.89-f152.08 | 5.6999 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |
| 50 | 1 | X0 rows a | f152.08-f156.20 | 5.8614 | 6.0202 | 1:26 | 15 | 1:26 | 18 |
| 50 | 2 | X0 rows b | f152.08-f156.20 | 5.8614 | 6.0202 | 1:26 | 16:18 | 1:26 | 15:17 |

### A32. frames 152-158 -- X1+X0 rows f152-158 `15->18 \| 16:18->15:17`

rotation of the MEASURED moving run 15:18 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  end moved from f156.47 to f156.20, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0867 (worst 0.901), moving-frame mean 0.0795, free per-frame 0.0577, monotone 0.0; window f152.08-f156.20 (t 5.8614-6.0202 ms); per species {'X1': 0.0529, 'X0': 0.0684, 'Z1': 6.4422, 'Z0': 6.4733}.

**Rows the automatic book had for X1+X0 in f152-158:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 39 | 1 | X0 rows a | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |
| 39 | 2 | X0 rows b | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 40 | 2 | X1 rows a | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 40 | 1 | X1 rows b | f147.87-f152.08 | 5.6992 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |
| 41 | 1 | X0 rows a | f152.08-f156.47 | 5.8614 | 6.0306 | 1:26 | 15 | 1:26 | 18 |
| 41 | 2 | X0 rows b | f152.08-f156.47 | 5.8614 | 6.0306 | 1:26 | 16:18 | 1:26 | 15:17 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 49 | 3 | X1 rows a | f147.89-f152.08 | 5.6999 | 5.8614 | 1:26 | 19:21 | 1:26 | 21:23 |
| 49 | 4 | X1 rows b | f147.89-f152.08 | 5.6999 | 5.8614 | 1:26 | 22:23 | 1:26 | 19:20 |
| 50 | 1 | X0 rows a | f152.08-f156.20 | 5.8614 | 6.0202 | 1:26 | 15 | 1:26 | 18 |
| 50 | 2 | X0 rows b | f152.08-f156.20 | 5.8614 | 6.0202 | 1:26 | 16:18 | 1:26 | 15:17 |
| 52 | 1 | X0 rows a | f156.20-f161.87 | 6.0202 | 6.2387 | 1:26 | 13:14 | 1:26 | 18:19 |
| 52 | 2 | X0 rows b | f156.20-f161.87 | 6.0202 | 6.2387 | 1:26 | 15:19 | 1:26 | 13:17 |

### A33. frames 152-161 -- Z1 rows f152-161 `27->36 \| 31->27 \| 36->31`

appearance triple (rule 3z): the outline colours name the sub-blocks directly -- CONTRADICTED by the moving-tone read, kept only because it out-scored every rotation of the measured run |  start moved from f152.08 to f152.08, the boundary with the block's previous move (chosen by measurement). |  end moved from f159.81 to f159.80, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0427 (worst 0.885), moving-frame mean 0.0398, free per-frame 0.0271, monotone 0.0; window f152.08-f159.80 (t 5.8614-6.1590 ms); per species {'X1': 6.442, 'X0': 6.4763, 'Z1': 0.0302, 'Z0': 0.1116}.

**Rows the automatic book had for Z1 in f152-161:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 42 | 3 | Z1 rows a | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 27 | 1:13 | 36 |
| 42 | 4 | Z1 rows b | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 31 | 1:13 | 27 |
| 42 | 4 | Z1 rows c | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 36 | 1:13 | 31 |
| 43 | 1 | Z1 rows a | f159.81-f163.11 | 6.1593 | 6.2865 | 1:13 | 26:29 | 1:13 | 30:33 |
| 43 | 2 | Z1 rows b | f159.81-f163.11 | 6.1593 | 6.2865 | 1:13 | 30:33 | 1:13 | 26:29 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 47 | 1 | Z1 rows a | f144.80-f152.08 | 5.5808 | 5.8614 | 1:13 | 25 | 1:13 | 34 |
| 47 | 1 | Z1 rows b | f144.80-f152.08 | 5.5808 | 5.8614 | 1:13 | 34 | 1:13 | 35 |
| 47 | 2 | Z1 rows c | f144.80-f152.08 | 5.5808 | 5.8614 | 1:13 | 35 | 1:13 | 25 |
| 51 | 3 | Z1 rows a | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 27 | 1:13 | 36 |
| 51 | 4 | Z1 rows b | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 31 | 1:13 | 27 |
| 51 | 4 | Z1 rows c | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 36 | 1:13 | 31 |
| 53 | 3 | Z1 rows a | f159.80-f165.59 | 6.1590 | 6.3821 | 1:13 | 26 | 1:13 | 32 |
| 53 | 3 | Z1 rows b | f159.80-f165.59 | 6.1590 | 6.3821 | 1:13 | 32 | 1:13 | 33 |
| 53 | 4 | Z1 rows c | f159.80-f165.59 | 6.1590 | 6.3821 | 1:13 | 33 | 1:13 | 26 |

### A34. frames 156-162 -- X0+X1 rows f156-162 `13:14->18:19 \| 15:19->13:17`

UNDETERMINED X0 and X1 rows f156-162: a rotation of rows 13:19 -- gold rows 13,14 -> 18,19 (12.82-14.33 f157, 13.59-15.09 f158, 15.62-16.56 f159, 16.95-18.23 f160, 17.53-18.95 f161) and mauve rows 15:19 -> 13:17 (14.99..18.91 f157, 14.40..18.62 f158, 13.28..17.30 f160, 13.13..17.08 f161); rows 20:24 static; on tones f162. X1 identical. |  start moved from f156.20 to f156.20, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0649 (worst 0.620), moving-frame mean 0.0474, free per-frame 0.0525, monotone 0.2391; window f156.20-f161.87 (t 6.0202-6.2387 ms); per species {'X1': 0.063, 'X0': 0.0649, 'Z1': 6.4546, 'Z0': 6.4805}.

**Rows the automatic book had for X0+X1 in f156-162:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 41 | 1 | X0 rows a | f152.08-f156.47 | 5.8614 | 6.0306 | 1:26 | 15 | 1:26 | 18 |
| 41 | 2 | X0 rows b | f152.08-f156.47 | 5.8614 | 6.0306 | 1:26 | 16:18 | 1:26 | 15:17 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 50 | 1 | X0 rows a | f152.08-f156.20 | 5.8614 | 6.0202 | 1:26 | 15 | 1:26 | 18 |
| 50 | 2 | X0 rows b | f152.08-f156.20 | 5.8614 | 6.0202 | 1:26 | 16:18 | 1:26 | 15:17 |
| 52 | 1 | X0 rows a | f156.20-f161.87 | 6.0202 | 6.2387 | 1:26 | 13:14 | 1:26 | 18:19 |
| 52 | 2 | X0 rows b | f156.20-f161.87 | 6.0202 | 6.2387 | 1:26 | 15:19 | 1:26 | 13:17 |
| 54 | 1 | X0 rows a | f162.02-f165.06 | 6.2445 | 6.3617 | 1:26 | 13,18 | 1:26 | 15,20 |
| 54 | 2 | X0 rows b | f162.02-f165.06 | 6.2445 | 6.3617 | 1:26 | 14:15,19:20 | 1:26 | 13:14,18:19 |

### A35. frames 160-166 -- Z1 rows f160-166 `26->32 \| 32->33 \| 33->26`

the last-resort 26:29->30:33 | 30:33->26:29 is wrong: rows 27:31 sit at 26.98 27.98 28.98 29.99 30.99 on f162-164. Three rows move: mauve row 26 -> 32 (26.62 f161, 27.85 f162, 29.58 f163, 30.98 f164, 31.80 f165), mauve row 32 -> 33 (32.12, 32.30, 32.60, 32.84, 32.96) and gold row 33 -> 26 (32.85 f160, 32.44 f161, 30.83 f162, 28.66 f163, 27.37 f164, 26.19 f165); on tones f166. |  start moved from f159.80 to f159.80, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0422 (worst 0.759), moving-frame mean 0.0224, free per-frame 0.02, monotone 0.1203; window f159.80-f165.59 (t 6.1590-6.3821 ms); per species {'X1': 6.5646, 'X0': 6.599, 'Z1': 0.0333, 'Z0': 0.0854}.

**Rows the automatic book had for Z1 in f160-166:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 42 | 3 | Z1 rows a | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 27 | 1:13 | 36 |
| 42 | 4 | Z1 rows b | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 31 | 1:13 | 27 |
| 42 | 4 | Z1 rows c | f152.08-f159.81 | 5.8614 | 6.1593 | 1:13 | 36 | 1:13 | 31 |
| 43 | 1 | Z1 rows a | f159.81-f163.11 | 6.1593 | 6.2865 | 1:13 | 26:29 | 1:13 | 30:33 |
| 43 | 2 | Z1 rows b | f159.81-f163.11 | 6.1593 | 6.2865 | 1:13 | 30:33 | 1:13 | 26:29 |
| 45 | 1 | Z1 rows a | f165.66-f169.52 | 6.3848 | 6.5336 | 1:13 | 30 | 1:13 | 28 |
| 45 | 2 | Z1 rows b | f165.66-f169.52 | 6.3848 | 6.5336 | 1:13 | 28:29 | 1:13 | 29:30 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 51 | 3 | Z1 rows a | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 27 | 1:13 | 36 |
| 51 | 4 | Z1 rows b | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 31 | 1:13 | 27 |
| 51 | 4 | Z1 rows c | f152.08-f159.80 | 5.8614 | 6.1590 | 1:13 | 36 | 1:13 | 31 |
| 53 | 3 | Z1 rows a | f159.80-f165.59 | 6.1590 | 6.3821 | 1:13 | 26 | 1:13 | 32 |
| 53 | 3 | Z1 rows b | f159.80-f165.59 | 6.1590 | 6.3821 | 1:13 | 32 | 1:13 | 33 |
| 53 | 4 | Z1 rows c | f159.80-f165.59 | 6.1590 | 6.3821 | 1:13 | 33 | 1:13 | 26 |
| 56 | 3 | Z1 rows a | f165.66-f169.52 | 6.3848 | 6.5336 | 1:13 | 30 | 1:13 | 28 |
| 56 | 4 | Z1 rows b | f165.66-f169.52 | 6.3848 | 6.5336 | 1:13 | 28:29 | 1:13 | 29:30 |

### A36. frames 162-165 -- X0+X1 rows f162-165 `13,18->15,20 \| 14,15,19,20->13,14,18,19`

the last-resort 13->20 | 14:20->13:19 (rotation of 13:20 by 7) is wrong: rows 16, 17 sit at 16.03 17.03 on every frame. Two 3-cycles: gold rows 13 -> 15 and 18 -> 20 (13.21 18.27 f163, 14.21-14.83 19.77 f164, 14.67-15.17 19.70-20.32 f165) and mauve rows 14,15 -> 13,14 and 19,20 -> 18,19 (13.74 14.73 18.80 19.78 f163, 13.28 13.98 18.25 19.27 f164, 13.20 14.04 17.99 19.04 f165). X1 identical (gold 13.25 18.23 f163, 14.70 15.16 19.70 20.19 f165), so one rectangle over cols 1:26.

Measured: smoothstep mean 0.0589 (worst 0.273), moving-frame mean 0.0502, free per-frame 0.0605, monotone 0.185; window f162.02-f165.06 (t 6.2445-6.3617 ms); per species {'X1': 0.0644, 'X0': 0.0589, 'Z1': 6.5234, 'Z0': 6.4806}.

**Rows the automatic book had for X0+X1 in f162-165:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 44 | 1 | X0 rows a | f165.66-f167.76 | 6.3848 | 6.4657 | 1:13 | 13 | 1:13 | 20 |
| 44 | 2 | X0 rows b | f165.66-f167.76 | 6.3848 | 6.4657 | 1:13 | 14:20 | 1:13 | 13:19 |
| 46 | 3 | X0 rows a | f165.66-f172.00 | 6.3848 | 6.6292 | 1:26 | 22:24 | 1:26 | 15:17 |
| 46 | 4 | X0 rows b | f165.66-f172.00 | 6.3848 | 6.6292 | 1:26 | 15:21 | 1:26 | 18:24 |
| 47 | 3 | X1 rows a | f165.66-f172.00 | 6.3848 | 6.6292 | 14:26 | 22:24 | 14:26 | 15:17 |
| 47 | 4 | X1 rows b | f165.66-f172.00 | 6.3848 | 6.6292 | 14:26 | 15:21 | 14:26 | 18:24 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 52 | 1 | X0 rows a | f156.20-f161.87 | 6.0202 | 6.2387 | 1:26 | 13:14 | 1:26 | 18:19 |
| 52 | 2 | X0 rows b | f156.20-f161.87 | 6.0202 | 6.2387 | 1:26 | 15:19 | 1:26 | 13:17 |
| 54 | 1 | X0 rows a | f162.02-f165.06 | 6.2445 | 6.3617 | 1:26 | 13,18 | 1:26 | 15,20 |
| 54 | 2 | X0 rows b | f162.02-f165.06 | 6.2445 | 6.3617 | 1:26 | 14:15,19:20 | 1:26 | 13:14,18:19 |
| 55 | 1 | X0 rows a | f165.42-f172.00 | 6.3756 | 6.6292 | 1:26 | 13:21 | 1:26 | 16:24 |
| 55 | 2 | X0 rows b | f165.42-f172.00 | 6.3756 | 6.6292 | 1:26 | 22:24 | 1:26 | 13:15 |

### A37. frames 165-171 -- X1+X0 rows f165-171 `13:21->16:24 \| 22:24->13:15`

the read 22:24->15:17 | 15:21->18:24 holds rows 13, 14 static; they move (13.45 14.48 f167, 13.78 14.91 f168, 14.64 15.64 f169). The whole block rotates by +3: mauve rows 13:21 -> 16:24 (13.36..21.71 f167, 14.63..22.66 f169, 15.60..23.28 f170, 15.45..23.73 f171) and gold rows 22:24 -> 13:15 (20.63-21.24 22.11-23.25 f167, 19.08-21.22 f168, 16.97-19.12 f169, 14.83-17.25 f170, 13.44-14.93 f171); on tones at the f172 pulse. X1 identical.

Measured: smoothstep mean 0.1287 (worst 0.537), moving-frame mean 0.0616, free per-frame 0.0616, monotone 0.0; window f165.42-f172.00 (t 6.3756-6.6292 ms); per species {'X1': 0.1399, 'X0': 0.1287, 'Z1': 6.7924, 'Z0': 6.7676}.

**Rows the automatic book had for X1+X0 in f165-171:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 44 | 1 | X0 rows a | f165.66-f167.76 | 6.3848 | 6.4657 | 1:13 | 13 | 1:13 | 20 |
| 44 | 2 | X0 rows b | f165.66-f167.76 | 6.3848 | 6.4657 | 1:13 | 14:20 | 1:13 | 13:19 |
| 46 | 3 | X0 rows a | f165.66-f172.00 | 6.3848 | 6.6292 | 1:26 | 22:24 | 1:26 | 15:17 |
| 46 | 4 | X0 rows b | f165.66-f172.00 | 6.3848 | 6.6292 | 1:26 | 15:21 | 1:26 | 18:24 |
| 47 | 3 | X1 rows a | f165.66-f172.00 | 6.3848 | 6.6292 | 14:26 | 22:24 | 14:26 | 15:17 |
| 47 | 4 | X1 rows b | f165.66-f172.00 | 6.3848 | 6.6292 | 14:26 | 15:21 | 14:26 | 18:24 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 54 | 1 | X0 rows a | f162.02-f165.06 | 6.2445 | 6.3617 | 1:26 | 13,18 | 1:26 | 15,20 |
| 54 | 2 | X0 rows b | f162.02-f165.06 | 6.2445 | 6.3617 | 1:26 | 14:15,19:20 | 1:26 | 13:14,18:19 |
| 55 | 1 | X0 rows a | f165.42-f172.00 | 6.3756 | 6.6292 | 1:26 | 13:21 | 1:26 | 16:24 |
| 55 | 2 | X0 rows b | f165.42-f172.00 | 6.3756 | 6.6292 | 1:26 | 22:24 | 1:26 | 13:15 |

### A38. frames 178-189 -- X0 rows f178-189 `13->30 \| 14->33 \| 15->35 \| 18->36 \| 16,19->31,34`

FAULT D, step 1: the 8-part read (0.276) had every row moving; six rows stay (17, 20:24 at 17.03 20.05 21.01 21.98 22.98 23.97 on every frame f180-189) and six descend to 30,31,33,34,35,36. The mauve pair 16,19 -> 31,34 (16.78 19.54 f180, 17.95 20.63 f181, 24.33 27.17/27.66 f184, 29.85 32.54/33.02 f187, 30.99 34.00 f189) is rigid (+15); the gold rows 13,14,15,18 travel +17,+19,+20,+18 (22.10-22.59 24.80 25.81-26.42 27.73-28.15 at f184 = p 0.55; 28.43-29.05 31.29-31.71 33.63 34.31-34.80 at f187 = p 0.92; 29.67-30.16 32.69-33.18 34.70-35.31 35.70-36.32 at f189). The fill cannot tell 16,19->31,34 from 14,16->31,34, the outline colours can. |  end moved from f189.40 to f189.40, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0803 (worst 1.114), moving-frame mean 0.0685, free per-frame 0.0681, monotone 0.0; window f178.00-f189.40 (t 6.8604-7.2998 ms); per species {'X1': 1.3392, 'X0': 0.0803, 'Z1': 1.3512, 'Z0': 10.2094}.

**Rows the automatic book had for X0 in f178-189:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 48 | 1 | X0 rows a | f181.75-f187.81 | 7.0049 | 7.2385 | 1:13 | 16,19 | 1:13 | 31,34 |
| 48 | 1 | X0 rows b | f181.75-f187.81 | 7.0049 | 7.2385 | 1:13 | 13 | 1:13 | 17 |
| 48 | 1 | X0 rows c | f181.75-f187.81 | 7.0049 | 7.2385 | 1:13 | 14:15 | 1:13 | 20:21 |
| 48 | 2 | X0 rows d | f181.75-f187.81 | 7.0049 | 7.2385 | 1:13 | 17:18 | 1:13 | 22:23 |
| 48 | 2 | X0 rows e | f181.75-f187.81 | 7.0049 | 7.2385 | 1:13 | 20 | 1:13 | 24 |
| 48 | 2 | X0 rows f | f181.75-f187.81 | 7.0049 | 7.2385 | 1:13 | 21 | 1:13 | 30 |
| 48 | 2 | X0 rows g | f181.75-f187.81 | 7.0049 | 7.2385 | 1:13 | 22 | 1:13 | 33 |
| 48 | 1 | X0 rows h | f181.75-f187.81 | 7.0049 | 7.2385 | 1:13 | 23:24 | 1:13 | 35:36 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 57 | 1 | X0 rows a | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 13 | 1:13 | 30 |
| 57 | 1 | X0 rows b | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 14 | 1:13 | 33 |
| 57 | 1 | X0 rows c | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 15 | 1:13 | 35 |
| 57 | 1 | X0 rows d | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 18 | 1:13 | 36 |
| 57 | 2 | X0 rows e | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 16,19 | 1:13 | 31,34 |
| 58 | 1 | X0 rows a | f189.40-f197.29 | 7.2998 | 7.6039 | 1:13 | 17 | 1:13 | 27 |
| 58 | 1 | X0 rows b | f189.40-f197.29 | 7.2998 | 7.6039 | 1:13 | 21 | 1:13 | 32 |
| 58 | 2 | X0 rows c | f189.40-f197.29 | 7.2998 | 7.6039 | 1:13 | 20,22:23 | 1:13 | 26,28:29 |

### A39. frames 189-197 -- X0 rows f189-197 `17->27 \| 21->32 \| 20,22,23->26,28,29`

FAULT D, step 2 (the UNDETERMINED relocation 17,20:24,30:31,33:36 -> 24,26:36): five rows descend into the gaps, row 24 waits (23.97 on f190-197, it goes 24->25 in the next move). Mauve rows 20,22,23 -> 26,28,29 (19.85/20.33 22.15 22.87/23.32 f190, 22.77 24.82 25.50 f193, 25.76 27.75 28.75 f196, 26.10 28.03 29.02 f197: +6 rigid) and gold rows 17 -> 27 and 21 -> 32 (16.92/17.41 21.26 f190, 21.40-22.01 25.81-26.30 f193, 26.27/26.76 31.22-31.84 f196, 26.73/27.15 31.68/32.17 f197: +10 and +11). |  start moved from f189.00 to f189.40, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0933 (worst 0.597), moving-frame mean 0.0435, free per-frame 0.0413, monotone 0.0; window f189.40-f197.29 (t 7.2998-7.6039 ms); per species {'X1': 4.4632, 'X0': 0.0592, 'Z1': 4.5877, 'Z0': 15.8702}.

**Rows the automatic book had for X0 in f189-197:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 49 | 1 | X0 rows a | f196.87-f205.83 | 7.5877 | 7.9330 | 1:13 | 24 | 1:13 | 25 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 57 | 1 | X0 rows a | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 13 | 1:13 | 30 |
| 57 | 1 | X0 rows b | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 14 | 1:13 | 33 |
| 57 | 1 | X0 rows c | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 15 | 1:13 | 35 |
| 57 | 1 | X0 rows d | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 18 | 1:13 | 36 |
| 57 | 2 | X0 rows e | f178.00-f189.40 | 6.8604 | 7.2998 | 1:13 | 16,19 | 1:13 | 31,34 |
| 58 | 1 | X0 rows a | f189.40-f197.29 | 7.2998 | 7.6039 | 1:13 | 17 | 1:13 | 27 |
| 58 | 1 | X0 rows b | f189.40-f197.29 | 7.2998 | 7.6039 | 1:13 | 21 | 1:13 | 32 |
| 58 | 2 | X0 rows c | f189.40-f197.29 | 7.2998 | 7.6039 | 1:13 | 20,22:23 | 1:13 | 26,28:29 |
| 60 | 1 | X0 rows a | f197.29-f205.41 | 7.6039 | 7.9168 | 1:13 | 24 | 1:13 | 25 |

### A40. frames 199-206 -- X0 rows f199-206 `24->25`

appearance triple (rule 3z): the outline colours name the sub-blocks directly |  start clipped to f197.29, after the second descent step.

Measured: smoothstep mean 0.0275 (worst 0.106), moving-frame mean 0.0249, free per-frame 0.0249, monotone 0.0; window f197.29-f205.41 (t 7.6039-7.9168 ms); per species {'X1': 2.218, 'X0': 0.0275, 'Z1': 6.288, 'Z0': 18.2927}.

**Rows the automatic book had for X0 in f199-206:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 49 | 1 | X0 rows a | f196.87-f205.83 | 7.5877 | 7.9330 | 1:13 | 24 | 1:13 | 25 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 60 | 1 | X0 rows a | f197.29-f205.41 | 7.6039 | 7.9168 | 1:13 | 24 | 1:13 | 25 |

### A41. frames 216-224 -- X0 cols f216-224 `1:3->11:13 \| 4:13->1:10`

rotation of the MEASURED moving run 1:13 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  start moved from f214.00 to f214.56, after the Z carry-in (flat easing, no measurable change).

Measured: smoothstep mean 0.1028 (worst 0.612), moving-frame mean 0.0641, free per-frame 0.0555, monotone 0.0; window f214.56-f221.60 (t 8.2695-8.5408 ms); per species {'X1': 7.3445, 'X0': 0.0568, 'Z1': 0.1628, 'Z0': 0.1735}.

**Rows the automatic book had for X0 in f216-224:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 51 | 1 | X0 cols a | f214.00-f221.60 | 8.2479 | 8.5408 | 1:3 | 25:36 | 11:13 | 25:36 |
| 51 | 2 | X0 cols b | f214.00-f221.60 | 8.2479 | 8.5408 | 4:13 | 25:36 | 1:10 | 25:36 |
| 53 | 1 | X0 rows a | f221.60-f225.27 | 8.5408 | 8.6823 | 1:13 | 28:29 | 1:13 | 30:31 |
| 53 | 2 | X0 rows b | f221.60-f225.27 | 8.5408 | 8.6823 | 1:13 | 30:31 | 1:13 | 28:29 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 61 | 1 | X0 cols a | f214.56-f221.60 | 8.2695 | 8.5408 | 1:3 | 25:36 | 11:13 | 25:36 |
| 61 | 2 | X0 cols b | f214.56-f221.60 | 8.2695 | 8.5408 | 4:13 | 25:36 | 1:10 | 25:36 |
| 63 | 1 | X0 rows a | f221.60-f225.20 | 8.5408 | 8.6796 | 1:13 | 28:29 | 1:13 | 30:31 |
| 63 | 2 | X0 rows b | f221.60-f225.20 | 8.5408 | 8.6796 | 1:13 | 30:31 | 1:13 | 28:29 |

### A42. frames 216-224 -- Z1+Z0 cols f216-224 `1:10->4:13 \| 11:13->1:3`

rotation of the MEASURED moving run 1:13 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  start moved from f214.00 to f214.56, after the Z carry-in (flat easing, no measurable change).

Measured: smoothstep mean 0.1333 (worst 0.545), moving-frame mean 0.0426, free per-frame 0.043, monotone 0.0; window f214.56-f221.60 (t 8.2695-8.5408 ms); per species {'X1': 7.3367, 'X0': 0.1811, 'Z1': 0.0306, 'Z0': 0.04}.

**Rows the automatic book had for Z1+Z0 in f216-224:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 52 | 3 | Z0 cols a | f214.00-f221.60 | 8.2479 | 8.5408 | 1:10 | 1:24 | 4:13 | 1:24 |
| 52 | 4 | Z0 cols b | f214.00-f221.60 | 8.2479 | 8.5408 | 11:13 | 1:24 | 1:3 | 1:24 |
| 54 | 1 | Z0 rows a | f221.60-f225.27 | 8.5408 | 8.6823 | 1:13 | 3 | 1:13 | 2 |
| 54 | 2 | Z0 rows b | f221.60-f225.27 | 8.5408 | 8.6823 | 1:13 | 2 | 1:13 | 3 |
| 55 | 3 | Z0 rows a | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 1:5 | 1:13 | 8:12 |
| 55 | 4 | Z0 rows b | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 6:12 | 1:13 | 1:7 |
| 56 | 1 | Z1 rows a | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 13:17 | 1:13 | 20:24 |
| 56 | 2 | Z1 rows b | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 18:24 | 1:13 | 13:19 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 62 | 3 | Z0 cols a | f214.56-f221.60 | 8.2695 | 8.5408 | 1:10 | 1:24 | 4:13 | 1:24 |
| 62 | 4 | Z0 cols b | f214.56-f221.60 | 8.2695 | 8.5408 | 11:13 | 1:24 | 1:3 | 1:24 |
| 64 | 1 | Z1 rows a | f221.60-f228.45 | 8.5408 | 8.8048 | 1:13 | 13:17 | 1:13 | 20:24 |
| 64 | 2 | Z1 rows b | f221.60-f228.45 | 8.5408 | 8.8048 | 1:13 | 18:24 | 1:13 | 13:19 |
| 65 | 1 | Z0 rows a | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 1:5 | 1:13 | 8:12 |
| 65 | 2 | Z0 rows b | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 6:12 | 1:13 | 1:7 |

### A43. frames 222-227 -- X0 rows f222-227 `28:29->30:31 \| 30:31->28:29`

appearance triple (rule 3z): the outline colours name the sub-blocks directly |  end moved from f225.27 to f225.20, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0619 (worst 0.450), moving-frame mean 0.0756, free per-frame 0.0223, monotone 0.0; window f221.60-f225.20 (t 8.5408-8.6796 ms); per species {'X1': 0.0673, 'X0': 0.0616, 'Z1': 7.0841, 'Z0': 19.1074}.

**Rows the automatic book had for X0 in f222-227:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 51 | 1 | X0 cols a | f214.00-f221.60 | 8.2479 | 8.5408 | 1:3 | 25:36 | 11:13 | 25:36 |
| 51 | 2 | X0 cols b | f214.00-f221.60 | 8.2479 | 8.5408 | 4:13 | 25:36 | 1:10 | 25:36 |
| 53 | 1 | X0 rows a | f221.60-f225.27 | 8.5408 | 8.6823 | 1:13 | 28:29 | 1:13 | 30:31 |
| 53 | 2 | X0 rows b | f221.60-f225.27 | 8.5408 | 8.6823 | 1:13 | 30:31 | 1:13 | 28:29 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 61 | 1 | X0 cols a | f214.56-f221.60 | 8.2695 | 8.5408 | 1:3 | 25:36 | 11:13 | 25:36 |
| 61 | 2 | X0 cols b | f214.56-f221.60 | 8.2695 | 8.5408 | 4:13 | 25:36 | 1:10 | 25:36 |
| 63 | 1 | X0 rows a | f221.60-f225.20 | 8.5408 | 8.6796 | 1:13 | 28:29 | 1:13 | 30:31 |
| 63 | 2 | X0 rows b | f221.60-f225.20 | 8.5408 | 8.6796 | 1:13 | 30:31 | 1:13 | 28:29 |
| 66 | 1 | X0 rows a | f225.20-f228.62 | 8.6796 | 8.8114 | 1:13 | 27:28,31:32 | 1:13 | 28:29,32:33 |
| 66 | 2 | X0 rows b | f225.20-f228.62 | 8.6796 | 8.8114 | 1:13 | 29,33 | 1:13 | 27,31 |

### A44. frames 222-230 -- Z1 rows f222-230 `13:17->20:24 \| 18:24->13:19`

rotation of the whole comb (session 26): a 3+-part appearance read over the guideline competes against the one-integer family |  end moved from f228.51 to f228.45, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0315 (worst 0.214), moving-frame mean 0.0389, free per-frame 0.0345, monotone 0.0; window f221.60-f228.45 (t 8.5408-8.8048 ms); per species {'X1': 6.9005, 'X0': 6.884, 'Z1': 0.0335, 'Z0': 7.081}.

**Rows the automatic book had for Z1 in f222-230:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 56 | 1 | Z1 rows a | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 13:17 | 1:13 | 20:24 |
| 56 | 2 | Z1 rows b | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 18:24 | 1:13 | 13:19 |
| 60 | 1 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21 | 1:13 | 20 |
| 60 | 2 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 21 |
| 61 | 3 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 23 |
| 61 | 1 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21:23 | 1:13 | 20:22 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 64 | 1 | Z1 rows a | f221.60-f228.45 | 8.5408 | 8.8048 | 1:13 | 13:17 | 1:13 | 20:24 |
| 64 | 2 | Z1 rows b | f221.60-f228.45 | 8.5408 | 8.8048 | 1:13 | 18:24 | 1:13 | 13:19 |
| 67 | 1 | Z1 rows a | f228.45-f230.40 | 8.8048 | 8.8800 | 1:13 | 21 | 1:13 | 22 |
| 67 | 2 | Z1 rows b | f228.45-f230.40 | 8.8048 | 8.8800 | 1:13 | 22 | 1:13 | 21 |
| 71 | 1 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 23 |
| 71 | 2 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21:23 | 1:13 | 20:22 |

### A45. frames 225-229 -- X0 rows f225-229 `27,28,31,32->28,29,32,33 \| 29,33->27,31`

UNDETERMINED X0 rows f225-229: two 3-cycles on {27,28,29} and {31,32,33}: mauve rows 27,28,31,32 -> 28,29,32,33 (26.81/27.27 28.11 31.17 32.15 f226; 27.40 28.35/28.82 31.37 32.56 f227; 27.99 28.94 31.93 32.75/33.23 f228) and gold rows 29,33 -> 27,31 (28.51-29.13 32.53-33.15 f226; 27.84 31.79 f227; 26.89/27.30 30.83/31.32 f228); on tones f229. |  start moved from f225.20 to f225.20, the boundary with the block's previous move (chosen by measurement). |  end moved from f228.72 to f228.62, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0724 (worst 0.595), moving-frame mean 0.0322, free per-frame 0.0322, monotone 0.1583; window f225.20-f228.62 (t 8.6796-8.8114 ms); per species {'X1': 0.0591, 'X0': 0.0714, 'Z1': 6.9623, 'Z0': 18.9809}.

**Rows the automatic book had for X0 in f225-229:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 53 | 1 | X0 rows a | f221.60-f225.27 | 8.5408 | 8.6823 | 1:13 | 28:29 | 1:13 | 30:31 |
| 53 | 2 | X0 rows b | f221.60-f225.27 | 8.5408 | 8.6823 | 1:13 | 30:31 | 1:13 | 28:29 |
| 58 | 1 | X0 rows a | f228.51-f234.16 | 8.8072 | 9.0249 | 1:13 | 30:31 | 1:13 | 26:27 |
| 58 | 2 | X0 rows b | f228.51-f234.16 | 8.8072 | 9.0249 | 1:13 | 26:29 | 1:13 | 28:31 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 63 | 1 | X0 rows a | f221.60-f225.20 | 8.5408 | 8.6796 | 1:13 | 28:29 | 1:13 | 30:31 |
| 63 | 2 | X0 rows b | f221.60-f225.20 | 8.5408 | 8.6796 | 1:13 | 30:31 | 1:13 | 28:29 |
| 66 | 1 | X0 rows a | f225.20-f228.62 | 8.6796 | 8.8114 | 1:13 | 27:28,31:32 | 1:13 | 28:29,32:33 |
| 66 | 2 | X0 rows b | f225.20-f228.62 | 8.6796 | 8.8114 | 1:13 | 29,33 | 1:13 | 27,31 |
| 69 | 1 | X0 rows a | f228.62-f234.16 | 8.8114 | 9.0249 | 1:13 | 30:31 | 1:13 | 26:27 |
| 69 | 2 | X0 rows b | f228.62-f234.16 | 8.8114 | 9.0249 | 1:13 | 26:29 | 1:13 | 28:31 |

### A46. frames 228-233 -- Z1 rows f228-233 `21->22 \| 22->21`

the read 21->20 | 20->21 (fitted to f230.4-235.1, the NEXT move's window) swaps the wrong pair: row 20 sits at 20.00 on f229-230 while rows 21 and 22 are at 21.18/21.79 (f229) and 21.15/21.86 (f230), on tones at f231; the outline classes cross between f229 and f230 (mauve 21.82 -> 21.13, gold 21.09 -> 21.90). It is 21<->22, the twin of Z0's written 9<->10 at f228-231. |  start moved from f228.40 to f228.45, the boundary with the block's previous move (chosen by measurement). |  end moved from f230.65 to f230.40, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0950 (worst 0.780), moving-frame mean 0.131, free per-frame 0.131, monotone 0.1075; window f228.45-f230.40 (t 8.8048-8.8800 ms); per species {'X1': 6.5291, 'X0': 6.5262, 'Z1': 0.0932, 'Z0': 6.5836}.

**Rows the automatic book had for Z1 in f228-233:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 56 | 1 | Z1 rows a | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 13:17 | 1:13 | 20:24 |
| 56 | 2 | Z1 rows b | f221.60-f228.51 | 8.5408 | 8.8072 | 1:13 | 18:24 | 1:13 | 13:19 |
| 60 | 1 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21 | 1:13 | 20 |
| 60 | 2 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 21 |
| 61 | 3 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 23 |
| 61 | 1 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21:23 | 1:13 | 20:22 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 64 | 1 | Z1 rows a | f221.60-f228.45 | 8.5408 | 8.8048 | 1:13 | 13:17 | 1:13 | 20:24 |
| 64 | 2 | Z1 rows b | f221.60-f228.45 | 8.5408 | 8.8048 | 1:13 | 18:24 | 1:13 | 13:19 |
| 67 | 1 | Z1 rows a | f228.45-f230.40 | 8.8048 | 8.8800 | 1:13 | 21 | 1:13 | 22 |
| 67 | 2 | Z1 rows b | f228.45-f230.40 | 8.8048 | 8.8800 | 1:13 | 22 | 1:13 | 21 |
| 71 | 1 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 23 |
| 71 | 2 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21:23 | 1:13 | 20:22 |

### A47. frames 229-235 -- X0 rows f229-235 `30:31->26:27 \| 26:29->28:31`

appearance triple (rule 3z): the outline colours name the sub-blocks directly |  start moved from f228.51 to f228.62, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0948 (worst 0.822), moving-frame mean 0.0547, free per-frame 0.0351, monotone 0.0; window f228.62-f234.16 (t 8.8114-9.0249 ms); per species {'X1': 0.0892, 'X0': 0.043, 'Z1': 6.5448, 'Z0': 18.5481}.

**Rows the automatic book had for X0 in f229-235:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 58 | 1 | X0 rows a | f228.51-f234.16 | 8.8072 | 9.0249 | 1:13 | 30:31 | 1:13 | 26:27 |
| 58 | 2 | X0 rows b | f228.51-f234.16 | 8.8072 | 9.0249 | 1:13 | 26:29 | 1:13 | 28:31 |
| 62 | 1 | X0 rows a | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 36 | 1:13 | 32 |
| 62 | 2 | X0 rows b | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 32:35 | 1:13 | 33:36 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 66 | 1 | X0 rows a | f225.20-f228.62 | 8.6796 | 8.8114 | 1:13 | 27:28,31:32 | 1:13 | 28:29,32:33 |
| 66 | 2 | X0 rows b | f225.20-f228.62 | 8.6796 | 8.8114 | 1:13 | 29,33 | 1:13 | 27,31 |
| 69 | 1 | X0 rows a | f228.62-f234.16 | 8.8114 | 9.0249 | 1:13 | 30:31 | 1:13 | 26:27 |
| 69 | 2 | X0 rows b | f228.62-f234.16 | 8.8114 | 9.0249 | 1:13 | 26:29 | 1:13 | 28:31 |
| 72 | 1 | X0 rows a | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 36 | 1:13 | 32 |
| 72 | 2 | X0 rows b | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 32:35 | 1:13 | 33:36 |

### A48. frames 231-237 -- Z0 rows f231-237 `8->11 \| 9:11->8:10`

LAST-RESORT rotation of the measured moving run 8:11 (session 27): no outline and no displacement fit described this transition, so the one-integer family is ranked on the FREE per-frame progress (mean error 0.0131 site, monotone penalty 0.000); committed only because no other species' rectangle carries the transition |  end moved from f235.08 to f235.08, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0399 (worst 0.622), moving-frame mean 0.0581, free per-frame 0.0106, monotone 0.0; window f230.40-f235.08 (t 8.8800-9.0604 ms); per species {'X1': 18.5425, 'X0': 18.4872, 'Z1': 6.4593, 'Z0': 0.0422}.

**Rows the automatic book had for Z0 in f231-237:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 57 | 1 | Z0 rows a | f228.51-f230.40 | 8.8072 | 8.8800 | 1:13 | 9 | 1:13 | 10 |
| 57 | 2 | Z0 rows b | f228.51-f230.40 | 8.8072 | 8.8800 | 1:13 | 10 | 1:13 | 9 |
| 59 | 1 | Z0 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 8 | 1:13 | 11 |
| 59 | 2 | Z0 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 9:11 | 1:13 | 8:10 |
| 63 | 1 | Z0 rows a | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 5,7,11 | 1:13 | 6,8,12 |
| 63 | 2 | Z0 rows b | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 6,8,12 | 1:13 | 5,7,11 |
| 65 | 1 | Z0 rows a | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 3 | 1:13 | 9 |
| 65 | 2 | Z0 rows b | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 4:9 | 1:13 | 3:8 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 68 | 1 | Z0 rows a | f228.51-f230.40 | 8.8072 | 8.8800 | 1:13 | 9 | 1:13 | 10 |
| 68 | 2 | Z0 rows b | f228.51-f230.40 | 8.8072 | 8.8800 | 1:13 | 10 | 1:13 | 9 |
| 70 | 1 | Z0 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 8 | 1:13 | 11 |
| 70 | 2 | Z0 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 9:11 | 1:13 | 8:10 |
| 73 | 1 | Z0 rows a | f235.08-f237.18 | 9.0604 | 9.1413 | 1:13 | 5,7,11 | 1:13 | 6,8,12 |
| 73 | 2 | Z0 rows b | f235.08-f237.18 | 9.0604 | 9.1413 | 1:13 | 6,8,12 | 1:13 | 5,7,11 |
| 75 | 1 | Z0 rows a | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 3 | 1:13 | 9 |
| 75 | 2 | Z0 rows b | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 4:9 | 1:13 | 3:8 |

### A49. frames 231-237 -- Z1 rows f231-237 `20->23 \| 21:23->20:22`

appearance triple (rule 3z): the outline colours name the sub-blocks directly |  start moved from f230.40 to f230.40, the boundary with the block's previous move (chosen by measurement). |  end moved from f235.08 to f235.08, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0369 (worst 0.557), moving-frame mean 0.0573, free per-frame 0.0108, monotone 0.0; window f230.40-f235.08 (t 8.8800-9.0604 ms); per species {'X1': 6.5424, 'X0': 6.487, 'Z1': 0.037, 'Z0': 6.5842}.

**Rows the automatic book had for Z1 in f231-237:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 60 | 1 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21 | 1:13 | 20 |
| 60 | 2 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 21 |
| 61 | 3 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 23 |
| 61 | 1 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21:23 | 1:13 | 20:22 |
| 64 | 1 | Z1 rows a | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 18,20 | 1:13 | 17,19 |
| 64 | 1 | Z1 rows b | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 24 | 1:13 | 23 |
| 64 | 2 | Z1 rows c | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 17,19,23 | 1:13 | 18,20,24 |
| 66 | 1 | Z1 rows a | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 15 | 1:13 | 21 |
| 66 | 2 | Z1 rows b | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 16:21 | 1:13 | 15:20 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 67 | 1 | Z1 rows a | f228.45-f230.40 | 8.8048 | 8.8800 | 1:13 | 21 | 1:13 | 22 |
| 67 | 2 | Z1 rows b | f228.45-f230.40 | 8.8048 | 8.8800 | 1:13 | 22 | 1:13 | 21 |
| 71 | 1 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 23 |
| 71 | 2 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21:23 | 1:13 | 20:22 |
| 74 | 1 | Z1 rows a | f235.08-f237.18 | 9.0604 | 9.1413 | 1:13 | 18,20,24 | 1:13 | 17,19,23 |
| 74 | 2 | Z1 rows b | f235.08-f237.18 | 9.0604 | 9.1413 | 1:13 | 17,19,23 | 1:13 | 18,20,24 |
| 76 | 1 | Z1 rows a | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 15 | 1:13 | 21 |
| 76 | 2 | Z1 rows b | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 16:21 | 1:13 | 15:20 |

### A50. frames 235-239 -- Z0 rows f235-239 `5,7,11->6,8,12 \| 6,8,12->5,7,11`

appearance triple (rule 3z): the outline colours name the sub-blocks directly |  start moved from f234.16 to f235.08, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0523 (worst 0.843), moving-frame mean 0.0717, free per-frame 0.0224, monotone 0.0; window f235.08-f237.18 (t 9.0604-9.1413 ms); per species {'X1': 18.6306, 'X0': 18.5427, 'Z1': 6.5605, 'Z0': 0.0502}.

**Rows the automatic book had for Z0 in f235-239:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 59 | 1 | Z0 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 8 | 1:13 | 11 |
| 59 | 2 | Z0 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 9:11 | 1:13 | 8:10 |
| 63 | 1 | Z0 rows a | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 5,7,11 | 1:13 | 6,8,12 |
| 63 | 2 | Z0 rows b | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 6,8,12 | 1:13 | 5,7,11 |
| 65 | 1 | Z0 rows a | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 3 | 1:13 | 9 |
| 65 | 2 | Z0 rows b | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 4:9 | 1:13 | 3:8 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 70 | 1 | Z0 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 8 | 1:13 | 11 |
| 70 | 2 | Z0 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 9:11 | 1:13 | 8:10 |
| 73 | 1 | Z0 rows a | f235.08-f237.18 | 9.0604 | 9.1413 | 1:13 | 5,7,11 | 1:13 | 6,8,12 |
| 73 | 2 | Z0 rows b | f235.08-f237.18 | 9.0604 | 9.1413 | 1:13 | 6,8,12 | 1:13 | 5,7,11 |
| 75 | 1 | Z0 rows a | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 3 | 1:13 | 9 |
| 75 | 2 | Z0 rows b | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 4:9 | 1:13 | 3:8 |

### A51. frames 235-239 -- Z1 rows f235-239 `18,20,24->17,19,23 \| 17,19,23->18,20,24`

the same map (three pair swaps 17<->18, 19<->20, 23<->24: mauve 18.00 20.01 23.99 -> 16.99 19.00 23.02, gold 17.05 19.00 22.97 -> 17.93 19.95 23.98 on f235-237) written as TWO rigid groups instead of three (18,20 and 24 share D = -1): one crossed pair less. |  start moved from f234.16 to f235.08, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0405 (worst 0.832), moving-frame mean 0.0211, free per-frame 0.0159, monotone 0.0875; window f235.08-f237.18 (t 9.0604-9.1413 ms); per species {'X1': 6.573, 'X0': 6.4838, 'Z1': 0.0492, 'Z0': 6.616}.

**Rows the automatic book had for Z1 in f235-239:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 60 | 1 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21 | 1:13 | 20 |
| 60 | 2 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 21 |
| 61 | 3 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 23 |
| 61 | 1 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21:23 | 1:13 | 20:22 |
| 64 | 1 | Z1 rows a | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 18,20 | 1:13 | 17,19 |
| 64 | 1 | Z1 rows b | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 24 | 1:13 | 23 |
| 64 | 2 | Z1 rows c | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 17,19,23 | 1:13 | 18,20,24 |
| 66 | 1 | Z1 rows a | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 15 | 1:13 | 21 |
| 66 | 2 | Z1 rows b | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 16:21 | 1:13 | 15:20 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 71 | 1 | Z1 rows a | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 20 | 1:13 | 23 |
| 71 | 2 | Z1 rows b | f230.40-f235.08 | 8.8800 | 9.0604 | 1:13 | 21:23 | 1:13 | 20:22 |
| 74 | 1 | Z1 rows a | f235.08-f237.18 | 9.0604 | 9.1413 | 1:13 | 18,20,24 | 1:13 | 17,19,23 |
| 74 | 2 | Z1 rows b | f235.08-f237.18 | 9.0604 | 9.1413 | 1:13 | 17,19,23 | 1:13 | 18,20,24 |
| 76 | 1 | Z1 rows a | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 15 | 1:13 | 21 |
| 76 | 2 | Z1 rows b | f237.18-f243.08 | 9.1413 | 9.3687 | 1:13 | 16:21 | 1:13 | 15:20 |

### A52. frames 238-241 -- X0 rows f238-241 `33->34 \| 34->33`

UNDETERMINED X0 rows f238-241: rows 33 and 34 swap -- gold row 33 -> 34 (32.84-33.46 f239, 33.94 f240) and mauve row 34 -> 33 (33.70-34.15 f239, 33.23 f240); fill 33.15 33.96 f239, 33.19 33.88 f240, on tones f241.

Measured: smoothstep mean 0.1006 (worst 0.840), moving-frame mean 0.2013, free per-frame 0.1428, monotone 0.025; window f238.45-f240.70 (t 9.1903-9.2770 ms); per species {'X1': 0.0317, 'X0': 0.1006, 'Z1': 6.4883, 'Z0': 18.5067}.

**Rows the automatic book had for X0 in f238-241:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 62 | 1 | X0 rows a | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 36 | 1:13 | 32 |
| 62 | 2 | X0 rows b | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 32:35 | 1:13 | 33:36 |
| 67 | 1 | X0 rows a | f240.84-f246.99 | 9.2824 | 9.5194 | 1:13 | 25:31 | 1:13 | 30:36 |
| 67 | 2 | X0 rows b | f240.84-f246.99 | 9.2824 | 9.5194 | 1:13 | 32:36 | 1:13 | 25:29 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 72 | 1 | X0 rows a | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 36 | 1:13 | 32 |
| 72 | 2 | X0 rows b | f234.16-f237.18 | 9.0249 | 9.1413 | 1:13 | 32:35 | 1:13 | 33:36 |
| 77 | 1 | X0 rows a | f238.45-f240.70 | 9.1903 | 9.2770 | 1:13 | 33 | 1:13 | 34 |
| 77 | 2 | X0 rows b | f238.45-f240.70 | 9.1903 | 9.2770 | 1:13 | 34 | 1:13 | 33 |
| 78 | 1 | X0 rows a | f240.84-f246.99 | 9.2824 | 9.5194 | 1:13 | 25:31 | 1:13 | 30:36 |
| 78 | 2 | X0 rows b | f240.84-f246.99 | 9.2824 | 9.5194 | 1:13 | 32:36 | 1:13 | 25:29 |

### A53. frames 248-254 -- X0 cols f248-254 `1:6->8:13 \| 7:13->1:7`

UNDETERMINED X0 cols f248-254 on rows 25:36 (the candidate copied Z's 1:7->7:13 | 8:13->1:6). X0 rotates by +7, not +6: gold cols 1:6 -> 8:13 (1.79-5.43 f249, 5.65-10.99 f251, 7.59-13.03 f253) and mauve cols 7:13 -> 1:7 (6.12..12.08 f249, 2.84..9.08 f251, 0.79..7.29 f253); on tones f254.

Measured: smoothstep mean 0.0670 (worst 0.342), moving-frame mean 0.0682, free per-frame 0.0682, monotone 0.1411; window f247.00-f253.79 (t 9.5198-9.7815 ms); per species {'X1': 7.4205, 'X0': 0.067, 'Z1': 0.1123, 'Z0': 0.1076}.

**Rows the automatic book had for X0 in f248-254:**

_(no rows)_

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 81 | 1 | X0 cols a | f247.00-f253.79 | 9.5198 | 9.7815 | 1:6 | 25:36 | 8:13 | 25:36 |
| 81 | 2 | X0 cols b | f247.00-f253.79 | 9.5198 | 9.7815 | 7:13 | 25:36 | 1:7 | 25:36 |
| 85 | 1 | X0 rows a | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 27 | 1:13 | 31 |
| 85 | 1 | X0 rows b | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 31 | 1:13 | 36 |
| 85 | 2 | X0 rows c | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 36 | 1:13 | 27 |

### A54. frames 254-261 -- X0 rows f254-261 `27->31 \| 31->36 \| 36->27`

the 5-part 27->33 | 31->35 | 34->28 | 28->27 | 32,33,35->31,32,34 with an EMPTY comb is wrong; the block is on cols 1:13 and three rows move: mauve row 27 -> 31 (27.29 f255, 27.58 f256, 28.52 f257, 29.44 f258, 30.64 f259, 30.90 f260), mauve row 31 -> 36 (31.37, 32.06, 33.46, 34.58, 35.19/35.63, 35.87) and gold row 36 -> 27 (35.08-35.70 f255, 33.77-34.26 f256, 31.84-32.45 f257, 29.73-30.21 f258, 27.97-28.39 f259, 26.97-27.46 f260); on tones f261.

Measured: smoothstep mean 0.0694 (worst 0.664), moving-frame mean 0.0539, free per-frame 0.0509, monotone 0.1472; window f254.00-f260.52 (t 9.7896-10.0409 ms); per species {'X1': 0.0797, 'X0': 0.0694, 'Z1': 6.7964, 'Z0': 18.7842}.

**Rows the automatic book had for X0 in f254-261:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 74 | 1 | X0 rows a | f260.31-f267.11 | 10.0328 | 10.2949 | None | 28 | None | 35 |
| 74 | 2 | X0 rows b | f260.31-f267.11 | 10.0328 | 10.2949 | None | 32 | None | 28 |
| 74 | 2 | X0 rows c | f260.31-f267.11 | 10.0328 | 10.2949 | None | 35 | None | 33 |
| 74 | 2 | X0 rows d | f260.31-f267.11 | 10.0328 | 10.2949 | None | 33 | None | 32 |
| 77 | 1 | X0 rows a | f261.87-f263.45 | 10.0929 | 10.1538 | None | 27 | None | 33 |
| 77 | 5 | X0 rows b | f261.87-f263.45 | 10.0929 | 10.1538 | None | 31 | None | 35 |
| 77 | 6 | X0 rows c | f261.87-f263.45 | 10.0929 | 10.1538 | None | 34 | None | 28 |
| 77 | 2 | X0 rows d | f261.87-f263.45 | 10.0929 | 10.1538 | None | 28 | None | 27 |
| 77 | 7 | X0 rows e | f261.87-f263.45 | 10.0929 | 10.1538 | None | 32:33,35 | None | 31:32,34 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 81 | 1 | X0 cols a | f247.00-f253.79 | 9.5198 | 9.7815 | 1:6 | 25:36 | 8:13 | 25:36 |
| 81 | 2 | X0 cols b | f247.00-f253.79 | 9.5198 | 9.7815 | 7:13 | 25:36 | 1:7 | 25:36 |
| 85 | 1 | X0 rows a | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 27 | 1:13 | 31 |
| 85 | 1 | X0 rows b | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 31 | 1:13 | 36 |
| 85 | 2 | X0 rows c | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 36 | 1:13 | 27 |
| 88 | 1 | X0 rows a | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 28 | 1:13 | 35 |
| 88 | 2 | X0 rows b | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 33 | 1:13 | 28 |
| 88 | 2 | X0 rows c | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 35 | 1:13 | 33 |

### A55. frames 261-267 -- X0 rows f261-267 `28->35 \| 33->28 \| 35->33`

the 4-part 28->35 | 32->28 | 35->33 | 33->32 (EMPTY comb) moves row 32, which sits at 31.97-32.00 on every frame f261-267; gold row 28 -> 35 (28.12-28.74 f262, 29.21-29.82 f263, 31.26-31.60 f264, 33.04-33.46 f265, 34.58 f266, 34.70-35.31 f267), mauve row 33 -> 28 (32.69, 31.88, 30.64, 29.32, 28.44, 27.99) and mauve row 35 -> 33 (34.91, 34.65, ~34, 33.61, 33.22, 33.00). |  end moved from f267.40 to f267.30, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0981 (worst 0.991), moving-frame mean 0.0621, free per-frame 0.0621, monotone 0.1141; window f260.90-f267.30 (t 10.0555-10.3022 ms); per species {'X1': 0.0744, 'X0': 0.0685, 'Z1': 6.473, 'Z0': 18.4837}.

**Rows the automatic book had for X0 in f261-267:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 74 | 1 | X0 rows a | f260.31-f267.11 | 10.0328 | 10.2949 | None | 28 | None | 35 |
| 74 | 2 | X0 rows b | f260.31-f267.11 | 10.0328 | 10.2949 | None | 32 | None | 28 |
| 74 | 2 | X0 rows c | f260.31-f267.11 | 10.0328 | 10.2949 | None | 35 | None | 33 |
| 74 | 2 | X0 rows d | f260.31-f267.11 | 10.0328 | 10.2949 | None | 33 | None | 32 |
| 77 | 1 | X0 rows a | f261.87-f263.45 | 10.0929 | 10.1538 | None | 27 | None | 33 |
| 77 | 5 | X0 rows b | f261.87-f263.45 | 10.0929 | 10.1538 | None | 31 | None | 35 |
| 77 | 6 | X0 rows c | f261.87-f263.45 | 10.0929 | 10.1538 | None | 34 | None | 28 |
| 77 | 2 | X0 rows d | f261.87-f263.45 | 10.0929 | 10.1538 | None | 28 | None | 27 |
| 77 | 7 | X0 rows e | f261.87-f263.45 | 10.0929 | 10.1538 | None | 32:33,35 | None | 31:32,34 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 85 | 1 | X0 rows a | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 27 | 1:13 | 31 |
| 85 | 1 | X0 rows b | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 31 | 1:13 | 36 |
| 85 | 2 | X0 rows c | f254.00-f260.52 | 9.7896 | 10.0409 | 1:13 | 36 | 1:13 | 27 |
| 88 | 1 | X0 rows a | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 28 | 1:13 | 35 |
| 88 | 2 | X0 rows b | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 33 | 1:13 | 28 |
| 88 | 2 | X0 rows c | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 35 | 1:13 | 33 |
| 91 | 1 | X0 rows a | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 25 | 1:13 | 26 |
| 91 | 1 | X0 rows b | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 26 | 1:13 | 29 |
| 91 | 1 | X0 rows c | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 30 | 1:13 | 34 |
| 91 | 2 | X0 rows d | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 29 | 1:13 | 25 |
| 91 | 2 | X0 rows e | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 32,34 | 1:13 | 30,32 |

### A56. frames 267-272 -- X0 rows f267-272 `25->26 \| 26->29 \| 30->34 \| 29->25 \| 32,34->30,32`

the 5-part 27->26 | 30->28 | 31->32 | 26,28,29->27,29,30 | 32->31 (EMPTY comb) is wrong: rows 27, 28, 31 sit at 27.08 28.01 30.97 on every frame f268-272. Gold rows 25 -> 26, 26 -> 29, 30 -> 34 (24.72-26.30 29.90-30.32 f268; 25.34-25.77 27.51-28.00 32.27 f270; 26.10 28.36-28.97 33.23-33.72 f271; 25.73-26.35 28.67-29.16 33.69-34.31 f272) and mauve rows 29 -> 25, 32,34 -> 30,32 (28.52-29.13 31.90 33.92 f268; 26.44 30.83 32.83 f270; 25.46 30.26 32.22 f271; 25.00 30.03 31.97 f272). |  start moved from f267.30 to f267.30, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0616 (worst 0.453), moving-frame mean 0.0597, free per-frame 0.0583, monotone 0.1268; window f267.30-f272.25 (t 10.3022-10.4930 ms); per species {'X1': 0.0996, 'X0': 0.0646, 'Z1': 6.6247, 'Z0': 18.6356}.

**Rows the automatic book had for X0 in f267-272:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 74 | 1 | X0 rows a | f260.31-f267.11 | 10.0328 | 10.2949 | None | 28 | None | 35 |
| 74 | 2 | X0 rows b | f260.31-f267.11 | 10.0328 | 10.2949 | None | 32 | None | 28 |
| 74 | 2 | X0 rows c | f260.31-f267.11 | 10.0328 | 10.2949 | None | 35 | None | 33 |
| 74 | 2 | X0 rows d | f260.31-f267.11 | 10.0328 | 10.2949 | None | 33 | None | 32 |
| 80 | 3 | X0 rows a | f268.33-f270.19 | 10.3419 | 10.4136 | None | 27 | None | 26 |
| 80 | 3 | X0 rows b | f268.33-f270.19 | 10.3419 | 10.4136 | None | 30 | None | 28 |
| 80 | 3 | X0 rows c | f268.33-f270.19 | 10.3419 | 10.4136 | None | 31 | None | 32 |
| 80 | 4 | X0 rows d | f268.33-f270.19 | 10.3419 | 10.4136 | None | 26,28:29 | None | 27,29:30 |
| 80 | 4 | X0 rows e | f268.33-f270.19 | 10.3419 | 10.4136 | None | 32 | None | 31 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 88 | 1 | X0 rows a | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 28 | 1:13 | 35 |
| 88 | 2 | X0 rows b | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 33 | 1:13 | 28 |
| 88 | 2 | X0 rows c | f260.90-f267.30 | 10.0555 | 10.3022 | 1:13 | 35 | 1:13 | 33 |
| 91 | 1 | X0 rows a | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 25 | 1:13 | 26 |
| 91 | 1 | X0 rows b | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 26 | 1:13 | 29 |
| 91 | 1 | X0 rows c | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 30 | 1:13 | 34 |
| 91 | 2 | X0 rows d | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 29 | 1:13 | 25 |
| 91 | 2 | X0 rows e | f267.30-f272.25 | 10.3022 | 10.4930 | 1:13 | 32,34 | 1:13 | 30,32 |

### A57. frames 281-291 -- Z1+Z0 cols f281-291 `1:10->17:26 \| 11:13->14:16`

the 5-part 6->21 | 11:13->14:16 | 1:4->17:20 | 5->22 | 7:10->23:26 swaps cols 5 and 6; the pixels show cols 1:10 travelling together +16 (1.95..9.92 f281, 8.17..17.19 f284 with 5,6 merged into 11:13's 12.3-14.3, 16.49..24.50 f287, 16.56..25.60 f288, 17.00..26.07 f289) and 11:13 -> 14:16 (11.15-13.16 f281, 12.33-14.33 f284, 13.70-15.71 f287, 14.01-16.01 f289). Both Z blocks (rows 1:24) on one rectangle. |  end moved from f289.43 to f289.43, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0557 (worst 0.374), moving-frame mean 0.0566, free per-frame 0.0528, monotone 0.0; window f279.06-f289.43 (t 10.7554-11.1551 ms); per species {'X1': 5.0662, 'X0': 10.9188, 'Z1': 0.0561, 'Z0': 0.0587}.

**Rows the automatic book had for Z1+Z0 in f281-291:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 87 | 2 | Z1 cols a | f279.06-f289.43 | 10.7554 | 11.1551 | 6 | 1:24 | 21 | 1:24 |
| 87 | 3 | Z1 cols b | f279.06-f289.43 | 10.7554 | 11.1551 | 11:13 | 1:24 | 14:16 | 1:24 |
| 87 | 2 | Z1 cols c | f279.06-f289.43 | 10.7554 | 11.1551 | 1:4 | 1:24 | 17:20 | 1:24 |
| 87 | 4 | Z1 cols d | f279.06-f289.43 | 10.7554 | 11.1551 | 5 | 1:24 | 22 | 1:24 |
| 87 | 2 | Z1 cols e | f279.06-f289.43 | 10.7554 | 11.1551 | 7:10 | 1:24 | 23:26 | 1:24 |
| 88 | 5 | Z0 rows a | f285.75-f288.47 | 11.0133 | 11.1181 | None | 6 | None | 7 |
| 88 | 6 | Z0 rows b | f285.75-f288.47 | 11.0133 | 11.1181 | None | 7 | None | 6 |
| 90 | 2 | Z1 rows a | f289.43-f292.62 | 11.1551 | 11.2781 | 1:13 | 18,24 | 1:13 | 13,19 |
| 90 | 3 | Z1 rows b | f289.43-f292.62 | 11.1551 | 11.2781 | 1:13 | 13:17,19:23 | 1:13 | 14:18,20:24 |
| 91 | 4 | Z1 rows a | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 15 | 14:26 | 13 |
| 91 | 4 | Z1 rows b | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 18 | 14:26 | 14 |
| 91 | 4 | Z1 rows c | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 20 | 14:26 | 17 |
| 91 | 4 | Z1 rows d | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 23 | 14:26 | 19 |
| 91 | 4 | Z1 rows e | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 24 | 14:26 | 22 |
| 91 | 6 | Z1 rows f | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 13:14,16 | 14:26 | 15:16,18 |
| 91 | 6 | Z1 rows g | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 17 | 14:26 | 20 |
| 91 | 6 | Z1 rows h | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 19,21:22 | 14:26 | 21,23:24 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 98 | 2 | Z1 cols a | f279.06-f289.43 | 10.7554 | 11.1551 | 1:10 | 1:24 | 17:26 | 1:24 |
| 98 | 3 | Z1 cols b | f279.06-f289.43 | 10.7554 | 11.1551 | 11:13 | 1:24 | 14:16 | 1:24 |
| 100 | 2 | Z1 rows a | f289.43-f293.75 | 11.1551 | 11.3216 | 14:26 | 13,22 | 14:26 | 15,24 |
| 100 | 2 | Z1 rows b | f289.43-f293.75 | 11.1551 | 11.3216 | 14:26 | 14,16:17,19 | 14:26 | 18,20:21,23 |
| 100 | 3 | Z1 rows c | f289.43-f293.75 | 11.1551 | 11.3216 | 14:26 | 15,24 | 14:26 | 13,22 |
| 100 | 3 | Z1 rows d | f289.43-f293.75 | 11.1551 | 11.3216 | 14:26 | 18,20:21,23 | 14:26 | 14,16:17,19 |

### A58. frames 289-294 -- Z1 rows f289-294 `13,22->15,24 \| 14,16,17,19->18,20,21,23 \| 15,24->13,22 \| 18,20,21,23->14,16,17,19`

Z1's rows exchange in four rigid groups after the columns land (f289): the dark-green class rows 13,14,16,17,19,22 go DOWN (13.13 14.20 16.26 17.40 19.41 22.24 f290; 14.36 16.64 18.60 19.80 21.71 23.30 f292; 14.74 17.82 19.61 20.70 22.62 23.83 f293) to 15,18,20,21,23,24 = +2 for 13,22 and +4 for 14,16,17,19; the light-green class rows 15,18,20,21,23,24 go UP (14.77 17.82 19.87 20.74 22.76 23.83 f290; 13.59 15.25 17.16 18.14 20.37 22.59 f292; 13.17 14.24 16.26 17.38 19.14 22.05 f293) to 13,14,16,17,19,22. On tones at f294. |  start moved from f289.40 to f289.43, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0617 (worst 0.350), moving-frame mean 0.0257, free per-frame 0.0257, monotone 0.0464; window f289.43-f293.75 (t 11.1551-11.3216 ms); per species {'X1': 6.5691, 'X0': 6.5873, 'Z1': 0.0582, 'Z0': 6.6057}.

**Rows the automatic book had for Z1 in f289-294:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 87 | 2 | Z1 cols a | f279.06-f289.43 | 10.7554 | 11.1551 | 6 | 1:24 | 21 | 1:24 |
| 87 | 3 | Z1 cols b | f279.06-f289.43 | 10.7554 | 11.1551 | 11:13 | 1:24 | 14:16 | 1:24 |
| 87 | 2 | Z1 cols c | f279.06-f289.43 | 10.7554 | 11.1551 | 1:4 | 1:24 | 17:20 | 1:24 |
| 87 | 4 | Z1 cols d | f279.06-f289.43 | 10.7554 | 11.1551 | 5 | 1:24 | 22 | 1:24 |
| 87 | 2 | Z1 cols e | f279.06-f289.43 | 10.7554 | 11.1551 | 7:10 | 1:24 | 23:26 | 1:24 |
| 90 | 2 | Z1 rows a | f289.43-f292.62 | 11.1551 | 11.2781 | 1:13 | 18,24 | 1:13 | 13,19 |
| 90 | 3 | Z1 rows b | f289.43-f292.62 | 11.1551 | 11.2781 | 1:13 | 13:17,19:23 | 1:13 | 14:18,20:24 |
| 91 | 4 | Z1 rows a | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 15 | 14:26 | 13 |
| 91 | 4 | Z1 rows b | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 18 | 14:26 | 14 |
| 91 | 4 | Z1 rows c | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 20 | 14:26 | 17 |
| 91 | 4 | Z1 rows d | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 23 | 14:26 | 19 |
| 91 | 4 | Z1 rows e | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 24 | 14:26 | 22 |
| 91 | 6 | Z1 rows f | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 13:14,16 | 14:26 | 15:16,18 |
| 91 | 6 | Z1 rows g | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 17 | 14:26 | 20 |
| 91 | 6 | Z1 rows h | f289.43-f294.15 | 11.1551 | 11.3370 | 14:26 | 19,21:22 | 14:26 | 21,23:24 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 98 | 2 | Z1 cols a | f279.06-f289.43 | 10.7554 | 11.1551 | 1:10 | 1:24 | 17:26 | 1:24 |
| 98 | 3 | Z1 cols b | f279.06-f289.43 | 10.7554 | 11.1551 | 11:13 | 1:24 | 14:16 | 1:24 |
| 100 | 2 | Z1 rows a | f289.43-f293.75 | 11.1551 | 11.3216 | 14:26 | 13,22 | 14:26 | 15,24 |
| 100 | 2 | Z1 rows b | f289.43-f293.75 | 11.1551 | 11.3216 | 14:26 | 14,16:17,19 | 14:26 | 18,20:21,23 |
| 100 | 3 | Z1 rows c | f289.43-f293.75 | 11.1551 | 11.3216 | 14:26 | 15,24 | 14:26 | 13,22 |
| 100 | 3 | Z1 rows d | f289.43-f293.75 | 11.1551 | 11.3216 | 14:26 | 18,20:21,23 | 14:26 | 14,16:17,19 |

### A59. frames 294-298 -- Z0 rows f294-298 `1,10->3,12 \| 2,4,5,7->6,8,9,11 \| 3,12->1,10 \| 6,8,9,11->2,4,5,7`

UNDETERMINED Z0 rows f294-298: the same four-group exchange as Z1's, four frames later. Gold class rows 1,2,4,5,7,10 go down (1.18 2.25 4.35 5.37 7.36 10.17 f295; 1.74 3.43 5.42 6.48 8.49 10.75 f296; 2.42 4.72 6.89 7.92 9.90 11.45 f297) to 3,6,8,9,11,12; mauve rows 3,6,8,9,11,12 go up (2.84 5.80 7.77 8.61 10.74 11.77 f295; 2.43 4.55 7.31 9.53 11.36 f296; 1.53 3.20 5.05 6.06 8.28 10.62 f297) to 1,2,4,5,7,10; on tones at the f298 pulse.

Measured: smoothstep mean 0.0876 (worst 0.914), moving-frame mean 0.0536, free per-frame 0.0536, monotone 0.0906; window f294.28-f297.26 (t 11.3420-11.4569 ms); per species {'X1': 18.5722, 'X0': 18.6, 'Z1': 6.6028, 'Z0': 0.0876}.

**Rows the automatic book had for Z0 in f294-298:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 93 | 3 | Z0 cols a | f298.52-f307.19 | 11.5055 | 11.8396 | 14:24 | 1:24 | 16:26 | 1:24 |
| 93 | 4 | Z0 cols b | f298.52-f307.19 | 11.5055 | 11.8396 | 25:26 | 1:24 | 14:15 | 1:24 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 101 | 2 | Z0 rows a | f294.28-f297.26 | 11.3420 | 11.4569 | 14:26 | 1,10 | 14:26 | 3,12 |
| 101 | 2 | Z0 rows b | f294.28-f297.26 | 11.3420 | 11.4569 | 14:26 | 2,4:5,7 | 14:26 | 6,8:9,11 |
| 101 | 3 | Z0 rows c | f294.28-f297.26 | 11.3420 | 11.4569 | 14:26 | 3,12 | 14:26 | 1,10 |
| 101 | 3 | Z0 rows d | f294.28-f297.26 | 11.3420 | 11.4569 | 14:26 | 6,8:9,11 | 14:26 | 2,4:5,7 |
| 103 | 3 | Z0 cols a | f298.52-f307.19 | 11.5055 | 11.8396 | 14:24 | 1:24 | 16:26 | 1:24 |
| 103 | 4 | Z0 cols b | f298.52-f307.19 | 11.5055 | 11.8396 | 25:26 | 1:24 | 14:15 | 1:24 |

### A60. frames 300-309 -- X1 cols f300-309 `1:2->12:13 \| 3:13->1:11`

rotation of the MEASURED moving run 1:13 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  end moved from f307.19 to f307.10, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0585 (worst 0.146), moving-frame mean 0.0608, free per-frame 0.0574, monotone 0.0; window f298.52-f307.10 (t 11.5055-11.8361 ms); per species {'X1': 0.0573, 'X0': 6.6122, 'Z1': 7.4316, 'Z0': 7.4144}.

**Rows the automatic book had for X1 in f300-309:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 92 | 1 | X1 cols a | f298.52-f307.19 | 11.5055 | 11.8396 | 1:2 | 25:36 | 12:13 | 25:36 |
| 92 | 2 | X1 cols b | f298.52-f307.19 | 11.5055 | 11.8396 | 3:13 | 25:36 | 1:11 | 25:36 |
| 97 | 5 | X1 rows a | f309.07-f311.92 | 11.9121 | 12.0219 | None | 27:31 | None | 32:36 |
| 97 | 6 | X1 rows b | f309.07-f311.92 | 11.9121 | 12.0219 | None | 32:36 | None | 27:31 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 102 | 1 | X1 cols a | f298.52-f307.10 | 11.5055 | 11.8361 | 1:2 | 25:36 | 12:13 | 25:36 |
| 102 | 2 | X1 cols b | f298.52-f307.10 | 11.5055 | 11.8361 | 3:13 | 25:36 | 1:11 | 25:36 |
| 104 | 1 | X1 rows a | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 27 | 1:13 | 31 |
| 104 | 1 | X1 rows b | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 31 | 1:13 | 36 |
| 104 | 2 | X1 rows c | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 36 | 1:13 | 27 |

### A61. frames 307-314 -- X1 rows f307-314 `27->31 \| 31->36 \| 36->27`

the last-resort 27:31->32:36 | 32:36->27:31 with an EMPTY comb is wrong (rows 28:30, 32:35 static at 28.01 28.94 29.98 32.01 33.03 34.12 35.00). X1 on cols 1:13 repeats X0's f254-261 cycle: mauve row 27 -> 31 (27.20 f308, 27.49 f309, 28.67 f310, 29.51 f311, 30.37 f312, 30.81 f313, 30.97 f314), mauve row 31 -> 36 (31.31, 31.60, 32.61, 34.15, 35.15, 35.78, 36.01) and gold row 36 -> 27 (35.28-35.73 f308, 34.15-34.65 f309, 32.46 f310, 30.02-30.46 f311, 28.63 f312, 27.32 f313, 26.73-27.18 f314). |  start moved from f307.00 to f307.10, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0721 (worst 0.815), moving-frame mean 0.0524, free per-frame 0.0491, monotone 0.1056; window f307.10-f314.27 (t 11.8361-12.1125 ms); per species {'X1': 0.0602, 'X0': 0.084, 'Z1': 6.454, 'Z0': 18.4682}.

**Rows the automatic book had for X1 in f307-314:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 92 | 1 | X1 cols a | f298.52-f307.19 | 11.5055 | 11.8396 | 1:2 | 25:36 | 12:13 | 25:36 |
| 92 | 2 | X1 cols b | f298.52-f307.19 | 11.5055 | 11.8396 | 3:13 | 25:36 | 1:11 | 25:36 |
| 97 | 5 | X1 rows a | f309.07-f311.92 | 11.9121 | 12.0219 | None | 27:31 | None | 32:36 |
| 97 | 6 | X1 rows b | f309.07-f311.92 | 11.9121 | 12.0219 | None | 32:36 | None | 27:31 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 102 | 1 | X1 cols a | f298.52-f307.10 | 11.5055 | 11.8361 | 1:2 | 25:36 | 12:13 | 25:36 |
| 102 | 2 | X1 cols b | f298.52-f307.10 | 11.5055 | 11.8361 | 3:13 | 25:36 | 1:11 | 25:36 |
| 104 | 1 | X1 rows a | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 27 | 1:13 | 31 |
| 104 | 1 | X1 rows b | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 31 | 1:13 | 36 |
| 104 | 2 | X1 rows c | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 36 | 1:13 | 27 |
| 111 | 1 | X1 rows a | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 28 | 1:13 | 35 |
| 111 | 2 | X1 rows b | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 33 | 1:13 | 28 |
| 111 | 2 | X1 rows c | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 35 | 1:13 | 33 |

### A62. frames 307-312 -- Z1 rows f307-312 `20:21->22:23 \| 22:23->20:21`

rotation of the measured moving run 20:23 (session 26 competition) |  end moved from f310.37 to f310.30, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0548 (worst 0.494), moving-frame mean 0.0624, free per-frame 0.0113, monotone 0.0; window f307.19-f310.30 (t 11.8396-11.9595 ms); per species {'X1': 6.4907, 'X0': 6.5481, 'Z1': 0.0444, 'Z0': 6.5107}.

**Rows the automatic book had for Z1 in f307-312:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 96 | 1 | Z1 rows a | f307.19-f310.37 | 11.8396 | 11.9622 | 14:26 | 20:21 | 14:26 | 22:23 |
| 96 | 2 | Z1 rows b | f307.19-f310.37 | 11.8396 | 11.9622 | 14:26 | 22:23 | 14:26 | 20:21 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 105 | 3 | Z1 rows a | f307.19-f310.30 | 11.8396 | 11.9595 | 14:26 | 20:21 | 14:26 | 22:23 |
| 105 | 4 | Z1 rows b | f307.19-f310.30 | 11.8396 | 11.9595 | 14:26 | 22:23 | 14:26 | 20:21 |
| 107 | 3 | Z1 rows a | f310.30-f313.50 | 11.9595 | 12.0828 | 14:26 | 13,18 | 14:26 | 15,20 |
| 107 | 4 | Z1 rows b | f310.30-f313.50 | 11.9595 | 12.0828 | 14:26 | 14:15,19:20 | 14:26 | 13:14,18:19 |

### A63. frames 310-314 -- Z1 rows f310-314 `13,18->15,20 \| 14,15,19,20->13,14,18,19`

the S2.1 read 13:15->18:20 | 16:20->13:17 (rotation of 13:20 by 5) is wrong: rows 16, 17, 21:24 sit at 15.99 16.99 21.00..24.01 on f311-313. Two 3-cycles, the twin of X0's f162-165: gold rows 13 -> 15 and 18 -> 20 (13.20 18.22 f311, 13.89 19.04 f312, 14.89 19.80 f313) and mauve rows 14,15 -> 13,14 and 19,20 -> 18,19 (14.50 19.43 f311, 13.39 14.47 18.38 19.63 f312, 13.09 14.01 18.48 f313); on tones f314. |  start moved from f310.30 to f310.30, the boundary with the block's previous move (chosen by measurement). |  end moved from f313.72 to f313.50, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0747 (worst 0.580), moving-frame mean 0.0644, free per-frame 0.0644, monotone 0.1542; window f310.30-f313.50 (t 11.9595-12.0828 ms); per species {'X1': 6.4565, 'X0': 6.5053, 'Z1': 0.0691, 'Z0': 6.57}.

**Rows the automatic book had for Z1 in f310-314:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 96 | 1 | Z1 rows a | f307.19-f310.37 | 11.8396 | 11.9622 | 14:26 | 20:21 | 14:26 | 22:23 |
| 96 | 2 | Z1 rows b | f307.19-f310.37 | 11.8396 | 11.9622 | 14:26 | 22:23 | 14:26 | 20:21 |
| 99 | 1 | Z1 rows a | f313.50-f316.18 | 12.0828 | 12.1861 | 14:26 | 13:15 | 14:26 | 18:20 |
| 99 | 2 | Z1 rows b | f313.50-f316.18 | 12.0828 | 12.1861 | 14:26 | 16:20 | 14:26 | 13:17 |
| 101 | 1 | Z1 rows a | f313.50-f319.31 | 12.0828 | 12.3067 | 14:26 | 14:16 | 14:26 | 19:21 |
| 101 | 2 | Z1 rows b | f313.50-f319.31 | 12.0828 | 12.3067 | 14:26 | 17:21 | 14:26 | 14:18 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 105 | 3 | Z1 rows a | f307.19-f310.30 | 11.8396 | 11.9595 | 14:26 | 20:21 | 14:26 | 22:23 |
| 105 | 4 | Z1 rows b | f307.19-f310.30 | 11.8396 | 11.9595 | 14:26 | 22:23 | 14:26 | 20:21 |
| 107 | 3 | Z1 rows a | f310.30-f313.50 | 11.9595 | 12.0828 | 14:26 | 13,18 | 14:26 | 15,20 |
| 107 | 4 | Z1 rows b | f310.30-f313.50 | 11.9595 | 12.0828 | 14:26 | 14:15,19:20 | 14:26 | 13:14,18:19 |
| 110 | 3 | Z1 rows a | f313.50-f319.31 | 12.0828 | 12.3067 | 14:26 | 14:16 | 14:26 | 19:21 |
| 110 | 4 | Z1 rows b | f313.50-f319.31 | 12.0828 | 12.3067 | 14:26 | 17:21 | 14:26 | 14:18 |

### A64. frames 314-321 -- Z1 rows f314-321 `14:16->19:21 \| 17:21->14:18`

rotation of the measured moving run 14:21 (session 26 competition) |  start moved from f313.50 to f313.50, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0531 (worst 0.637), moving-frame mean 0.0482, free per-frame 0.0244, monotone 0.0; window f313.50-f319.31 (t 12.0828-12.3067 ms); per species {'X1': 6.4495, 'X0': 6.4701, 'Z1': 0.038, 'Z0': 6.5139}.

**Rows the automatic book had for Z1 in f314-321:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 99 | 1 | Z1 rows a | f313.50-f316.18 | 12.0828 | 12.1861 | 14:26 | 13:15 | 14:26 | 18:20 |
| 99 | 2 | Z1 rows b | f313.50-f316.18 | 12.0828 | 12.1861 | 14:26 | 16:20 | 14:26 | 13:17 |
| 101 | 1 | Z1 rows a | f313.50-f319.31 | 12.0828 | 12.3067 | 14:26 | 14:16 | 14:26 | 19:21 |
| 101 | 2 | Z1 rows b | f313.50-f319.31 | 12.0828 | 12.3067 | 14:26 | 17:21 | 14:26 | 14:18 |
| 103 | 1 | Z1 rows a | f319.31-f324.05 | 12.3067 | 12.4894 | 14:26 | 19 | 14:26 | 23 |
| 103 | 2 | Z1 rows b | f319.31-f324.05 | 12.3067 | 12.4894 | 14:26 | 20:23 | 14:26 | 19:22 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 107 | 3 | Z1 rows a | f310.30-f313.50 | 11.9595 | 12.0828 | 14:26 | 13,18 | 14:26 | 15,20 |
| 107 | 4 | Z1 rows b | f310.30-f313.50 | 11.9595 | 12.0828 | 14:26 | 14:15,19:20 | 14:26 | 13:14,18:19 |
| 110 | 3 | Z1 rows a | f313.50-f319.31 | 12.0828 | 12.3067 | 14:26 | 14:16 | 14:26 | 19:21 |
| 110 | 4 | Z1 rows b | f313.50-f319.31 | 12.0828 | 12.3067 | 14:26 | 17:21 | 14:26 | 14:18 |
| 113 | 3 | Z1 rows a | f319.31-f324.05 | 12.3067 | 12.4894 | 14:26 | 19 | 14:26 | 23 |
| 113 | 4 | Z1 rows b | f319.31-f324.05 | 12.3067 | 12.4894 | 14:26 | 20:23 | 14:26 | 19:22 |

### A65. frames 314-321 -- X1 rows f314-321 `28->35 \| 33->28 \| 35->33`

the read 28->31 | 29:31->28:30 with an EMPTY comb is wrong (rows 29:32 static at 28.94 29.98 30.98 32.01); X1 repeats X0's f261-267 cycle: gold row 28 -> 35 (28.26 f315, 28.94-29.38 f316, 30.52 f317, 32.53-32.97 f318, 33.92-34.36 f319, 34.62-35.05 f320), mauve row 33 -> 28 (32.82, 32.16, 30.97, 29.58, 28.60, 27.87/28.36) and mauve row 35 -> 33 (34.91, 34.75, 34.54, 33.43, 33.23, 33.09); on tones f321.

Measured: smoothstep mean 0.0729 (worst 0.566), moving-frame mean 0.0475, free per-frame 0.0428, monotone 0.1083; window f314.30-f320.45 (t 12.1136-12.3507 ms); per species {'X1': 0.0729, 'X0': 0.0656, 'Z1': 6.4594, 'Z0': 18.473}.

**Rows the automatic book had for X1 in f314-321:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 104 | 3 | X1 rows a | f321.77-f324.05 | 12.4016 | 12.4894 | None | 28 | None | 31 |
| 104 | 4 | X1 rows b | f321.77-f324.05 | 12.4016 | 12.4894 | None | 29:31 | None | 28:30 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 104 | 1 | X1 rows a | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 27 | 1:13 | 31 |
| 104 | 1 | X1 rows b | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 31 | 1:13 | 36 |
| 104 | 2 | X1 rows c | f307.10-f314.27 | 11.8361 | 12.1125 | 1:13 | 36 | 1:13 | 27 |
| 111 | 1 | X1 rows a | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 28 | 1:13 | 35 |
| 111 | 2 | X1 rows b | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 33 | 1:13 | 28 |
| 111 | 2 | X1 rows c | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 35 | 1:13 | 33 |
| 114 | 1 | X1 rows a | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 25 | 1:13 | 26 |
| 114 | 1 | X1 rows b | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 26 | 1:13 | 29 |
| 114 | 1 | X1 rows c | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 30 | 1:13 | 34 |
| 114 | 2 | X1 rows d | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 29 | 1:13 | 25 |
| 114 | 2 | X1 rows e | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 32,34 | 1:13 | 30,32 |

### A66. frames 321-326 -- X1 rows f321-326 `25->26 \| 26->29 \| 30->34 \| 29->25 \| 32,34->30,32`

UNDETERMINED X1 rows f321-326: X1 repeats X0's f267-272 move. Gold rows 25 -> 26, 26 -> 29, 30 -> 34 (25.11-26.22 29.77-30.24 f321; 25.56 27.53 31.81-32.24 f323; 25.57-26.07 28.63 33.11-33.54 f324; 25.73-26.15 28.69-29.13 33.69-34.11 f325) and mauve rows 29 -> 25, 32,34 -> 30,32 (28.94 31.92 34.01 f321; 26.62 31.04 32.99 f323; 25.38 30.37 32.37 f324; 24.73-25.21 30.05 32.05 f325); rows 27, 28, 31 static; on tones f326.

Measured: smoothstep mean 0.0585 (worst 0.630), moving-frame mean 0.038, free per-frame 0.0354, monotone 0.1393; window f321.20-f324.79 (t 12.3796-12.5179 ms); per species {'X1': 0.0585, 'X0': 0.0689, 'Z1': 6.5511, 'Z0': 18.5627}.

**Rows the automatic book had for X1 in f321-326:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 104 | 3 | X1 rows a | f321.77-f324.05 | 12.4016 | 12.4894 | None | 28 | None | 31 |
| 104 | 4 | X1 rows b | f321.77-f324.05 | 12.4016 | 12.4894 | None | 29:31 | None | 28:30 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 111 | 1 | X1 rows a | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 28 | 1:13 | 35 |
| 111 | 2 | X1 rows b | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 33 | 1:13 | 28 |
| 111 | 2 | X1 rows c | f314.30-f320.45 | 12.1136 | 12.3507 | 1:13 | 35 | 1:13 | 33 |
| 114 | 1 | X1 rows a | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 25 | 1:13 | 26 |
| 114 | 1 | X1 rows b | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 26 | 1:13 | 29 |
| 114 | 1 | X1 rows c | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 30 | 1:13 | 34 |
| 114 | 2 | X1 rows d | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 29 | 1:13 | 25 |
| 114 | 2 | X1 rows e | f321.20-f324.79 | 12.3796 | 12.5179 | 1:13 | 32,34 | 1:13 | 30,32 |

### A67. frames 334-342 -- X1 cols f334-342 `1:8->6:13 \| 9:13->1:5`

rotation of the MEASURED moving run 1:13 (session 17 S2.1): the tones held static are the ones a peak provably sits on throughout |  end moved from f339.94 to f339.80, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0765 (worst 0.428), moving-frame mean 0.0736, free per-frame 0.0702, monotone 0.0; window f332.58-f339.80 (t 12.8182-13.0965 ms); per species {'X1': 0.0621, 'X0': 6.6716, 'Z1': 7.7349, 'Z0': 7.7299}.

**Rows the automatic book had for X1 in f334-342:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 109 | 1 | X1 cols a | f332.58-f339.94 | 12.8182 | 13.1019 | 1:8 | 25:36 | 6:13 | 25:36 |
| 109 | 2 | X1 cols b | f332.58-f339.94 | 12.8182 | 13.1019 | 9:13 | 25:36 | 1:5 | 25:36 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 120 | 3 | X1 cols a | f332.58-f339.80 | 12.8182 | 13.0965 | 1:8 | 25:36 | 6:13 | 25:36 |
| 120 | 4 | X1 cols b | f332.58-f339.80 | 12.8182 | 13.0965 | 9:13 | 25:36 | 1:5 | 25:36 |
| 121 | 1 | X1 rows a | f339.80-f345.07 | 13.0965 | 13.2996 | 1:13 | 25,33 | 1:13 | 28,36 |
| 121 | 1 | X1 rows b | f339.80-f345.07 | 13.0965 | 13.2996 | 1:13 | 26:27,29:30 | 1:13 | 31:32,34:35 |
| 121 | 2 | X1 rows c | f339.80-f345.07 | 13.0965 | 13.2996 | 1:13 | 28,36 | 1:13 | 25,33 |
| 121 | 2 | X1 rows d | f339.80-f345.07 | 13.0965 | 13.2996 | 1:13 | 31:32,34:35 | 1:13 | 26:27,29:30 |

### A68. frames 333-340 -- Z1+Z0 cols f333-340 `14:18->22:26 \| 19:26->14:21`

UNDETERMINED Z1 cols f333-340 (Z0's twin was never listed): both Z blocks rotate by -5, the OPPOSITE way to X1's written 1:8->6:13 | 9:13->1:5. Gold cols 14:18 -> 22:26 (14.41-18.43 f334, 19.56-23.52 f337, 21.86-25.83 f339) and mauve/green cols 19:26 -> 14:21 (19.88-25.72 f334, 15.51-18.53 f337, 14.08-21.04 f339); Z0 identical (14.43-18.40 f334 -> 23.85 f339; 18.87-25.72 -> 14.08-21.04). One rectangle over rows 1:24. |  end moved from f339.94 to f339.94, the boundary with the block's next move (chosen by measurement). |  window synchronised with its twin in the same batch (own f332.58-339.94).

Measured: smoothstep mean 0.0686 (worst 0.290), moving-frame mean 0.0242, free per-frame 0.0259, monotone 0.1219; window f332.58-f339.80 (t 12.8182-13.0965 ms); per species {'X1': 7.7046, 'X0': 19.6049, 'Z1': 0.0304, 'Z0': 0.0378}.

**Rows the automatic book had for Z1+Z0 in f333-340:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 110 | 1 | Z0 rows a | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 4 | 14:26 | 1 |
| 110 | 1 | Z0 rows b | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 8 | 14:26 | 4 |
| 110 | 1 | Z0 rows c | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 9:10 | 14:26 | 6:7 |
| 110 | 1 | Z0 rows d | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 11 | 14:26 | 10 |
| 110 | 2 | Z0 rows e | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 1:2 | 14:26 | 2:3 |
| 110 | 2 | Z0 rows f | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 3 | 14:26 | 5 |
| 110 | 2 | Z0 rows g | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 5:6 | 14:26 | 8:9 |
| 110 | 2 | Z0 rows h | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 7 | 14:26 | 11 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 119 | 1 | Z1 cols a | f332.58-f339.80 | 12.8182 | 13.0965 | 14:18 | 1:24 | 22:26 | 1:24 |
| 119 | 2 | Z1 cols b | f332.58-f339.80 | 12.8182 | 13.0965 | 19:26 | 1:24 | 14:21 | 1:24 |
| 122 | 3 | Z0 rows a | f339.94-f344.49 | 13.1019 | 13.2772 | 14:26 | 1,10 | 14:26 | 3,12 |
| 122 | 3 | Z0 rows b | f339.94-f344.49 | 13.1019 | 13.2772 | 14:26 | 2,4:5,7 | 14:26 | 6,8:9,11 |
| 122 | 4 | Z0 rows c | f339.94-f344.49 | 13.1019 | 13.2772 | 14:26 | 3,12 | 14:26 | 1,10 |
| 122 | 4 | Z0 rows d | f339.94-f344.49 | 13.1019 | 13.2772 | 14:26 | 6,8:9,11 | 14:26 | 2,4:5,7 |

### A69. frames 340-345 -- X1 rows f340-345 `25,33->28,36 \| 26,27,29,30->31,32,34,35 \| 28,36->25,33 \| 31,32,34,35->26,27,29,30`

UNDETERMINED X1 rows f340-345 (the candidate pairwise swap read 0.128): the X version of the Z exchanges, +3/+5 and -3/-5. Gold rows 25,26,27,29,30,33 go down (25.09-27.28 29.31-30.74 f341; 26.90 29.21-30.72 32.17-33.65 34.82-35.27 f343; 27.98 30.29-31.74 33.79-35.91 f344; 27.74-28.16 30.72-32.17 33.71-36.16 f345) to 28,31,32,34,35,36; mauve rows 28,31,32,34,35,36 go up (27.65 30.13 31.47 33.49 34.48 35.62 f341; 25.97 27.51 28.56 31.51 34.09 f343; 25.28 26.46 27.47 29.43 30.12 33.26 f344; 25.08 26.05 27.04 29.05 30.05 33.01 f345). |  start moved from f339.80 to f339.80, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0703 (worst 0.432), moving-frame mean 0.0617, free per-frame 0.0617, monotone 0.0518; window f339.80-f345.07 (t 13.0965-13.2996 ms); per species {'X1': 0.076, 'X0': 0.1651, 'Z1': 6.6737, 'Z0': 18.7791}.

**Rows the automatic book had for X1 in f340-345:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 109 | 1 | X1 cols a | f332.58-f339.94 | 12.8182 | 13.1019 | 1:8 | 25:36 | 6:13 | 25:36 |
| 109 | 2 | X1 cols b | f332.58-f339.94 | 12.8182 | 13.1019 | 9:13 | 25:36 | 1:5 | 25:36 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 120 | 3 | X1 cols a | f332.58-f339.80 | 12.8182 | 13.0965 | 1:8 | 25:36 | 6:13 | 25:36 |
| 120 | 4 | X1 cols b | f332.58-f339.80 | 12.8182 | 13.0965 | 9:13 | 25:36 | 1:5 | 25:36 |
| 121 | 1 | X1 rows a | f339.80-f345.07 | 13.0965 | 13.2996 | 1:13 | 25,33 | 1:13 | 28,36 |
| 121 | 1 | X1 rows b | f339.80-f345.07 | 13.0965 | 13.2996 | 1:13 | 26:27,29:30 | 1:13 | 31:32,34:35 |
| 121 | 2 | X1 rows c | f339.80-f345.07 | 13.0965 | 13.2996 | 1:13 | 28,36 | 1:13 | 25,33 |
| 121 | 2 | X1 rows d | f339.80-f345.07 | 13.0965 | 13.2996 | 1:13 | 31:32,34:35 | 1:13 | 26:27,29:30 |

### A70. frames 340-345 -- Z0 rows f340-345 `1,10->3,12 \| 2,4,5,7->6,8,9,11 \| 3,12->1,10 \| 6,8,9,11->2,4,5,7`

the 8-part 4->1 | 8->4 | 9:10->6:7 | 11->10 | 1:2->2:3 | 3->5 | 5:6->8:9 | 7->11 fitted to f339.9-341.5 is wrong; Z0's rows sit on their tones f334-339 and then do the same four-group exchange as at f294-298: gold rows 1,2,4,5,7,10 down (1.28 2.56 4.56 5.59 7.60 10.26 f341; 1.87 3.83 6.26 8.77 10.82 f342; 2.56 5.13 7.16 8.22 10.11 11.58 f343; 2.97 5.94 7.92 8.88 10.89 11.92 f344), mauve rows 3,6,8,9,11,12 up (2.91 5.26 7.23 8.45 10.60 11.70 f341; 1.37 3.01 4.65 5.92 7.72 10.58 f343; 1.02 2.10 4.13 5.09 7.05 10.04 f344); on tones f345. |  start moved from f339.80 to f339.94, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.0635 (worst 0.382), moving-frame mean 0.0771, free per-frame 0.0634, monotone 0.2339; window f339.94-f344.49 (t 13.1019-13.2772 ms); per species {'X1': 18.7837, 'X0': 18.6107, 'Z1': 6.6246, 'Z0': 0.0506}.

**Rows the automatic book had for Z0 in f340-345:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 110 | 1 | Z0 rows a | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 4 | 14:26 | 1 |
| 110 | 1 | Z0 rows b | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 8 | 14:26 | 4 |
| 110 | 1 | Z0 rows c | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 9:10 | 14:26 | 6:7 |
| 110 | 1 | Z0 rows d | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 11 | 14:26 | 10 |
| 110 | 2 | Z0 rows e | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 1:2 | 14:26 | 2:3 |
| 110 | 2 | Z0 rows f | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 3 | 14:26 | 5 |
| 110 | 2 | Z0 rows g | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 5:6 | 14:26 | 8:9 |
| 110 | 2 | Z0 rows h | f339.94-f341.54 | 13.1019 | 13.1635 | 14:26 | 7 | 14:26 | 11 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 122 | 3 | Z0 rows a | f339.94-f344.49 | 13.1019 | 13.2772 | 14:26 | 1,10 | 14:26 | 3,12 |
| 122 | 3 | Z0 rows b | f339.94-f344.49 | 13.1019 | 13.2772 | 14:26 | 2,4:5,7 | 14:26 | 6,8:9,11 |
| 122 | 4 | Z0 rows c | f339.94-f344.49 | 13.1019 | 13.2772 | 14:26 | 3,12 | 14:26 | 1,10 |
| 122 | 4 | Z0 rows d | f339.94-f344.49 | 13.1019 | 13.2772 | 14:26 | 6,8:9,11 | 14:26 | 2,4:5,7 |

### A71. frames 345-349 -- Z1 rows f345-349 `13,22->15,24 \| 14,16,17,19->18,20,21,23 \| 15,24->13,22 \| 18,20,21,23->14,16,17,19`

UNDETERMINED Z1 rows f345-349 (the candidate 13:18<->19:24 read 0.21): the same exchange Z1 did at f289-294, finishing at the f349 pulse. Gold rows 13,14,16,17,19,22 down (13.34 14.71 16.66 17.73 19.66 22.35 f346 = p 0.17 for +2/+4; 14.67 17.32 19.81 22.32 23.66 f348), mauve rows 15,18,20,21,23,24 up (14.34 17.26 19.15 20.36 22.00 23.64 f346; 13.32 16.56 17.82 19.76 f348); on tones at f349.

Measured: smoothstep mean 0.0719 (worst 0.329), moving-frame mean 0.0358, free per-frame 0.0358, monotone 0.0925; window f344.90-f348.94 (t 13.2930-13.4487 ms); per species {'X1': 7.9356, 'X0': 7.8561, 'Z1': 0.0719, 'Z0': 6.6555}.

**Rows the automatic book had for Z1 in f345-349:**

_(no rows)_

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 123 | 3 | Z1 rows a | f344.90-f348.94 | 13.2930 | 13.4487 | 14:26 | 13,22 | 14:26 | 15,24 |
| 123 | 3 | Z1 rows b | f344.90-f348.94 | 13.2930 | 13.4487 | 14:26 | 14,16:17,19 | 14:26 | 18,20:21,23 |
| 123 | 4 | Z1 rows c | f344.90-f348.94 | 13.2930 | 13.4487 | 14:26 | 15,24 | 14:26 | 13,22 |
| 123 | 4 | Z1 rows d | f344.90-f348.94 | 13.2930 | 13.4487 | 14:26 | 18,20:21,23 | 14:26 | 14,16:17,19 |
| 133 | 3 | X0+X1 | f349.04-f357.35 | 13.4526 | 13.7729 | -12:0,1:13 | 25:36 | -12:0,1:13 | 34:45 |

### A72. frames 350-373 -- Z0 rows f350-373 `1:12->25:36`

FAULT B: the rows half of Z0's return to its seed was missing (the appearance read produced two atoms per site and was rejected). After the cols land on 1:13 (f361) all twelve rows descend +24 together: 1.15..12.18 f362, 3.39..14.52 f364, 8.64..19.50 f366, 15.91..26.89 f368, 21.55..32.60 f370, 24.62..35.47 f372, 24.97..36.00 f373 -- twelve peaks one row apart on every frame. Z1's written 13:24->25:36 (+12) is the same batch. |  end moved from f373.63 to f373.63, the boundary with the block's next move (chosen by measurement).

Measured: smoothstep mean 0.0920 (worst 0.983), moving-frame mean 0.0849, free per-frame 0.0921, monotone 0.0008; window f360.86-f373.63 (t 13.9081-14.4003 ms); per species {'X1': 17.6106, 'X0': 17.5659, 'Z1': 2.7104, 'Z0': 0.0964}.

**Rows the automatic book had for Z0 in f350-373:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 111 | 1 | Z0 cols a | f349.00-f360.81 | 13.4510 | 13.9062 | 14:24 | 1:12 | 3:13 | 1:12 |
| 111 | 2 | Z0 cols b | f349.00-f360.81 | 13.4510 | 13.9062 | 25:26 | 1:12 | 1:2 | 1:12 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 124 | 1 | Z0 cols a | f349.00-f360.81 | 13.4510 | 13.9062 | 14:24 | 1:12 | 3:13 | 1:12 |
| 124 | 2 | Z0 cols b | f349.00-f360.81 | 13.4510 | 13.9062 | 25:26 | 1:12 | 1:2 | 1:12 |
| 126 | 2 | Z0 rows a | f360.86-f373.63 | 13.9081 | 14.4003 | 1:13 | 1:12 | 1:13 | 25:36 |
| 127 | 1 | Z0 rows a | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 25 | 1:13 | 28 |
| 127 | 1 | Z0 rows b | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 29 | 1:13 | 34 |
| 127 | 2 | Z0 rows c | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 27 | 1:13 | 25 |
| 127 | 2 | Z0 rows d | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 28,34 | 1:13 | 27,33 |
| 127 | 2 | Z0 rows e | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 33 | 1:13 | 29 |

### A73. frames 373-379 -- Z0 rows f373-379 `25->28 \| 29->34 \| 27->25 \| 28,34->27,33 \| 33->29`

UNDETERMINED Z0 rows f373-379 (the candidate 25:29<->30:34 read 0.104): six rows move in five rigid groups. Gold rows 25 -> 28 and 29 -> 34 (25.19 29.15 f374, 25.46 30.29 f375, 26.71 31.59 f376, 27.67 ~33 f377, 27.93 33.88 f378) and mauve rows 27 -> 25, 28,34 -> 27,33, 33 -> 29 (26.93 27.93 32.81 33.97 f374; 26.50 27.78 32.10 33.82 f375; 25.89 27.47 30.84 33.41 f376; 25.30 27.14 29.64 33.17 f377; 25.07 27.00 29.13 32.99 f378); rows 26, 30:32, 35, 36 static; on tones f379. |  start moved from f373.30 to f373.63, the boundary with the block's previous move (chosen by measurement).

Measured: smoothstep mean 0.1018 (worst 0.532), moving-frame mean 0.1137, free per-frame 0.0815, monotone 0.1359; window f373.63-f378.37 (t 14.4003-14.5830 ms); per species {'X1': 24.3075, 'X0': 24.2989, 'Z1': 0.1045, 'Z0': 0.0923}.

**Rows the automatic book had for Z0 in f373-379:**

_(no rows)_

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 126 | 2 | Z0 rows a | f360.86-f373.63 | 13.9081 | 14.4003 | 1:13 | 1:12 | 1:13 | 25:36 |
| 127 | 1 | Z0 rows a | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 25 | 1:13 | 28 |
| 127 | 1 | Z0 rows b | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 29 | 1:13 | 34 |
| 127 | 2 | Z0 rows c | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 27 | 1:13 | 25 |
| 127 | 2 | Z0 rows d | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 28,34 | 1:13 | 27,33 |
| 127 | 2 | Z0 rows e | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 33 | 1:13 | 29 |
| 128 | 1 | Z0 rows a | f379.40-f382.96 | 14.6227 | 14.7599 | 1:13 | 26 | 1:13 | 31 |
| 128 | 2 | Z0 rows b | f379.40-f382.96 | 14.6227 | 14.7599 | 1:13 | 30 | 1:13 | 26 |
| 128 | 2 | Z0 rows c | f379.40-f382.96 | 14.6227 | 14.7599 | 1:13 | 31 | 1:13 | 30 |

### A74. frames 379-383 -- Z0 rows f379-383 `26->31 \| 30->26 \| 31->30`

the last-resort 26:28->29:31 | 29:31->26:28 is wrong: rows 27, 28, 29 sit at 26.98 27.98 28.98 on f380-382. A 3-cycle: gold row 26 -> 31 (26.51 f380, 27.85 f381, 29.62 f382), mauve row 30 -> 26 (29.56, 28.32, 27.08) and mauve row 31 -> 30 (30.87, 30.60, 30.30); on tones at the f383 pulse.

Measured: smoothstep mean 0.0467 (worst 0.612), moving-frame mean 0.0213, free per-frame 0.0213, monotone 0.0; window f379.40-f382.96 (t 14.6227-14.7599 ms); per species {'X1': 19.572, 'X0': 19.553, 'Z1': 0.0578, 'Z0': 0.0467}.

**Rows the automatic book had for Z0 in f379-383:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 113 | 1 | Z0 rows a | f380.82-f382.85 | 14.6774 | 14.7557 | 1:13 | 26:28 | 1:13 | 29:31 |
| 113 | 2 | Z0 rows b | f380.82-f382.85 | 14.6774 | 14.7557 | 1:13 | 29:31 | 1:13 | 26:28 |

**Rows the s31 book has:**

| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |
|---|---|---|---|---|---|---|---|---|---|
| 127 | 1 | Z0 rows a | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 25 | 1:13 | 28 |
| 127 | 1 | Z0 rows b | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 29 | 1:13 | 34 |
| 127 | 2 | Z0 rows c | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 27 | 1:13 | 25 |
| 127 | 2 | Z0 rows d | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 28,34 | 1:13 | 27,33 |
| 127 | 2 | Z0 rows e | f373.63-f378.37 | 14.4003 | 14.5830 | 1:13 | 33 | 1:13 | 29 |
| 128 | 1 | Z0 rows a | f379.40-f382.96 | 14.6227 | 14.7599 | 1:13 | 26 | 1:13 | 31 |
| 128 | 2 | Z0 rows b | f379.40-f382.96 | 14.6227 | 14.7599 | 1:13 | 30 | 1:13 | 26 |
| 128 | 2 | Z0 rows c | f379.40-f382.96 | 14.6227 | 14.7599 | 1:13 | 31 | 1:13 | 30 |

## A'. Moves DELETED from the automatic book

| automatic move | why |
|---|---|

| X0 rows f055-061 `1:6->2:7 \| 7->1` | row 4 is static; X0 does X1's `3,7->1,5 \| 1,2,5,6->2,3,6,7` (one rectangle now) |

| X1 rows f132-136 `14->19 \| 15->18 \| 17:18->14:15 \| 19->17` | X1 does X0's `14:15->18:19 \| 16:19->14:17` (one rectangle now) |

| X1+X0 rows f148-154 `22:23->19:20 \| 19:21->21:23` | duplicate of the same batch (X atoms claimed twice) |

| X1 rows f165-171 `22:24->15:17 \| 15:21->18:24` | duplicate of the X1+X0 row (and both maps replaced) |

| Z0 rows f249-256 `7->3 \| 3:6->4:7` | phantom: rows on tones f252-254 |

| Z0 rows f281-291 `6->7 \| 7->6` (empty comb) | phantom: rows on tones f281-293 |

| Z1 rows f289-296 8-part | replaced, with the f281-291 'relocation', by one four-group exchange |

| Z0 rows f300-309 `6->10 \| 7:10->6:9` | phantom: rows 6, 7 on tones f300-310 |


## B. Moves over the 0.10 guideline in the s31 book -- check the map by eye

Rule from c540: 29 of 31 over-guideline moves there were right. Only name the ones the movie contradicts. The fast whole-block wraps (Z0 cols f350-361, 24 columns in 12 frames) and the four-frame moves are over the bar on the smoothstep fit while their free per-frame error is small.

| species | axis | frames | t (ms) | comb | map | mean | free | origin |
|---|---|---|---|---|---|---|---|---|

| X1+X0 | rows | f026-032 | 1.022-1.149 | 1:26 | 1->3 \| 3->1 \| 4->6 \| 6->4 | 0.1576 |  |  |

| X1+X0 | rows | f030-034 | 1.149-1.336 | 1:26 | 1:6->7:12 \| 7:12->1:6 | 0.1598 |  | last resort |

| X0 | cols | f072-079 | 2.700-2.962 | 1:12 | 1:5->9:13 \| 6:13->1:8 | 0.1877 | 0.0612 | HAND s31 |

| X1 | cols | f071-077 | 2.700-2.962 | 1:12 | 14:18->22:26 \| 19:26->14:21 | 0.1921 | 0.0742 | HAND s31 |

| Z1 | rows | f084-093 | 3.222-3.510 | 1:13 | 34->25 \| 25:33->26:34 | 0.1061 | 0.0672 | HAND s31 |

| X1+X0 | rows | f165-171 | 6.376-6.629 | 1:26 | 13:21->16:24 \| 22:24->13:15 | 0.1287 | 0.0616 | HAND s31 |

| X0 | cols | f216-224 | 8.270-8.541 | 25:36 | 1:3->11:13 \| 4:13->1:10 | 0.1028 | 0.0555 | HAND s31 |

| Z1+Z0 | cols | f216-224 | 8.270-8.541 | 1:24 | 1:10->4:13 \| 11:13->1:3 | 0.1333 | 0.043 | HAND s31 |

| X0 | rows | f238-241 | 9.190-9.277 | 1:13 | 33->34 \| 34->33 | 0.1006 | 0.1428 | HAND s31 |

| X0 | rows | f241-246 | 9.282-9.519 | 1:13 | 25:31->30:36 \| 32:36->25:29 | 0.1267 |  | last resort |

| Z0 | rows | f254-262 | 9.781-10.033 | 1:13 | 2:4->10:12 \| 5:12->2:9 | 0.1033 |  | last resort |

| Z1 | rows | f254-262 | 9.781-10.033 | 1:13 | 14:16->22:24 \| 17:24->14:21 | 0.1020 |  | S2.1 |

| Z0 | rows | f310-316 | 11.962-12.022 | 14:26 | 1->3 \| 3->1 \| 6->8 \| 8->6 | 0.1268 |  |  |

| Z0 | cols | f350-375 | 13.451-13.906 | 1:12 | 14:24->3:13 \| 25:26->1:2 | 0.1280 |  |  |

| Z0 | rows | f373-379 | 14.400-14.583 | 1:13 | 25->28 \| 29->34 \| 27->25 \| 28,34->27,33 \| 33->29 | 0.1018 | 0.0815 | HAND s31 |


## C. Checked on the pixels and found CORRECT (no change)

* X0 cols f002-010 `1:2->12:13 | 3:13->1:11`; X1+X0 rows f008-034 (all seven moves incl. the two over-guideline ones: `1->3 | 3->1 | 4->6 | 6->4` f026-030 and the involution `1:6<->7:12` f030-035 -- gold 7:12 up, mauve 1:6 down frame by frame).

* X0, X1 and Z0 cols f037-045: X rotate by -4 (`5:13->1:9 | 1:4->10:13`, `14:17->23:26 | 18:26->14:22`), Z0 by +4 (`1:9->5:13 | 10:13->1:4`) -- the directions are right as written.

* X1+X0 rows f051-055 `4:7->5:8 | 8->4`, f058-063 `1:3<->4:6`, f066-070 `7:9->9:11 | 10:11->7:8`; X0 cols f072-079 `1:5->9:13 | 6:13->1:8`.

* Z1 rows f084-091 `34->25 | 25:33->26:34`, f095-099 `28:31->30:33 | 32:33->28:29`, f100-104 `33:35->34:36 | 36->33`, f104-107 `31:32->34:35 | 33:35->31:33`.

* X1+X0 rows f109-116 `13:18<->19:24`, f114-119 `22->24 | 23:24->22:23`, f120-132 `14->22 | 15:22->14:21`; X0 rows f133-137 `14:15->18:19 | 16:19->14:17` (now carrying X1 too).

* X1 cols f139-147 and Z1 cols f139-146 (X by +9, Z1 by +4 -- opposite, as written); X1+X0 rows f148-154 `19:21->21:23 | 22:23->19:20` (one copy), f152-158 `15->18 | 16:18->15:17`; Z1 rows f152-161 `27->36 | 31->27 | 36->31`, f166-171 `30->28 | 28:29->29:30`; X1 rows f197-207 `13:24->25:36`.

* X0 cols f216-224 `1:3->11:13 | 4:13->1:10` and Z1+Z0 cols `1:10->4:13 | 11:13->1:3` (opposite, as written); X0 rows f222-227 `28:29<->30:31`, f229-235 `30:31->26:27 | 26:29->28:31`, f234-240 `36->32 | 32:35->33:36`, f241-246 `25:31->30:36 | 32:36->25:29` (the last-resort rotation by 5 is right); Z1+Z0 cols f249-256 `1:7->7:13 | 8:13->1:6`; Z0 rows f254-262 `2:4->10:12 | 5:12->2:9`, Z1 rows f254-262 `14:16->22:24 | 17:24->14:21`; Z0 rows f261-269 `1:7->5:11 | 8:11->1:4`, Z1 rows `13:19->17:23 | 20:23->13:16`.

* X1 cols f281-290 `14:26->1:13` and f288-297 `1:12->2:13 | 13->1`; Z rows f307-312, f310-316 (Z0 `1->3 | 3->1 | 6->8 | 8->6` is two real pair swaps), f314-321, f319-326, f324-329, f327-332 -- all confirmed; Z0 cols f350-375 `14:24->3:13 | 25:26->1:2`; Z1 rows f362-375 `13:24->25:36`.


## D. Not defects

* The 8 readout/load/carry-in rows of `extra.json` (Z readout f174-178 descending +9 rows, Z loads f174 at cols -12:0, Z carry-in f205-214.5, X readout f350-355, X loads f350 at rows -11:0, X carry-in f372-382): destinations of the descents and the integer staging are CONVENTIONS (report section 3), unchanged.

* Not verified frame by frame (no doubt raised, no probe): X0 cols f281-290 `1:13->-12:0` (the parking slide), the readout windows.
