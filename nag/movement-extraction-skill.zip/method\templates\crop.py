"""crop.py -- montage of one lattice region across frames, for reading a block's movement by eye.
   python crop.py OUT.png f0 f1 c0 c1 r0 r1 [ncol]      (c, r in tone units; frames from calib.json)"""
import json, sys, os
from PIL import Image, ImageDraw

out, f0, f1 = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
c0, c1, r0, r1 = [float(v) for v in sys.argv[4:8]]
ncol = int(sys.argv[8]) if len(sys.argv) > 8 else 7
C = json.load(open("calib.json"))
ox, px, oy, py = C["origin_x"], C["pitch_x"], C["origin_y"], C["pitch_y"]
# sb_read: pixel = origin + (tone - 1 + marker_offset) * pitch  (the origin is tone 1)
X0, X1 = int(ox + (c0 - 1) * px), int(ox + (c1 - 1) * px)
Y0, Y1 = int(oy + (r0 - 1) * py), int(oy + (r1 - 1) * py)
frames = list(range(f0, f1 + 1))
w, h = X1 - X0, Y1 - Y0
nrow = (len(frames) + ncol - 1) // ncol
M = Image.new("RGB", (ncol * (w + 4), nrow * (h + 18)), (40, 40, 40))
d = ImageDraw.Draw(M)
for i, f in enumerate(frames):
    im = Image.open(os.path.join(C["frames_dir"], "p_%03d.png" % f)).crop((X0, Y0, X1, Y1))
    x, y = (i % ncol) * (w + 4), (i // ncol) * (h + 18)
    M.paste(im, (x, y + 16))
    d.text((x + 2, y + 1), "f%03d" % f, fill=(255, 255, 0))
    # tone grid: faint lines through every integer tone (marker_offset applied), labels at the left / top
    mx, my = C.get("marker_offset", [0, 0])
    for r in range(int(r0) + 1, int(r1) + 1):
        yy = y + 16 + int((r + my - r0) * py)
        d.line((x, yy, x + w, yy), fill=(255, 80, 80))
        d.text((x + 1, yy - 11), str(r), fill=(255, 0, 0))
    for c in range(int(c0) + 1, int(c1) + 1):
        xx = x + int((c + mx - c0) * px)
        d.line((xx, y + 16, xx, y + 16 + h), fill=(255, 80, 80))
        d.text((xx + 1, y + 17), str(c), fill=(255, 0, 0))
M.save(out)
print("wrote", out, M.size)
