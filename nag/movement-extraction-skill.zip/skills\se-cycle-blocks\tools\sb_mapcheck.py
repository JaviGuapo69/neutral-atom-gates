"""sb_mapcheck.py -- verify every move's MAP independently of its TIMING.

SKILL.md rule 11 / section 3a: all sub-blocks of a move share ONE easing, so at every frame
d_i(t) = D_i * s(u).  Solve for the progress s SEPARATELY from each sub-block's own measured
displacement.  If the map is right every part gives the SAME s on every frame, whatever the easing
is doing -- so a WRONG PARTITION shows up as a spread in s even when the fitted timing is perfect,
and a merely MISTIMED move shows up as a clean s that simply differs from the model's.

That separation is the point.  The profile score cannot tell the two apart: both raise the mean.
This says which you have, and on c300 it was what established that the elevated means were a
one-frame timing bound and not wrong maps -- before the bound was found and fixed.

    python sb_mapcheck.py --calib calib.json --moves moves_full.json

RULE 20 IS THE TRAP HERE, AND THIS SCRIPT FELL INTO IT FIRST.  After two sub-blocks cross, the peak
COUNT is back to normal but the ORDER is scrambled, so `sorted(peaks)[i]` is no longer tone i and
three exactly-correct maps scored a spread of 1.2 to 4.1.  Guarding by "stop at the first frame
whose count is short" is right in principle and useless in practice -- one mask dropout ends the
window and it left 41 of 54 moves unchecked.  So compute the crossing analytically instead: tone a
of one part meets tone b of another at progress s = (b - a) / (D_a - D_b), and the first crossing
is the smallest such s in (0, 1].  Use only frames below it.  The FRAME SELECTION uses the fitted
timing; the TEST does not.
"""
import argparse, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sb_compose
from sb_read import Movie, smoothstep

SPREAD_OK = 0.05        # progress units: a correct partition agrees far better than this
SPREAD_BAD = 0.12


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--moves", required=True, help="moves_full.json from sb_full.py")
    ap.add_argument("--margin", type=float, default=0.85,
                    help="fraction of the first-crossing progress to stay below")
    a = ap.parse_args()

    M = Movie(a.calib, a.frames)
    moves = json.load(open(a.moves))["moves"]

    print("%-9s %-4s %-11s  %-4s %-6s %-6s %s"
          % ("species", "axis", "frames", "nfr", "sprMAX", "sprP75", "verdict"))
    flagged, checked = [], 0
    for m in sorted(moves, key=lambda m: m["f0"]):
        axis = 0 if m["axis"] == "cols" else 1
        parts = m["parts"]
        if len(parts) < 2:
            continue                       # k = 1: one part gives one s, nothing to cross-check
        f0, f1, src = m["f0"], m["f1"], m["src"]
        Dm = {s: t - s for s, t in zip(src, m["dst"])}

        scross = 1.0
        for si in src:
            for sj in src:
                dD = Dm[si] - Dm[sj]
                if si == sj or dD == 0:
                    continue
                s = (sj - si) / float(dD)
                if 1e-6 < s <= 1.0:
                    scross = min(scross, s)

        wins = sb_compose.species_windows(M, max(0, f0 - 2), min(M.nf - 1, f1 + 2))
        P = sb_compose.Peaks(M, wins, max(0, f0 - 2), min(M.nf - 1, f1 + 2))
        spreads = []
        for f in range(f0, f1 + 1):
            if f in M.gate:
                continue
            u = (f - m["fa"]) / (m["fb"] - m["fa"])
            if float(smoothstep(u)) > a.margin * scross:
                continue
            meas = sorted(P(m["sp"], f, axis))
            if len(meas) != len(src):
                continue
            ss = []
            for p in parts:
                aa, bb = sorted(p[0]), sorted(p[1])
                if bb[0] - aa[0] == 0:
                    continue
                ss.append(sum((meas[sorted(src).index(s0)] - s0) / float(s1 - s0)
                              for s0, s1 in zip(aa, bb)) / len(aa))
            if len(ss) >= 2:
                spreads.append(max(ss) - min(ss))

        name = "+".join(m["joins"])
        if len(spreads) < 3:
            print("%-9s %-4s f%03d-f%03d  %-4d (too few pre-crossing frames to cross-check)"
                  % (name, m["axis"], f0, f1, len(spreads)))
            continue
        checked += 1
        p75 = sorted(spreads)[int(0.75 * (len(spreads) - 1))]
        verdict = ("MAP OK" if p75 <= SPREAD_OK else
                   "map suspect" if p75 <= SPREAD_BAD else "*** MAP WRONG?")
        print("%-9s %-4s f%03d-f%03d  %-4d %-6.3f %-6.3f %s"
              % (name, m["axis"], f0, f1, len(spreads), max(spreads), p75, verdict))
        if p75 > SPREAD_OK:
            flagged.append((p75, name, m["axis"], f0, f1))

    print("\n%d move(s) cross-checked; %d with a 75th-percentile progress spread over %.2f"
          % (checked, len(flagged), SPREAD_OK))
    for w in sorted(flagged, reverse=True):
        print("   %.3f  %-9s %-4s f%03d-f%03d" % w)
    print("A move with too few pre-crossing frames is NOT verified by this test -- it is simply "
          "not testable this way; check it against the outline profiles with sb_probe.py.")
    return 1 if flagged else 0


if __name__ == "__main__":
    sys.exit(main())
