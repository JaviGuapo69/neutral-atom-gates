# c975 — second and third pass: your items applied, and every open window read

**Written for: Javier.** You approved the twelve corrections written up in `SESSION_32_USER_ITEMS_TO_APPLY.md`
and asked a fresh session to apply them, and to have a go at the windows session 32 could not read. That is
§2 and §3. You then watched the result, said it was greatly improved, and named four more windows — those
are §3d, all four checked against the pixels and applied. This is the account; the thing to look at is the
new video.

**Deliverable: `c975_s32_blocks.xlsx` + `c975_s32_original_vs_rebuild_panels.mp4` / `_full.mp4`** — in
`run_c975_s32\` and at the project root (same names as before, they overwrite). Per-move evidence, all 75
corrected or added moves with their maps, windows and residuals: `run_c975_s32\s32_correction_list.md`.

---

## 1. What changed since the video you watched

| | s32 (the video you watched) | now |
|---|---|---|
| moves | 86 | **95** |
| undetermined transitions | 7 | **0** |
| `sb_audit` | CLEAN, but 8 transitions still unexplained | **CLEAN, 101 of 101 transitions explained, 0 holes** |
| `se_sim` | clean, census 780 | **clean, census 780** |
| render validation entries | 0 | (see §5) |
| `sb_score` | 0.0606 site | (see §5) |
| AOM groups / peak | 6 / 6 | **6 / 6** |

The line that matters most is the second one. Until now the sheet carried a footnote — *"clean means nothing is
SILENTLY missing; 8 transitions are still undetermined and the sheet is not complete until each has a row."*
That footnote is gone. **Every transition of every block now has a row.**

---

## 2. Your twelve items (52–63), as approved

All twelve applied exactly as written up, with the measured residual each one was chosen on.

| # | frames | block | what was wrong | applied | mean |
|---|---|---|---|---|---|
| 52 | f001-007 | Z0 (D5) | the comb was read as five rows; all fifteen move | same map (+9), comb = whole block rows 31:45 | 0.0699 |
| 53 | f145-151 | X0 (D3) | no move and no transition at all | `1→13 \| 13→10 \| 10→1`, rows 16:30 | 0.0674 |
| 54 | f160-164 | X0 (D3) | no move | `4→9 \| 9→11 \| 11→4`, rows 16:30 | 0.0514 |
| 55 | f185-190 | X0 | `2:7↔8:13` moved twelve columns; the movie moves three | `2→13 \| 13→7 \| 7→2` | 0.0685 |
| 56 | f190-194 | — | X0 was in the `3↔4` batch; it is at rest on f191-192 | X0 dropped, comb narrowed to rows 1:30 | 0.1208 |
| 57 | f193-198 | X0 | `11→1 \| 1:10→2:11` moved eleven columns | `1→10 \| 10→11 \| 11→1` | 0.0517 |
| 58 | f201-205 | X0 | undetermined | `4→6 \| 6→12 \| 12→4` | 0.0532 |
| 59 | f207-210 | X0 | `5→9 \| 6:9→5:8` moved two still columns | `5→9 \| 9→8 \| 8→5` | 0.0382 |
| 60 | f239-250 | Z0+Z1 | map right, window 1.3 frames late → up to 1.4 sites of lag | refit from the gate instant f237 | 0.1881 → **0.1257** |
| 61 | f278-282 | X1 | undetermined | **superseded by item 70 — see §3c** | — |
| 62 | f284-287 | X1 | undetermined | `3↔6 \| 9↔12` | 0.0779 |
| 63 | f335-350 | Z0 (D1) | two sub-comb rotations written as one on eleven rows | +3 on rows 2,5,8,11,14 f335-341 **added**; +12 restricted to rows 3,6,9,12,15 f343-350 | 0.0698 / 0.0245 |

Eleven of the twelve went in exactly as approved. The twelfth, item 61, turned out to be wrong once I could
scan it properly — §3c.

### One thing I had to fix to make item 60 stick

The timing-hygiene pass at the end of the script was quietly undoing it. Z's row rotation fits to f237.98 and
the translation to f237.25, so they overlap by 0.73 frames; the pass splits such an overlap at whichever
boundary measures best, and here the two candidates came out at **0.319 against 0.321** — a tie of two parts
in a thousand, which handed the translation the late start again and put your 1.4-site lag straight back
(the move re-measured at 0.2884 instead of 0.1257).

The whole overlap lies inside the pulse run f237-238, and **nothing moves during a gate** — both fits are just
tails meeting inside the frozen frames. So the pass now skips any overlap contained in a single pulse run and
lets both moves keep their own fit. That rule fired six times in the book, always on the same pattern (a row
rotation ending into a gate and a column move starting out of it), and it is worth keeping.

---

## 3. The two windows session 32 left open — both read

Session 32 stopped on these and wrote *"do not invent a map"*. They are readable, and they turned out to be
**the same shape as each other**: not one cycle but **two disjoint 3-cycles sharing one window**. That is
exactly why no cyclic rotation fitted either of them, and why the residuals at the landing frames looked like
two different timings — six columns moving under one progress, but in two independent orbits.

| # | window | map | free error | runner-up |
|---|---|---|---|---|
| 64 | X0 cols f153-157 (rows 16:30) | `2→3→6→2` **and** `5→12→7→5` | **0.0467** | 0.0722 |
| 65 | Z0 cols f278-282 (rows 1:15) | `14→22→16→14` **and** `17→23→25→17` | **0.0372** | 0.0641 |
| 66 | Z1 cols f284-289 (rows 16:30) | the same map, seven frames later | **0.0404** | 0.0605 |

**How.** `gaps.py` gives the set of moving columns; the question was always which column goes where. I added
`run_c975_s32\permscan.py`, which ranks **every** permutation of that set — all 265 derangements of six
tones — on the skill's own fit and the FREE per-frame progress error, the way `rotscan.py` ranks every
rotation. Exactly as with a rotation, each map ties with its own inverse to four decimals on the free error,
so the direction comes from the smoothstep mean and the fitted window: each winner fits **rest to rest**
(X0 f152.54-158.00, Z1 f283.14-290.00) while its inverse fits a window the pixels refute.

Two independent confirmations that these are right:

* **Z0 and Z1 agree.** They were scanned separately and the same map wins both — Z1 by 0.0404 against 0.0605,
  Z0 by 0.0372 against 0.0641. Session 32 had already shown these are one movement seven frames apart; now
  they carry one map. At Z1's last moving frame f289 the six distances still to run are 0.10 / 0.34 / 0.37 /
  0.39 / 0.27 / 0.18, which is one common (1−p) = 0.05 times displacements 2, 6, 8, 8, 6, 2 — this pair of
  3-cycles and no other.
* **X0's interval makes sense at last.** With item 64 in place, f145-f165 is four whole-block 3-cycles —
  (1 13 10), (2 3 6), (5 12 7), (4 9 11) — which between them permute twelve of the thirteen columns and
  leave only column 8 standing. Checked against the peaks of row 16 at f156: the map predicts
  2.70 / 3.22 / 5.09 / 5.61 / 8.52 / 9.87 and the movie shows 2.70 / 3.32 / 5.04 / 5.66 / 8.67 / 9.53.

### 3b. The last two holes (item 67) — neither was a movement

* **X1 f126-128.** Not a movement at all. Over f125-f129 the only lines of X1 that ever leave their column
  tones are the sub-comb 17,20,23,26,29 at f125 (the end of the f120-125 rotation) and the sub-comb
  18,21,24,27,30 from f127 on (the start of the f127-133 rotation). At f126 **nothing moves**, on either axis,
  on any of the fifteen rows or thirteen columns. So f126 is a rest and f128 is not — it is the second frame
  of the comb-C rotation — and occupancy had split one transition into f126-128 plus f128-134. Merged back
  into f126-134, which the existing move already explains.
* **X0 f269-271.** A stale entry: item 51 had already dropped that transition (the block is parked off panel
  and nothing can be read there) but left the report line behind.

### 3c. Item 70 — one of your approved items was wrong, and I have changed it

**Item 61 (X1 cols f278-282) does not survive the scan, so I replaced it.** I am flagging this rather than
burying it, because you approved the other reading.

In the finished book it was the **only** map with a free per-frame error still above 0.13 — three times every
other window of its kind — so I put it through `permscan.py` as well. Item 61's map does not appear in the
top eight of all 265 derangements. The winner is, once again, **two disjoint 3-cycles**:

| | map | free error |
|---|---|---|
| item 61, as approved | `2↔13 \| 4→10 \| 10→11 \| 11→5 \| 5→4` | 0.1326 |
| **item 70, applied** | `2→4→10→2` **and** `5→13→11→5` | **0.0588** |

The pixels settle it at f279 and f280, where item 61's map has no explanation at all:

* **f279**, off-tone peaks 2.50, 7.19, 7.68, 12.30. Item 61 read the 7.19 / 7.68 pair as columns 2 and 13
  crossing in a ±11 swap — which needs p = 0.47 one frame after p = 0.028 — and then nothing in that map
  lands anywhere near 2.50 or 12.30. Under the two 3-cycles the crossing pair is columns 5 (+8) and 10 (−8)
  at p = 0.28, predicted 7.24 / 7.76; the 2.50 and 12.30 are the short ±2 hops of columns 2 and 13; and
  columns 4 (+6) and 11 (−6) sit at 5.68 and 9.32, merged with the static columns 6 and 9 — which is why
  that frame shows 11 peaks and not 13.
* **f280**, visible off-tone peaks 5.16, 7.66, 9.74. This map predicts 5.20, 7.60, 9.80 at p = 0.60
  (columns 10, 11, 5). Item 61's map cannot produce that triple at any progress.
* **f282**, the frame the first reading was built on, does not separate them: the distances still to run,
  0.41 / 0.25 / 0.23 / 0.41, are one common (1−p) times 8 / 6 / 6 / 8 under this map and times
  11 / 6 / 6 / 11 under item 61's. That is why it survived the first look.

Item 61's map is kept in `apply_s32.py` as a comment beside the new one, so it is a one-line revert if you
disagree.

I re-scanned **item 62** (`3↔6 | 9↔12`) the same way: it comes out top-two within 0.001 of the leader and wins
the tie on its rest-to-rest window, so it stands exactly as approved.

---

## 4. What I did not touch

* The skill's `tools\` — unchanged, as always.
* `run_c975\` — provenance only, never written to.
* No xlsx cell was edited. Everything goes through `apply_s32.py` → `sb_emit.emit`, from the untouched
  `moves_full_c975_original.json` / `rests_full_c975_original.json`, so the whole book is reproducible with
  one command.

---

## 3d. Your four items from the 2026-09-21 video (items 71–74)

You watched the second-pass video, said it was greatly improved, and named four windows. **All four are
right, all four were checked against the pixels before being applied, and all four beat what the book had
by a factor of two to five on the free per-frame error.**

| # | frames | block | what you said | measured (yours / the book's) |
|---|---|---|---|---|
| 71 | f186-190 | Z1 (D3) | both Z blocks do one move: col 4 +3, cols 5:7 −1, col 10 +3, cols 11:13 −1 | **0.0230** / 0.0918 |
| 72 | f239-250 | Z0+Z1 | not a whole block: col 1 +25, cols 2:13 +12 | **0.0565** / 0.0833 |
| 73 | f284-288 | X1 (D5) | six columns: 3 +4, 6 −3, 7 −1, 8 +1, 9 +3, 12 −4 | **0.0344** / 0.0857 |
| 74 | f291-294 | Z0 (D2) | six columns: 15 +3, 18 +1, 19 −4, 20 +4, 21 −1, 24 −3 | **0.0261** / 0.1383 |

The pixel evidence for each:

* **71.** Z0 and Z1 agree to 0.02 site on every frame of f183-f196, so they are provably one movement — and
  Z0 already carried your map; only Z1 had a ten-column rotation. At f189 the only empty tones are 7 and 13,
  approached from below and both 0.41 short, which is one common (1−p) = 0.137 times +3, i.e. 4→7 and 10→13.
* **72.** The first moving frame settles it: at f239 column 1 is at 1.57 (+0.57) while all twelve of columns
  2:13 are at +0.25. A rigid +13 moves them equally; column 1 moves 2.3× as far against the 25/12 = 2.1 your
  map predicts. This turned out to be the rest of your item 60 — the *window* was fixed then, the *map* now.
* **73.** At f284 the six deltas are +0.22, −0.20, −0.05, +0.08, +0.20, −0.28, and dividing each by your
  displacements (+4, −3, −1, +1, +3, −4) gives 0.055, 0.067, 0.05, 0.08, 0.067, 0.07 — one common progress
  across all six. Under the old `3↔6 | 9↔12` the −0.05 and +0.08 have no cause at all.
* **74.** The empty tones over f291-f294 are exactly your six columns; 16, 17, 22, 23 never leave their
  tones, and the book moved all nine. Your map is also *exactly* the one the book already carries for the
  twin Z1 at f295-302, the same movement five frames later.

### What your items exposed about my method

Two of these (73, 74) are maps my own scans got wrong, for one reason worth recording: **`gaps.py` cannot
see a column that moves by one tone.** At low progress a ±1 column never leaves the 0.15 tolerance around
its source; at high progress it is already inside its destination's. So a permutation containing ±1 parts
reads as a *smaller* permutation of only the columns that travel further, and the scan is then run on the
wrong mover set. Both f284 and f290 came out as two disjoint 3-cycles once the ±1 columns were restored —
the same shape as every other small permutation in this movie.

**One knock-on I fixed with them (71b).** The `3↔4` swap at f190-194 had been fitted to f188.77-192.31 only
because the wrong Z1 map was ending early and leaving that space. With your map the two overlapped by 1.6
frames and the AOM count went 6 → 8. The pixels separate them completely — the Z blocks are on tone at f190,
only f191 shows the swap, on tone again at f192 — so it was refitted into f190-192: **0.0201, was 0.1208**,
and the AOM count is back to 6.

---

## 3e. Your last item (77) — f317-f325 in D5, and why nothing ever saw it

You said there was a missing movement in D5 from f317 to f325. There was, and the book had **neither a
move nor a transition** for it: X1's rests stop at f316-317 and the next entry in the file is the readout
at f326. **X1's fifteen rows rotate by +3 over f318-f324** (`31:42→34:45 | 43:45→31:33`); its columns
never move there at all, and all thirteen columns carry the row move.

What pins the map is the compression — the block's row span shrinks from 14 rows to 11 and re-expands,
which no rigid move can do: twelve rows travel +3 and three travel −12. At f324 (p = 0.973) the map
predicts 31.32 / 32.32 / 33.32 for the three and 33.92 … 44.92 for the twelve, against 31.37 / 32.38 /
33.33 and 33.90 … 44.94 observed. The direction is +3 and not its inverse +12 because on the first moving
frame all twelve of rows 31:42 move *down* (+0.18) while the three race up; the free error cannot separate
a rotation from its inverse (0.0317 either way) but the smoothstep reads **0.1198 / worst 0.687 for +3
against 0.2114 / worst 2.041 for +12**.

**Why no automatic tool ever saw it, which is worth keeping.** At p = 1/3 of a +3 rotation of fifteen rows
**both groups land exactly on integers at once** — the twelve one site down, the three four sites up, and
the three land *on top of* three of the twelve. So f320 shows twelve on-tone peaks and reads as a **rest**:
`lineprof` reports "moving lines: none" for that frame. The occupancy detector saw a rest, found no
transition, and the window simply never entered any list — not even the undetermined one. The tell is the
peak **count** (twelve where the block has fifteen rows) and the span compressing.

This one item removed four of the book's remaining spikes at once: f319, f321, f322, f323 read
1.97 / 1.56 / 2.25 / 1.44 site and now read **0.67 / 0.27 / 0.36 / 0.51**.

---

## 5. Checks on the final book

| check | automatic `run_c975` | s32 (your first viewing) | FINAL |
|---|---|---|---|
| moves | 80 | 86 | **96** |
| undetermined transitions | 15 | 7 | **0** |
| `sb_audit` | FAILED, 2 | CLEAN, 8 unexplained | **CLEAN, 102 of 102 explained, 0 holes** |
| `se_sim` | check4 ×366 | clean | **clean, census 780** |
| render validation entries | 374 | 0 | **0** |
| `sb_score` | 0.3237 site | 0.0606 site | **0.0575 site** |
| frames with a worst over 1.5 site | — | 18 | **12** |
| AOM groups / peak | 8 / 8 | 6 / 6 | **6 / 6** |

The s32 column is not quoted from the old report — I re-rendered and re-scored the delivered book in
`rframes_old\` so the two numbers are measured the same way on the same day.

**Your four windows, per-frame worst error, before and after:**

| window | before | after |
|---|---|---|
| f186-190 | 0.87 / 0.99 / 0.76 / 1.00 / 1.00 / 0.87 | **0.87 / 0.51 / 0.35 / 0.45 / 0.51 / 0.60** |
| f239-250 | up to 1.05 | up to **0.46** |
| f284-288 | 0.34 / 0.61 / 0.67 | **0.41 / 0.51 / 0.56** |
| f291-294 | 0.43 / 0.63 / 0.76 / 0.30 | **0.21 / 0.19 / 0.44 / 0.23** |

**Spikes that went away since the book you watched** (none appeared): f003-f005, 2.71 / 2.32 / 1.94 → 0.47 /
0.57 / 0.69 (your item 52) and f362, 10.41 → 0.55.

**The residuals that remain**, all pre-existing, none introduced by any pass and none in a window you ever
named: f320 (26.5 site, X0 rows — the largest in the book), f099-f101 (13.7), f305 (10.0), f313 (6.2),
f234 (3.0), f118 (2.9), f116 (2.0), f063 (1.9), f009 (1.6), f235 (1.6). If you ever want one of them read,
`permscan.py` + `gaps.py` is the tooling, with the ±1 blindness above in mind.

**One cost, stated plainly.** Clipping the Z rows rotations to their gates — which is what stops the render
breaking, and which the pixels demand — raised the residual inside those two windows: f231-f236 means went
0.064 → 0.067 … 0.137 → 0.167. Refitting inside the clipped bound halved that penalty but did not remove it.

---

## 6. Run book

```powershell
cd run_c975_s32
python -u apply_s32.py > apply_s32.log 2>&1
python ..\.claude\skills\se-cycle-blocks\tools\sb_audit.py --moves moves_full.json --rests rests_full.json
python ..\.claude\skills\se-cycle-movies\tools\se_sim.py c975_s32_blocks.xlsx
python ..\.claude\skills\se-cycle-blocks\tools\cmp_tol.py ..\run_c975\moves_full.json moves_full.json > s32_vs_c975.txt
python make_list_s32.py
.\deliver_s32.ps1                       # render + score + sb_watch + the two mp4s, ~42 min
```

New tools this session, both in `run_c975_s32\`:

* **`permscan.py`** — rank every permutation of a named set of moving tones on the free per-frame progress
  error. The general form of `rotscan.py`, and the thing to reach for when `gaps.py` has isolated a small set
  of movers and no rotation fits. `python permscan.py X0 0 153 157 1 13 2,3,5,6,7,12`
* **`peaks.py`** — raw marker peaks of one species on one axis, frame by frame, with the delta to the nearest
  tone. The blunt instrument for "does this block still move on this frame?"
* **`bnd.py`** — score a boundary between two consecutive moves of one block frame by frame, which is how the
  item-60 tie-break was caught.
