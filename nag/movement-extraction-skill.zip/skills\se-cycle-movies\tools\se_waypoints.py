"""se_waypoints.py -- transcribe a movie by reading each species' RESTING RECTANGLES, not by
propagating identity forward from the seed.

WHEN TO REACH FOR THIS INSTEAD OF se_moves.py
---------------------------------------------
`se_moves.py` fits each window's motion against the pixels and is very good at that -- 0.09 to
0.13 tone mean error.  But it carries species identity FORWARD from the seed through a chain of
fitted pick-ups, and that chain has one systematic failure mode:

    A BLOCK CROSSING THE EDGE OF THE PANEL.

Only on-screen atoms take part in the fit.  When a block is carried off the left edge the extractor
keeps, say, 5 of its 30 atoms, and the fit would have to send 25 atoms to nowhere to explain it.
It prefers the cheaper reading: re-pair the arrivals onto whatever sources are nearest -- which are
another species' atoms standing where the departing block used to be.  From that instant the
species labels are wrong, and because `move` rows pick up BY POSITION the error compounds forward.

On c150 this cost 1374 mislabelled site-frames from frame 54 on, two of four readouts never written
(`MIN_BLOCK = 8` in se_moves.py makes a 5-visible block structurally invisible, at any threshold),
38 per-site fragment rows in a single batch, and a demand for 33 AOM trap groups where the correct
schedule needs 4.  Run `se_divergence.py` to find out whether the movie you are working on has this
disease before you spend time tuning thresholds; it is not a tuning problem.

WHAT THIS DOES
--------------
Species identity comes from the pixels at EVERY step and is never inherited:

  1. REST IS PER SPECIES.  A species is at rest at a frame when all of its on-screen solid markers
     sit within `--tol` of a whole tone.  Do not wait for the whole array to be still: AODs act
     independently, and on c150 only 30 of 384 frames have every block on a tone, while each
     individual species rests dozens of times.

  2. EVERY MARKER MUST BE ON A TONE BEFORE YOU ROUND.  Rounding first and testing later calls a
     block in mid-flight "at rest" -- c150's X0 markers at x = 1.35, 2.37, 2.83 round to a tidy
     1:6 that is nowhere near where the atoms are.  This mistake moves every batch boundary.

  3. A PARTLY VISIBLE BLOCK IS SIZED BY ITS KNOWN POPULATION, never by what the panel shows.  Each
     species' block dimensions are measured once, from the first frame it is wholly on screen and
     on-grid.  Thereafter, if fewer sites are visible, the block is straddling an edge and its full
     rectangle is recovered by extending AWAY from the edge that cuts it -- and the inference is
     then verified by checking that the number of the full rectangle's sites lying inside the
     visible window equals the number of markers actually seen.  Sizing a block from its visible
     part is the mistake that cost c540 v11 51 atoms while rendering clean and scoring 84.9 %.

  4. A TRANSLATING BLOCK LANDS ON A TONE EVERY FRAME OR TWO, so one slow move shows up as a ramp of
     one-frame plateaus (guide 4.2).  Plateaus shorter than `--min-rest` are transit samples;
     everything between two genuine rests is ONE motion.

  5. A READOUT IS READ OFF THE FADED TRACK.  The block is drawn desaturated and descends off the
     panel.  Its start frame and rectangle are observable; its DESTINATION is not, and is written
     as the observed descent extended far enough to clear the array -- flagged as convention in
     every note.

  6. FRESH STOCK waits OFF the data lattice, half a pitch out, with one or two of its rows or
     columns on screen.  Its rectangle is rounded away from the array and extended off-panel to the
     block's known population: the one piece of invented geometry, and it is flagged.  The `load`
     goes at the frame the stock turns SOLID -- which is the readout frame, because the stock has
     been on screen faded since early in the cycle (handover 4.3).  Putting it just before the
     carry-in instead leaves the array short between the unload and the load, and `se_sim.census()`
     will say so.

  7. THE CARRY-IN TIMING IS FITTED, not assumed, against the two or three frames the block was seen
     part way through -- the staging position is half a pitch off the lattice, so it is approximate
     whatever you do.

WHAT IT DOES NOT DO
-------------------
A block can return to its OWN site set with the atoms rearranged.  One rectangle cannot do that --
guide I.2 fixes the tone order for the whole motion, so a rectangle's map is strictly increasing
and can never reorder itself -- so it takes TWO sub-rectangles swapping (`1:3 -> 4:6` together with
`4:6 -> 1:3`).  These are the CZ gate pairings and there are many: 40 windows on c150.  The
at-rest configurations cannot say which split was used, so this tool reports each such window and
writes nothing for it, unless you point `--lift` at a fitted schedule (se_moves.py's output).

Lifting is sound even from a sheet whose species are corrupted: a `move` row picks atoms up BY
POSITION and never consults `species`, so a row describing a rearrangement inside one block is
correct wherever that block is, whatever the other sheet thought was standing there.  Only rows
geometrically contained in the block's own rectangle, over the window's own frames, are taken.

Usage:
    python se_waypoints.py --calib calib.json --marks marks.csv --out-prefix sheet \
        [--lift other_schedule.csv] [--tol 0.15] [--min-rest 3] [--tshift 0]

Then se_emit.py the four CSVs, and CHECK ALL FOUR OF:
    python se_sim.py wb.xlsx          -> validation clean, census never short
    python se_divergence.py ...       -> 0 mislabelled site-frames
    python se_aom.py --xlsx wb.xlsx --max-aom 8   -> peak groups within budget, VIOLATIONS none
    python se_score.py ...            -> and read it knowing the caveat below

A WARNING ABOUT SCORES.  A more correct sheet can score WORSE on close positional agreement.  c150
v8 has 0 mislabelled site-frames against v6's 1374, 4 AOM groups against 33, and a clean census --
yet 48 % of atom-frames within 0.15 site against v6's 66 %, because the unwritten permutation
windows leave those blocks parked while the movie shuffles them.  Judge a transcription on census,
divergence, AOM feasibility and unexplained markers FIRST.  Positional RMS alone once preferred a
workbook that was quietly missing 58 atoms.
"""
import argparse, collections, csv, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import se_sim


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--marks", required=True)
    ap.add_argument("--out-prefix", required=True)
    ap.add_argument("--lift", default="",
                    help="a fitted schedule CSV (se_moves.py's) to lift permutation rows from")
    ap.add_argument("--tol", type=float, default=0.15,
                    help="how close to a whole tone counts as at rest, in tones")
    ap.add_argument("--min-rest", type=int, default=3,
                    help="plateaus shorter than this are transit samples, not rests")
    ap.add_argument("--tshift", type=float, default=0.0,
                    help="shift every MOVE boundary by this many frames.  A rest plateau dates a "
                         "boundary only to the frame and a batch boundary usually falls BETWEEN "
                         "frames.  load/unload are never shifted: a readout is an unload and a "
                         "load that must stay in step, and moving one across a frame leaves old "
                         "and fresh stock alive together.")
    ap.add_argument("--block", default="",
                    help="override the measured block size, e.g. 'X0=6x5,Z0=6x5'")
    a = ap.parse_args()

    K = json.load(open(a.calib))
    DT = float(K["dt_ms"])
    NF = int(K["n_frames"])
    WC0, WC1 = (int(v) for v in K["visible_col"])
    WR0, WR1 = (int(v) for v in K["visible_row"])
    DCOL, DROW = int(K["data_cols"]), int(K["data_rows"])
    notes = []

    per = collections.defaultdict(
        lambda: collections.defaultdict(lambda: collections.defaultdict(list)))
    species = set()
    with open(a.marks, newline="") as fh:
        for r in csv.DictReader(fh):
            per[int(float(r["frame"]))][r["species"]][r["state"]].append(
                (float(r["x"]), float(r["y"])))
            species.add(r["species"])
    species = sorted(species)

    print("frames %d, dt %.9f ms, window cols %d..%d rows %d..%d, data %dx%d, species %s"
          % (NF, DT, WC0, WC1, WR0, WR1, DCOL, DROW, ",".join(species)))

    # ---------------------------------------------------------------- block size per species
    def plain_rect(pts):
        """A rectangle, only if every marker is ON a tone.  Test before rounding (rule 2)."""
        if not pts:
            return None
        for x, y in pts:
            if abs(x - round(x)) > a.tol or abs(y - round(y)) > a.tol:
                return None
        sites = sorted({(int(round(x)), int(round(y))) for x, y in pts})
        if len(sites) != len(pts):
            return None
        rs = se_sim.rectangles(sites)
        if len(rs) != 1:
            return None
        xs, ys = rs[0]
        cs, rws = sorted(xs), sorted(ys)
        if cs != list(range(cs[0], cs[-1] + 1)) or rws != list(range(rws[0], rws[-1] + 1)):
            return None
        return (cs, rws)

    override = {}
    for spec in [s for s in a.block.split(",") if s]:
        nm, dim = spec.split("=")
        w, h = dim.lower().split("x")
        override[nm.strip()] = (int(w), int(h))

    BLK = {}
    for sp in species:
        if sp in override:
            BLK[sp] = override[sp]
            continue
        best = None
        for f in range(NF):
            d = per[f].get(sp)
            r = plain_rect(d.get("solid", [])) if d else None
            if r is None:
                continue
            # wholly inside the window, so nothing is hidden
            if min(r[0]) > WC0 and max(r[0]) < WC1 and min(r[1]) > WR0 and max(r[1]) < WR1:
                best = (len(r[0]), len(r[1]))
                break
        if best is None:
            print("  !! %s is never wholly on screen and on-grid; pass --block %s=WxH" % (sp, sp))
            return 2
        BLK[sp] = best
    for sp in species:
        print("  %-4s block %dx%d = %d atoms" % (sp, BLK[sp][0], BLK[sp][1],
                                                 BLK[sp][0] * BLK[sp][1]))

    # ---------------------------------------------------------------- full-rectangle inference
    def full_rect(sp, pts):
        r = plain_rect(pts)
        if r is None:
            return None
        bw, bh = BLK[sp]
        cs, rws = list(r[0]), list(r[1])
        if len(cs) < bw:
            if cs[0] <= WC0:
                cs = list(range(cs[-1] - bw + 1, cs[-1] + 1))
            elif cs[-1] >= WC1:
                cs = list(range(cs[0], cs[0] + bw))
            else:
                return None                     # short in mid-panel: mid-move, not at rest
        elif len(cs) > bw:
            return None
        if len(rws) < bh:
            if rws[0] <= WR0:
                rws = list(range(rws[-1] - bh + 1, rws[-1] + 1))
            elif rws[-1] >= WR1:
                rws = list(range(rws[0], rws[0] + bh))
            else:
                return None
        elif len(rws) > bh:
            return None
        inside = sum(1 for c in cs for w in rws
                     if WC0 <= c <= WC1 and WR0 <= w <= WR1)
        if inside != len(pts):
            return None                         # the inference does not explain what we saw
        return (cs, rws)

    def tag(rect):
        return "%s|%s" % (se_sim.compact(rect[0]), se_sim.compact(rect[1]))

    # ---------------------------------------------------------------- rest plateaus, per species
    rest = {}
    for sp in species:
        seq = []
        for f in range(NF):
            d = per[f].get(sp)
            r = full_rect(sp, d.get("solid", [])) if d else None
            if r is None:
                continue
            if seq and seq[-1][2] == tag(r) and f == seq[-1][1] + 1:
                seq[-1][1] = f
            else:
                seq.append([f, f, tag(r), r])
        rest[sp] = seq

    spine = {}
    for sp in species:
        seq = rest[sp]
        keep = [i for i, p in enumerate(seq) if p[1] - p[0] + 1 >= a.min_rest]
        if seq and 0 not in keep:
            keep.insert(0, 0)
        if seq and len(seq) - 1 not in keep:
            keep.append(len(seq) - 1)
        spine[sp] = [seq[i] for i in sorted(set(keep))]
        print("  %-4s %d rest plateaus -> %d genuine rests" % (sp, len(seq), len(spine[sp])))

    # ---------------------------------------------------------------- readouts, off the faded track
    readout = {}
    for sp in species:
        trk = []
        for f in range(NF):
            d = per[f].get(sp)
            if not d or not d.get("faded"):
                continue
            r = full_rect(sp, d["faded"])
            if r is not None:
                trk.append((f, r))
        if not trk:
            continue
        f0, src = trk[0]
        f1, seen = trk[-1]
        drow = seen[1][0] - src[1][0]
        dcol = seen[0][0] - src[0][0]
        readout[sp] = dict(f0=f0, f1=f1 + 1, src=src, dcol=dcol, drow=drow)
        notes.append("%s readout: the block %s is drawn faded from frame %d and its markers are "
                     "tracked to %s at frame %d, a displacement of (%+d,%+d). It then leaves the "
                     "panel, so THE DESTINATION IS NOT DETERMINED -- what is written below is the "
                     "observed displacement extended far enough that no row of the block remains "
                     "on screen. That extension is a CONVENTION, not a measurement."
                     % (sp, tag(src).replace("|", " x "), f0,
                        tag(seen).replace("|", " x "), f1, dcol, drow))

    # ---------------------------------------------------------------- fresh stock
    def staging_rect(sp, fr, arrive):
        pts = []
        for f in range(fr, min(fr + 80, NF)):
            d = per[f].get(sp)
            if d:
                pts += [p for p in d.get("solid", [])
                        if abs(p[0] - round(p[0])) > a.tol or abs(p[1] - round(p[1])) > a.tol]
        if not pts:
            return None
        bw, bh = BLK[sp]
        mx = sum(p[0] for p in pts) / len(pts)
        my = sum(p[1] for p in pts) / len(pts)
        ac, ar = arrive
        if abs(mx - (ac[0] + ac[-1]) / 2.0) > abs(my - (ar[0] + ar[-1]) / 2.0):
            cs = (list(range(WC0 - bw + 1, WC0 + 1)) if mx < ac[0]
                  else list(range(WC1, WC1 + bw)))
            return (cs, list(ar))
        rws = (list(range(WR0 - bh + 1, WR0 + 1)) if my < ar[0]
               else list(range(WR1, WR1 + bh)))
        return (list(ac), rws)

    def fit_transit(src, dst, samples):
        """Brute-force (t0, t1) against the frames the block was seen part way through."""
        if not samples:
            return None
        dc = dst[0][0] - src[0][0]
        dr = dst[1][0] - src[1][0]
        lo = min(f for f, _ in samples)
        hi = max(f for f, _ in samples)
        best = None
        for t0 in range(max(0, lo - 25), lo + 1):
            for t1 in range(hi, hi + 30):
                if t1 <= t0:
                    continue
                err = 0.0
                for f, rc in samples:
                    u = min(1.0, max(0.0, (f - t0) / float(t1 - t0)))
                    s = 10 * u ** 3 - 15 * u ** 4 + 6 * u ** 5
                    err += (abs(src[0][0] + s * dc - rc[0][0])
                            + abs(src[1][0] + s * dr - rc[1][0]))
                err /= len(samples)
                if best is None or err < best[2]:
                    best = (t0, t1, err)
        return best

    stock = {}
    for sp in species:
        if sp not in readout:
            continue
        fr = readout[sp]["f0"]
        inside = [p for p in spine[sp]
                  if p[0] > fr and min(p[3][0]) >= 1 and max(p[3][0]) <= DCOL
                  and min(p[3][1]) >= 1 and max(p[3][1]) <= DROW]
        if not inside:
            notes.append("%s: a readout was seen at frame %d but no later rest inside the data "
                         "array, so NO fresh block is written. Check whether the cycle really "
                         "reloads this species." % (sp, fr))
            continue
        arrive = inside[0]
        st = staging_rect(sp, fr, arrive[3])
        if st is None:
            notes.append("%s: a readout was seen at frame %d and the species returns to %s, but no "
                         "off-lattice stock is visible to carry in. NOTHING IS CREATED; this is "
                         "reported, not invented."
                         % (sp, fr, tag(arrive[3]).replace("|", " x ")))
            continue
        transit = [(p[0], p[3]) for p in spine[sp] if fr < p[0] < arrive[0]]
        fit = fit_transit(st, arrive[3], transit) or (arrive[0] - 12, arrive[0], -1.0)
        stock[sp] = dict(rect=st, arrive=arrive, f0=fit[0], f1=arrive[0], err=fit[2],
                         transit=transit)
        notes.append("%s fresh stock: it waits OFF the data lattice with only part of it on screen, "
                     "so its rectangle %s is rounded AWAY from the array and extended off-panel to "
                     "the block's known %d atoms. THIS IS THE ONLY INVENTED GEOMETRY in the sheet. "
                     "The carry-in to %s is fitted to the %d frame(s) it was seen part way through "
                     "(frames %s), giving %d-%d at %.2f site mean error; the staging position is "
                     "half a pitch off the lattice, so this timing stays approximate."
                     % (sp, tag(st).replace("|", " x "), BLK[sp][0] * BLK[sp][1],
                        tag(arrive[3]).replace("|", " x "), len(transit),
                        ",".join(str(f) for f, _ in transit) or "none",
                        fit[0], arrive[0], fit[2]))

    # ---------------------------------------------------------------- net moves and permutations
    rows, perm = [], []
    for sp in species:
        sq = spine[sp]
        for i in range(len(sq) - 1):
            f0a, f1a, ta, ra = sq[i]
            f0b, f1b, tb, rb = sq[i + 1]
            if ta == tb:
                if f0b - f1a > 1:
                    perm.append((sp, f1a, f0b, ta, ra))
                continue
            if sp in readout and f1a <= readout[sp]["f0"] <= f0b:
                continue
            if sp in stock and readout[sp]["f0"] <= f1a and f0b <= stock[sp]["arrive"][0]:
                continue
            rows.append(dict(sp=sp, fa=f1a, fb=f0b, src=ra, dst=rb))
    print("\nnet moves %d, same-site permutation windows %d" % (len(rows), len(perm)))

    lifted = []
    if a.lift:
        with open(a.lift, newline="") as fh:
            cand = [r for r in csv.DictReader(fh) if (r.get("event") or "move") == "move"]

        def ts(cell):
            return set(se_sim.split_elements(cell))

        def is_bijection(got, rect):
            """Do these rows permute the block's OWN site set, one atom per trap?

            THIS GUARD IS NOT OPTIONAL, and none of the other checks replaces it.  A set of rows
            can be individually legal -- matching tone counts, non-crossing, no two rows claiming
            one atom -- and still land two atoms on one trap, because a site no row mentions STAYS
            PUT while another row moves onto it.  c150's lifted move 2 maps rows 11->13, 12->14,
            14->15, 15->12 and never moves 13, so row 13 ends up holding two atoms.
            `check1`, `check3`, `check4` and `census` ALL PASS on that: each row picks up the right
            count, no atom is double-claimed, and the population is conserved.  The only visible
            symptom is that two atoms draw as one marker, so the render comes out SHORT -- c150 v8
            lost 11 markers per held frame this way and still reported a clean sheet.
            """
            cells = [(c, r) for c in rect[0] for r in rect[1]]
            dest = {}
            for site in cells:
                dest[site] = site
            for r in got:
                xm = dict(zip(se_sim.split_elements(r["x_start"]),
                              se_sim.split_elements(r["x_finish"])))
                ym = dict(zip(se_sim.split_elements(r["y_start"]),
                              se_sim.split_elements(r["y_finish"])))
                for site in cells:
                    if site[0] in xm and site[1] in ym:
                        dest[site] = (xm[site[0]], ym[site[1]])
            images = list(dest.values())
            return len(set(images)) == len(images) and set(images) == set(cells)

        for sp, fa, fb, tg, rect in perm:
            cs, rws = set(rect[0]), set(rect[1])
            t0, t1 = fa * DT, fb * DT
            got = [r for r in cand
                   if t0 - 0.6 * DT <= float(r["t_start"])
                   and float(r["t_finish"]) <= t1 + 0.6 * DT
                   and ts(r["x_start"]) <= cs and ts(r["y_start"]) <= rws
                   and ts(r["x_finish"]) <= cs and ts(r["y_finish"]) <= rws]
            if got and not is_bijection(got, rect):
                notes.append("%s frames %d-%d at %s: %d candidate row(s) were found for this "
                             "rearrangement but they do NOT permute the block one atom per trap -- "
                             "some site they do not mention stays put while another row moves onto "
                             "it, stacking two atoms on one trap. REJECTED and nothing is written. "
                             "(check1/check3/check4/census all pass on such a set; only a short "
                             "render reveals it.)"
                             % (sp, fa, fb, tg.replace("|", " x "), len(got)))
                got = []
            if got:
                for r in got:
                    lifted.append(dict(ts=float(r["t_start"]), tf=float(r["t_finish"]),
                                       xs=r["x_start"], ys=r["y_start"],
                                       xf=r["x_finish"], yf=r["y_finish"], sp=sp, tg=tg))
                notes.append("%s frames %d-%d at %s: written as %d row(s) LIFTED from the "
                             "per-window pixel fit. A move row picks up BY POSITION, so these rows "
                             "do not depend on which species the other sheet thought was standing "
                             "here; only their geometry is used, and it lies entirely inside the "
                             "block's own rectangle."
                             % (sp, fa, fb, tg.replace("|", " x "), len(got)))
            else:
                notes.append("%s frames %d-%d at %s: the block leaves the tone grid and returns to "
                             "the SAME rectangle, so two sub-rectangles swapped onto its own site "
                             "set (one rectangle cannot reorder itself -- guide I.2). WHICH split "
                             "was used is not determined by the at-rest configurations, and "
                             "NOTHING IS WRITTEN. The atoms end where they began, so the schedule "
                             "is correct about every position and silent about this rearrangement."
                             % (sp, fa, fb, tg.replace("|", " x ")))
    else:
        for sp, fa, fb, tg, rect in perm:
            notes.append("%s frames %d-%d at %s: same-site rearrangement, NOTHING IS WRITTEN. "
                         "Point --lift at a fitted schedule to recover it."
                         % (sp, fa, fb, tg.replace("|", " x ")))
    print("lifted permutation rows %d of %d windows"
          % (len(lifted), len({(p[0], p[1]) for p in perm})))

    # ---------------------------------------------------------------- compose
    def snap(vals, within=1):
        """Cluster near-equal frames so rows moving together share ONE t_start exactly.

        All rows of a batch must agree to the digit or the renderer sequences them, and the later
        row sweeps up the atoms the earlier one just delivered (SKILL.md composition rule 1).
        """
        out, cur = {}, []
        for v in sorted(set(vals)):
            if cur and v - cur[-1] <= within:
                cur.append(v)
            else:
                for w in cur:
                    out[w] = cur[0]
                cur = [v]
        for w in cur:
            out[w] = cur[0]
        return out

    SH = a.tshift
    sched = []
    fa_map = snap([r["fa"] for r in rows])
    for r in rows:
        sched.append(dict(event="move", species="", t0=max(0.0, (fa_map[r["fa"]] + SH) * DT),
                          t1=(r["fb"] + SH) * DT,
                          xs=se_sim.compact(r["src"][0]), ys=se_sim.compact(r["src"][1]),
                          xf=se_sim.compact(r["dst"][0]), yf=se_sim.compact(r["dst"][1]),
                          note=""))
    for sp, ro in readout.items():
        src = ro["src"]
        bh = BLK[sp][1]
        d = ro["drow"] if abs(ro["drow"]) > abs(ro["dcol"]) else 0
        d = max(d, bh + 1) if d >= 0 else min(d, -(bh + 1))
        dst = (src[0], [v + d for v in src[1]]) if d else \
              ([v + (ro["dcol"] + BLK[sp][0]) for v in src[0]], src[1])
        sched.append(dict(event="unload", species=sp, t0=ro["f0"] * DT, t1=ro["f1"] * DT,
                          xs=se_sim.compact(src[0]), ys=se_sim.compact(src[1]),
                          xf=se_sim.compact(dst[0]), yf=se_sim.compact(dst[1]),
                          note="readout: this species is measured and replaced. The destination is "
                               "off the panel and is a CONVENTION -- see the notes file."))
    for sp, st in stock.items():
        rect = st["rect"]
        # the stock has been on screen faded since early in the cycle and turns SOLID at the
        # readout frame (handover 4.3).  Load there: loading just before the carry-in instead
        # leaves the array short from the unload until then, and census() will report it.
        tload = readout[sp]["f0"] * DT
        sched.append(dict(event="load", species=sp, t0=max(0.0, tload), t1=max(0.0, tload),
                          xs=se_sim.compact(rect[0]), ys=se_sim.compact(rect[1]),
                          xf=se_sim.compact(rect[0]), yf=se_sim.compact(rect[1]),
                          note="fresh stock, waiting off the data lattice. Rectangle is a "
                               "CONVENTION -- see the notes file."))
        arrive = st["arrive"][3]
        sched.append(dict(event="move", species="", t0=st["f0"] * DT, t1=st["f1"] * DT,
                          xs=se_sim.compact(rect[0]), ys=se_sim.compact(rect[1]),
                          xf=se_sim.compact(arrive[0]), yf=se_sim.compact(arrive[1]),
                          note="carries the fresh %s block in from its staging area; timing fitted "
                               "to %d frame(s), %.2f site mean error"
                               % (sp, len(st["transit"]), st["err"])))
    for L in lifted:
        sched.append(dict(event="move", species="", t0=L["ts"], t1=L["tf"],
                          xs=L["xs"], ys=L["ys"], xf=L["xf"], yf=L["yf"],
                          note="internal rearrangement of the %s block at %s, lifted from a "
                               "pixel fit; geometry only, species-agnostic"
                               % (L["sp"], L["tg"].replace("|", " x "))))

    # a load must sit in a strictly earlier batch than the move that carries it in
    sched.sort(key=lambda r: (round(r["t0"], 6), r["event"] != "load"))

    pfx = a.out_prefix
    with open(pfx + "_schedule.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["move", "slot", "event", "species", "t_start", "t_finish",
                    "x_start", "y_start", "x_finish", "y_finish", "note"])
        bat = collections.OrderedDict()
        for r in sched:
            bat.setdefault(round(r["t0"], 6), []).append(r)
        for mi, t0 in enumerate(sorted(bat), 1):
            for si, r in enumerate(bat[t0], 1):
                w.writerow([mi, si, r["event"], r["species"], round(r["t0"], 4),
                            round(r["t1"], 4), r["xs"], r["ys"], r["xf"], r["yf"], r["note"]])
    with open(pfx + "_seed.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["species", "x_tones", "y_tones", "note"])
        for sp in species:
            first = next((p for p in rest[sp] if p[0] == 0), None)
            if first:
                w.writerow([sp, se_sim.compact(first[3][0]), se_sim.compact(first[3][1]),
                            "position at t = 0, read from frame 0"])
            else:
                notes.append("%s is not at rest on frame 0; its seed position had to be taken from "
                             "its first rest instead. Check it by eye." % sp)
                p = rest[sp][0]
                w.writerow([sp, se_sim.compact(p[3][0]), se_sim.compact(p[3][1]),
                            "NOT at rest on frame 0; taken from frame %d" % p[0]])
    with open(pfx + "_gates.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["move", "t_start", "t_finish"])
        for i, gf in enumerate(sorted(K.get("gate_frames") or []), 1):
            w.writerow([i, round(max(0.0, (gf - 0.45) * DT), 4), round((gf + 0.45) * DT, 4)])
    with open(pfx + "_constants.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["key", "value", "note"])
        w.writerow(["lattice_cols", DCOL, "data sites across"])
        w.writerow(["lattice_rows", DROW, "data sites down; row 1 is topmost"])
        w.writerow(["cycle_ms", K.get("cycle_ms", ""), "from the movie header"])
        w.writerow(["frames", NF, ""])
        w.writerow(["dt_ms", DT, "cycle_ms / frames"])
        w.writerow(["easing", "s(u) = 10u^3 - 15u^4 + 6u^5", "guide I.5"])
        w.writerow(["tone_divisor", 1, "data sites"])
        for sp in species:
            w.writerow(["block_%s" % sp, "%dx%d" % BLK[sp], "measured from the first wholly "
                                                            "visible on-grid frame"])
    with open(pfx + "_notes.txt", "w", encoding="utf-8") as fh:
        fh.write("\n\n".join(notes) + "\n")

    nb = len({round(r["t0"], 6) for r in sched})
    peak = max(collections.Counter(round(r["t0"], 6) for r in sched).values())
    print("\nwrote %s_{schedule,seed,gates,constants}.csv and _notes.txt" % pfx)
    print("rows %d  (%d move, %d unload, %d load)"
          % (len(sched), sum(1 for r in sched if r["event"] == "move"),
             sum(1 for r in sched if r["event"] == "unload"),
             sum(1 for r in sched if r["event"] == "load")))
    print("batches %d, peak rows in one batch %d  <- this bounds the AOM groups needed" % (nb, peak))
    print("open notes %d, all of them in %s_notes.txt" % (len(notes), pfx))
    return 0


if __name__ == "__main__":
    sys.exit(main())
