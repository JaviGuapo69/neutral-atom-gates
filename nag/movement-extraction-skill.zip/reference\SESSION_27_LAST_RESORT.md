# Session 27 (2026-09-15, evening) — the LAST RESORT: the six movements the s26 book was missing

**Written for: the user (Javier).** Follows `SESSION_26_PATCH_DETECTOR.md` (same day). Read that
first for the state of the book this session started from (`run_c540_s26\c540_s26_blocks.xlsx`,
86 of 92 movements matching the hand book, 6 hand-book events missing). This document is about the
change that goes after those six, all of one class: whole-block transitions production left
UNDETERMINED.

---

## 0. Where everything is

| | |
|---|---|
| **the skill — PROMOTED 2026-09-16** | `.claude/skills/se-cycle-blocks/` = the former `se-cycle-blocks-s25` fork: sessions 9-22 production + S2.1 (s25) + patch detector (s26) + **this session's last resort and `MAX_SPAN` 16 → 27**, both in `tools/sb_build.py`. Promoted on the user's instruction at the end of this session ("the skill will never get better than this at analysing the movements; I will correct its mistakes by hand") |
| **the pre-promotion production** | `.claude/skill_archive/se-cycle-blocks-PRODUCTION-pre-promotion-2026-09-16/` (byte-identical to `se-cycle-blocks-PRODUCTION-BACKUP-2026-09-15/` beside it) |
| **c540 result** | `run_c540_s27/` — the book, the comparisons, the audit, the census, the rebuild videos, `logs/` (per-segment tests, the two halves, the three regressions) |
| **the s26 book's rebuild video**, made this session on the user's request so the defects can be seen | `run_c540_s26\c540_s26_original_vs_rebuild_panels.mp4` / `_full.mp4` (copies at the project root) |

---

## 1. What the handover asked for, and what it turned out to need

The handover's next steps were (a) the last-resort rotation route placed AFTER the "carried by
another species' rectangle" filter, and (b) `MAX_SPAN` raised for the f315-328 relocation. Both
were done; neither was sufficient on its own, and the tests on the segments they target showed why.

### 1.1 The last resort, committed after the "carried" test

The session-25 draft (`run_c540_s25\logs\seg0_last_resort_TEST.log`) tried the rotations of the
measured moving run inside the per-transition loop, after every route had failed. It recovered
`Z0 f001-007` as `13:18->19:24 | 19:24->13:18` — the hand book's map — but also fired on
`X1 f023-026`, a transition production correctly leaves to X0's joined `X0+X1 rows` rectangle, and
invented a 5-cycle for it; `drop_conflicting_joins` then split the genuine joined rectangle.

The "carried" test needs every other move to exist first, so it runs after the loop. The fix is
mechanical: the candidate is computed inside the loop (where `emit`, the transition's frames and
its pulse bounds are in scope) and stored; after the loop, each stored candidate is committed only
if rule 29's midpoint test finds no rectangle of another species carrying the transition — the same
test the UNDETERMINED filter applies later. Segment 0 with this ordering: Z0 f001-007 recovered,
`X1 f023-026: carried by another species' rectangle`, 8 moves, 0 undetermined, and the
`X0+X1 rows f023-027 12,15->13,16 | 13,16->12,15` rectangle stays joined as the hand book has it.

### 1.2 `MAX_SPAN` alone recovers nothing at f315-328

With the cap at 27 the displacement route still returned no candidate for `Z0/Z1 cols 13:24 ->
1:12`. The peaks say why (`scratchpad\diag_seg9.py`): the two wrap columns travel at 2.2× the
body's speed, so the sorted correspondence is scrambled from the SECOND moving frame (f317 reads 11
peaks, f318's sorted sixth peak belongs to tone 23), and rule 20's leading run is one frame long.
`measured_partition` needs two; and on that one frame the body has moved 0.18–0.29 site — peak
noise — so the ratios do not round to a consistent scale at any Dmax. The cap was never the guard
that mattered (every scale is pinned by the destination set), so 27 is kept; the family that reaches
this movement is a different one, §1.3.

### 1.3 The relocation composed with a rotation — and why the smoothstep fit refused the right map

`relocation_rotations(S, S2)`: shift the destination run by k, k = 0 (the plain translation) .. n−1,
each member two rigid groups with uniform integer displacements. This is the family the v2 fork had
and that broke c300 (`X0 cols f246-261`, a plain translation, came out as a rotation by +1). The
lesson of session 25 §3 was "a new candidate family without a gate that keeps it silent where the
old route was right"; here the family lives in the last resort only, i.e. it is asked exactly when
the alternative is UNDETERMINED, and c150/c200/c300 have no such transition.

First result: the family fired and its best member was `13:21->4:12 | 22:24->1:3` at 0.2194 on the
moving frames, refused by the gate. Scoring every member directly (`scratchpad\diag_seg9b.py`):

| member | smoothstep fit, mean over moving frames | free per-frame progress: mean error, p-sequence |
|---|---|---|
| `13:24->1:12` (translation) | 0.305 | 0.14 |
| **`13:22->3:12 \| 23:24->1:2` (hand book)** | 0.232 | **0.046**, p 0.03 0.08 0.12 0.21 0.31 0.44 0.56 0.69 0.79 0.88 0.93 0.98 |
| `13:21->4:12 \| 22:24->1:3` | 0.219 | 0.085, p plateaus twice (0.24 0.24 … 0.76 0.76) |

The hand book's map explains every frame to 0.02–0.08 site with a monotone progress, i.e. it is the
right partition. The joint fit fails on it for a reason specific to fast wraps: a 22-site
displacement done in 13 frames turns a 1 % error in the easing into 0.22 site, and on a comb of
unit pitch an error of ~1 site scores as ~0 against the neighbouring peak while 0.5 scores 0.5 — the
error surface is periodic and a slightly wrong easing is punished more than a wrong map. So the
last resort ranks and gates on the free per-frame progress — `sb_compose.progress_per_frame`, which
the file itself calls "the heart of the method" — and uses the smoothstep fit only for the timing
and the quoted `mean` (which honestly reads OVER 0.10 on these moves).

### 1.4 The same on the f329-336 rotations, and the time-reversal ambiguity

Segment 10's three rotations (X0 +7, Z0/Z1 +5) had the same failure: the smoothstep fit preferred
the rotations one tone over (0.19–0.20) and refused them at the bar. On the free progress
(`scratchpad\diag_rot.py`) the hand book's maps score 0.032 (X0) and 0.028 (Z0), monotone, the
runners-up 0.11. But the free error alone cannot tell a rotation from its mirror — the same frames
are explained with p running 1 → 0 — so the monotone penalty is added (0.17 on the mirror). One
exception, found on Z0 f001-007: a rotation by n/2 is an involution, the configuration at p is the
one at 1 − p, the per-frame p is arbitrary between the two and the penalty was 0.22 of noise on the
correct map. Time reversal of an involution is the same map, so there is nothing to break, and the
penalty is skipped for it.

### 1.5 Z0 f380-383 is not a rotation of a contiguous run

On f381 rows 19, 22 and 25 move up by the same amount and the other six move down by half of it:
each row triple rotates within itself, `19,22,25 -> 21,24,27 | 20:21,23:24,26:27 -> 19:20,22:23,
25:26` — exactly the hand book's "+2 on rows 19, 22, 25". Two rigid groups with uniform integer
displacements (+2 and −1), so a legal move under 3a, but `rotation_candidates` cannot reach it and
the best contiguous rotation scores 0.12 on the free progress (correctly refused). Added
`periodic_rotations(S)`: rotation by k within each consecutive group of m tones, m | n, m < n.

---

## 2. Per-segment tests, final code (all four families, free-progress ranking, gate 0.10)

| segment | transition | s26 book | s27 | hand book |
|---|---|---|---|---|
| 0 | Z0 cols f001-007 | UNDETERMINED | `13:18->19:24 \| 19:24->13:18`, free 0.048 | `13:18 <-> 19:24` ✓ |
| 9 | Z0/Z1 cols f315-328 | UNDETERMINED ×2 | one `Z0+Z1` rectangle `13:22->3:12 \| 23:24->1:2`, free 0.046 | `13:22->3:12 \| 23:24->1:2` ✓ |
| 10 | X0 cols f329-336 | UNDETERMINED | `13:17->20:24 \| 18:24->13:19`, free 0.032 | +7 / −5 ✓ |
| 10 | Z0/Z1 cols f329-336 | UNDETERMINED ×2 | one `Z0+Z1` rectangle `1:7->6:12 \| 8:12->1:5`, free 0.028 | +5 / −7 ✓ |
| 7 | X1 cols f247-256 | UNDETERMINED | (diagnostic) `13->24 \| 14:24->13:23`, free 0.041 | `14:24->13:23 \| 13->24` ✓ |
| 11 | Z0 rows f380-383 | UNDETERMINED | `20:21,23:24,26:27->19:20,22:23,25:26 \| 19,22,25->21,24,27` (periodic), free 0.033, smoothstep 0.065 | `19,22,25 -> 21,24,27` ✓ |

Segment 7 was not solved in isolation (it is the longest); in the full run X1 f247-256 came out as
the diagnostic predicted.

## 3. Whole movie — `run_c540_s27\c540_s27_blocks.xlsx` (copy at the project root)

Solved as two halves (`--only 0-5`, `--only 6-11`, `logs\half_a.log`, `logs\half_b.log`, 17:38 →
17:56 with the three regressions running alongside), merged with `tools/merge_halves.py`;
`finish_s27.ps1` is the whole post-solve chain, `finish_s27.log` its output.

| | s26 book | **s27 book** |
|---|---|---|
| moves / undetermined | 88 / 8 | **94 / 0** |
| sheet movements matching the hand book (`run_c540_v3\cmp_full.py`, ±0.12 ms) | 86 of 92 | **92 of 98** |
| hand-book events fully / partly / not accounted for (53) | 47 / 4 / 2 | **52 / 0 / 1** |
| hand-book displacement entries accounted (217) | 200 | **215** |
| `sb_audit` | 3 problems (2 relocation holes, 1 silent hole) | **AUDIT CLEAN** — 121 transitions, 117 explained, 4 held back as readout/load, 0 undetermined, 0 silent, 0 idle moves, 0 rest clashes over 87,696 claims |
| `se_sim` render validation | check3 ×2 at the f315 hole | **clean**; census conserved (432 atoms, never short) |
| AOM groups | 6, peak 6 | 6, peak 6 |

**Against the s26 book** (`s27_vs_s26.txt`, `cmp_tol`): all 88 s26 moves reproduced exactly, maps
and windows; 6 new moves, every one a last-resort answer and every one the hand book's map:

| new move | family | free progress | smoothstep `mean` |
|---|---|---|---|
| `Z0 cols f002-009 13:18->19:24 \| 19:24->13:18` | rotation of the measured run (involution) | 0.048 | 0.100 |
| `X1 cols f248-258 13->24 \| 14:24->13:23` | rotation of the measured run | 0.041 | 0.057 |
| `Z0+Z1 cols f316-327 13:22->3:12 \| 23:24->1:2` | relocation + rotation | 0.046 | 0.229 |
| `X0 cols f330-335 13:17->20:24 \| 18:24->13:19` | rotation of the measured run | 0.032 | 0.232 |
| `Z0+Z1 cols f330-335 1:7->6:12 \| 8:12->1:5` | rotation of the measured run | 0.028 | 0.225 |
| `Z0 rows f380-382 19,22,25->21,24,27 \| rest -1` | rotation within each triple | 0.033 | 0.066 |

The three `mean` values over 0.10 are the smoothstep fit's, on the fast wraps §1.3 describes; the
maps are the hand book's and the free per-frame fit explains every frame to 0.03–0.05 site.
Downstream of f328 the Z species are now in the right columns, so the s26 book's "everything after
f328 twelve columns out" is gone, and the render validation has nothing to report.

**The 6 sheet movements the hand book "does not have"** are the same six as in session 26 and are
not defects of the transcription: four readouts/loads (+9 descents at t 4.28, 5.05, 10.59, the
−8:0→1:9 carry-in at 11.53) the hand book omits; `X0+X1 rows f104-114 1:2→8:9 | 3:9→1:7` at 3.44,
a comparator artefact (Shayne writes it across two batch rows with a blank between); and
**`X0+X1 rows f152-154`**, the one genuine disagreement (hand book: +2 on rows 10, 13, 16; still to
be adjudicated on the pixels — S2.1's best rotation scored 0.178 there and was refused, production's
appearance read stands at 0.161).

**The one hand-book event still missing:** t 10.85 `13:18 <-> 19:24` on y 1:9 (`f348-355`), a
six-frame rotation by 6 of Z0's 12 columns while the block is parked at 1:12 × 1:9. Whole-block
occupancy never enumerates a transition for it (the block reads at rest before and after), so no
route — the last resort included — is ever asked. It is the same class as the sub-comb batches
(session 25 §2.2): a movement the enumerator does not see. `sb_audit` cannot see it either (rule
27); only the hand book does.

**Render and video** (`deliver_s27.ps1`, `deliver_s27.log`): 384 frames rendered, **0 validation
entries** (the s25/s26 books had the two `check3` entries at the f315 hole), profile score **0.0493
site raw over the whole movie with nothing dropped** (s26: 0.0983 with the hole's 67 cells dropped,
0.27 raw; Z1 0.20 there because of the twelve-column offset). Rule 27 applies: the number is not
the evidence, the hand-book comparison above is. Videos `run_c540_s27\c540_s27_original_vs_rebuild_panels.mp4`
and `_full.mp4`, copied to the project root. (The first render attempt stalled when the machine
slept between 18:00 and 21:40; it resumed on wake and was restarted from scratch at 21:41.)

## 4. Regressions (the fork's `sb_full.py --events`, detector on, final code; run in parallel with the c540 solve)

Compared with `tools/cmp_tol.py` (maps identical, ≤ 1 frame of window shift tolerated). Logs in
`run_c540_s27\logs\reg_*.log`, outputs and verdicts in `run_c540_s27\reg\`.

| movie | reference | result |
|---|---|---|
| c150 | `reg_c150\fix\moves_full.json` (55) | **55/55 identical, maps and windows**; 0 undetermined; last resort fired 0 times |
| c300 | `reg_c300_fix\moves_full.json` (64) | **64/64 identical**; 0 undetermined; 0 firings |
| c200 | `reg_c200\moves_full.json` (production's own run, 69) | **69/69 identical**; 0 undetermined; 0 firings |
| c200 | `reg_c200\accepted_moves_full.json` (session 14) | 68 identical + the documented one-frame shift of `Z0+Z1 cols f276-287 → f276-288` (pulse-bound convention, production shows it too) |

As the design says: the last resort only ever answers a transition that is UNDETERMINED and not
carried, and the closed movies have none. `MAX_SPAN` at 27 changed nothing on them either.

## 5. Open items, in order

1. **`f348-355`**, the last hand-book event with no counterpart: a six-frame same-site rotation
   that rest detection swallows. It needs a detector, not a solver route — the transition is never
   enumerated. The patch detector (`sb_gaps`) looks for sub-comb batches; a whole-comb same-site
   permutation between two rests that occupancy declares identical is the analogous gap for whole
   blocks. `sb_watch.py` / the outline-appearance scan over f348-355 is where to start.
2. **`X0+X1 rows f152-154`**: adjudicate on the pixels (hand book +2 on rows 10, 13, 16; every
   book so far has production's 5-part read at 0.161).
3. **The quoted `mean` on the fast wraps** (0.22–0.23 for three correct moves): the smoothstep
   easing does not fit a 13-frame 22-site wrap well. Whether the movie's easing differs from
   smoothstep on long moves, or the fit is trapped by the periodic error surface, is worth one
   diagnostic; it affects the number, not the map.
4. **Promotion — DONE (2026-09-16).** The user decided the automatic analysis will not improve
   further and promoted this version to be the official `se-cycle-blocks`; from now on its
   mistakes are corrected by hand against the movie, and sessions run the skill rather than change
   it. Items 1–3 above are therefore hand corrections, not tool work.
5. Speed: ~18 min per half with the regressions sharing the machine; `sb_full` still writes only
   at the end.
