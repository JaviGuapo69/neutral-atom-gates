"""se_repack.py -- two bookkeeping repairs every AUTO-TRANSCRIBED workbook needs before se_aom.py.

Neither changes the physics.  No row is added, removed, re-pointed, or retimed beyond the clamp.

  a) CLAMP NEGATIVE TIMES.  The cycle starts at t = 0, but se_moves.py's timing fitter searches
     below its seed value and clamps only its GATE rows -- so move rows can come out negative.
     c150's first batch read t_start = -0.0016 ms; c540's fitted move 2 reads -0.013 (handover
     12.2).  It is a fraction of a frame and harmless to the render, but it is meaningless as a
     schedule and the first thing a reader notices.

  b) REPACK `slot` AS A REAL AOM GROUP INDEX.  This one silently invalidates a feasibility report.

     `se_aom.py` decides which rows share a crossed AOM pair by grouping on the sheet's `slot`
     column.  `se_moves.py` writes `slot` as a RUNNING COUNTER, one value per row.  Read literally
     that assigns one AOM group per row, so the reported "peak concurrent AOM groups" is nothing
     but the largest batch's ROW COUNT -- a number about the transcription, not about the hardware.
     c150's automatic sheet reported 39 groups this way; packed properly it needs 33, and the
     correct schedule needs 4.  c540's v11 reported 31 for the same reason (AOM_CLASSIFICATION.md
     section 2); Shayne's hand-written V3 escaped it only because its `slot` IS the AOM index.

     This packs each batch onto as few groups as se_aom's own checks 3 (comb merge) and 4 (atom
     capture) permit, greedily, largest rectangle first -- so the number it prints is an UPPER
     BOUND on the true optimum, and a genuine statement about the schedule.

     If the packed peak is still far above the machine's budget, do NOT reach for a bigger budget:
     a batch needing many groups is nearly always a segmentation or fit failure upstream, where a
     run of sequential motions was written as though simultaneous, or the fit gave up and emitted
     one row per site.  Look at the batch (its rows will have many different displacements) before
     you believe the hardware is the problem.

Usage:
    python se_repack.py --in-xlsx auto.xlsx --out-xlsx packed.xlsx
    python se_aom.py --xlsx packed.xlsx --max-aom 8
"""
import argparse, collections, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import se_sim
import se_aom


def can_share(ps, state):
    """Would these rows sit on ONE crossed AOM pair?  se_aom's checks 3 and 4."""
    mx = se_aom.merge([p["xm"] for p in ps])
    my = se_aom.merge([p["ym"] for p in ps])
    if mx is None or my is None:
        return False
    owned = set()
    for p in ps:
        for x in p["xm"]:
            for y in p["ym"]:
                owned.add((x, y))
    for x in mx:
        for y in my:
            if (x, y) not in owned and (x, y) in state:
                return False                      # atom capture
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-xlsx", required=True)
    ap.add_argument("--out-xlsx", required=True)
    a = ap.parse_args()

    import openpyxl
    wb = openpyxl.load_workbook(a.in_xlsx)
    ws = wb["Schedule"]
    hdr = [c.value for c in ws[1]]
    ci = {h: i for i, h in enumerate(hdr)}

    n = 0
    for r in ws.iter_rows(min_row=2):
        if r[0].value is None:
            continue
        for key in ("t_start", "t_finish"):
            c = r[ci[key]]
            if c.value is not None and float(c.value) < 0:
                c.value = 0.0
                n += 1
    for r in wb["Gates"].iter_rows(min_row=2):
        for c in r[1:3]:
            if c.value is not None and float(c.value) < 0:
                c.value = 0.0
                n += 1
    print("clamped %d negative time cell(s) to 0" % n)
    wb.save(a.out_xlsx)

    S = se_sim.from_workbook(a.out_xlsx)
    nslot = len({p["slot"] for p in S.rows})
    if nslot == len(S.rows):
        print("`slot` holds %d distinct values over %d rows -- a running counter, so it carries no "
              "AOM meaning and se_aom.py would report one group per row" % (nslot, len(S.rows)))
    else:
        print("`slot` holds %d distinct values over %d rows -- it may already be a real AOM index; "
              "repacking anyway, which can only reduce the count" % (nslot, len(S.rows)))

    by_t = collections.defaultdict(list)
    for p in S.rows:
        by_t[p["t0"]].append(p)

    assign, peak, before = {}, 0, 0
    for t0 in sorted(by_t):
        batch = [p for p in by_t[t0] if p["ev"] != "load"]
        loads = [p for p in by_t[t0] if p["ev"] == "load"]
        state = S.state_at(t0)
        groups = []
        for p in sorted(batch, key=lambda p: -(len(p["xm"]) * len(p["ym"]))):
            for g in groups:
                if can_share(g + [p], state):
                    g.append(p)
                    break
            else:
                groups.append([p])
        for k, g in enumerate(groups, 1):
            for p in g:
                assign[p["slot"]] = k
        # a load is a fresh batch generated on a comb of its own, so it gets a column of its own
        for k, p in enumerate(loads, len(groups) + 1):
            assign[p["slot"]] = k
        peak = max(peak, len(groups) + len(loads))
        before = max(before, len(batch) + len(loads))

    wb = openpyxl.load_workbook(a.out_xlsx)
    ws = wb["Schedule"]
    for r in ws.iter_rows(min_row=2):
        if r[0].value is None:
            continue
        old = r[ci["slot"]].value
        if old in assign:
            r[ci["slot"]].value = assign[old]
    wb.save(a.out_xlsx)

    print("peak concurrent AOM groups: %d packed, against %d if `slot` is read literally"
          % (peak, before))
    print("wrote %s" % a.out_xlsx)
    if peak > 8:
        print()
        print("%d is still above a typical 8-group budget.  Before concluding the hardware cannot "
              "run this, LOOK AT THE WORST BATCH." % peak)
        print("Rows with many different displacements in one batch mean the fit gave up and emitted")
        print("one row per site, or a run of sequential motions was collapsed into one window.")
        print("See se_waypoints.py, and run se_divergence.py to check the species bookkeeping.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
