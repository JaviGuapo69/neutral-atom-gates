"""alt_s30.py -- measure the ALTERNATIVE maps for the corrections whose residual is not decisive, on the
same peaks and with the skill's own fit_timing / verify / progress_per_frame, so the list can quote both."""
import os, sys
sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_build, sb_compose
from sb_read import Movie

M = Movie("calib.json")
runs = sb_compose.pulse_runs(M)
wins = sb_compose.species_windows(M, 0, M.nf - 1)
P = sb_compose.Peaks(M, wins, 0, M.nf - 1)
R = lambda a, b: list(range(a, b + 1))


def mapof(parts, block=None):
    mp = {}
    for a, b in parts:
        mp.update(dict(zip(a, b)))
    for t in (block or []):
        mp.setdefault(t, t)
    src = sorted(mp)
    return src, [mp[s] for s in src]


def score(name, sp, axis, parts, frames, lo, hi, block=None, sub=None):
    src, dst = mapof(parts, block)
    PP = sb_build.SubPeaks(M, wins, (1 - axis, list(sub)), frames) if sub else P
    best = sb_build.fit_timing(PP, M, sp, axis, src, dst, frames, float(lo), float(hi))
    if best is None:
        print("%-60s  no fit" % name); return
    _, a, b = best
    mean, worst, n = sb_compose.verify(PP, sp, axis, src, dst, a, b, frames, M)
    seq = sb_compose.progress_per_frame(PP, sp, axis, src, dst, frames, M)
    free = [s[2] for s in seq if 0.02 < s[1] < 0.98]
    mono = sb_compose.monotone_penalty(seq)
    print("%-60s  f%.2f-%.2f  mean %.4f worst %.3f  FREE %.4f (%d frames) mono %.3f"
          % (name, a, b, mean, worst, (sum(free) / len(free)) if free else float('nan'), len(free), mono))
    for f, p, e, w in seq:
        print("      f%03d  p %.3f  err %.3f  worst %.3f" % (f, p, e, w))


print("=== item 26: Z0 rows f278-294 (block 1:7 -> 22:28)")
score("A  2:7->22:27 | 1->28  (Z1's shape)", "Z0", 1, [[R(2, 7), R(22, 27)], [[1], [28]]], R(277, 296), 277.27, 295.5)
score("B  1:7->22:28  (+21 translation)", "Z0", 1, [[R(1, 7), R(22, 28)]], R(277, 296), 277.27, 295.5)
score("A on f277-285 only (before the X1 occlusion)", "Z0", 1, [[R(2, 7), R(22, 27)], [[1], [28]]], R(277, 285), 277.27, 295.5)
score("B on f277-285 only", "Z0", 1, [[R(1, 7), R(22, 28)]], R(277, 285), 277.27, 295.5)
score("A on f290-296 only (after)", "Z0", 1, [[R(2, 7), R(22, 27)], [[1], [28]]], R(290, 296), 277.27, 295.5)
score("B on f290-296 only", "Z0", 1, [[R(1, 7), R(22, 28)]], R(290, 296), 277.27, 295.5)
print("    Z1's written 9:14->29:34 | 8->35 for comparison:")
score("Z1 9:14->29:34 | 8->35", "Z1", 1, [[R(9, 14), R(29, 34)], [[8], [35]]], R(277, 296), 277.27, 295.5)
score("Z1 8:14->29:35 (+21)", "Z1", 1, [[R(8, 14), R(29, 35)]], R(277, 296), 277.27, 295.5)

print("\n=== item 19: Z1 rows f202-208 on cols 5,11,17 (block 8:14)")
score("B  9:13->10:14 | 14->9 (row 8 static) -- applied", "Z1", 1, [[R(9, 13), R(10, 14)], [[14], [9]]], R(201, 210), 201.37, 208.38, block=R(8, 14), sub=[5, 11, 17])
score("A  8:13->9:14 | 14->8", "Z1", 1, [[R(8, 13), R(9, 14)], [[14], [8]]], R(201, 210), 201.37, 208.38, block=R(8, 14), sub=[5, 11, 17])
score("C  8:12->10:14 | 13:14->8:9 (Z0's twin shape)", "Z1", 1, [[R(8, 12), R(10, 14)], [R(13, 14), R(8, 9)]], R(201, 210), 201.37, 208.38, block=R(8, 14), sub=[5, 11, 17])
score("D  9:13->10:14 | 14->8, 8->9 == A", "Z1", 1, [[R(8, 13), R(9, 14)], [[14], [8]]], R(201, 210), 201.37, 208.38, block=R(8, 14), sub=[5, 11, 17])

print("\n=== item 7: X0 cols f045-054 (rows 1:7)")
score("rotation by +7  1:11->8:18 | 12:18->1:7 -- applied", "X0", 0, [[R(1, 11), R(8, 18)], [R(12, 18), R(1, 7)]], R(44, 56), 44.0, 54.22)
score("rotation by +9  1:9->10:18 | 10:18->1:9 (last resort's)", "X0", 0, [[R(1, 9), R(10, 18)], [R(10, 18), R(1, 9)]], R(44, 56), 44.0, 54.22)
score("rotation by +8  1:10->9:18 | 11:18->1:8", "X0", 0, [[R(1, 10), R(9, 18)], [R(11, 18), R(1, 8)]], R(44, 56), 44.0, 54.22)

print("\n=== item 11: X0 rows f081-085 (block 8:14)")
score("8:12->10:14 | 13:14->8:9 -- applied", "X0", 1, [[R(8, 12), R(10, 14)], [R(13, 14), R(8, 9)]], R(80, 87), 79.0, 86.0)
score("book 13->8 | 14->10 | 8->9 | 9:12->11:14", "X0", 1, [[[13], [8]], [[14], [10]], [[8], [9]], [R(9, 12), R(11, 14)]], R(80, 87), 79.0, 86.0)

print("\n=== item 25: X1 rows f267-281")
score("36:42->15:21 -- applied", "X1", 1, [[R(36, 42), R(15, 21)]], R(266, 284), 266.0, 281.64)
score("book 35:41->15:21", "X1", 1, [[R(35, 41), R(15, 21)]], R(266, 284), 266.0, 281.64)
