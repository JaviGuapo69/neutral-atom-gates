"""sb_emit.py -- moves.json -> the six-sheet workbook.

Constants / Seed / Schedule / Gates are exactly c540_v4's layout, so `render.ps1` and `se_sim.py`
read the result unchanged; `slot` carries the AOM group index, which is what V3/V4 meant by it.
Combined is Shayne's hand layout (one row pair per event, AOM x/y tone columns) so the sheet can be
read as hardware instructions.  Notes carries the per-row evidence and, importantly, the list of
what is NOT determined.

Readouts and loads are NOT produced by sb_compose: a readout carries no outline and no fill (the
block desaturates and descends off panel), so it is measured separately -- see SKILL.md 'Readouts
and loads'.  Supply them in a JSON file via extra= and they are merged in at the right times.
"""
import json, os

import openpyxl
from openpyxl.utils import get_column_letter

from sb_read import comb


def emit(path, M, mv, tr, runs, P, f0, f1, extra=None, scope_note=None):
    moves = mv["moves"]
    undet = mv.get("undetermined", [])
    blocks = mv.get("blocks", {})
    extra_ev = []
    if extra and os.path.exists(extra):
        extra_ev = json.load(open(extra))

    # ---- schedule rows, with the AOM index already assigned by sb_compose.allocate_aom
    import sb_compose
    rows = sb_compose.schedule_rows(moves)

    # The readouts and loads occupy crossed pairs exactly like any other row, so they belong in the
    # SAME interval colouring (rule 8).  Allocating over the measured moves alone and then giving
    # the hand-measured rows slots afterwards understates `aom_peak_concurrent`, which is one of
    # the numbers this workbook exists to report.
    def parse_comb(s):
        out = []
        for tok in str(s).replace(" ", "").split(","):
            if not tok:
                continue
            if ":" in tok:
                a, b = tok.split(":")
                out += list(range(int(a), int(b) + 1))
            else:
                out.append(int(tok))
        return out

    extra_rows = []
    for ev in extra_ev:
        extra_rows.append(dict(mi="x", mv=None, tag=ev["event"],
                               t0=float(ev["t_start"]), t1=float(ev["t_finish"]),
                               xs=parse_comb(ev["x_start"]), xf=parse_comb(ev["x_finish"]),
                               ys=parse_comb(ev["y_start"]), yf=parse_comb(ev["y_finish"]),
                               ev=ev))
    ng, peak = sb_compose.allocate_aom(rows + extra_rows)
    for r in extra_rows:
        r["ev"]["slot"] = r["aom"]

    seed = {}
    for nm in sorted(tr):
        rr = tr[nm]["rests"]
        if rr:
            seed[nm] = (rr[0][2], rr[0][3])

    wb = openpyxl.Workbook()

    # ---------------------------------------------------------------- Constants
    ws = wb.active
    ws.title = "Constants"
    ws.append(["key", "value", "note"])
    K = M.K
    for k, v, n in [
        ("lattice_cols", K["data_cols"], "data sites across"),
        ("lattice_rows", K["data_rows"],
         "data sites down; row 1 is topmost, y increases downward"),
        ("cycle_ms", round(M.nf * M.dt, 4), "the full movie"),
        ("frames", M.nf, ""),
        ("dt_ms", M.dt, "cycle_ms / frames; frame(t) = round(t / dt_ms)"),
        ("easing", "s(u) = 10u^3 - 15u^4 + 6u^5", "verified against the movie"),
        ("tone_divisor", 1,
         "tones are data sites. EVERY move measured on c150 lands on integer tones; a merged "
         "profile peak is a CROSSING, not a destination"),
        ("visible_col_min", K["visible_col"][0], ""),
        ("visible_col_max", K["visible_col"][1], ""),
        ("visible_row_min", K["visible_row"][0], ""),
        ("visible_row_max", K["visible_row"][1], ""),
        ("aom_groups_used", ng, "crossed AOD pairs required"),
        ("aom_peak_concurrent", peak, "maximum simultaneously active"),
        # The transition count is NOT the move count: one rectangle can carry two species, so two
        # transitions are described by one move (SKILL.md 5).  Reporting len(moves) here understated
        # c150 as 55 transitions where occupancy enumerates 69.
        ("transitions_found", sum(len(v["transitions"]) for v in tr.values()),
         "relocations + permutation windows, enumerated from occupancy (rule 12)"),
        ("moves_measured", len(moves), "one rectangle may carry two species, so fewer than "
                                       "transitions_found"),
        ("transitions_undetermined", len(undet), "listed in Notes; not invented"),
    ]:
        ws.append([k, v, n])
    for nm in sorted(seed):
        ws.append(["block_%s" % nm, "%s x %s" % (comb(seed[nm][0]), comb(seed[nm][1])), "seed"])
    if scope_note:
        ws.append(["scope", scope_note, "frames covered by this workbook"])
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 84

    # ---------------------------------------------------------------- Seed
    ws = wb.create_sheet("Seed")
    ws.append(["species", "x_tones", "y_tones", "note"])
    for nm in sorted(seed):
        ws.append([nm, comb(seed[nm][0]), comb(seed[nm][1]), "position at t = 0"])
    for c, w in (("A", 10), ("B", 14), ("C", 14), ("D", 24)):
        ws.column_dimensions[c].width = w

    # ---------------------------------------------------------------- Gates
    ws = wb.create_sheet("Gates")
    ws.append(["move", "t_start", "t_finish"])
    for i, (p0, p1) in enumerate(runs, 1):
        ws.append([i, round(p0 * M.dt, 4), round(p1 * M.dt, 4)])
    for c, w in (("A", 8), ("B", 11), ("C", 11)):
        ws.column_dimensions[c].width = w

    # ---------------------------------------------------------------- Schedule
    ws = wb.create_sheet("Schedule")
    ws.append(["move", "slot", "event", "species", "t_start", "t_finish",
               "x_start", "y_start", "x_finish", "y_finish", "note"])
    mvno, nxt = {}, 1
    for r in rows:
        if r["mi"] not in mvno:
            mvno[r["mi"]] = nxt; nxt += 1
    for r in rows:
        m = r["mv"]
        ws.append([mvno[r["mi"]], r["aom"], "move", "", r["t0"], r["t1"],
                   comb(r["xs"]), comb(r["ys"]), comb(r["xf"]), comb(r["yf"]),
                   "%s %s %s; verified %.4f site (worst %.3f) against every profile peak on "
                   "frames %d-%d" % (m["sp"], m["axis"], r["tag"], m["mean"], m["worst"],
                                     m["f0"], m["f1"])])
    for ev in extra_ev:
        ws.append([ev.get("move", nxt), ev.get("slot", 1), ev["event"], ev.get("species", ""),
                   ev["t_start"], ev["t_finish"], ev["x_start"], ev["y_start"],
                   ev["x_finish"], ev["y_finish"], ev.get("note", "")])
        nxt += 1
    for c, w in (("A", 7), ("B", 6), ("C", 9), ("D", 9), ("E", 10), ("F", 10),
                 ("G", 13), ("H", 13), ("I", 13), ("J", 13), ("K", 104)):
        ws.column_dimensions[c].width = w

    # ---------------------------------------------------------------- Combined
    ws = wb.create_sheet("Combined")
    NCOL = max(8, ng)
    hdr = ["Move", "", "Rydberg?", "Start time", "Finish time"]
    for i in range(1, NCOL + 1):
        hdr += ["AOM%d x tones" % i, "AOM%d y tones" % i]
    hdr += ["event", "species", "note"]
    ws.append(hdr)

    def held(f):
        """the configuration held on frame f, groups sharing a y comb merged (rule 8)"""
        cfg = {}
        for nm in M.species:
            xs = [int(round(v)) for v in P(nm, f, 0)]
            ys = [int(round(v)) for v in P(nm, f, 1)]
            if xs and ys:
                cfg.setdefault(tuple(sorted(ys)), set()).update(xs)
        return [(comb(sorted(xv)), comb(list(yk))) for yk, xv in sorted(cfg.items())]

    events = []
    for p0, p1 in runs:
        ref = p0 - 1 if (p0 - 1) >= f0 and (p0 - 1) not in M.gate else p1 + 1
        if ref > f1 or ref in M.gate:
            ref = max(f0, min(f1, p0))
        cells = held(ref)
        events.append(dict(t0=round(p0 * M.dt, 4), t1=round(p1 * M.dt, 4), ryd=True,
                           c1=[(i, x, y) for i, (x, y) in enumerate(cells)],
                           c2=[(i, x, y) for i, (x, y) in enumerate(cells)], sp="",
                           note="global pulse held over frames %d-%d; the columns are the "
                                "configuration held" % (p0, p1)))
    for mi, n in sorted(mvno.items(), key=lambda kv: kv[1]):
        rs = [r for r in rows if r["mi"] == mi]
        m = rs[0]["mv"]
        note = ("%s %s, frames %d-%d; verified %.4f site (worst %.3f) against every profile peak"
                % ("+".join(m["joins"]) or m["sp"], m["axis"], m["f0"], m["f1"],
                   m["mean"], m["worst"]))
        if m["kind"] == "permutation":
            note += "; SAME-SITE permutation -- no render and no positional score can check this"
        if not m["ok"]:
            note += "; OVER the 0.10 site guideline"
        events.append(dict(t0=rs[0]["t0"], t1=rs[0]["t1"], ryd=False,
                           c1=[(r["aom"] - 1, comb(r["xs"]), comb(r["ys"])) for r in rs],
                           c2=[(r["aom"] - 1, comb(r["xf"]), comb(r["yf"])) for r in rs],
                           sp="+".join(m["joins"]) or m["sp"], note=note))
    events.sort(key=lambda e: (e["t0"], e["t1"]))

    r = 2
    notes = []
    for n, ev in enumerate(events, 1):
        for is_start in (True, False):
            ws.cell(row=r, column=1, value=(n if r <= 3 else "=A%d+1" % (r - 2)))
            ws.cell(row=r, column=2, value="=MIN(D%d,E%d)" % (r, r))
            if ev["ryd"]:
                ws.cell(row=r, column=3, value="Rydberg")
            ws.cell(row=r, column=4 if is_start else 5,
                    value=ev["t0"] if is_start else ev["t1"])
            for gi, x, y in (ev["c1"] if is_start else ev["c2"]):
                if gi < NCOL:
                    ws.cell(row=r, column=6 + 2 * gi, value=x)
                    ws.cell(row=r, column=7 + 2 * gi, value=y)
            ws.cell(row=r, column=6 + 2 * NCOL, value="gate" if ev["ryd"] else "move")
            ws.cell(row=r, column=7 + 2 * NCOL, value=ev["sp"])
            if is_start:
                ws.cell(row=r, column=8 + 2 * NCOL, value=ev["note"])
            r += 1
        notes.append((n, ev["t0"], ev["t1"], ev["note"]))
    ws.freeze_panes = "A2"
    for c, w in ((1, 8), (2, 10), (3, 10), (4, 11), (5, 11)):
        ws.column_dimensions[get_column_letter(c)].width = w
    for c in range(6, 6 + 2 * NCOL):
        ws.column_dimensions[get_column_letter(c)].width = 14
    ws.column_dimensions[get_column_letter(8 + 2 * NCOL)].width = 112

    # ---------------------------------------------------------------- Notes
    ws = wb.create_sheet("Notes")
    ws.append(["Move", "Start time", "Finish time", "how this row was measured"])
    for row in notes:
        ws.append(list(row))
    if undet:
        ws.append([])
        ws.append(["", "", "", "UNDETERMINED -- reported, never invented (%d)" % len(undet)])
        for t in undet:
            ws.append(["", t["f0"] * M.dt, t["f1"] * M.dt,
                       "%s %s over frames %d-%d: x %s -> %s, y %s -> %s. No candidate partition "
                       "verified. The movie shows this block leaving its tones; the schedule does "
                       "not describe it."
                       % (t["sp"], t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                          comb(t["y0"]), comb(t["y1"]))])
    ws.append([])
    ws.append(["", "", "", "METHOD (see se-cycle-blocks/SKILL.md)"])
    for ln in [
        "Positions are 1-D colour-profile peaks: mask pixels within 34 RGB of the species' fill "
        "colour, sum along each axis, take the peaks with sub-pixel refinement. Two markers stay "
        "two peaks down to ~0.3 pitch and merge at their MIDPOINT below that.",
        "A merged peak is where markers CROSS, never where they stop. Reading one as a destination "
        "turns an ordinary pairwise swap into a fictitious move to half-integer tones.",
        "A configuration is read only at rest: every peak within 0.14 of a whole tone AND a full "
        "rectangle, never on a pulse frame. A single on-grid frame not adjacent to a pulse is a "
        "translating block landing on integers by coincidence and is discarded.",
        "NOTHING MOVES DURING A GLOBAL PULSE. Every move is fitted with (t_start, t_finish) "
        "confined to one pulse-free interval: t_start >= the last pulse frame's time, t_finish <= "
        "the next pulse's first frame's time.",
        "Partition and timing are found SEPARATELY. For each candidate partition the progress p "
        "is fitted independently on every frame; a correct partition explains every frame AND "
        "yields a monotone p-sequence. The easing is fitted to that sequence afterwards.",
        "Scoring is symmetric -- every measured peak near a prediction and every prediction near "
        "a measured peak -- and predictions closer than 0.3 pitch are merged first, because that "
        "is what the profile does.",
        "A rectangle may span two species. Each fitted tone map is tested against every OTHER "
        "species over the same frames; where it verifies, that species is on the same rectangle "
        "and its tones join the comb, read at the time of the move and never from the seed.",
        "AOM groups are an interval colouring taking the lowest free index, because a crossed AOD "
        "pair is reprogrammed between batches. Two rows share a group only with an identical comb "
        "on one axis. A swap or split always needs two groups.",
        "Boundaries within 1.5 frames are one boundary measured twice and are merged -- but never "
        "across a pulse, and placed where they cost least rather than at the cluster mean.",
        "Calibrate the noise floor on a species that is static in the window. On c150 frames 0-49 "
        "Z1 sits 0.008 site from its tones on every frame; an excursion 60x that is a real move.",
    ]:
        ws.append(["", "", "", ln])
    ws.column_dimensions["D"].width = 124
    for c, w in (("A", 8), ("B", 12), ("C", 12)):
        ws.column_dimensions[c].width = w

    wb.save(path)
    print("wrote %s" % path)
    print("  %d moves -> %d schedule rows, %d AOM groups (peak %d), %d gates, %d undetermined"
          % (len(moves), len(rows), ng, peak, len(runs), len(undet)))
