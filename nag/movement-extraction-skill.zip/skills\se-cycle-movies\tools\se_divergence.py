"""se_divergence.py -- does the workbook agree with the movie about WHICH SPECIES IS WHERE?

RUN THIS EARLY.  It is the cheapest test in the kit and it catches the failure that every other
check misses.

A `move` row picks atoms up BY POSITION and never consults `species`.  So if a schedule loses track
of one block -- most often because the block crossed the edge of the panel, where the extractor
keeps a handful of its atoms and the fit re-pairs the arrivals onto whatever was nearest -- the
stale atoms sit in the array and get swept up by later rows WEARING THE WRONG SPECIES LABEL.  From
that instant every downstream row compounds the error.

Nothing else in the kit sees this:

  * `render.ps1` / `se_sim.py` validation: clean.  Every row is individually legal.
  * `se_sim.census()`: never short.  The atom count is conserved; only the labels are swapped.
  * `se_score.py`: reports a mediocre RMS, because it pairs species by species, but gives no hint
    that the cause is labelling rather than timing -- and it is easy to spend a session tuning
    thresholds against it.
  * `se_compare.py` at held frames: reports `mislabelled`, but only at the couple of dozen frames
    where the whole array happens to be at rest.

On c150 this test read `first divergent frame 54, 1374 mislabelled site-frames` on the automatic
transcription, and `none / 0` after rebuilding with se_waypoints.py.  It is the single number that
separated the two.

Only at-rest, on-grid, on-screen markers take part: a translating block is genuinely ambiguous
(guide 4.2) and must not count against the sheet.

Usage:
    python se_divergence.py --xlsx wb.xlsx --calib calib.json --marks marks.csv [--show 20]

Reads 0 mislabelled site-frames -> the sheet's species bookkeeping is sound.
Reads anything else -> find the FIRST divergent frame and look there; everything after it is
consequence, not cause.
"""
import argparse, collections, csv, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import se_sim


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", required=True)
    ap.add_argument("--calib", required=True)
    ap.add_argument("--marks", required=True)
    ap.add_argument("--tol", type=float, default=0.2,
                    help="how close to a whole tone a marker must be to count, in tones")
    ap.add_argument("--show", type=int, default=20)
    a = ap.parse_args()

    K = json.load(open(a.calib))
    DT = float(K["dt_ms"])
    S = se_sim.from_workbook(a.xlsx)

    movie = collections.defaultdict(dict)
    with open(a.marks, newline="") as fh:
        for r in csv.DictReader(fh):
            if r["state"] != "solid":
                continue
            x, y = float(r["x"]), float(r["y"])
            if abs(x - round(x)) < a.tol and abs(y - round(y)) < a.tol:
                movie[int(float(r["frame"]))][(int(round(x)), int(round(y)))] = r["species"]

    rows = []
    for f in sorted(movie):
        t = f * DT
        sim = {}
        for at in S.atoms:
            if not (at["born"] <= t < at["dies"]):
                continue
            x, y = S.position(at, t)
            if abs(x - round(x)) < 1e-6 and abs(y - round(y)) < 1e-6:
                sim[(int(round(x)), int(round(y)))] = at["sp"]
        mv = movie[f]
        shared = set(mv) & set(sim)
        wrong = sorted(k for k in shared if mv[k] != sim[k])
        rows.append((f, len(mv), len(sim), len(shared), wrong))

    bad = [r for r in rows if r[4]]
    print("=" * 74)
    print("%s vs the movie: does it agree about WHICH SPECIES is where?"
          % os.path.basename(a.xlsx))
    print("=" * 74)
    if bad:
        print("%6s %8s %8s %8s %8s  %s" % ("frame", "movie", "sheet", "shared", "WRONG", "e.g."))
        for f, nm, ns, nsh, wrong in bad[: a.show]:
            eg = ", ".join("%s: movie %s / sheet %s"
                           % (k, movie[f][k], "?") for k in wrong[:2])
            print("%6d %8d %8d %8d %8d  %s" % (f, nm, ns, nsh, len(wrong), eg))
        if len(bad) > a.show:
            print("   ... and %d more divergent frames" % (len(bad) - a.show))
        print()
    print("first divergent frame          : %s" % (bad[0][0] if bad else "none"))
    print("divergent frames               : %d of %d compared" % (len(bad), len(rows)))
    print("total mislabelled site-frames  : %d" % sum(len(r[4]) for r in rows))
    if bad:
        print()
        print("Look at the FIRST divergent frame only; the rest is consequence.  The usual cause is")
        print("a block leaving the panel: compare the movie and the sheet either side of it, and if")
        print("a species has moved off an edge in the movie but not in the sheet, that is it.")
        print("se_waypoints.py exists for exactly this failure -- see its header.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
