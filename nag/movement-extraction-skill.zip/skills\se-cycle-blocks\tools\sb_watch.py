"""sb_watch.py -- the NUMERICAL form of "watch the whole comparison video" (SKILL.md rule 27).

A SAME-SITE PERMUTATION is invisible to every automatic check in this project: it conserves atoms
(census blind), ends on the rectangle it began on (score blind) and is self-consistent (render
validation blind).  On c200 four of them were found only by a human watching the video.

But it is NOT invisible frame by frame.  While such a move runs, the movie's sub-blocks are at
intermediate positions and the rebuild's are not (or the reverse), so the disagreement is real and
positional -- it is merely SHORT and LOCAL, a few peaks on a few frames, which is exactly why it
does not move a 39000-comparison mean.  So instead of sampling stills, score every
(frame, species, axis) cell on its own and print the LOCAL RUNS that stand out.

    python sb_watch.py --movie-calib calib.json --render-calib render_calib.json --thresh 0.35

Each side is masked with ITS OWN palette -- render.ps1 assigns its own colours per species index
and c300's Z0 differs by 47 RGB between movie and render, more than the mask tolerance.  Compare
POSITIONS, never appearance: the renderer also uses its own marker shapes.

HOW TO READ THE OUTPUT.  Every run of three frames or more should be one of four things, and you
must be able to say which for each:
  * the INTEGER-STAGING cost on parked reservoir stock (a long, flat run at ~0.5 site);
  * a block LEAVING or ENTERING the panel, where only an edge column is measurable (rule 21);
  * an OCCLUSION in the movie -- two blocks on the same sites, the rear one not drawn;
  * a CROSSING, where the profile peaks genuinely merge for a few frames (section 4).
Anything else -- especially a short run where a small group moves on one side and not the other --
is a missing or a phantom permutation.  That is what this tool is for.
"""
import argparse, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sb_read import Movie

GONE = 9.99             # site: one side has the block and the other does not


def err(m, r):
    if not m and not r:
        return []
    if not m or not r:
        return [GONE]
    return ([min(abs(x - y) for y in r) for x in m] +
            [min(abs(y - x) for x in m) for y in r])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--movie-calib", required=True)
    ap.add_argument("--render-calib", required=True)
    ap.add_argument("--thresh", type=float, default=0.35, help="site, on a cell's WORST peak")
    ap.add_argument("--min-run", type=int, default=1, help="only print runs at least this long")
    a = ap.parse_args()

    MM, RR = Movie(a.movie_calib), Movie(a.render_calib)
    vc, vr = MM.K["visible_col"], MM.K["visible_row"]
    win = (vc[0] - 0.45, vc[1] + 0.45, vr[0] - 0.45, vr[1] + 0.45)
    frames = [f for f in range(MM.nf) if f not in MM.gate]

    cells = {}
    for nm in MM.species:
        for axis in (0, 1):
            for f in frames:
                m = sorted(MM.peaks(MM.fill[nm], win, f, axis))
                r = sorted(RR.peaks(RR.fill[nm], win, f, axis))
                e = err(m, r)
                cells[(nm, axis, f)] = (max(e) if e else 0.0, m, r)

    print("threshold %.2f site on the WORST peak of a (frame, species, axis) cell; "
          "runs of >= %d frame(s)\n" % (a.thresh, a.min_run))
    nrun = 0
    for nm in MM.species:
        for axis in (0, 1):
            ax = "cols" if axis == 0 else "rows"
            run = []
            for f in frames + [None]:
                if f is not None and cells[(nm, axis, f)][0] > a.thresh:
                    run.append(f); continue
                if len(run) >= a.min_run:
                    nrun += 1
                    print("%-3s %-4s f%03d-f%03d  (%d frames, worst %.3f)"
                          % (nm, ax, run[0], run[-1], len(run),
                             max(cells[(nm, axis, g)][0] for g in run)))
                    for g in run:
                        w, m, r = cells[(nm, axis, g)]
                        print("     f%03d %.3f  movie  %s"
                              % (g, w, " ".join("%6.2f" % v for v in m)))
                        print("               render %s" % " ".join("%6.2f" % v for v in r))
                run = []
    print("\n%d run(s) above %.2f site. Account for EVERY run of three frames or more -- see the "
          "four legitimate causes in this file's docstring." % (nrun, a.thresh))


if __name__ == "__main__":
    main()
