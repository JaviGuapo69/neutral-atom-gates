"""apply_s28.py -- the two HAND CORRECTIONS to the session-27 c540 book (session 28, 2026-09-16).

The user checked the movie by hand against the s27 rebuild and confirmed exactly two faults, both
the ones SESSION_27_LAST_RESORT.md left open.  The skill is FINAL and is not changed; the move
list `moves_full.json` (copied from run_c540_s27) is edited here, the residuals of the corrected
maps are MEASURED with the skill's own `verify`, the transition record `rests_full.json` is made
to enumerate the movement the rest detector swallowed, and the workbook is re-emitted through
`sb_emit.emit` exactly as `sb_full.py` would (so Combined, AOM colouring and Notes stay
consistent).

  1. f348-355  Z0 cols on rows 1:9: ADD the rotation 13:18->19:24 | 19:24->13:18 (the hand book's
               map; the pixels show gold outline 13:18 -> 19:24 and mauve 19:24 -> 13:18 over
               f348-355).  t 10.6336 (when the 1:12->13:24 slide ends) .. 10.8357 (when the rows
               1:9->19:27 move starts), so the same atoms never carry two motions at once.
  2. f152-155  X0+X1 rows on cols 1:24: REPLACE the five-part read
               10,13->11,14 | 16->18 | 11->10 | 14->13 | 17:18->16:17  (rows 12, 15 static; 0.161)
               by the hand book's triple rotation 10,13,16->12,15,18 | 11:12,14:15,17:18->10:11,13:14,16:17
               (the f154 fill peaks 10.35 11.26 13.33 14.35 16.29 17.41 have no peak at 12 or 15).
               Same timing 4.6431 .. 4.7388 (ends at the f155 pulse).
  3. f140-144  X0 rows on cols 1:12 (D3): the book gave X0 a five-row cyclic shift 13:17->14:18 | 18->13
               (S2.1 competition, 0.100) while X1 (D4) had 13:14,16:17->14:15,17:18 | 15,18->13,16
               (appearance read, 0.066).  The user saw D3 and D4 do the SAME movement in the movie;
               the pixels agree (X0's outline classes on f140: mauve 13.01 14.02 16.04 17.00, gold
               14.97 17.99 -- identical to X1's).  The X0 move is DROPPED and X1's move becomes one
               X0+X1 rectangle over cols 1:24, which also frees one AOM in that batch.

The script starts from the UNTOUCHED s27 files (moves_full_s27_original.json,
rests_full_s27_original.json), so re-running it re-applies every correction from scratch.

    python apply_s28.py            # from run_c540_s28; writes moves_full.json, rests_full.json,
                                   # c540_s28_blocks.xlsx and apply_s28.log
"""
import json, os, sys
sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_compose, sb_emit
from sb_read import Movie

OUT_XLSX = "c540_s28_blocks.xlsx"
M = Movie("calib.json")
dt = M.dt
mv = json.load(open("moves_full_s27_original.json", encoding="utf-8"))
rests = json.load(open("rests_full_s27_original.json", encoding="utf-8"))
moves = mv["moves"]

print("measuring every species' peaks once (sb_compose.Peaks) ...")
runs = sb_compose.pulse_runs(M)
wins = sb_compose.species_windows(M, 0, M.nf - 1)
P = sb_compose.Peaks(M, wins, 0, M.nf - 1)


def measure(m, frames):
    """fill mean/worst/detail/mean_moving of a move with the skill's own verify + progress fit"""
    axis = 0 if m["axis"] == "cols" else 1
    detail = {}
    for nm in M.species:
        mean, worst, n = sb_compose.verify(P, nm, axis, m["src"], m["dst"], m["fa"], m["fb"],
                                           frames, M)
        detail[nm] = round(mean, 4) if n else None
    mean, worst, n = sb_compose.verify(P, m["sp"], axis, m["src"], m["dst"], m["fa"], m["fb"],
                                       frames, M)
    seq = sb_compose.progress_per_frame(P, m["sp"], axis, m["src"], m["dst"], frames, M)
    moving = [s for s in seq if 0.05 < s[1] < 0.95]
    m["mean"] = round(mean, 4)
    m["worst"] = round(worst, 3)
    m["detail"] = detail
    m["mean_moving"] = round(sum(s[2] for s in moving) / len(moving), 4) if moving else m["mean"]
    m["n_moving"] = len(moving)
    m["mono"] = round(sb_compose.monotone_penalty(seq), 4)
    m["ok"] = bool(m["mean"] <= 0.10)
    print("  %s %s f%03d-%03d %s: mean %.4f worst %.3f over %d peaks; moving-frame mean %.4f "
          "on %d frames; monotone penalty %.3f; joins %s"
          % (m["sp"], m["axis"], m["f0"], m["f1"], "+".join(m["joins"]), mean, worst, n,
             m["mean_moving"], m["n_moving"], m["mono"], detail))
    for f, p, e, w in seq:
        print("      f%03d  p %.3f  err %.3f  worst %.3f" % (f, p, e, w))
    return seq


# ------------------------------------------------------------------ 2. X0+X1 rows f152-155
ix = [i for i, m in enumerate(moves) if m["sp"] == "X0" and m["axis"] == "rows"
      and m["f0"] == 152 and m["f1"] == 154]
assert len(ix) == 1, ix
m = moves[ix[0]]
old = "%s -> %s" % (m["src"], m["dst"])
A, A2 = [10, 13, 16], [12, 15, 18]
B, B2 = [11, 12, 14, 15, 17, 18], [10, 11, 13, 14, 16, 17]
m["parts"] = [[A, A2], [B, B2]]
m["A"], m["A2"], m["B"], m["B2"] = A, A2, B, B2
m["src"] = list(range(10, 19))
mp = dict(zip(A + B, A2 + B2))
m["dst"] = [mp[s] for s in m["src"]]
m["how"] = ("HAND CORRECTION (session 28, 2026-09-16, user-confirmed against the movie): the hand "
            "book's map, each row triple rotating within itself (+2 on rows 10, 13, 16; -1 on the "
            "other six). The outline colours on f152 name the groups directly -- gold on rows 10, "
            "13, 16, mauve on 11, 12, 14, 15, 17, 18 -- and on f153-154 every row, rows 12 and 15 "
            "included, leaves its tone (f154 fill peaks 10.35 11.26 13.33 14.35 16.29 17.41). "
            "Production's five-part appearance read held rows 12 and 15 static and scored 0.161; "
            "S2.1 refused its best rotation at 0.178.")
print("\nX0+X1 rows f152-155: %s  ->  %s -> %s" % (old, m["src"], m["dst"]))
seq_x = measure(m, list(range(151, 158)))

# ------------------------------------------------------------------ 1. Z0 cols f348-355 (NEW)
S = list(range(13, 25))
A, A2 = list(range(13, 19)), list(range(19, 25))
B, B2 = list(range(19, 25)), list(range(13, 19))
t0, t1 = 10.6336, 10.8357
new = dict(for_tr=["Z0", 348, 355], sp="Z0", axis="cols", kind="permutation", f0=348, f1=355,
           iv=[337, 382], parts=[[A, A2], [B, B2]], src=S, dst=A2 + B2, A=A, A2=A2, B=B, B2=B2,
           fa=round(t0 / dt, 2), fb=round(t1 / dt, 2), lo=336.0, hi=383.0, t0=t0, t1=t1,
           mean=None, mean_moving=None, n_moving=None, worst=None, mono=None, span=1.0,
           joins=["Z0"], detail={}, comb=list(range(1, 10)),
           how=("HAND CORRECTION (session 28, 2026-09-16, user-confirmed against the movie): the "
                "hand book's 13:18 <-> 19:24 rotation at t 10.85, MISSING from every automatic book "
                "because whole-block occupancy reads Z0 at rest on 13:24 x 1:9 before and after it "
                "and never enumerates a transition (SESSION_27_LAST_RESORT.md section 5, item 1). "
                "On f348 the block splits into a gold-outlined half on cols 13:18 and a mauve-"
                "outlined half on 19:24; they cross at f351 (gold 15.72..20.73, mauve 16.25..21.24) "
                "and land swapped on f355. The free fit puts the motion at about f347.3-f355.1; it "
                "is clipped to start when the 1:12->13:24 slide ends (10.6336) and finish when the "
                "rows 1:9->19:27 move starts (10.8357), so no atom carries two motions at once."),
           sub_comb_lines=None, ok=False)
# insert after the Z0 cols 1:12->13:24 slide it follows
iz = [i for i, m in enumerate(moves) if m["sp"] == "Z0" and m["axis"] == "cols" and m["f0"] == 337]
assert len(iz) == 1, iz
moves.insert(iz[0] + 1, new)
print("\nZ0 cols f348-355 (new): %s -> %s" % (new["src"], new["dst"]))
seq_z = measure(new, list(range(347, 357)))

# the slide's transition now ends where the rotation's begins (provenance only)
moves[iz[0]]["for_tr"] = ["Z0", 337, 348]

# ------------------------------------------------------------------ rests: enumerate the swallowed transition
z = rests["Z0"]
tr = [t for t in z["transitions"] if t["f0"] == 337 and t["f1"] == 355]
assert len(tr) == 1, tr
tr[0]["f1"] = 348
z["transitions"].append(dict(sp="Z0", f0=348, f1=355, x0=S, y0=list(range(1, 10)), x1=S,
                             y1=list(range(1, 10)), kind="permutation"))
z["transitions"].sort(key=lambda t: t["f0"])
z["rests"].append([348, 348, S, list(range(1, 10))])
z["rests"].sort(key=lambda r: r[0])

# ------------------------------------------------------------------ 3. X0 rows f140-144 -> X1's map, one X0+X1 rectangle
ix0 = [i for i, m in enumerate(moves) if m["sp"] == "X0" and m["axis"] == "rows"
       and m["f0"] == 140 and m["f1"] == 146]
ix1 = [i for i, m in enumerate(moves) if m["sp"] == "X1" and m["axis"] == "rows"
       and m["f0"] == 140 and m["f1"] == 146]
assert len(ix0) == 1 and len(ix1) == 1, (ix0, ix1)
dropped = moves.pop(ix0[0])
m3 = [m for m in moves if m["sp"] == "X1" and m["axis"] == "rows" and m["f0"] == 140][0]
m3["joins"] = ["X0", "X1"]
m3["comb"] = list(range(1, 25))
m3["how"] = ("HAND CORRECTION (session 28, 2026-09-16, user-confirmed against the movie): D3 and D4 "
             "perform the SAME movement, so X0 rides X1's rectangle over cols 1:24. X0's outline "
             "classes on f140 are mauve on rows 13, 14, 16, 17 and gold on 15, 18 -- identical to "
             "X1's -- and on f142 both blocks show the same peaks (13.5/13.8/14.6, 16.4/16.9/17.6). "
             "The dropped X0 move was S2.1's five-row cyclic shift 13:17->14:18 | 18->13 (0.100), "
             "read from a contradicted appearance class; X1's appearance read 13:14,16:17->14:15,"
             "17:18 | 15,18->13,16 (0.066) is the movement. One rectangle instead of two frees one "
             "AOM in this batch.")
print("\nX0 rows f140-144: DROPPED %s -> %s; X1's move now joins X0+X1 on cols 1:24: %s -> %s"
      % (dropped["src"], dropped["dst"], m3["src"], m3["dst"]))
seq_3 = measure(m3, list(range(139, 148)))

# ------------------------------------------------------------------ notes
mv["notes"].append("[HAND CORRECTION, session 28] X0 rows f140-144: S2.1's 13:17->14:18 | 18->13 "
                   "DROPPED; X0 rides X1's 13:14,16:17->14:15,17:18 | 15,18->13,16 as one X0+X1 "
                   "rectangle over cols 1:24 (user-confirmed: D3 and D4 move identically; verified "
                   "%.4f site on X1, %s on X0)" % (m3["mean"], m3["detail"].get("X0")))
mv["notes"].append("[HAND CORRECTION, session 28] X0+X1 rows f152-155: production's five-part read "
                   "10,13->11,14 | 16->18 | 11->10 | 14->13 | 17:18->16:17 REPLACED by the hand "
                   "book's 10,13,16->12,15,18 | 11:12,14:15,17:18->10:11,13:14,16:17 (user-confirmed "
                   "on the pixels; verified %.4f site)" % m["mean"])
mv["notes"].append("[HAND CORRECTION, session 28] Z0 cols f348-355 on rows 1:9: ADDED the hand "
                   "book's 13:18->19:24 | 19:24->13:18, which rest detection never enumerated "
                   "(user-confirmed on the pixels; verified %.4f site)" % new["mean"])

json.dump(mv, open("moves_full.json", "w", encoding="utf-8"), indent=1)
json.dump(rests, open("rests_full.json", "w", encoding="utf-8"), indent=1)
print("\nwrote moves_full.json (%d moves) and rests_full.json" % len(moves))

# ------------------------------------------------------------------ re-emit, as sb_full.py does at its end
sb_emit.emit(OUT_XLSX, M, mv, rests, runs, P, 0, M.nf - 1, extra="extra.json",
             scope_note="the WHOLE movie: frames 0-%d, t = 0 .. %.4f ms, all %d pulse runs; "
                        "session-27 book + 3 hand corrections (session 28)"
                        % (M.nf - 1, (M.nf - 1) * M.dt, len(runs)))
