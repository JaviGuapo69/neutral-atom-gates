"""list_moves_s31.py -- compact listing of moves_full.json (frames, map, comb, mean, origin) + the undetermined list."""
import json, sys
p = sys.argv[1] if len(sys.argv) > 1 else "moves_full.json"
d = json.load(open(p, encoding="utf-8"))
mv = d["moves"]
DT = 0.03854166666666667


def rg(a):
    a = list(a)
    return "%d:%d" % (a[0], a[-1]) if len(a) > 1 and a == list(range(a[0], a[-1] + 1)) else ",".join(map(str, a))


print(len(mv), "moves;", len(d.get("undetermined", [])), "undetermined; AOM", d.get("aom_groups"), d.get("aom_peak"))
for i, m in enumerate(mv):
    how = str(m.get("how", ""))
    origin = ("LAST-RESORT" if "LAST-RESORT" in how or "last resort" in how.lower() else
              "S2.1" if "S2.1" in how else "sub-comb" if m.get("sub_comb_lines") else "")
    mp = " | ".join("%s->%s" % (rg(a), rg(b)) for a, b in m["parts"])
    comb = rg(m["sub_comb_lines"]) if m.get("sub_comb_lines") else (rg(m["comb"]) if m.get("comb") else "(empty)")
    print("%3d %-9s %-4s f%03d-%03d fit f%6.2f-%6.2f t %.4f-%.4f %-11s comb %-14s mean %s%s  %s" % (
        i, "+".join(m["joins"]), m["axis"], m["f0"], m["f1"], m["fa"], m["fb"], m["t0"], m["t1"], m["kind"], comb,
        ("%.4f" % m["mean"]) if m.get("mean") is not None else "None", " OVER" if (m.get("mean") or 0) > 0.10 else "",
        mp + ("   [%s]" % origin if origin else "")))
print("\nUNDETERMINED:")
for u in d.get("undetermined", []):
    print("   %-3s %-12s f%03d-%03d  x %s -> %s  y %s -> %s" % (u["sp"], u.get("kind", ""), u["f0"], u["f1"],
          rg(u["x0"]) if u.get("x0") else "?", rg(u["x1"]) if u.get("x1") else "?",
          rg(u["y0"]) if u.get("y0") else "?", rg(u["y1"]) if u.get("y1") else "?"))
