"""sb_compose.py -- movie -> whole-cycle workbook, session 11.

sb_read.py measures.  This composes: it enumerates every transition in the movie, finds the
sub-block partition for each, fits the timing under the physical constraints, packs the AOM groups
and writes the workbook.  Read SKILL.md first; every stage here implements one of its rules.

WHY THIS EXISTS.  sb_read.py --solve is a good measurement primitive and a poor transcriber.  Run
over a whole movie it (a) only sees a move where the mauve OUTLINE happens to be drawn, and misses
the rest entirely -- on c150 it missed Z0's column swap at f019-029 and both of Z0's moves in
f029-047; (b) fits timings freely, so it returns moves that start at negative time or run through a
global pulse; (c) numbers AOM groups with a counter that never frees a group, reporting 8 where 4
suffice; and (d) writes only the Combined sheet, which no renderer can read.

THE CENTRAL IDEA, and the reason this works where hand-reading did not:
    SEPARATE *WHICH ATOMS GO WHERE* FROM *WHEN THEY GO*.
For a candidate partition, fit the progress p INDEPENDENTLY ON EACH FRAME (a 1-D search).  A
correct partition yields small per-frame errors AND a monotone p-sequence; a wrong one cannot
produce both.  Only then fit the easing to that p-sequence, under the pulse constraint.  This makes
partition discovery a scored search over a finite library instead of a judgement call, and it is
what lets the two Z0 moves that carry no outline be recovered automatically.

Modes:
    --transitions   enumerate rests, relocations and permutation windows; write transitions.json
    --solve         find each transition's partition and timing; write moves.json
    --xlsx PATH     emit Constants/Seed/Gates/Schedule/Combined/Notes
    --run           all three
"""
import argparse, itertools, json, os, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sb_read
from sb_read import Movie, comb, smoothstep

TOL_ONGRID = 0.14          # a peak this close to a whole tone is on it (rule 2)
MERGE_SEP = 0.30           # profile peaks closer than this merge; so must predictions, before scoring
ACCEPT = 0.10              # mean verification error a move must reach
JOIN_FACTOR = 1.3          # cross-species join threshold = max(ACCEPT, this x best achieved)
RECONCILE_FR = 1.5         # endpoints this close are one boundary measured twice


# ===================================================================== measurement, cached
class Peaks:
    """Every species' x- and y-profile peaks on every frame, measured ONCE.

    Fitting must never call the measuring code: sb_read.Movie.peaks() opens and masks an image, and
    a 2-D timing search calls it millions of times.  Measure 4 species x N frames x 2 axes up front
    and the entire rest of this file is arithmetic.  On c150 that is 400 peak lists for 50 frames,
    measured in seconds, against ~10 minutes per move when the call sat inside the fit loop.
    """

    def __init__(self, M, wins, f0, f1):
        self.M, self.wins, self.f0, self.f1 = M, wins, f0, f1
        self.pk = {}
        for nm in M.species:
            if nm not in wins:
                continue
            for f in range(f0, f1 + 1):
                for axis in (0, 1):
                    self.pk[(nm, f, axis)] = M.peaks(M.fill[nm], wins[nm], f, axis)

    def __call__(self, nm, f, axis):
        return self.pk.get((nm, f, axis), [])


def species_windows(M, f0, f1, pad=0.55, skip_gate=True):
    """each species' own bounding box over the span, measured on every non-pulse frame.

    NOT a subsample.  sb_read's default takes about seven frames and on a long span that clips the
    window, which silently loses whatever leaves it.  And NOT the whole panel either: the outline
    mask is shared across the panel, so a panel-wide window attributes one species' outline to
    every species (it reported X1's move as Z1's).

    `skip_gate=False` INCLUDES the pulse frames, and the window used to read a PULSE-FRAME
    configuration must (c540).  Rule 15 says a configuration living only on a pulse frame is still
    a configuration; if the box is drawn round the non-pulse frames only, that configuration can
    fall outside its own window and the read fails at the one frame it exists on.  c540's Z0
    stands on cols 13:24 only on the gate frames f314-315 -- it is mid-move on every non-pulse
    frame of segment 9 -- so the box came out 1.00..23.93, clipping col 24; no rest was recorded
    there, segment 8 held the other end, and NO SEGMENT SAW BOTH ENDS of `Z0 cols 13:24 -> 1:12`.
    The move was never enumerated, which is rule 35 and 'Ways to be confidently wrong' 13: it
    appeared in no list, not even the undetermined one, and `se_sim` only caught it downstream as
    a later row picking up 0 of 108 sites.
    The tint spoils the fill's COLOUR, not its position, so the peaks are still where the markers
    are and the box they imply is right; this is used for the bounding box alone, never to read a
    configuration from the fill (rule 2 still forbids that).
    """
    full = (M.K["visible_col"][0] - 0.4, M.K["visible_col"][1] + 0.4,
            M.K["visible_row"][0] - 0.4, M.K["visible_row"][1] + 0.4)
    wins = {}
    for nm in M.species:
        ext = []
        for f in range(f0, f1 + 1):
            if skip_gate and f in M.gate:
                continue
            xs = M.peaks(M.fill[nm], full, f, 0)
            ys = M.peaks(M.fill[nm], full, f, 1)
            if xs and ys:
                ext.append((min(xs), max(xs), min(ys), max(ys)))
        if ext:
            wins[nm] = (min(e[0] for e in ext) - pad, max(e[1] for e in ext) + pad,
                        min(e[2] for e in ext) - pad, max(e[3] for e in ext) + pad)
    return wins


# ===================================================================== pulses
def pulse_runs(M):
    g = sorted(M.gate)
    runs, cur = [], [g[0]]
    for f in g[1:]:
        if f == cur[-1] + 1:
            cur.append(f)
        else:
            runs.append(cur); cur = [f]
    runs.append(cur)
    return [(r[0], r[-1]) for r in runs]


def free_intervals(runs, nf):
    out = []
    for i in range(len(runs) - 1):
        a, b = runs[i][1] + 1, runs[i + 1][0] - 1
        if b >= a:
            out.append((a, b))
    return out


def move_bounds(runs, a_iv, b_iv):
    """the frame-time window a move inside pulse-free frames a_iv..b_iv may occupy.

    NOTHING MOVES DURING A GLOBAL PULSE.  A pulse frame shows the state AT that instant, so a move
    may begin the moment the last pulse frame is displayed and must be finished by the moment the
    next pulse's first frame is:  lo = last pulse frame, hi = first frame of the next pulse.

    The off-by-one here matters: using a_iv (the first pulse-FREE frame) as the lower bound instead
    of the last pulse frame pushed four of c150's first eight fits over the acceptance bar.
    c540_v4 settles the convention -- its Gates row 1 is t 0 -> 0.03 with dt 0.0306, i.e. frames
    0..1, and its first move row starts at exactly 0.03, which is frame 1, not frame 2.
    """
    lo, hi = a_iv - 1, b_iv + 1
    for p0, p1 in runs:
        if p1 < a_iv:
            lo = max(lo, p1)
        if p0 > b_iv:
            hi = min(hi, p0)
    return float(lo), float(hi)


# ===================================================================== rest & transitions
def rect_at(P, M, nm, f, block=None):
    """the species' full rounded rectangle if it is at rest on frame f, else None.

    Rule 2, plus two corrections learned the hard way:
      * never on a pulse frame -- the tint moves every fill colour ~40 RGB;
      * a CLIPPED rectangle is completed by rigidity.  A block is one rigid size throughout, so if
        only column 0 is visible and it runs off the left edge, its columns are (0-w+1)..0.  This is
        a deduction from rule 1, and it is the only way an off-panel rectangle enters the sheet.
    """
    if f in M.gate:
        return None
    xs, ys = P(nm, f, 0), P(nm, f, 1)
    if not xs or not ys:
        return None
    if not (all(abs(v - round(v)) <= TOL_ONGRID for v in xs) and
            all(abs(v - round(v)) <= TOL_ONGRID for v in ys)):
        return None
    xs = [int(round(v)) for v in xs]
    ys = [int(round(v)) for v in ys]
    vc, vr = M.K["visible_col"], M.K["visible_row"]
    if block:
        w, h = block
        if len(xs) < w:
            if min(xs) <= vc[0]:
                xs = list(range(max(xs) - w + 1, max(xs) + 1))
            elif max(xs) >= vc[1]:
                xs = list(range(min(xs), min(xs) + w))
            else:
                return None
        if len(ys) < h:
            if min(ys) <= vr[0]:
                ys = list(range(max(ys) - h + 1, max(ys) + 1))
            elif max(ys) >= vr[1]:
                ys = list(range(min(ys), min(ys) + h))
            else:
                return None
        if len(xs) != w or len(ys) != h:
            return None
    return xs, ys


def block_size(P, M, nm, f0, f1):
    """the species' block size: the LARGEST (n_x, n_y) seen on at least two on-grid frames.

    A block is one rigid size throughout (rule 1), so a view of it can only ever show FEWER markers
    than it has -- clipped at the panel edge, or two peaks merged mid-crossing -- never more.  The
    largest count observed is therefore the size, and the "at least two frames" guard keeps a single
    noisy frame from inflating it.

    This used to be the MODE, which makes the answer depend on how much of the range the block
    spends off panel: over c150's frames 48-88 Z0 sits at cols -5:0 with only column 0 visible for
    most of the span, so the mode came back 1 column, `rect_at` had no width to complete the clipped
    rectangle with, and Z0's whole parking slide -- 1:6 -> -5:0 -- was never enumerated as a
    transition at all.  The block would have stayed at 1:6 in the rebuild while the movie parked it
    off screen.  Take it over the WHOLE movie, not per window, for the same reason: a block can be
    off panel for an entire pulse-free interval.
    """
    from collections import Counter
    cx, cy = Counter(), Counter()
    for f in range(f0, f1 + 1):
        if f in M.gate:
            continue
        xs, ys = P(nm, f, 0), P(nm, f, 1)
        if xs and ys:
            cx[len(xs)] += 1; cy[len(ys)] += 1
    if not cx:
        return None
    w = max([k for k, n in cx.items() if n >= 2] or [max(cx)])
    h = max([k for k, n in cy.items() if n >= 2] or [max(cy)])
    return (w, h)


def transitions(P, M, f0, f1, blocks):
    """per species: the settled configurations, and every transition between them.

    A transition whose endpoints DIFFER is a relocation.  A transition whose endpoints are
    IDENTICAL is a same-site permutation -- invisible to occupancy, invisible to any positional
    score, and the class that the outline reader missed three of on c150.  Both must be accounted
    for or the movie is not reproduced.

    A single settled frame that is not adjacent to a pulse is DISCARDED: a translating block lands
    on integer tones by coincidence (guide 4.2).  Adjacency to a pulse rescues the genuine
    single-frame rests, because a block is always at rest while a pulse is on.
    """
    out = {}
    for nm in M.species:
        if nm not in blocks:
            continue
        st = {f: rect_at(P, M, nm, f, blocks[nm]) for f in range(f0, f1 + 1)}
        keep = {}
        for f in range(f0, f1 + 1):
            if st[f] is None:
                continue
            run = 1
            g = f - 1
            while g >= f0 and st.get(g) == st[f]:
                run += 1; g -= 1
            g = f + 1
            while g <= f1 and st.get(g) == st[f]:
                run += 1; g += 1
            if run >= 2 or any((f + d) in M.gate for d in (-2, -1, 1, 2)):
                keep[f] = st[f]
        segs = []
        for f in sorted(keep):
            if segs and keep[f] == segs[-1][2] and f - segs[-1][1] <= 3:
                segs[-1] = (segs[-1][0], f, keep[f])
            else:
                segs.append((f, f, keep[f]))
        # THE SEED IS A CONFIGURATION TOO, and the first move starts from it.  The opening pulse
        # frames hold it, but rect_at refuses a pulse frame because the tint corrupts the mask --
        # on c150 it reads X0/X1 correctly there and mangles Z0/Z1.  So try the pulse frames for
        # the seed only, accept the answer only if it is a full block, and otherwise leave the gap
        # for the caller to fill from the movie's own initial layout.  Without this, a move that
        # runs from the seed to the first rest is never enumerated: c150's Z0 column swap over
        # f002-006 was invisible until this was added.
        if segs and segs[0][0] > f0:
            for f in range(f0, min(segs[0][0], f0 + 3)):
                r = rect_at(P, M, nm, f, blocks[nm]) if f not in M.gate else None
                if r is None and f in M.gate:
                    xs, ys = P(nm, f, 0), P(nm, f, 1)
                    if (xs and ys and len(xs) == blocks[nm][0] and len(ys) == blocks[nm][1]
                            and all(abs(v - round(v)) <= TOL_ONGRID for v in xs)
                            and all(abs(v - round(v)) <= TOL_ONGRID for v in ys)):
                        r = ([int(round(v)) for v in xs], [int(round(v)) for v in ys])
                if r is not None and r != segs[0][2]:
                    segs.insert(0, (f, f, r))
                    break
        tr = []
        for i in range(len(segs) - 1):
            a, b, c0 = segs[i]
            a2, b2, c1 = segs[i + 1]
            tr.append(dict(sp=nm, f0=b, f1=a2, x0=c0[0], y0=c0[1], x1=c1[0], y1=c1[1],
                           kind="permutation" if c0 == c1 else "relocation"))
        out[nm] = dict(rests=[(a, b, c[0], c[1]) for a, b, c in segs], transitions=tr)
    return out


# ===================================================================== candidate partitions
def candidate_maps(src, dst):
    """A STRUCTURED library of bijections src -> dst, each decomposing into <=2 increasing maps.

    Why a library and not all subsets: a rectangle's tone map must be strictly increasing (guide
    I.2), so a move needing k increasing pieces needs k crossed pairs, and in practice k is 1 or 2.
    Enumerating every subset pairing is C(2n, n) -- 924 for a 6-tone block but 2.7 million for
    c540's 12 -- so instead generate the shapes the hardware actually produces.  Every c150 move
    found this session is in here:

        identity / rigid                  a plain translation
        contiguous split                  rows 7:10 -> 1:4 with row 6 -> 5  (X-rowreloc)
        half-block swap                   cols 4:6 <-> 1:3                  (X0-colswap)
        stride-2 interleave swap          cols 2,4,6 <-> 1,3,5              (Z0-colswap)
        adjacent-pair swap                cols 1<->2, 3<->4, 5<->6          (Z0-colpair)
        cyclic shift                      rows 11:14 -> 12:15, 15 -> 11     (Z0-rowcyc)
        reversal

    Returns a list of (A, A2, B, B2) with B, B2 possibly empty (a single increasing map).
    Anything not in here is reported as undetermined rather than approximated -- see solve().
    """
    S, D = sorted(src), sorted(dst)
    n = len(S)
    out, seen = [], set()

    def add(A, A2, B, B2):
        if len(A) != len(A2) or len(B) != len(B2):
            return
        if sorted(A + B) != S or sorted(A2 + B2) != D:
            return
        if list(A) != sorted(A) or list(A2) != sorted(A2):
            return
        if list(B) != sorted(B) or list(B2) != sorted(B2):
            return
        key = (tuple(A), tuple(A2), tuple(B), tuple(B2))
        if key in seen:
            return
        seen.add(key)
        out.append((list(A), list(A2), list(B), list(B2)))

    add(S, D, [], [])                                            # rigid / identity
    for k in range(1, n):                                        # contiguous split, both pairings
        add(S[:k], D[:k], S[k:], D[k:])
        add(S[:k], D[n - k:], S[k:], D[:n - k])
    for k in range(1, n):                                        # half-block swap at every cut
        add(S[k:], D[:n - k], S[:k], D[n - k:])
    for st in (2, 3):                                            # stride interleave swap
        for off in range(st):
            A = [S[i] for i in range(n) if i % st == off]
            B = [S[i] for i in range(n) if i % st != off]
            A2 = [D[i] for i in range(n) if i % st != off][:len(A)]
            B2 = [d for d in D if d not in A2]
            add(A, sorted(A2), B, sorted(B2))
    if n % 2 == 0:                                               # adjacent-pair swap
        A = [S[i] for i in range(0, n, 2)]
        B = [S[i] for i in range(1, n, 2)]
        A2 = [D[i] for i in range(1, n, 2)]
        B2 = [D[i] for i in range(0, n, 2)]
        add(A, sorted(A2), B, sorted(B2))
    for k in range(1, n):                                        # cyclic shift by k, both ways
        rot = D[k:] + D[:k]
        A = S[:n - k]; A2 = sorted(rot[:n - k])
        B = S[n - k:]; B2 = sorted(rot[n - k:])
        add(A, A2, B, B2)
        rot = D[-k:] + D[:-k]
        A = S[k:]; A2 = sorted(rot[k:])
        B = S[:k]; B2 = sorted(rot[:k])
        add(A, A2, B, B2)
    add(S[:n // 2], D[:n // 2][::-1] and sorted(D[:n // 2]), S[n // 2:], sorted(D[n // 2:]))
    return out


# ===================================================================== per-frame progress fit
def merge_close(vals, sep=MERGE_SEP):
    """merge values closer than `sep`, as a 1-D profile does at a crossing.

    Predictions MUST be merged before scoring.  Two markers closer than about 0.3 pitch produce a
    single profile peak at their midpoint, so comparing against unmerged predictions penalises a
    correct model exactly where the interesting moves are.  Equally, a merged peak is where markers
    CROSS, never where they stop -- reading one as a destination is how a plain pairwise swap gets
    mistaken for a move to half-integer tones.
    """
    v = sorted(vals)
    out, i = [], 0
    while i < len(v):
        j = i
        while j + 1 < len(v) and v[j + 1] - v[i] < sep:
            j += 1
        out.append(sum(v[i:j + 1]) / (j - i + 1))
        i = j + 1
    return out


def err_at(meas, src, dst, p, vis=None):
    """symmetric peak-matching error of the map at progress p.

    Symmetric is not optional: score predictions alone and any timing that keeps the atoms inside
    the crowd satisfies it, so the fit slides to whatever stretches the motion furthest.

    But a prediction OFF THE PANEL cannot be seen, so it must not be required to be.  `vis` is the
    visible tone range on this axis; predictions outside it are dropped from the prediction ->
    measurement half only.  The measurement -> prediction half still uses every prediction, because
    the model does know where its atoms are.

    Without this, every move that leaves the panel is scored as though the crop were error: c150's
    two parking slides -- Z0 and X0 sliding from cols 1:6 to -5:0, where only column 0 stays
    visible -- came back at 0.62 and 0.64 site for a map that is exactly right, and the penalty
    dragged X0's fitted finish seven frames past where the movie stops moving.
    """
    if not meas:
        return None
    pred = merge_close([s + (d - s) * p for s, d in zip(src, dst)])
    e1 = [min(abs(m - q) for q in pred) for m in meas]
    seen = pred if vis is None else [q for q in pred if vis[0] <= q <= vis[1]]
    e2 = [min(abs(m - q) for m in meas) for q in seen]
    return e1 + e2


def progress_per_frame(P, nm, axis, src, dst, frames, M, steps=81):
    """fit p INDEPENDENTLY on each frame.  Returns [(frame, p, err)].

    This is the heart of the method.  A candidate partition is judged by whether SOME progress
    explains each frame, with no timing model imposed at all; the timing is fitted afterwards to
    the p-sequence.  A wrong partition cannot both explain every frame and yield a monotone
    sequence, so the two tests together are far sharper than a joint (partition, timing) fit and
    vastly cheaper.
    """
    grid = np.linspace(0.0, 1.0, steps)
    out = []
    vis = visible_range(M, axis)
    for f in frames:
        if f in M.gate:
            continue
        meas = P(nm, f, axis)
        if not meas:
            continue
        best = None
        for p in grid:
            e = err_at(meas, src, dst, float(p), vis)
            if e is None:
                continue
            m = sum(e) / len(e)
            if best is None or m < best[1]:
                best = (float(p), m, max(e))
        if best:
            out.append((f, best[0], best[1], best[2]))
    return out


def monotone_penalty(seq):
    """how far the p-sequence departs from non-decreasing, per frame.

    A real move's progress only increases.  A partition that fits each frame individually but needs
    p to go up and down is describing a different motion than the one on screen.
    """
    if len(seq) < 2:
        return 0.0
    bad = 0.0
    for (f1, p1, _, _), (f2, p2, _, _) in zip(seq, seq[1:]):
        if p2 < p1:
            bad += p1 - p2
    return bad / (len(seq) - 1)


def fit_easing(seq, lo, hi, step=0.05):
    """fit (t_start, t_finish) in frames to the p-sequence, confined to [lo, hi]"""
    fs = np.array([s[0] for s in seq], float)
    ps = np.array([s[1] for s in seq], float)
    best = None
    for a in np.arange(lo, hi - 1.0 + 1e-9, step):
        for b in np.arange(a + 1.5, hi + 1e-9, step):
            e = float(np.sqrt(((smoothstep((fs - a) / (b - a)) - ps) ** 2).mean()))
            if best is None or e < best[0]:
                best = (e, float(a), float(b))
    return best


def visible_range(M, axis):
    """the panel's visible tone range on this axis -- what the movie is able to show at all"""
    return tuple(M.K["visible_col" if axis == 0 else "visible_row"])


def verify(P, nm, axis, src, dst, a, b, frames, M):
    """mean/worst symmetric error of the whole model (partition AND easing) on every frame"""
    tot = n = 0
    worst = 0.0
    vis = visible_range(M, axis)
    for f in frames:
        if f in M.gate:
            continue
        meas = P(nm, f, axis)
        if not meas:
            continue
        e = err_at(meas, src, dst, float(smoothstep((f - a) / (b - a))), vis)
        if not e:
            continue
        tot += sum(e); n += len(e); worst = max(worst, max(e))
    return (tot / n if n else float("nan")), worst, n


# ===================================================================== cross-species comb
def moves_on_axis(P, M, nm, axis, frames):
    """Does this species' block actually MOVE on this axis over these frames?

    `verify` is a mean over every one of the species' peaks, so where a move touches only a few of
    the block's tones the correctly-static majority dominates it and a block standing perfectly
    still passes the join test.  Section 5's justification -- "a genuinely static block misses by
    half a tone at half progress, so the separation is 20-40x" -- holds only when the WHOLE block
    moves, which is the case every c150 example is drawn from.

    c200's `rows 5 -> 6 | 6 -> 5` at f092-095 moves 2 of 10 rows, and on that map Z0 scores well
    enough to join while its rows are provably motionless: its peak list is byte-identical and
    exactly on tones across f091-f095.  Joining it would have put Z0's cols 1:4 on the rectangle
    and swapped ITS rows 5 and 6 too -- atoms in the wrong place, and invisible to any positional
    score because a same-site swap ends where it began.

    A block held by a moving rectangle must travel, and a marker in flight is off its tone.  So
    require the species to leave the lattice on this axis at some point in the window.  A species
    that never does is either static or busy on the OTHER axis; either way this rectangle is not
    carrying it, and excluding it is safe even if it were on the rectangle, because the map is the
    identity at every tone it occupies.
    """
    for f in frames:
        if f in M.gate:
            continue
        pk = P(nm, f, axis)
        if pk and max(abs(v - round(v)) for v in pk) > TOL_ONGRID:
            return True
    return False


def extend_comb(P, M, axis, src, dst, a, b, frames, blocks, rests, f_before):
    """which species share this move's rectangle, and the merged comb on the other axis.

    A rectangle may span more than one species; the atom-centric model allows it and the slot model
    cannot express it.  The outline marks only one species' half, so a move carrying two blocks is
    reported as one move PLUS a block wrongly called static.  Test the fitted tone map against
    every other species over the same frames: where it verifies, that species is on the same
    rectangle.  A genuinely static block misses by half a tone at half progress, so the separation
    is 20-40x and there are no cheap false positives.  This is what turns c150's two X row-moves
    into one x 1:12 rectangle and puts X0's column swap on y 6:15 carrying Z0.

    The threshold is RELATIVE as well as absolute.  Where two sub-blocks cross, their peaks are
    unresolvable for a few frames and the achievable error rises for EVERY species on the
    rectangle; c150's X-rowcross scores 0.159 on X0 and 0.166 on X1 against 5.87 on Z0, so a flat
    0.10 bar would reject X1 from its own rectangle.

    The comb is read from each joining species' configuration AT THE TIME OF THE MOVE, never from
    the seed: X0 is on rows 6:10 when it swaps columns, not on its seed rows 1:5.
    """
    sc = {}
    for nm in M.species:
        if nm not in blocks:
            continue
        m, w, n = verify(P, nm, axis, src, dst, a, b, frames, M)
        sc[nm] = m if n else None
    vals = [v for v in sc.values() if v is not None and v == v]
    if not vals:
        return [], {}, None
    thresh = max(ACCEPT, JOIN_FACTOR * min(vals))
    joins = [nm for nm in M.species if sc.get(nm) is not None and sc[nm] == sc[nm]
             and sc[nm] <= thresh and moves_on_axis(P, M, nm, axis, frames)]
    return (joins, {k: (None if v is None else round(v, 4)) for k, v in sc.items()},
            comb_for(joins, rests, axis, f_before))


def comb_for(joins, rests, axis, f_before):
    """the merged comb on the OTHER axis: each joining species' own tones at the time of the move.

    Rule 13 -- never from the seed.  X0 is on rows 6:10 when it swaps columns, not on its seed
    rows 1:5, and taking the seed put c150's rectangle at `y 1:5,11:15` where the movie plainly
    shows `y 6:15`.
    """
    combset = set()
    for j in joins:
        got = None
        for a2, b2, xs, ys in rests.get(j, {}).get("rests", []):
            if b2 <= f_before:
                got = (xs, ys)
        if got is None and rests.get(j, {}).get("rests"):
            got = (rests[j]["rests"][0][2], rests[j]["rests"][0][3])
        if got:
            combset |= set(got[1 - axis])
    return sorted(combset)


# ===================================================================== solve one transition
def solve_transition(P, M, tr, runs, ivs, blocks, rests, outline=None):
    """find the partition and timing for one transition, or report it undetermined"""
    axis_jobs = []
    if tr["x0"] != tr["x1"] or tr["kind"] == "permutation":
        axis_jobs.append((0, tr["x0"], tr["x1"]))
    if tr["y0"] != tr["y1"] or tr["kind"] == "permutation":
        axis_jobs.append((1, tr["y0"], tr["y1"]))
    iv = None
    for a_iv, b_iv in ivs:
        if tr["f0"] <= b_iv and tr["f1"] >= a_iv:
            lo2, hi2 = max(a_iv, tr["f0"]), min(b_iv, tr["f1"])
            if hi2 >= lo2 and (iv is None or (hi2 - lo2) > (iv[1] - iv[0])):
                iv = (a_iv, b_iv)
    if iv is None:
        return None
    lo, hi = move_bounds(runs, *iv)
    frames = [f for f in range(max(tr["f0"], iv[0]), min(tr["f1"], iv[1]) + 1) if f not in M.gate]
    if len(frames) < 3:
        return None

    results = []
    for axis, s0, s1 in axis_jobs:
        cands = candidate_maps(s0, s1)
        if outline:
            cands = outline + cands
        scored = []
        for A, A2, B, B2 in cands:
            src, dst = A + B, A2 + B2
            if src == dst:                                     # identity explains nothing moving
                continue
            seq = progress_per_frame(P, tr["sp"], axis, src, dst, frames, M, steps=41)
            if len(seq) < 3:
                continue
            pen = monotone_penalty(seq)
            span = max(s[1] for s in seq) - min(s[1] for s in seq)
            mean_e = sum(s[2] for s in seq) / len(seq)
            # Rank ONLY on how well each frame is explained and how monotone the progress is.
            # An earlier version added a bonus for a large p-span, which rewarded candidates that
            # swing further than the block actually does, and it kept the correct partition out of
            # the shortlist entirely (it chose Z0 cols 1:4->3:6 over the true 4:6<->1:3).  The
            # shortlist is also generous: the cheap per-frame score is a screen, and the decision
            # is the full verification after the easing is fitted.
            scored.append((mean_e + pen, mean_e, pen, span, A, A2, B, B2))
        if not scored:
            continue
        scored.sort(key=lambda t: t[0])
        best = None
        for cand in scored[:24]:                               # refit timing for the shortlist
            _, mean_e, pen, span, A, A2, B, B2 = cand
            src, dst = A + B, A2 + B2
            seq = progress_per_frame(P, tr["sp"], axis, src, dst, frames, M, steps=81)
            fe = fit_easing(seq, lo, hi)
            if fe is None:
                continue
            _, a, b = fe
            m, w, n = verify(P, tr["sp"], axis, src, dst, a, b, frames, M)
            if best is None or m < best[0]:
                best = (m, w, a, b, A, A2, B, B2, pen, span)
        if best is None:
            continue
        m, w, a, b, A, A2, B, B2 = best[:8]
        pen, span = best[8], best[9]
        if span < 0.45:
            continue          # the block never gets far enough from its start for this to be a move
        joins, detail, cb = extend_comb(P, M, axis, A + B, A2 + B2, a, b, frames, blocks,
                                        rests, tr["f0"])
        results.append(dict(sp=tr["sp"], axis="cols" if axis == 0 else "rows",
                            kind=tr["kind"], f0=frames[0], f1=frames[-1], iv=list(iv),
                            A=A, A2=A2, B=B, B2=B2, fa=round(a, 3), fb=round(b, 3),
                            t0=round(a * M.dt, 4), t1=round(b * M.dt, 4),
                            mean=round(m, 4), worst=round(w, 3), mono=round(pen, 4),
                            span=round(span, 3), joins=joins, detail=detail,
                            comb=cb, ok=bool(m <= ACCEPT)))
    return results


# ===================================================================== reconcile boundaries
def reconcile(moves, runs, P, M):
    """endpoints within RECONCILE_FR of each other are ONE boundary measured twice.

    One block cannot do two things at once, and the easing is flat at both ends so each endpoint is
    individually soft.  Left alone the sub-frame overlap makes the AOM colouring think both moves
    are live at once and allocate a fresh crossed pair instead of reusing a free one -- that is what
    reported 8 groups for c150's first 0.7 ms where 4 suffice.

    Two corrections over sb_read's --reconcile:
      * NEVER merge across a pulse.  A pulse separates two batches by definition, and chaining
        16.74 and 17.00 (ends, before the pulse) with 18.00 (starts, after it) drags the post-pulse
        moves 1.75 frames early and triples their error.
      * put the merged boundary where it costs LEAST, not at the cluster mean.  The mean is
        arbitrary and traded one move's accuracy for another's.
    """
    def same_boundary(v, w):
        if abs(w - v) > RECONCILE_FR:
            return False
        a, b = min(v, w), max(v, w)
        return not any(a <= p0 and p1 <= b for p0, p1 in runs)

    pts = sorted({round(v, 4) for mv in moves for v in (mv["fa"], mv["fb"])})
    if not pts:
        return []
    clusters, cur = [], [pts[0]]
    for v in pts[1:]:
        if same_boundary(cur[-1], v) and same_boundary(cur[0], v):
            cur.append(v)
        else:
            clusters.append(cur); cur = [v]
    clusters.append(cur)

    remap, log = {}, []
    for cl in clusters:
        if len(cl) == 1:
            remap[cl[0]] = cl[0]
            continue
        cls = set(cl)
        touched = [mv for mv in moves
                   if round(mv["fa"], 4) in cls or round(mv["fb"], 4) in cls]
        best = None
        for trial in np.arange(min(cl) - 0.4, max(cl) + 0.4 + 1e-9, 0.05):
            tot = 0.0
            ok = True
            for mv in touched:
                fa = float(trial) if round(mv["fa"], 4) in cls else mv["fa"]
                fb = float(trial) if round(mv["fb"], 4) in cls else mv["fb"]
                if fb - fa < 1.0:
                    ok = False; break
                axis = 0 if mv["axis"] == "cols" else 1
                m, _, _ = verify(P, mv["sp"], axis, mv["A"] + mv["B"], mv["A2"] + mv["B2"],
                                 fa, fb, list(range(mv["f0"], mv["f1"] + 1)), M)
                tot += m
            if ok and (best is None or tot < best[0]):
                best = (tot, float(trial))
        tgt = best[1] if best else sum(cl) / len(cl)
        for v in cl:
            remap[v] = tgt
        log.append((cl, tgt))

    for mv in moves:
        fa2, fb2 = remap[round(mv["fa"], 4)], remap[round(mv["fb"], 4)]
        if (fa2, fb2) == (mv["fa"], mv["fb"]):
            continue
        axis = 0 if mv["axis"] == "cols" else 1
        m, w, n = verify(P, mv["sp"], axis, mv["A"] + mv["B"], mv["A2"] + mv["B2"],
                         fa2, fb2, list(range(mv["f0"], mv["f1"] + 1)), M)
        mv["fa"], mv["fb"] = round(fa2, 3), round(fb2, 3)
        mv["t0"], mv["t1"] = round(fa2 * M.dt, 4), round(fb2 * M.dt, 4)
        mv["mean"], mv["worst"], mv["ok"] = round(m, 4), round(w, 3), bool(m <= ACCEPT)
    return log


# ===================================================================== AOM allocation
def schedule_rows(moves):
    """one row per rigid sub-block; a swap or split needs two, since 1->2 with 2->1 is not
    increasing and one crossed pair realises only an increasing map.

    `mv["parts"]` is the general form: k rigid sub-blocks, each with one uniform displacement, one
    row each.  Two is what c150's first 0.7 ms shows and what the A/B pair used to express, but
    three occurs the moment the outline marks only some of a block (the complement then makes a
    third part) and folding the extras into one B row would put two different displacements on one
    crossed pair, which no single frequency offset can realise.
    """
    rows = []
    for i, mv in enumerate(moves):
        axis = 0 if mv["axis"] == "cols" else 1
        cb = mv["comb"] or []
        if mv.get("parts"):
            groups = [("%s" % chr(ord("a") + k), list(s), list(d))
                      for k, (s, d) in enumerate(mv["parts"])]
        else:
            groups = [("a", mv["A"], mv["A2"]), ("b", mv["B"], mv["B2"])]
        for tag, s, d in groups:
            if not s:
                continue
            if axis == 0:
                xs, xf, ys, yf = s, d, cb, cb
            else:
                xs, xf, ys, yf = cb, cb, s, d
            rows.append(dict(mi=i, mv=mv, tag=tag, t0=mv["t0"], t1=mv["t1"],
                             xs=list(xs), xf=list(xf), ys=list(ys), yf=list(yf)))
    rows.sort(key=lambda r: (r["t0"], r["t1"], r["mi"], r["tag"]))
    return rows


def allocate_aom(rows):
    """interval colouring, LOWEST FREE INDEX.

    A crossed AOD pair is reprogrammed between batches, so a group that is free at this instant is
    reused; packing is an interval colouring, not a running counter and not a first-fit that never
    releases.  sb_read numbered groups with a counter, which is why it reported one group per row.

    Two rows may share a group at OVERLAPPING times only if they have an identical comb on one axis
    and the merged map on the other stays strictly increasing.  Merging two different combs creates
    traps at the full product of the unions and can capture an atom belonging to another group --
    the guide's atom-capture rule.
    """
    def overlap(r1, r2):
        return r1["t0"] < r2["t1"] - 1e-9 and r2["t0"] < r1["t1"] - 1e-9

    def compatible(r1, r2):
        if not overlap(r1, r2):
            return True
        same_x = r1["xs"] == r2["xs"] and r1["xf"] == r2["xf"]
        same_y = r1["ys"] == r2["ys"] and r1["yf"] == r2["yf"]
        if not (same_x or same_y):
            return False
        if same_y:
            m = dict(zip(r1["xs"], r1["xf"]))
            pairs = list(zip(r2["xs"], r2["xf"]))
        else:
            m = dict(zip(r1["ys"], r1["yf"]))
            pairs = list(zip(r2["ys"], r2["yf"]))
        for k, v in pairs:
            if k in m and m[k] != v:
                return False
            m[k] = v
        it = sorted(m.items())
        return all(it[i][1] < it[i + 1][1] for i in range(len(it) - 1))

    groups = []
    for r in rows:
        for gi, g in enumerate(groups):
            if all(compatible(r, o) for o in g):
                g.append(r); r["aom"] = gi + 1; break
        else:
            groups.append([r]); r["aom"] = len(groups)
    edges = sorted({r["t0"] for r in rows} | {r["t1"] for r in rows})
    peak = 0
    for i in range(len(edges) - 1):
        mid = (edges[i] + edges[i + 1]) / 2
        peak = max(peak, len({r["aom"] for r in rows if r["t0"] < mid < r["t1"]}))
    return (max((r["aom"] for r in rows), default=0), peak)


# ===================================================================== main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--f0", type=int, default=0)
    ap.add_argument("--f1", type=int, default=None)
    ap.add_argument("--transitions", action="store_true")
    ap.add_argument("--solve", action="store_true")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--xlsx", default="")
    ap.add_argument("--work", default=".", help="directory for transitions.json / moves.json")
    a = ap.parse_args()

    M = Movie(a.calib, a.frames)
    f1 = a.f1 if a.f1 is not None else M.nf - 1
    runs = pulse_runs(M)
    ivs = free_intervals(runs, M.nf)
    print("movie: %d frames, dt %.9f ms, cycle %.4f ms" % (M.nf, M.dt, M.nf * M.dt))
    print("pulse runs         : %s" % runs)
    print("pulse-free windows : %s" % ivs)

    wins = species_windows(M, a.f0, f1)
    print("windows (cols lo,hi / rows lo,hi):")
    for nm in sorted(wins):
        print("   %-3s %.2f..%.2f x %.2f..%.2f" % (nm, *wins[nm]))
    print("measuring peaks, frames %d..%d ..." % (a.f0, f1), flush=True)
    P = Peaks(M, wins, a.f0, f1)
    blocks = {nm: block_size(P, M, nm, a.f0, f1) for nm in wins}
    blocks = {k: v for k, v in blocks.items() if v}
    print("block sizes: %s" % blocks)

    TRJ = os.path.join(a.work, "transitions.json")
    MVJ = os.path.join(a.work, "moves.json")

    if a.transitions or a.run:
        rests = transitions(P, M, a.f0, f1, blocks)
        nrel = sum(1 for nm in rests for t in rests[nm]["transitions"]
                   if t["kind"] == "relocation")
        nper = sum(1 for nm in rests for t in rests[nm]["transitions"]
                   if t["kind"] == "permutation")
        for nm in sorted(rests):
            print("\n== %s : %d settled configurations" % (nm, len(rests[nm]["rests"])))
            for a2, b2, xs, ys in rests[nm]["rests"]:
                print("   rest f%03d-%03d  %-14s x %-12s" % (a2, b2, comb(xs), comb(ys)))
            for t in rests[nm]["transitions"]:
                print("      -> %-11s f%03d..f%03d  x %s -> %s   y %s -> %s"
                      % (t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                         comb(t["y0"]), comb(t["y1"])))
        print("\n%d relocations + %d permutation windows = %d transitions to account for"
              % (nrel, nper, nrel + nper))
        json.dump(rests, open(TRJ, "w"), indent=1)
        print("wrote %s" % TRJ)

    if a.solve or a.run:
        rests = json.load(open(TRJ))
        allt = [t for nm in rests for t in rests[nm]["transitions"]]
        allt.sort(key=lambda t: t["f0"])
        moves, undet = [], []
        for t in allt:
            res = solve_transition(P, M, t, runs, ivs, blocks, rests)
            if not res:
                undet.append(t); continue
            got = [r for r in res if r["ok"]] or res
            for r in got:
                moves.append(r)
            if not any(r["ok"] for r in res):
                undet.append(t)
        moves.sort(key=lambda m: (m["fa"], m["fb"]))
        log = reconcile(moves, runs, P, M)
        for cl, tgt in log:
            print("  reconciled %s -> f%.3f" % (", ".join("f%.2f" % v for v in cl), tgt))
        # drop duplicates: two species' halves of one shared rectangle are one move
        uniq, seen = [], set()
        for mv in moves:
            k = (mv["axis"], tuple(mv["A"]), tuple(mv["A2"]), tuple(mv["B"]), tuple(mv["B2"]),
                 tuple(mv["comb"] or []), round(mv["fa"], 1))
            if k in seen:
                continue
            seen.add(k); uniq.append(mv)
        print("\n== %d moves (%d before merging shared rectangles)" % (len(uniq), len(moves)))
        for mv in uniq:
            print("  %-3s %-4s f%03d-%03d  %-20s -> %-20s | %-14s -> %-14s  t %.4f-%.4f  "
                  "spans %-9s comb %-12s mean %.4f %s"
                  % (mv["sp"], mv["axis"], mv["f0"], mv["f1"], comb(mv["A"]), comb(mv["A2"]),
                     comb(mv["B"]) if mv["B"] else "-", comb(mv["B2"]) if mv["B2"] else "-",
                     mv["t0"], mv["t1"], "+".join(mv["joins"]), comb(mv["comb"] or []),
                     mv["mean"], "OK" if mv["ok"] else "OVER 0.10"))
        rows = schedule_rows(uniq)
        ng, peak = allocate_aom(rows)
        print("\nAOM groups used %d, peak concurrent %d" % (ng, peak))
        if undet:
            print("\n*** %d transitions UNDETERMINED -- reported, not invented:" % len(undet))
            for t in undet:
                print("    %-3s %-11s f%03d..f%03d  x %s -> %s  y %s -> %s"
                      % (t["sp"], t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                         comb(t["y0"]), comb(t["y1"])))
        json.dump(dict(moves=uniq, undetermined=undet, aom_groups=ng, aom_peak=peak,
                       blocks={k: list(v) for k, v in blocks.items()}),
                  open(MVJ, "w"), indent=1, default=str)
        print("wrote %s" % MVJ)

    if a.xlsx:
        import sb_emit
        sb_emit.emit(a.xlsx, M, json.load(open(MVJ)), json.load(open(TRJ)), runs, P,
                     a.f0, f1)


if __name__ == "__main__":
    main()
