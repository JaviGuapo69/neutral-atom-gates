"""cmp_tol.py -- two moves_full.json books, move by move, with a TIMING TOLERANCE.

    python cmp_tol.py <accepted.json> <new.json> [--tol 1]

The user's pass criterion (2026-09-15): MAPS must be identical; a move's frame window may shift by
about one frame.  `cmp_moves.py` keys on the exact (f0, f1) and so reports a one-frame window shift
as one move lost plus one move gained.  This one matches each accepted move to the new move of the
same species set and axis whose window is nearest (both ends within --tol frames), then compares
src -> dst and the comb.  Anything unmatched is listed in full.
"""
import json, sys, argparse


def load(p):
    d = json.load(open(p, encoding="utf-8"))
    mv = d["moves"] if isinstance(d, dict) else d
    out = []
    for m in mv:
        out.append(dict(who="+".join(sorted(m.get("joins") or [m["sp"]])), axis=m["axis"],
                        f0=m["f0"], f1=m["f1"], fa=m.get("fa"), fb=m.get("fb"),
                        src=tuple(m["src"]), dst=tuple(m["dst"]), comb=tuple(m.get("comb") or ()),
                        mean=m.get("mean"), how=(m.get("how") or "")[:60]))
    return out


def fmt(m):
    return "%-9s %-4s f%03d-%03d  %s -> %s  comb %s  mean %s" % (
        m["who"], m["axis"], m["f0"], m["f1"],
        ",".join(map(str, m["src"])), ",".join(map(str, m["dst"])),
        ",".join(map(str, m["comb"])) if m["comb"] else "-", m["mean"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("acc"); ap.add_argument("new")
    ap.add_argument("--tol", type=float, default=1.0)
    a = ap.parse_args()
    A, B = load(a.acc), load(a.new)
    print("accepted: %d moves      new run: %d moves" % (len(A), len(B)))
    usedB = set()
    exact = shifted = wrong = 0
    lostA = []
    for m in A:
        cands = [(abs(n["f0"] - m["f0"]) + abs(n["f1"] - m["f1"]), j) for j, n in enumerate(B)
                 if j not in usedB and n["who"] == m["who"] and n["axis"] == m["axis"]
                 and abs(n["f0"] - m["f0"]) <= a.tol and abs(n["f1"] - m["f1"]) <= a.tol]
        if not cands:
            lostA.append(m); continue
        cands.sort()
        j = cands[0][1]; usedB.add(j); n = B[j]
        same_map = (n["src"], n["dst"]) == (m["src"], m["dst"])
        same_win = (n["f0"], n["f1"]) == (m["f0"], m["f1"])
        if same_map and same_win:
            exact += 1
        elif same_map:
            shifted += 1
            print("  WINDOW SHIFT   acc %s\n                 new %s" % (fmt(m), fmt(n)))
        else:
            wrong += 1
            print("  *** MAP DIFFERS  acc %s\n                   new %s" % (fmt(m), fmt(n)))
        if same_map and n["comb"] != m["comb"]:
            print("  comb differs    acc %s\n                 new %s" % (fmt(m), fmt(n)))
    extraB = [n for j, n in enumerate(B) if j not in usedB]
    print("\n%d accepted moves matched exactly, %d with a window shift <= %.0f frame(s), "
          "%d with a DIFFERENT MAP" % (exact, shifted, a.tol, wrong))
    print("\nin the ACCEPTED book with no counterpart in the new run (%d):" % len(lostA))
    for m in lostA:
        print("   " + fmt(m))
    print("\nin the NEW run with no counterpart in the accepted book (%d):" % len(extraB))
    for n in extraB:
        print("   " + fmt(n) + "   [" + n["how"] + "]")
    verdict = "PASS (maps identical, windows within tolerance)" if not (wrong or lostA or extraB) \
        else "DIFFERS"
    print("\n==== VERDICT: %s ====" % verdict)


if __name__ == "__main__":
    main()
