"""Dump Schedule (and Combined) rows of a workbook whose time window overlaps [t0, t1] ms."""
import sys, openpyxl
xlsx, t0, t1 = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
wb = openpyxl.load_workbook(xlsx, data_only=True)
print("sheets:", wb.sheetnames)
dt = 0.03057291666666667
ws = wb["Schedule"]
rows = list(ws.iter_rows(values_only=True))
hdr = rows[0]
print("Schedule header:", hdr)
its = hdr.index("t_start"); itf = hdr.index("t_finish")
for r in rows[1:]:
    if r[its] is None: continue
    ts, tf = float(r[its]), float(r[itf])
    if tf >= t0 and ts <= t1:
        print(f"  f{ts/dt:6.2f}-f{tf/dt:6.2f} | " + " | ".join("" if v is None else str(v) for v in r))
if "Combined" in wb.sheetnames:
    ws = wb["Combined"]
    rows = list(ws.iter_rows(values_only=True))
    print("Combined header:", rows[0])
    hdr = rows[0]
    # find time columns
    tcols = [i for i, h in enumerate(hdr) if h and ("t" in str(h).lower())]
    for r in rows[1:]:
        vals = [v for v in r if v is not None]
        if not vals: continue
        nums = [float(v) for v in r if isinstance(v, (int, float))]
        if any(t0 - 0.2 <= n <= t1 + 0.2 for n in nums):
            print("  " + " | ".join("" if v is None else str(v) for v in r))
