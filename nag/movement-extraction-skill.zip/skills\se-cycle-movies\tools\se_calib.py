"""se_calib.py -- stage 1 of movie -> workbook.  Measures the geometry of an SE-cycle movie.

Nothing about any particular movie is hard-coded.  Everything below is measured from the frames:

  * the array panel, from its black border;
  * the data lattice (origin + pitch), from the EMPTY-SITE RINGS only -- a ring is drawn at every
    data site and nowhere else, so it is the one feature that cannot be confused with a staging
    column half a pitch off the lattice;
  * the species palette, from the interior colour of the filled markers, with each solid colour
    paired to its faded (readout / reservoir-stock) variant;
  * which frames are gate frames, from the panel's background tint.

Writes a JSON calibration used by every later stage.  Read the report it prints: if the lattice
extent or the species count is wrong, everything downstream is wrong in a way no later check can
see.
"""
import argparse, collections, glob, json, os, sys
import numpy as np
from PIL import Image
from scipy import ndimage


# ---------------------------------------------------------------- helpers
def frame_paths(d):
    p = sorted(glob.glob(os.path.join(d, "*.png")))
    if not p:
        sys.exit("no .png frames in %s" % d)
    return p


def load(p):
    return np.asarray(Image.open(p).convert("RGB")).astype(np.int16)


def modal_colour(a, step=3):
    """The most common exact colour in a (subsampled) region -- these are flat-colour renders,
    so the background is always the mode by a wide margin."""
    s = a[::step, ::step].reshape(-1, 3)
    key = (s[:, 0].astype(np.int32) << 16) | (s[:, 1].astype(np.int32) << 8) | s[:, 2]
    v, n = np.unique(key, return_counts=True)
    k = int(v[n.argmax()])
    return np.array([(k >> 16) & 255, (k >> 8) & 255, k & 255])


def comb_fit(vals, lo, hi, coarse=0.02, fine=0.0005):
    """Fit a 1-D comb to a set of coordinates by maximising |sum exp(2*pi*i*v/p)|.

    Peak centroids of touching markers are unusable for this; ring centroids are clean.  The
    harmonic fit uses every point at once and so tolerates a missing site anywhere.
    Returns (pitch, phase) where a comb tooth sits at v = phase + k*pitch.
    """
    v = np.asarray(vals, float)

    def score(p):
        z = np.exp(2j * np.pi * v / p).sum()
        return abs(z), np.angle(z)

    best = None
    p = lo
    while p <= hi:
        s, _ = score(p)
        if best is None or s > best[0]:
            best = (s, p)
        p += coarse
    p0 = best[1]
    best = None
    p = p0 - 2 * coarse
    while p <= p0 + 2 * coarse:
        s, _ = score(p)
        if best is None or s > best[0]:
            best = (s, p)
        p += fine
    pitch = best[1]
    _, ang = score(pitch)
    phase = ((ang / (2 * np.pi)) * pitch) % pitch
    return pitch, phase


# ---------------------------------------------------------------- panel
def find_panel(a):
    dark = a.max(axis=2) < 120
    H, W = dark.shape
    cols = np.nonzero(dark.sum(axis=0) > 0.45 * H)[0]
    if len(cols) < 2:
        sys.exit("could not find the panel's vertical borders")
    x0, x1 = int(cols.min()), int(cols.max())
    band = dark[:, x0:x1 + 1]
    w = x1 - x0 + 1
    rows = np.nonzero(band.sum(axis=1) > 0.8 * w)[0]
    if len(rows) < 2:
        sys.exit("could not find the panel's horizontal borders")
    return x0, x1, int(rows.min()), int(rows.max())


# ---------------------------------------------------------------- components
def components(a, bg, x0, x1, y0, y1, thr=22, minpx=12, maxpx=4000):
    """Every blob inside the panel that differs from the background, with its median colour and a
    'holeness' flag that tells a hollow ring (an empty site) from a filled marker (an atom)."""
    sub = a[y0 + 3:y1 - 2, x0 + 3:x1 - 2]
    d = np.sqrt(((sub - bg) ** 2).sum(axis=2))
    m = d > thr
    lab, n = ndimage.label(m)
    if n == 0:
        return []
    objs = ndimage.find_objects(lab)
    out = []
    for i in range(n):
        sl = objs[i]
        piece = (lab[sl] == i + 1)
        area = int(piece.sum())
        if area < minpx or area > maxpx:
            continue
        filled = ndimage.binary_fill_holes(piece)
        holeness = filled.sum() / float(area)
        px = sub[sl][piece]
        med = np.median(px, axis=0)
        cy, cx = ndimage.center_of_mass(filled)
        out.append(dict(
            x=float(cx + sl[1].start + x0 + 3), y=float(cy + sl[0].start + y0 + 3),
            area=area, holeness=float(holeness), colour=[float(v) for v in med],
            h=int(sl[0].stop - sl[0].start), w=int(sl[1].stop - sl[1].start)))
    return out


def cluster_colours(cols, tol=42):
    """Greedy colour clustering, largest population first."""
    cols = np.asarray(cols, float)
    used = np.zeros(len(cols), bool)
    out = []
    while True:
        idx = np.nonzero(~used)[0]
        if len(idx) == 0:
            break
        # seed on the densest remaining point
        d = np.sqrt(((cols[idx][:, None, :] - cols[idx][None, :, :]) ** 2).sum(axis=2))
        cnt = (d < tol).sum(axis=1)
        seed = idx[int(cnt.argmax())]
        near = idx[np.sqrt(((cols[idx] - cols[seed]) ** 2).sum(axis=1)) < tol]
        if len(near) == 0:
            break
        out.append((np.median(cols[near], axis=0), len(near)))
        used[near] = True
    out.sort(key=lambda t: -t[1])
    return out


def chroma(c):
    return float(max(c) - min(c))


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", required=True, help="directory of p_%%03d.png frames")
    ap.add_argument("--out", required=True, help="calibration .json to write")
    ap.add_argument("--cycle-ms", type=float, default=None,
                    help="the total cycle time printed in the movie header (e.g. 11.74). "
                         "Without it, times are written in frame units.")
    ap.add_argument("--samples", type=int, default=40, help="frames to sample for palette/lattice")
    ap.add_argument("--species-names", default=None,
                    help="comma-separated override, in top-to-bottom label order")
    args = ap.parse_args()

    paths = frame_paths(args.frames)
    nfr = len(paths)
    a0 = load(paths[0])
    H, W = a0.shape[:2]
    x0, x1, y0, y1 = find_panel(a0)
    print("frames            : %d  (%d x %d)" % (nfr, W, H))
    print("panel             : x %d..%d   y %d..%d" % (x0, x1, y0, y1))

    # ---- background per frame -> gate frames
    bgs = np.array([modal_colour(load(p)[y0 + 3:y1 - 2, x0 + 3:x1 - 2], 4) for p in paths])
    uniq = cluster_colours(bgs, tol=20)
    plain = uniq[0][0]                                     # the commonest background is the plain one
    dist = np.sqrt(((bgs - plain) ** 2).sum(axis=1))
    gate = dist > 18
    print("background        : plain rgb(%d,%d,%d)" % tuple(int(v) for v in plain))
    if gate.any():
        tint = np.median(bgs[gate], axis=0)
        print("gate tint         : rgb(%d,%d,%d) on %d frames" % (*(int(v) for v in tint), gate.sum()))
    else:
        print("gate tint         : none found")

    # ---- sample frames for geometry and palette
    pick = np.unique(np.linspace(0, nfr - 1, min(args.samples, nfr)).astype(int))
    rings, marks = [], []
    for f in pick:
        a = load(paths[f])
        for c in components(a, bgs[f], x0, x1, y0, y1):
            c["frame"] = int(f)
            (rings if c["holeness"] > 1.22 else marks).append(c)
    print("sampled %d frames : %d ring blobs, %d filled blobs" % (len(pick), len(rings), len(marks)))
    if len(rings) < 20:
        sys.exit("too few empty-site rings found -- cannot fit the lattice")

    # ---- lattice from the rings only
    ring_area = np.median([r["area"] for r in rings])
    rings = [r for r in rings if 0.78 * ring_area < r["area"] < 1.30 * ring_area and r["holeness"] > 1.5]
    rx = np.array([r["x"] for r in rings])
    ry = np.array([r["y"] for r in rings])
    span = min(x1 - x0, y1 - y0)
    px, phx = comb_fit(rx, 6.0, span / 3.0)
    py, phy = comb_fit(ry, 6.0, span / 3.0)
    # index 1 = the first tooth at or after the leftmost / topmost ring
    ox = phx + np.floor((rx.min() - phx) / px + 0.5) * px
    oy = phy + np.floor((ry.min() - phy) / py + 0.5) * py
    ci = np.round((rx - ox) / px).astype(int) + 1
    ri = np.round((ry - oy) / py).astype(int) + 1
    resid = max(np.abs((rx - ox) / px - (ci - 1)).max(), np.abs((ry - oy) / py - (ri - 1)).max())
    print("lattice           : origin (%.2f, %.2f)  pitch %.3f x %.3f  worst ring residual %.3f site"
          % (ox, oy, px, py, resid))
    print("data extent       : cols %d..%d   rows %d..%d" % (ci.min(), ci.max(), ri.min(), ri.max()))
    if resid > 0.18:
        print("!! ring centres do not sit on one comb -- check the panel and the frame choice")

    # ---- palette, from the colour AT each lattice site centre
    # Not from whole blobs: a marker is a filled shape inside a differently-coloured outline whose
    # colour changes during the cycle, and the two have comparable pixel counts, so a blob's median
    # colour flips between fill and outline and one species turns into two.  The centre pixel of a
    # trap can only ever be a fill colour or the background.
    # Sampled at each FILLED BLOB's own centroid, not at the lattice site centres.
    #
    # Site centres were the obvious choice and they are subtly wrong: these movies do not draw a
    # marker on the trap it occupies (c540 is 2.5 px left and 3 px down), and that offset is a fixed
    # number of PIXELS while the marker stays a fixed fraction of the pitch.  On a coarse lattice it
    # is harmless; on c150, whose pitch is 57 px against c540's 34, the site centre lands on the
    # marker's edge, the flatness test throws the sample away, and 98.7% of samples come back as
    # bare background.  c150 then reported TWO species where the movie plainly shows four, and the
    # error is silent -- there is nothing in the output to say a species is missing.
    #
    # A filled blob's centroid is the marker's own centre by construction, whatever the offset, and
    # the centre of a marker can only ever be its fill colour.  Sampling there keeps the property
    # that made site centres attractive (never the outline, so a species cannot split in two) and
    # drops the dependence on the pitch.
    csite = []
    by_frame = collections.defaultdict(list)
    for c in marks:
        by_frame[c["frame"]].append(c)
    for f, cs in by_frame.items():
        a = load(paths[f])
        for c in cs:
            sx, sy = int(round(c["x"])), int(round(c["y"]))
            if not (x0 + 6 < sx < x1 - 6 and y0 + 6 < sy < y1 - 6):
                continue
            patch = a[sy - 2:sy + 3, sx - 2:sx + 3].reshape(-1, 3)
            med = np.median(patch, axis=0)
            # a flat 5x5 patch is the inside of a filled marker.  Anything that varies across the
            # patch is an edge -- two markers merged mid-flight, or an outline -- and must not
            # become a "species".
            if np.sqrt(((patch - med) ** 2).sum(axis=1)).max() > 26:
                continue
            csite.append(med)
    # the background still has to be in the sample, or it cannot be recognised as the background
    for f in pick:
        a = load(paths[f])
        for cc in range(int(ci.min()), int(ci.max()) + 1):
            for rr in range(int(ri.min()), int(ri.max()) + 1):
                sx = int(round(ox + (cc - 1) * px)); sy = int(round(oy + (rr - 1) * py))
                if not (x0 + 6 < sx < x1 - 6 and y0 + 6 < sy < y1 - 6):
                    continue
                patch = a[sy - 2:sy + 3, sx - 2:sx + 3].reshape(-1, 3)
                med = np.median(patch, axis=0)
                if np.sqrt(((patch - med) ** 2).sum(axis=1)).max() > 26:
                    continue
                csite.append(med)
    # cluster_colours is O(n^2) in memory; a few thousand samples locate the modes just as well as
    # thirty thousand, and c540 produces 29308 (19 GiB if clustered whole).  Subsample evenly so
    # the class proportions -- which the 0.4% cut below depends on -- are preserved.
    csite_all = csite
    if len(csite) > 6000:
        step = int(np.ceil(len(csite) / 6000.0))
        csite = csite[::step]
    clus = cluster_colours(csite, tol=40)
    clus = [(c, n) for c, n in clus if n >= 0.004 * len(csite)]
    print("site-centre colours (%d samples):" % len(csite))
    bgset = [np.asarray(plain, float)] + [np.asarray(b, float) for b in np.unique(bgs, axis=0)]
    solids = []
    for c, n in clus:
        isbg = any(np.sqrt(((np.asarray(c) - b) ** 2).sum()) < 26 for b in bgset)
        print("   rgb(%3d,%3d,%3d)  n %6d  %5.1f%%   %s"
              % (*(int(v) for v in c), n, 100.0 * n / len(csite), "background" if isbg else "SPECIES"))
        if not isbg:
            solids.append((np.asarray(c, float), n))
    solids.sort(key=lambda t: -t[1])

    def fade_of(c):
        return np.asarray(c, float) + (255 - np.asarray(c, float)) * 0.55

    # A SPECIES' OWN FADED FORM IS NOT ANOTHER SPECIES.
    # A block being read out, and reservoir stock waiting to be loaded, are drawn desaturated -- the
    # fill blended 55% into white.  That is a flat colour at the centre of a real marker, so it
    # clusters exactly like a fill, and on c150 (where a readout is on screen for a long stretch)
    # the pale green and pale blue came back as two extra species, six in all where the movie has
    # four.  Downstream nothing recovers from that: the extra names get their own seed rows, and
    # every atom that fades mid-cycle looks like one species vanishing and another appearing.
    # Anything within a few RGB of a stronger cluster's faded form is that cluster.
    keep, dropped = [], []
    for c, n in solids:
        parent = None
        for c2, n2 in solids:
            if n2 <= n:
                continue
            if np.sqrt(((c - fade_of(c2)) ** 2).sum()) < 26:
                parent = c2
                break
        if parent is None:
            keep.append((c, n))
        else:
            dropped.append((c, parent))
    for c, parent in dropped:
        print("   rgb(%3d,%3d,%3d) is the faded form of rgb(%3d,%3d,%3d) -- merged, not a species"
              % (*(int(v) for v in c), *(int(v) for v in parent)))
    solids = keep

    # a faded marker is the solid colour blended 55% into white; it may or may not ever rest on a
    # site, so look for it in the pixels rather than at site centres
    fade_seen = []
    for c, _ in solids:
        want = fade_of(c)
        hits = 0
        for f in pick[::4]:
            a = load(paths[f])[y0 + 3:y1 - 2, x0 + 3:x1 - 2]
            hits += int((np.sqrt(((a - want) ** 2).sum(axis=2)) < 22).sum())
        fade_seen.append(hits > 400)

    # marker area per species, from its own colour mask, and the constant offset between a marker's
    # centroid and its trap centre.  These movies do not draw the marker exactly on the ring it
    # sits in -- c540 is about 2.5 px left and 3 px down -- and an uncorrected 0.09-site bias is
    # enough to make every fractional position read as "in flight".
    areas, offx, offy = [], [], []
    for c, _ in solids:
        aa, ex, ey = [], [], []
        for f in pick[:8]:
            a = load(paths[f])[y0 + 3:y1 - 2, x0 + 3:x1 - 2]
            m = np.sqrt(((a - c) ** 2).sum(axis=2)) < 40
            lab, n = ndimage.label(m)
            if not n:
                continue
            sz = ndimage.sum(m, lab, range(1, n + 1))
            keep = [i + 1 for i in range(n) if sz[i] > 20]
            aa.extend([sz[i - 1] for i in keep])
            if not keep:
                continue
            for cy, cx in ndimage.center_of_mass(m, lab, keep):
                fx = (cx + x0 + 3 - ox) / px
                fy = (cy + y0 + 3 - oy) / py
                ex.append(fx - round(fx)); ey.append(fy - round(fy))
        areas.append(float(np.median(aa)) if aa else 0.0)
        if ex:
            mx, my = np.median(ex), np.median(ey)
            ex = [v for v in ex if abs(v - mx) < 0.10]; ey = [v for v in ey if abs(v - my) < 0.10]
            offx.append(np.median(ex)); offy.append(np.median(ey))
    moff = [float(np.median(offx)) if offx else 0.0, float(np.median(offy)) if offy else 0.0]
    solids = [(c, n, a) for (c, n), a in zip(solids, areas)]
    print("species colours   : %d" % len(solids))
    print("marker offset     : %+.4f, %+.4f site (subtracted from every centroid)" % tuple(moff))

    # ---- name the species from the coloured row labels drawn to the right of the panel
    names = None
    if args.species_names:
        names = [s.strip() for s in args.species_names.split(",")]
    else:
        lab_y = []
        a = load(paths[0])
        right = a[:, x1 + 6:]
        # Each species is named by a coloured row label to the left of the H_X / H_Z tables.  The
        # label is small anti-aliased text, so it needs a wide colour tolerance; the table contents
        # are also drawn in these colours, but always further right, so the LEFTMOST blob is the
        # label.  Top-to-bottom order across the two tables is X0, X1, Z0, Z1.
        for c, _, _ in solids:
            d = np.sqrt(((right - np.asarray(c)) ** 2).sum(axis=2))
            m = d < 95
            lab, n = ndimage.label(m)
            if n == 0:
                lab_y.append(1e9); continue
            objs = ndimage.find_objects(lab)
            sizes = ndimage.sum(m, lab, range(1, n + 1))
            cand = [(objs[i][1].start, objs[i][0].start) for i in range(n) if sizes[i] >= 15]
            lab_y.append(min(cand)[1] if cand else 1e9)
        if len(set(lab_y)) == len(lab_y) and all(v < 1e8 for v in lab_y):
            order = np.argsort(lab_y)
            default = ["X0", "X1", "Z0", "Z1", "S4", "S5"]
            names = [None] * len(solids)
            for rank, i in enumerate(order):
                names[i] = default[rank] if rank < len(default) else "S%d" % rank
            print("species naming    : by label order top->bottom on the right-hand tables")
        else:
            names = ["S%d" % i for i in range(len(solids))]
            print("!! could not find the coloured labels; species named S0.. -- pass --species-names")

    species = []
    for (c, n, ar), nm, fs in zip(solids, names, fade_seen):
        species.append(dict(name=nm, solid=[float(v) for v in c],
                            faded=[float(v) for v in fade_of(c)],
                            faded_seen=bool(fs), marker_area=ar))
        print("   %-4s solid rgb(%3d,%3d,%3d)  faded rgb(%3d,%3d,%3d)  marker area %.0f px%s"
              % (nm, *(int(v) for v in c), *(int(v) for v in fade_of(c)), ar,
                 "" if fs else "   (no faded markers found in the sampled frames)"))

    # ---- how far a fill colour drifts frame to frame.
    # h.264 subsamples chroma, so a saturated fill next to a strong edge moves by as much as 50 in
    # RGB between frames -- c540's green reads (0,130,0) on a plain frame and (46,129,15) on a gate
    # frame.  The extractor's colour tolerance has to cover that, which means marker outlines get
    # inside it too; they are rejected on SHAPE instead (a hollow ring is not a marker, and a blob
    # must carry its claimed colour at its own centre).  Nothing to record here but the check.
    drift = 0.0
    for c, _, _ in solids:
        for f in pick[::4]:
            a = load(paths[f])[y0 + 3:y1 - 2, x0 + 3:x1 - 2].astype(float)
            m = np.sqrt(((a - c) ** 2).sum(axis=2)) < 78
            if m.sum() > 200:
                lab, n = ndimage.label(m)
                sz = ndimage.sum(m, lab, range(1, n + 1))
                big = (np.argsort(-sz)[:8]) + 1
                for b in big:
                    med = np.median(a[lab == b], axis=0)
                    drift = max(drift, float(np.sqrt(((med - c) ** 2).sum())))
    print("fill colour drift : up to %.0f RGB across frames" % drift)

    # ---- visible window: which integer indices have their centre inside the panel
    def rng(o, p, lo, hi):
        i = np.arange(-40, 200)
        c = o + (i - 1) * p
        ok = (c >= lo + 2) & (c <= hi - 2)
        return int(i[ok].min()), int(i[ok].max())
    vc = rng(ox, px, x0, x1)
    vr = rng(oy, py, y0, y1)
    print("visible window    : cols %d..%d   rows %d..%d" % (vc[0], vc[1], vr[0], vr[1]))

    cyc = args.cycle_ms
    dt = (cyc / nfr) if cyc else 1.0
    print("timing            : %s" % ("cycle %.4f ms, dt %.9f ms" % (cyc, dt) if cyc
                                      else "no --cycle-ms given; times will be in FRAMES"))

    calib = dict(
        frames_dir=os.path.abspath(args.frames), n_frames=nfr, image_w=W, image_h=H,
        panel=[x0, x1, y0, y1],
        origin_x=float(ox), pitch_x=float(px), origin_y=float(oy), pitch_y=float(py),
        data_cols=int(ci.max()), data_rows=int(ri.max()),
        data_col_min=int(ci.min()), data_row_min=int(ri.min()),
        visible_col=[vc[0], vc[1]], visible_row=[vr[0], vr[1]],
        ring_area=float(ring_area), marker_offset=moff, colour_drift=drift,
        # every (col,row) seen carrying an empty-site ring.  A site in the data extent that never
        # shows one holds no data qubit -- that is how the parking zone is found.
        ring_sites=sorted(set("%d,%d" % (c, r) for c, r in zip(ci.tolist(), ri.tolist()))),
        background=[float(v) for v in plain],
        background_per_frame=[[float(v) for v in b] for b in bgs],
        gate_frames=[int(i) for i in np.nonzero(gate)[0]],
        species=species, cycle_ms=cyc, dt_ms=float(dt),
        time_units="ms" if cyc else "frames")
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(calib, fh, indent=1)
    print("wrote %s" % args.out)


if __name__ == "__main__":
    main()
