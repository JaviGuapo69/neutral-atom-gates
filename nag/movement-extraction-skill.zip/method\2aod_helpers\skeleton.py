"""The movie's skeleton: where every block sits, interval by interval.

Diagnostic only -- it writes nothing the solver reads.  For each pulse-free interval it
prints, per species, the SOLID occupancy (cols x rows, rounded to tones) on the interval's
first and last settled frame, and the same for the FADED track, so a readout (solid
collapses, faded jumps), a load (faded turns solid) and a relocation are all visible in one
table.  This is the reading step 2b of `handmade correction method.md` asks for, done once
up front instead of interval by interval.

Usage:  python skeleton.py <run dir> [--faded]
"""
import argparse, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SB = os.path.abspath(os.path.join(HERE, "..", ".claude", "skills", "se-cycle-blocks", "tools"))
sys.path.insert(0, SB)
import sb_read  # noqa: E402


def runs_of(gates, nf):
    """[(a, b)] of the gate RUNS, and the pulse-free intervals between them."""
    gs = sorted(gates)
    runs, i = [], 0
    while i < len(gs):
        j = i
        while j + 1 < len(gs) and gs[j + 1] == gs[j] + 1:
            j += 1
        runs.append((gs[i], gs[j]))
        i = j + 1
    ivs = []
    for k in range(len(runs) - 1):
        a, b = runs[k][1] + 1, runs[k + 1][0] - 1
        if a <= b:
            ivs.append((a, b))
    return runs, ivs


def occ(M, sp, faded, f, win):
    c = M.faded[sp] if faded else M.fill[sp]
    return M.peaks(c, win, f, 0), M.peaks(c, win, f, 1)


def fmt(v):
    if not len(v):
        return "-"
    r = [round(x, 1) for x in v]
    ints = [int(round(x)) for x in v]
    if all(abs(a - b) < 0.12 for a, b in zip(r, ints)):
        # contiguous run -> a:b
        if len(ints) > 1 and ints == list(range(ints[0], ints[0] + len(ints))):
            return "%d:%d" % (ints[0], ints[-1])
        return ",".join(str(i) for i in ints)
    return " ".join("%.2f" % x for x in r)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--faded", action="store_true")
    a = ap.parse_args()

    K = json.load(open(os.path.join(a.run, "calib.json")))
    M = sb_read.Movie(os.path.join(a.run, "calib.json"))
    nf = K["n_frames"]
    runs, ivs = runs_of(K["gate_frames"], nf)
    vc, vr = K["visible_col"], K["visible_row"]
    win = (vc[0] - 0.6, vc[1] + 0.6, vr[0] - 0.6, vr[1] + 0.6)
    names = [s["name"] for s in K["species"]]

    print("%d gate runs, %d pulse-free intervals" % (len(runs), len(ivs)))
    print("gate runs: " + " ".join("%d-%d" % r for r in runs))
    print()
    for k, (a0, b0) in enumerate(ivs):
        print("=== interval %2d   f%03d..f%03d   (%d frames)" % (k, a0, b0, b0 - a0 + 1))
        for sp in names:
            for f, tag in ((a0, "first"), (b0, "last "))[: 2 if b0 > a0 else 1]:
                c, r = occ(M, sp, False, f, win)
                line = "   %-3s %s f%03d  cols %-14s rows %-14s" % (sp, tag, f, fmt(c), fmt(r))
                if a.faded:
                    fc, fr = occ(M, sp, True, f, win)
                    if len(fc):
                        line += "  | faded cols %-12s rows %s" % (fmt(fc), fmt(fr))
                print(line)
        print()


if __name__ == "__main__":
    main()
