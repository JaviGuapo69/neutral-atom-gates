"""se_calibtxt.py -- bridge between se_calib.py's JSON and render.ps1.

Two small jobs, both needed to compare a render against the movie it came from:

  --out-txt   the ini-style calibration `render.ps1 -MatchCalib` reads, so the render is drawn on
              the MOVIE's geometry and the two can be laid side by side frame for frame.

  --out-json  a calibration for running se_extract.py over the RENDER's frames.  It is the movie's
              geometry with `marker_offset` ZEROED and the render's palette substituted, because
              those are the two things that genuinely differ:

                * the movie draws a marker a couple of pixels off the trap it occupies (c540:
                  -0.076, +0.087 site) and se_calib measures that so it can be subtracted; render.ps1
                  draws markers exactly on the trap, so subtracting the movie's offset from the
                  render would introduce the very bias it was measured to remove.
                * render.ps1 assigns colours from its own fixed palette in species order, which is
                  not the movie's palette.  Extracting the render with the movie's colours finds
                  nothing at all.

Everything else -- panel, origin, pitch, visible window -- is shared, which is the whole point.
"""
import argparse, json, os, sys

# render.ps1's palette, in species order, and its fade rule.  Kept in step with the $PALETTE array
# and the 0.55 blend-to-white in that script.
RENDER_PALETTE = [(231, 122, 163), (236, 160, 0), (80, 121, 186), (0, 130, 0),
                  (150, 80, 190), (0, 150, 150)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True, help="se_calib.py JSON for the MOVIE")
    ap.add_argument("--out-txt", default=None, help="ini for render.ps1 -MatchCalib")
    ap.add_argument("--out-json", default=None, help="JSON for extracting the RENDER's frames")
    ap.add_argument("--render-frames", default=None, help="frames dir to record in --out-json")
    ap.add_argument("--tone-divisor", type=int, default=1,
                    help="the divisor the WORKBOOK counts in (se_moves.py prints it)")
    ap.add_argument("--species", default=None,
                    help="comma-separated species order of the workbook; defaults to the movie's")
    args = ap.parse_args()

    K = json.load(open(args.calib, encoding="utf-8"))
    x0, x1, y0, y1 = K["panel"]

    if args.out_txt:
        lines = [
            "image_w=%d" % K["image_w"], "image_h=%d" % K["image_h"],
            "panel_x0=%d" % x0, "panel_x1=%d" % x1, "panel_y0=%d" % y0, "panel_y1=%d" % y1,
            "origin_x=%.3f" % K["origin_x"], "pitch_x=%.4f" % K["pitch_x"],
            "origin_y=%.3f" % K["origin_y"], "pitch_y=%.4f" % K["pitch_y"],
            "tone_divisor=%d" % args.tone_divisor,
            "data_cols=%d" % K["data_cols"], "data_rows=%d" % K["data_rows"],
            "lattice_cols=%d" % ((K["data_cols"] - 1) * args.tone_divisor + 1),
            "lattice_rows=%d" % ((K["data_rows"] - 1) * args.tone_divisor + 1),
            "visible_col_min=%d" % ((K["visible_col"][0] - 1) * args.tone_divisor + 1),
            "visible_col_max=%d" % ((K["visible_col"][1] - 1) * args.tone_divisor + 1),
            "visible_row_min=%d" % ((K["visible_row"][0] - 1) * args.tone_divisor + 1),
            "visible_row_max=%d" % ((K["visible_row"][1] - 1) * args.tone_divisor + 1),
        ]
        with open(args.out_txt, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("\n".join(lines) + "\n")
        print("wrote %s" % args.out_txt)

    if args.out_json:
        R = dict(K)
        R["marker_offset"] = [0.0, 0.0]
        if args.render_frames:
            R["frames_dir"] = os.path.abspath(args.render_frames)
        names = ([s.strip() for s in args.species.split(",")] if args.species
                 else [s["name"] for s in K["species"]])
        # render.ps1 sorts species alphabetically (Sort-Object -Unique) and assigns the palette in
        # that order, so the render's colours follow the SORTED names, not the movie's label order.
        order = sorted(names)
        sp = []
        for nm in names:
            c = RENDER_PALETTE[order.index(nm) % len(RENDER_PALETTE)]
            solid = [float(v) for v in c]
            sp.append(dict(name=nm, solid=solid,
                           faded=[v + (255.0 - v) * 0.55 for v in solid],
                           faded_seen=True, marker_area=K["species"][0].get("marker_area", 140)))
        R["species"] = sp
        # render.ps1 paints a plain white panel and tints it for a gate; the movie's per-frame
        # backgrounds do not apply.
        R["background"] = [255.0, 255.0, 255.0]
        R.pop("background_per_frame", None)
        with open(args.out_json, "w", encoding="utf-8") as fh:
            json.dump(R, fh, indent=1)
        print("wrote %s  (species %s)" % (args.out_json,
                                          ", ".join("%s rgb%s" % (s["name"], tuple(int(v) for v in s["solid"]))
                                                    for s in sp)))


if __name__ == "__main__":
    main()
