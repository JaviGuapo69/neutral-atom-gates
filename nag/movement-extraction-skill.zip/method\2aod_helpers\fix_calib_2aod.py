"""Correct a 2-AOD movie's calib.json species table.

WHY THIS EXISTS (2026-09-18, the 2-AOD session).  `se_calib.py` merges a species' faded
form into its solid on the rule `faded = solid + (255 - solid) * 0.55` -- the 4-AOD movies
draw stock blended 55% into white.  THE 2-AOD MOVIES BLEND 71% INTO WHITE (measured
alpha = 0.288 on all four species of c150_2aod), so the merge misses, every faded form
comes back as an extra SPECIES, and the top-to-bottom naming heuristic is then reading a
six-entry list against four labels and mislabels every one of them.

Nothing in the skill is changed for this: `calib.json` is an input file, and the fix is to
write the MEASURED colours into it.  This script

  * keeps the four species the movie's own legend names -- Z0 blue, Z1 green, X0 pink,
    X1 orange (identical RGB to the 4-AOD movies; the legend is the authority, and it is
    cropped to legend.png beside the calib so the reading can be checked);
  * sets `faded` to the measured blend, `faded_seen` from the pixels;
  * re-measures `marker_area` and `marker_offset` over those four colours only (se_calib's
    medians were polluted by the two phantom species);
  * leaves the lattice, panel, gate frames and timing exactly as se_calib measured them.

Usage:  python fix_calib_2aod.py <run dir>   [--alpha 0.288]
"""
import argparse, json, os
import numpy as np
from PIL import Image
from scipy import ndimage

# The legend, top to bottom: data, Z0, Z1, X0, X1.  Solid RGB read off the frames.
LEGEND = [("X1", (236.0, 159.0, 1.0)),
          ("X0", (232.0, 121.0, 163.0)),
          ("Z1", (0.0, 129.0, 1.0)),
          ("Z0", (42.0, 118.0, 213.0))]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--alpha", type=float, default=0.288,
                    help="faded = 255 - alpha * (255 - solid); measured 0.288 on c150_2aod")
    ap.add_argument("--samples", type=int, default=48)
    a = ap.parse_args()

    cpath = os.path.join(a.run, "calib.json")
    K = json.load(open(cpath))
    x0, x1, y0, y1 = K["panel"]
    ox, px, oy, py = K["origin_x"], K["pitch_x"], K["origin_y"], K["pitch_y"]
    nf = K["n_frames"]
    fd = K["frames_dir"]
    gates = set(K["gate_frames"])

    pick = [f for f in range(0, nf, max(1, nf // a.samples)) if f not in gates]

    def load(f):
        return np.asarray(Image.open(os.path.join(fd, "p_%03d.png" % f)).convert("RGB"),
                          dtype=float)[y0 + 3:y1 - 2, x0 + 3:x1 - 2]

    species, offx, offy = [], [], []
    for nm, s in LEGEND:
        s = np.asarray(s, float)
        faded = 255.0 - a.alpha * (255.0 - s)
        areas, ex, ey, fhits = [], [], [], 0
        for f in pick:
            im = load(f)
            m = np.sqrt(((im - s) ** 2).sum(axis=2)) < 40
            fhits += int((np.sqrt(((im - faded) ** 2).sum(axis=2)) < 22).sum())
            lab, n = ndimage.label(m)
            if not n:
                continue
            sz = ndimage.sum(m, lab, range(1, n + 1))
            keep = [i + 1 for i in range(n) if sz[i] > 20]
            if not keep:
                continue
            areas.extend([sz[i - 1] for i in keep])
            for cy, cx in ndimage.center_of_mass(m, lab, keep):
                fx = (cx + x0 + 3 - ox) / px
                fy = (cy + y0 + 3 - oy) / py
                ex.append(fx - round(fx)); ey.append(fy - round(fy))
        ar = float(np.median(areas)) if areas else 0.0
        if ex:
            mx, my = np.median(ex), np.median(ey)
            offx.extend([v for v in ex if abs(v - mx) < 0.10])
            offy.extend([v for v in ey if abs(v - my) < 0.10])
        species.append(dict(name=nm, solid=[float(v) for v in s],
                            faded=[float(v) for v in faded],
                            faded_seen=bool(fhits > 400), marker_area=ar))
        print("   %-3s solid rgb(%3d,%3d,%3d)  faded rgb(%3d,%3d,%3d)  area %5.0f px  "
              "faded px %6d %s" % (nm, *(int(v) for v in s), *(int(v) for v in faded),
                                   ar, fhits, "" if fhits > 400 else "(no stock seen)"))

    moff = [float(np.median(offx)) if offx else 0.0,
            float(np.median(offy)) if offy else 0.0]
    print("marker offset     : %+.4f, %+.4f site   (was %+.4f, %+.4f)"
          % (moff[0], moff[1], K["marker_offset"][0], K["marker_offset"][1]))

    if not os.path.exists(cpath + ".se_calib"):
        json.dump(K, open(cpath + ".se_calib", "w"), indent=1)
        print("kept se_calib's original as calib.json.se_calib")
    K["species"] = species
    K["marker_offset"] = moff
    K["faded_alpha_2aod"] = a.alpha
    json.dump(K, open(cpath, "w"), indent=1)
    print("wrote", cpath)


if __name__ == "__main__":
    main()
