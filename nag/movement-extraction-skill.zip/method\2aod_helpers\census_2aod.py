"""census_2aod.py -- the census check, re-based for a movie where blocks come and go.

`se_sim.census` asserts that the live population returns to the SEED count after every readout,
because in a 4-AOD movie all four blocks are on screen all the time.  A 2-AOD movie serialises
the cycle: c150_2aod draws one or two blocks solid at a time and the population is legitimately
30 or 60 where the seed is 120, so se_sim prints CENSUS FAILED for a book that is right.

This replaces the premise with a measurement: for every frame, the number of atoms the workbook
holds alive must equal 30 x (the number of species whose SOLID area the movie actually shows).
A readout that retired too few atoms, or a fresh block created too small, still fails it -- which
is what the original check is for.

Usage:  python census_2aod.py <run dir> <book.xlsx> [--block 30]
"""
import argparse, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, ".claude", "skills", "se-cycle-movies", "tools"))
sys.path.insert(0, os.path.join(ROOT, ".claude", "skills", "se-cycle-blocks", "tools"))
import se_sim  # noqa: E402
import sb_read  # noqa: E402

FLOOR = 300     # px: sb_events.FLOOR -- below this there is effectively nothing of that colour


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("book")
    ap.add_argument("--block", type=int, default=30, help="atoms per block")
    a = ap.parse_args()

    cal = os.path.join(a.run, "calib.json")
    M = sb_read.Movie(cal)
    K = json.load(open(cal))
    vc, vr = K["visible_col"], K["visible_row"]
    win = (vc[0] - 0.5, vc[1] + 0.5, vr[0] - 0.5, vr[1] + 0.5)
    names = [s["name"] for s in K["species"]]

    s = se_sim.from_workbook(os.path.join(a.run, a.book))
    bad, runs = [], []
    for f in range(s.n_frames):
        if f in M.gate:
            continue                       # the tint makes both masks meaningless
        t = f * s.dt
        # count the atoms the movie could show SOLID: alive and not yet fading (se_sim sets
        # fade = an unload row's t_start, dies = its t_finish, exactly as render.ps1 does)
        alive = sum(1 for at in s.atoms if at["born"] <= t < at["dies"] and t < at["fade"])
        on = [nm for nm in names if M.area(M.fill[nm], win, f) > FLOOR]
        want = a.block * len(on)
        if alive != want:
            bad.append((f, alive, want, on))
    print("%s: %d non-gate frames checked, %d disagree with the movie's own block count"
          % (a.book, s.n_frames - len(M.gate), len(bad)))
    # collapse into runs so the output is readable
    for f, alive, want, on in bad:
        if runs and runs[-1][1] == f - 1 and runs[-1][2] == alive and runs[-1][3] == want:
            runs[-1][1] = f
        else:
            runs.append([f, f, alive, want, on])
    for f0, f1, alive, want, on in runs:
        print("   f%03d-f%03d  workbook %3d alive, movie shows %d block(s) %s = %d"
              % (f0, f1, alive, len(on), ",".join(on), want))
    if not bad:
        print("   CENSUS CLEAN against the movie: every frame's live population is exactly the "
              "blocks the movie draws solid.")


if __name__ == "__main__":
    main()
