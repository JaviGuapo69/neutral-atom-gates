# SE-cycle movies and schedule workbooks: translating either way

**Version 3.** Version 2 covered only workbook → movie; part II of this document is that guide,
unchanged in substance, and part III is new.

This document defines one data model and two translations between the same two artifacts:

```
        m<code>SEmoves.xlsx  ──── part II: render ────►  se_cycle_<code>.mp4
        m<code>SEmoves.xlsx  ◄─── part III: transcribe ──  se_cycle_<code>.mp4
```

It contains **rules only** — no geometry, no timings, no coordinates. Everything specific to a
particular movie lives in the workbook, so the same rules apply to every SE-cycle movie.

You need only this document plus one of the two artifacts. If you have the workbook, part II tells
you how to produce the movie. If you have the movie, part III tells you how to produce the
workbook. Part IV is the acceptance test both directions are judged by, and it is the same test:
**render the workbook and compare against the movie at every frame where the movie holds a
configuration.**

---

## 0. Scope, and what "a movie of this format" means

Part III assumes the movie draws:

| | what part III relies on |
|---|---|
| **one array panel** | a rectangle with a dark border, containing the whole lattice; everything else on the canvas is annotation |
| **data sites** | a fixed grid of pale, near-neutral discs, one per lattice site, that never move |
| **atoms** | one filled marker per atom, one colour per species, centred on its trap |
| **trap rings** | each marker framed by a ring whose colour names the AOD carrying it |
| **fading** | an atom no longer part of the computation drawn at reduced saturation, in place, still moving |
| **a gate tint** | the panel background tinted while a global pulse fires |
| **a header line** | `t <now>/<total> ms · <phase> · <tokens>` on every frame |

The 4-AOD and 2-AOD `mitten_codes` movies all match. The `structured_mitten_codes` movies differ
in header format and page layout — the model in part I still holds, but part III's frame-parsing
steps need adapting before they will run on them.

Part III does **not** assume the number of species, the palette, the lattice size, the block
layout, the frame count or the cycle length. All of those are measured.

---

# Part I — the model

Both directions share this. If a statement here and a statement in part II or III disagree, this
part wins.

## I.1 A trap group is two frequency combs

Atoms are held in optical tweezers made by a **crossed pair of acousto-optic deflectors**. An AOD
carries a travelling acoustic wave that acts as a diffraction grating; the deflection angle is
proportional to the RF drive frequency. Drive it with a comb of N tones and you get N tweezers
along that axis.

Cross an x-AOD with a y-AOD and a trap appears at **every combination** of an x tone and a y tone.
So `x = 13:24, y = 19:27` is not 12 atoms, or 9, or 21. It is 12 × 9 = **108 traps**, the full
Cartesian product.

> **The rule that matters most:** a rectangle is `x-list × y-list`. Every pair. It can never
> describe an arbitrary set of sites — no holes, no L-shapes, no diagonals.

This cuts both ways. Rendering, it tells you how many atoms a row moves. Transcribing, it is the
constraint that makes the decomposition tractable at all: a configuration you observe on screen
must be a **union of products**, and that factorisation is nearly unique.

## I.1a The tone grid is not the data lattice

A tone is an RF frequency. Nothing ties it to where the data qubits are, and in these movies it is
**not** tied to them: blocks park in staging areas offset by exactly half a data pitch. In c150 the
ancilla blocks wait in half-pitch columns to the left of the array and the fresh batch waits in
half-pitch rows above it; c540 does the same in both of its reservoirs.

So the workbook counts in **tones**, not in data columns, and `Constants` declares the relation:

```
tone_divisor   2      two tone positions per data pitch
data_cols     12      data column k sits at tone 2*(k-1)+1, so odd tones carry data sites
lattice_cols  23      tone positions across, NOT data columns
```

`tone_divisor = 1` is the ordinary case and everything reduces to the data lattice. Tone lists stay
integers either way, so I.6's grammar and I.2's non-crossing rule are untouched.

> **This is the single assumption whose violation is hardest to notice.** An extractor that samples
> only at data-site centres reports an *empty frame* while thirty atoms sit plainly on screen half
> a pitch away. It does not error; it returns nothing, the schedule loses every move that starts or
> ends in a staging area, and the reconstruction diverges from the first readout onwards. Measure
> the tone grid (III.2) before you measure anything else.

## I.2 Tones cannot cross

Two tones at the same frequency would be the same trap, so within one comb the ordering of tones
is fixed for the whole motion. Tones may spread, compress and translate, but never pass through
one another. This is why a single solid block that has to turn inside out is written as two rows:
the halves exchange places, so they must be carried by two different AODs.

Transcribing, this is what removes the atom-correspondence problem. Two atoms of the same species
are indistinguishable on screen, so in principle a motion from configuration A to configuration B
admits many permutations. Non-crossing collapses them: **within one row, the k-th smallest start
tone is the k-th smallest finish tone.** Nothing else is possible. The only freedom left is how the
atoms divide into rows, and I.6 and III.5 deal with that.

## I.3 What a motion physically is

Chirping the tone frequencies from one set of values to another drags the traps, and the atoms in
them, across the array. A motion is therefore fully specified by the tone lists at the start, the
tone lists at the finish, and the two timestamps.

## I.4 Atoms, not slots

Version 1 of this guide tabulated, for every move, which species each slot carried. That cannot be
made to work. A slot is a trap rectangle, and a rectangle can straddle the boundary between two
species — during a shuffle a single comb routinely picks up some X0 and some X1 atoms at once. Any
table that assigns one species per slot must then mislabel the minority. In c540 this happens at
move 48, where one rectangle carries 6 Z0 and 3 Z1 per column.

Species is a property of the **atom**, and it never changes. So:

* the workbook seeds the atoms once, at t = 0;
* each schedule row moves whichever atoms are sitting on its start rectangle;
* every atom carries its own species along for the ride.

Nothing else is needed. There is no role table, no list of "parked" blocks, no inheritance, and no
way for a block to be drawn twice or to go missing — the atom count is conserved by construction.

## I.5 What a schedule row means

> The atoms resting on rectangle `(x_start × y_start)` at time `t_start` travel to rectangle
> `(x_finish × y_finish)`, arriving at `t_finish`.

That is the entire semantics. A row is a statement about atoms, not about a device.

Atoms that no row picks up simply stay where they are. A block that sits still for half the cycle
needs no rows at all.

**Rows may overlap in time.** Different AODs act independently, so rows may and do run
concurrently. Rows are therefore **not** in time order by position in the sheet, and must not be
walked sequentially. Sort by `t_start`, and evaluate every row that shares a `t_start` against the
state **before** that batch — never let one row's result feed the next row's pickup.

**Off-screen regions are ordinary positions.** Reservoirs are just coordinates outside the drawn
area. Draw only what falls inside the visible window the `Constants` sheet declares; clip the rest.
Some relocations are instantaneous: `t_start == t_finish` means the atoms are simply somewhere else
on the next frame.

## I.6 Tone-list grammar, and why the commas matter

```
tone_list := element ( "," element )*
element   := <int> ":" <int>        inclusive run, ascending
           | <int>                  single tone
```

`13:24` is 13,14,…,24 — twelve tones. Whitespace after commas is insignificant. Negative integers
are legal (`-8:0`).

`10:12, 13:15` is **not** a clumsy way of writing `10:15`. The comma marks two sub-runs that
translate by **different** amounts:

* the k-th element of the start list maps to the k-th element of the finish list;
* corresponding elements must contain the same number of tones;
* within an element, the j-th tone maps to the j-th tone — a rigid shift.

```
start  y = 10:12, 13:15          finish  y = 10:12, 16:18
       ^^^^^ stays                       ^^^^^ shifts +3
```

So the element boundaries carry information, and transcribing must reproduce them: **cut both tone
lists wherever the offset between corresponding tones changes.** A row whose every tone shifts by
the same amount is one element; a row that spreads or compresses has as many elements as it has
distinct shifts.

## I.7 The easing profile

```
s(u) = 10u³ − 15u⁴ + 6u⁵,     u = (t − t_start) / (t_finish − t_start)
position = start + (finish − start) · s(u)
```

If `t_finish == t_start` the move is instantaneous: use s = 1 for t ≥ t_start.

This was verified against a rendered movie by tracking block centroids through two long
translations: RMS error 0.021 lattice units, against 0.028 for cubic smoothstep and 0.086 for
linear. Do not substitute a different profile without re-measuring.

At every tabulated timestamp positions are exact integers; between them they are interpolated.
That single sentence is the hinge of the inverse direction — see III.4.

## I.8 Atoms are not conserved: they are measured and replaced

An ancilla species is measured partway through the cycle and a **fresh batch** takes its place. The
old atoms do not come back, so the population is not fixed — only the count of *active* ancillas
is. Each schedule row therefore carries an `event`:

| `event` | meaning |
|---|---|
| `move` (default) | the atoms on the start rectangle travel to the finish rectangle |
| `unload` | the same, but the atoms are **retired** at `t_finish` and never picked up again |
| `load` | **new** atoms of `species` appear on the finish rectangle at `t_start` |

An `unload` and its matching `load` usually share a timestamp, so for the duration of the transport
two batches of the same species are on screen at once. That is correct, and it is why check 5 in
part IV counts active atoms rather than all atoms.

## I.9 A retired block is carried away, not deleted

This is easy to get wrong and invisible to occupancy analysis. It has been got wrong twice.

A block being taken for measurement is **not** removed where it stands, and it does **not** travel
to a reservoir. It is translated bodily out of the array — in c540, nine rows straight down and off
the bottom edge — over several frames, exactly like any other motion. Give it a real destination
and a real duration; that is what the `unload` row's finish rectangle and `t_finish` are for.

While it is being carried the movie draws it **desaturated**, at roughly 45% of normal saturation,
so it reads as "no longer part of the computation". Reproducing the fade is optional — it is
styling — but reproducing the **motion** is not.

> **Warning for anyone measuring a movie.** Site-sampling extractors typically apply a saturation
> floor to reject background tints, and the faded markers fall below it. A block in transport is
> then absent from the extracted state entirely: it looks as though it vanished in one frame. It
> did not. Two separate transports in c540 were mis-modelled this way — as a teleport, and as a
> diagonal move to the side reservoir — and **neither error was detectable in the occupancy data**,
> because the atoms were missing from both the movie's extract and the reconstruction's. Both
> scored perfectly. They were caught by watching the video.
>
> Part III therefore treats `faded` as a first-class observation, not as noise. Any extractor you
> write must do the same.

Observed in c540 and worth knowing: the **fresh batch waiting in a reservoir is on screen from
frame 0, drawn faded**, and turns solid at the moment it is picked up. So a `load` is not an atom
appearing from nowhere — it is a state change at a rectangle you can already see. The workbook may
model it either way; the rendered result for the active atoms is identical.

---

# Part II — workbook → movie

## II.1 The workbook

Four sheets. Row 1 of each is a header.

**`Constants`** — `key`, `value`, `note`. Everything movie-specific: lattice size, block regions,
cycle length, frame count, `dt_ms`, the easing formula, and the visible window
(`visible_col_min/max`, `visible_row_min/max`). Read the geometry from here; never assume it.

**`Seed`** — `species`, `x_tones`, `y_tones`, `note`. One row per species, giving its atoms'
positions at t = 0 as a rectangle. Expand each as a product (I.1). The union over all rows is the
complete atom population at t = 0.

**`Schedule`** — `move`, `slot`, `event`, `species`, `t_start`, `t_finish`, `x_start`, `y_start`,
`x_finish`, `y_finish`, `note`. One row per motion, with the meaning of I.5. `event` is one of
`move` / `unload` / `load`; blank means `move`. `species` is used only by `load` rows, which is the
one place a species has to be named — every other row gets its species from the atoms it picks up.

`move` and `slot` are **provenance only**. They record which entry of some earlier transcription a
row came from and have no semantics. Do not group by them, do not inherit along them. Two
workbooks that number their rows differently but move the same atoms are the same workbook.

**`Gates`** — `move`, `t_start`, `t_finish`. The global Rydberg pulses. Nothing moves during a
gate; every ancilla is co-located with a data qubit and the CZ acts on each pair. Rendering them
is optional.

## II.2 The reconstruction algorithm

```
1.  Read Constants. Read Seed; create one atom per site of each species' rectangle.
2.  Read Schedule. For each row, build the tone maps:
        xmap[k-th start x tone] = k-th finish x tone      (element-wise, I.6)
        ymap likewise
3.  Sort rows by t_start. Group rows that share a t_start into a batch.
4.  Walk the batches in time order. For each batch:
       a. find, for every row, the atoms whose (x,y) is in (xmap keys × ymap keys),
          using positions as they are BEFORE the batch;
       b. check no atom was claimed by two rows;
       c. give each matched atom a motion: from its site, to (xmap[x], ymap[y]),
          over [t_start, t_finish].
5.  To draw frame n at t = n · dt_ms:
       for each atom, if it has a motion with t_start <= t <= t_finish, interpolate;
       otherwise it rests at its last position.
6.  Interpolate with the easing profile of I.7.
7.  Clip to the visible window. Draw.
```

## II.3 Drawing

Style is free. Only two things are required:

* **Geometry.** Map lattice `(col,row)` to pixels with a constant pitch, col 1 and row 1 at the
  top-left, y increasing downward. Draw the data sites as fixed markers; they never move. Some
  regions carry no data qubits — check `Constants`.
* **Clipping.** Draw nothing outside the visible window. A block in a reservoir is mostly
  off-screen and must be cut at the window edge, not squeezed inside it.

Colour, marker shape, background tint and frame styling are free choices; they are not part of the
specification. Distinguishing the species visually is useful but the particular colours and shapes
are arbitrary. Marking which atoms are in motion is likewise optional.

Note the asymmetry with part III: a renderer may choose any palette, but a **transcriber** must
read the palette the movie in front of it actually used. See III.2.

---

# Part III — movie → workbook

The output is a workbook that passes part IV. It will not be byte-identical to anyone else's
workbook for the same movie, and it is not supposed to be: the division of a batch into rows is
not unique (I.6, II.1), and `move`/`slot` carry no meaning. What must match is the position of
every atom at every timestamp.

## III.0 The shape of the problem

Three facts set the whole method.

1. **At every tabulated timestamp the atoms are on exact integer sites** (I.7). So the frames worth
   reading are the ones where every marker sits on a site. Everything between them is interpolation
   and carries no independent information.
2. **A configuration is a union of products** (I.1). So a frame that is on-lattice factorises, and
   the factorisation is what a schedule row is made of.
3. **Tones cannot cross** (I.2). So once you know which rectangle goes to which rectangle, the tone
   maps are forced.

What is left over is a search: which frames are the timestamps? Proposing an answer is cheap, and
**the test of a proposal is the forward direction run on it**. Transcription is therefore not a
measurement, it is a fit, and part IV is its loss function. Say so in your notes when you finish
one: what you have is the simplest schedule consistent with the movie, not the schedule that
generated it.

## III.1 Step 1 — read the header, and only then measure anything

Every frame prints its own time. In the c540-family movies the header reads

```
t 3.67/11.74 ms · phase 1 Z:D5 || X:D1-4 · global pulse
```

which gives you, free and exactly:

| from the header | into |
|---|---|
| the number after the slash | `Constants!cycle_ms` |
| `ffprobe -show_entries stream=nb_frames` | `Constants!frames` |
| the two together | `Constants!dt_ms = cycle_ms / frames` |
| the phase string changing | the phase boundaries, useful for sanity checks |
| tokens such as `global pulse` | the `Gates` rows |
| tokens such as `reset` | where to expect `unload` / `load` |

**Check it.** Read the header on three frames spread across the movie and confirm the printed time
equals `frame × dt_ms` to the printed precision. If it does not, the movie is not sampled uniformly
and nothing below applies.

Do not derive `dt_ms` by fitting motion durations. It is printed.

## III.2 Step 2 — calibrate the panel, the grid and the palette

Everything geometric must be measured, not assumed, or the guide is not movie-agnostic.

**The panel.** Find the long dark lines: the columns whose longest run of dark pixels spans most of
the image height are the left and right borders; then, searching only between them, the rows whose
longest dark run spans most of the panel width are the top and bottom. Restricting the row search
to the panel's own columns matters — the title text will otherwise be mistaken for the top border.

**The background.** The modal colour inside the panel. Define a *feature* pixel as one differing
from it by more than about 35 in any channel. Doing it relative to the background rather than
against white makes every later step immune to the Rydberg tint, and lets you calibrate on any
frame.

**The grid.** Project the feature mask onto each axis. Do **not** fit the peak centroids: adjacent
markers touch and their peaks merge. Instead fit the projection harmonically — the pitch `p` that
maximises `|Σ_x prof[x]·exp(−2πi·x/p)|` is the lattice period, and the phase of that sum is the
origin. Every mask pixel contributes, so a few merged peaks cost nothing. Scan `p` over ±20% of the
median peak spacing.

**Phase from the atoms, index from the discs.** Take the *phase* of that fit from a held frame's
full feature mask, which the filled markers dominate and which is therefore centred on the traps.
Take only the *index* — which grid line is data column 1 — from the disc mask. Fitting the grid to
the discs alone lands up to a tenth of a pitch out, because a disc is a ring and projects at its
two tangents rather than its centre; fitting the index to the markers alone puts column 1 on
whatever staging column happens to be leftmost, which is how c150 came out shifted by one column
with every later column wrong. Keep the disc mask's chroma limit tight (≈12): at 25 the
anti-aliased edge of a *faded* marker parked in a reservoir passes as a disc and invents a column.

**The tone divisor** (I.1a). Sample frames across the movie; for each species and axis, project the
marker mask, express each peak in data pitches and take its fractional part. Then look for
**persistence**, not popularity: a block parked off the lattice holds one offset for a run of
consecutive frames, while a block in flight sweeps every offset and holds none. Counting frames
alone does not separate them, because a long translation visits each offset once per lattice step
and there are many translations; counting raw peaks is worse still, since the on-lattice majority
outnumbers a real half-pitch park ten to one. Take the offsets held for at least three consecutive
samples, and the divisor is the smallest N putting every one of them within tolerance of some k/N.

**Lattice extent versus visible extent.** These differ, and the difference is `Constants`. Project
only the *weakly coloured* features — the data-site discs — and their extent is the lattice proper
(`lattice_cols`, `lattice_rows`). Project everything and the extent is what is ever drawn
(`visible_col_max`, `visible_row_max`): wider, because reservoir columns hold atoms but no data
sites. Confirm both against a picture of the frame before going on; an off-by-one here is silent.

**The palette.** One hue band per species. The bands are a property of the movie, so check them:
dump the occupancy of a held frame as an ASCII map and confirm it shows the blocks you can see in
the frame. Two collisions to expect, both real in this family:

* the **AOD ring shares a hue band with one species** (gold ring, gold X1) and is separated only by
  saturation — the ring reaching about 100–204 where the marker reaches 205+;
* a **faded marker's saturation overlaps a solid marker's anti-aliased edge**, so no threshold
  separates them. Erode: require a pixel's neighbours two pixels away in each direction to share
  its class. An edge is one or two pixels wide; a faded block is not.

A ring never covers a site centre, so site sampling is immune to the first collision even though
whole-panel pixel tracking is not.

## III.3 Step 3 — extract every frame twice over

Per frame, record two different things. You need both, and each is blind where the other sees.

**Site occupancy** — sample a small disc (about 0.13 of the pitch) at every site centre, over a
window generous enough to include the reservoirs, and take the majority class. Record the state as
`solid` or `faded`. This is exact when the atoms are on sites and blank when they are not.

**Whole-panel pixel statistics per species and state** — count, centroid and extent in fractional
lattice units, computed inside the panel only. This sees a block *between* sites, and it sees a
faded block leaving the array, which is exactly where occupancy goes blank.

Also record the gate flag: the mean colour of a small box of pure panel background, tinted while a
pulse fires.

> **Site occupancy cannot validate a move frame by frame.** A translating block registers on the
> lattice only at the frames where its displacement happens to land near an integer. Sampling site
> centres through a move gives a sequence like `108, 94, 0, 0, 0, 108, 0, 108`. Those zeros are
> atoms between sites, not missing atoms, and those 108s are not stops.

## III.4 Step 4 — find the waypoints

A frame where a species shows its **full complement on a clean union of rectangles** *and is at
rest* is a *candidate* timestamp. Most on-lattice frames are not timestamps: a rigid translation
passes through integer displacements on the way, and those frames look exactly like a stop.

**Both conditions are needed, and the second one matters more the finer the tone grid is.** Once
tone positions are half a data pitch apart, a block translating one tone per frame lands on a tone
*every single frame*; every frame becomes a candidate, and no eased interpolation between two
adjacent frames can explain the one between them, so nothing merges and one move is emitted as a
dozen. Rest is the physical notion actually wanted, and the pixel centroid measures it directly and
independently of the grid: a species is at rest on frame f when its centroid matches frame f−1 or
f+1. Frames 0 and n−1 are cycle boundaries and count as candidates regardless, or a move starting
on frame 1 leaves the seed with no waypoint at all.

Quote every pixel tolerance in **data pitches** and convert, never in tones. A tolerance in tones
silently halves the moment a movie turns out to have a half-pitch grid.

The discriminator is the easing profile itself:

> Take three consecutive candidates a, b, c. Build the rectangle pairing from configuration(a) to
> configuration(c), interpolate it with s(u) at u = (b−a)/(c−a), and compare against what frame b
> actually shows. **If one eased motion a → c already explains b, then b is a snapshot of that
> motion, not a waypoint. Drop it.** Repeat until nothing more can be dropped.

Four details make this work in practice:

* the true `t_start` and `t_finish` need not land on a frame, so try the phase one frame either
  side before concluding that b is real;
* a marker registers on a site while it covers the site centre, which is roughly ±0.35 of a data
  pitch, not ±0.5 and not ±0.1. Use the tolerance your own extractor implies;
* **check a proposed merge against every candidate the new interval would swallow, not just the one
  being dropped.** Checking only the middle frame lets waypoints be shaved off one at a time: near
  the end of a motion the easing curve is almost flat, so a real arrival at frame a looks explained
  by a motion ending one frame later — drop it, and the next frame looks explained too. The
  interval grows without ever being tested against what it now covers. In c150 this collapsed a
  genuine move plus the ten-frame rest after it into one long move, putting the block half a pitch
  out through every frame in between;
* **date the arrival with the centroid, not with occupancy.** Occupancy cannot tell "just arrived"
  from "nearly arrived" — the profile is flat at both ends, so a block a fifth of a site short
  still registers on the site. The pixel centroid is not quantised and settles it. Apply this only
  when the two ends differ (there is no arrival to date in a static interval) and only when the
  block is clear of the window edge, where the visible centroid is biased by clipping.

What survives is the boundary set. In c540's first 40 frames this yields waypoints at frames
0, 8, 18, 34 for both X species — frames 8 and 18 being exactly the ends of the one genuinely
visible move in that window.

## III.5 Step 5 — decompose a motion into rows

For one species and one motion from waypoint a to waypoint b:

1. **Factor** configuration(a) and configuration(b) into product rectangles. Group rows of the
   configuration by the set of columns they carry; each distinct column-set is one rectangle.
2. **Pair** them: a start rectangle can only go to a finish rectangle with the same tone counts in
   both axes. Where several candidates remain, take the least displacement, then *check the choice
   against a mid-motion frame* — the pixel centroid of the block halfway through will agree with
   one pairing and not the other. Two rectangles of identical shape swapping places is the case
   that needs the check.
3. **Map the tones** — forced by I.2: sorted start tones to sorted finish tones, element-wise.
4. **Cut into elements** wherever the offset between corresponding tones changes (I.6). This is
   what recovers `10:12, 13:15 → 10:12, 16:18` rather than a wrong single-element `10:15 → 10:18`.

Each surviving pair is one schedule row. Rectangles whose start and finish are identical produce no
row at all — an atom nobody moves stays where it is (I.5).

If step 2 finds no consistent pairing, do not guess. Say so, and decide that motion by eye.

## III.6 Step 6 — timing

`t_start = a × dt_ms`, `t_finish = b × dt_ms`, where a and b are the waypoint frames. This is exact
to within one frame by construction, and on the c540 move measured above it lands within 0.01 of a
frame of the reference workbook.

Fitting the easing curve to the observed centroid to get sub-frame timing is tempting and is
implemented as an option in the reference tool, but it is **off by default**: on the one move
tested it moved the answer further from the reference, not closer, because the whole-species
centroid is biased while markers overlap. If you turn it on, verify it against a move whose timing
you already know.

## III.7 Step 7 — unloads, loads and gates

**Faded runs.** Take the number of faded sites per species per frame and find the maximal runs
where it reaches block size. Ignore runs shorter than about three frames — a block passing through
itself mid-motion produces one- and two-frame artefacts. Then read each run:

| the run | what it is |
|---|---|
| present from frame 0, stationary | reservoir stock waiting to be picked up |
| begins as the solid count drops | a readout — the block has been taken for measurement |
| ends as the solid count rises | the load: that batch has just been picked up |

**Write the unload from where the block goes, not from where it disappears.** Track its centroid
and extent, in the faded channel, frame by frame until it leaves the window, and fit the
destination and duration to that. If you cannot see where it lands — and in c540 you cannot, it
goes off the bottom edge — say so in the `note` column and put the open question to whoever has the
source schedule. A wrong answer here is undetectable by every check in part IV (I.9).

**Gates** are the runs of frames whose background is tinted, cross-checked against the header
token. One `Gates` row per run.

**Seed** is the occupancy of frame 0, factored into rectangles.

## III.8 Step 8 — emit, render, compare, repeat

Write the four sheets, run part II on the result, and compare against the movie. Then close the
loop: every disagreement is either a wrong waypoint (III.4), a wrong pairing (III.5) or a missing
row, and each shows up differently in part IV's checks — a missing transit makes some later row
pick up fewer atoms than its rectangle has sites, which is check 3.

## III.9 What the movie cannot tell you

Be explicit about these in the workbook's `note` column rather than inventing values.

**A permutation is invisible.** When a move permutes a block onto its own site set, occupancy data
cannot see it at all; only the brief dip while atoms are between sites betrays that anything
happened. In c540's first 40 frames, four of the five moves are of this kind. You can detect *that*
something happened — atoms leave their sites and return to the same set — but neither its timing
nor its decomposition into rows. Recover those from the source schedule, or by tracking individual
markers frame by frame through the dip, which the AOD ring colours help with because they separate
the concurrently moving groups.

**Off-screen destinations.** A block carried out of the visible window has a destination you can
only extrapolate. Fit it from the fraction of the block still visible as it clips, state the
uncertainty, and ask.

**Which AOD carried what.** The ring colours distinguish at most two concurrent groups, while six
rows may run at once. This costs nothing: `slot` is provenance (II.1), and any valid decomposition
into rectangles renders identically.

**Sub-frame timing.** Everything you recover is quantised to the frame grid. ±1 frame is the floor.

---

# Part IV — validation, both directions

Run these on the workbook. They catch essentially every mistake, and all are decidable from the
workbook alone.

| # | check |
|---|---|
| 1 | Every row's x-list and y-list have the same tone count at start and finish. |
| 2 | Corresponding elements (I.6) have equal tone counts. |
| 3 | **Every row's start rectangle is exactly full**: the number of atoms picked up equals `len(x) × len(y)`. A short count means the row is picking up empty sites — usually a stale rectangle or a motion the schedule is missing. |
| 4 | **No atom is claimed by two rows in the same batch.** |
| 5 | Each species has exactly its seeded count of **active** atoms at *every* frame — atoms in transport after an `unload` do not count, and every `unload` is matched by a `load` of the same species and size. |
| 6 | No two atoms occupy the same site at any batch boundary. |
| 7 | Every atom is inside the lattice, the parking zone, or a declared reservoir. |
| 8 | The state after the last batch equals the seed — the cycle closes. |

Checks 3 and 4 are the load-bearing ones. Check 3 is what catches a transit the schedule fails to
record.

Then the acceptance test, which is the same in both directions:

> **Render the workbook. Extract the rendered frames and the movie's frames with the same
> extractor. Compare at every held frame — one whose configuration is identical to an adjacent
> frame. They must agree exactly.**

Comparing at any other frame is meaningless (III.3). c540 has 46 held frames out of 384, and the
current workbook reproduces all 46.

**And then watch the video.** Two errors in c540 passed every check above and every frame-by-frame
diff, because both concerned faded blocks that neither the movie's extract nor the
reconstruction's could see (I.9). A side-by-side render caught them in seconds. No amount of
tabular validation substitutes for this.

---

# Part V — the reference tools

PowerShell 5.1 and `System.Drawing` only; no Python, Node or Excel is needed. `ffmpeg` is used only
to turn a movie into frames. Run `tools/preflight.ps1` before anything else.

| tool | part | does |
|---|---|---|
| `tools/render.ps1` | II | workbook in, PNG frames + validation log out. Also writes a calibration file describing its own geometry, so the same extractor can read its frames and the movie's. |
| `tools/inv_calib.ps1` | III.2 | panel, grid origin and pitch, lattice and visible extents, gate probe box |
| `tools/inv_extract.ps1` | III.3 | per frame: site occupancy (solid *and* faded), per-species pixel statistics, gate flag. `-DumpFrame n` prints one frame as an ASCII map — use it to confirm the calibration before running the movie |
| `tools/inv_moves.ps1` | III.4–III.7 | waypoints, rectangle pairing, tone maps, element cuts, gates, seed; prints everything it could not decide |
| `tools/inv_emit.ps1` | III.8 | the four CSVs into a workbook |
| `tools/compare.ps1` | IV | the held-frame acceptance test |
| `tools/writexlsx.ps1` | — | minimal multi-sheet .xlsx writer, used by `inv_emit.ps1` |

```powershell
ffmpeg -y -v error -i <movie> -fps_mode passthrough -start_number 0 frames\p_%03d.png

tools\inv_calib.ps1   -Frame frames\p_000.png -SiteFrame frames\p_005.png -OutTxt calib.txt
tools\inv_extract.ps1 -Dir frames -Calib calib.txt -DumpFrame 0        # check this by eye first
tools\inv_extract.ps1 -Dir frames -Calib calib.txt -OutSites ref.csv -OutTrack track.csv
tools\inv_moves.ps1   -Sites ref.csv -Track track.csv -CycleMs <from the header> -NFrames <n> `
                      -LatticeCols <n> -LatticeRows <n> -VisibleColMax <n> -VisibleRowMax <n> `
                      -OutConst const.csv -OutSeed seed.csv -OutSchedule sched.csv -OutGates gates.csv
#   ... read what it says it could not decide, edit the CSVs ...
tools\inv_emit.ps1    -Out m<code>SEmoves.xlsx -Const const.csv -Seed seed.csv `
                      -Schedule sched.csv -Gates gates.csv

tools\render.ps1      -Xlsx m<code>SEmoves.xlsx -OutDir out -LogCsv log.csv
tools\inv_extract.ps1 -Dir out -Calib out\calib.txt -OutSites cand.csv
tools\compare.ps1     -Reference ref.csv -Candidate cand.csv
```

Both sides of `compare.ps1` must be extracted by `inv_extract.ps1`, each with its own calibration
file. Scoring two renders with different sampling rules produces a meaningless diff.

**Status.** The forward half is proven: a renderer reading only the reference c540 workbook
reproduces that movie at every held frame (40/40 scored on the data lattice, 40/48 once the scoring
grid is halved and a little extraction noise is admitted), with zero validation failures.

The inverse half, run end to end with no human input:

| movie | tone divisor | held frames reproduced |
|---|---|---|
| c150 4-AOD | 2 (measured) | **15 / 18** |
| c150 4-AOD | 1 (forced) | 9 / 15 |
| c540 4-AOD | 1 (forced) | **24 / 48** |
| c540 4-AOD | 2 (measured) | 2 / 48 |

Two things to read off that table. First, c150 needs the finer grid and c540 does not, and each is
much worse on the other's setting — so `tone_divisor` is measured per movie and can be overridden.
Second, **the finer grid currently degrades segmentation on a movie that only uses it off-screen.**
c540's half-pitch positions belong to its reservoirs alone; adopting the finer grid there multiplies
the candidate frames without adding information, and the merge cannot recover. That is an open
problem, not a property of the movies: see III.4 on why fine grids flood the candidate list. Until
it is fixed, check the divisor the calibration reports, and if the movie's off-lattice parking is
confined to reservoirs, force the divisor to 1.

Held frames are also a *lower bound* on agreement, not a picture of it: they are the only frames
where a site-by-site comparison means anything (III.3), and there are few of them on a busy movie.
A workbook can score well and still look wrong in motion. Watch the side by side.

The residual failures on both movies are `missing` atoms, not misplaced ones: no `load` row is ever
written, so a fresh ancilla batch never appears. That row cannot be written from the video (III.9).

---

# Appendix — traps that have cost real time

Physics and method:

* **A block being read out is drawn faded and is therefore missing from any saturation-floored
  extract.** No diff can flag an error about it. Check those by eye. (I.9)
* **Site occupancy cannot validate a move frame by frame**, and a permutation is invisible to it
  entirely. (III.3, III.9)
* **A rectangle can straddle two species.** No slot→species table can be correct. (I.4)
* **Row order is not time order.** Batch by `t_start`. (I.5)

PowerShell 5.1, on this machine:

* Variables are **case-insensitive**: `$S` and `$s` are one variable. This has corrupted results
  five times across three sessions.
* The comma operator **binds tighter than arithmetic**: `@($a*$dt, $b*$dt)` parses as
  `$a * ($dt,$b) * $dt`. Parenthesise each element.
* A function returning `,@($collection)` preserves the array — but wrapping the *call* in `@()`
  re-wraps it, giving a one-element array containing your array. Assign it plainly.
* `"$var:"` inside a string is parsed as a drive qualifier. Write `"${var}:"`.
* `[int](3/4)` **rounds** (banker's). Use `[Math]::Floor`.
* `Sort-Object` **flattens an array of arrays.** Use `[pscustomobject]` for records.
* `Get-Content` without `-Encoding utf8` mangles UTF-8 on write-back. Use
  `[System.IO.File]::ReadAllText($p,[Text.Encoding]::UTF8)`.
* `Set-Content` treats `[Content_Types].xml` as a wildcard — use `-LiteralPath`.
* `ZipFile::CreateFromDirectory` writes backslash entry names, which is invalid OOXML.
* **This project lives in OneDrive**, which locks `.xlsx` files. Write to temp, then copy with a
  retry loop.
* This machine's locale is es-ES. Pin `InvariantCulture` anywhere decimals are parsed or formatted.
* ffmpeg 9 removed `-vsync` (use `-fps_mode passthrough`); libx264 rejects odd frame heights.
