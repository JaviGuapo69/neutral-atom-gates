"""se_equiv.py -- are two schedule workbooks THE SAME SCHEDULE?

Not "do they have the same rows".  The division of a batch into rows is not unique, `move` and
`slot` are provenance with no semantics, and a batch can be written as one wide rectangle or four
narrow ones with identical effect.  Two workbooks that move the same atoms to the same places at
the same times are the same workbook, however differently they are laid out.

So both sheets are simulated with render.ps1's own semantics (`se_sim.py`) and compared as PICTURES
-- every atom, every frame, including atoms in mid-flight, matched species by species with the
Hungarian assignment so the comparison never depends on the order atoms happen to be listed in.

Two things this deliberately does:

  * IT COMPARES ON SCREEN ONLY, by default.  Where a block goes after it leaves the panel is not
    in the movie, so no transcription can recover it and no comparison should punish a difference
    there.  `--offscreen` includes it if you want to see it anyway.
  * IT CONVERTS GRIDS.  One workbook may count data sites and another tone positions half a pitch
    apart (guide I.1a).  Both sides are converted to data-site units from their own `tone_divisor`
    first, so a correct workbook cannot score zero merely for counting in finer units.

Exit status is 0 when the two agree at every frame within tolerance.
"""
import argparse, collections, sys, os
import numpy as np
from scipy.optimize import linear_sum_assignment

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import se_sim


def to_data_units(sim):
    """Convert this workbook's tone coordinates to data-site units, so two sheets counting in
    different grids are still comparable.  Data column c sits at tone (c-1)*D+1."""
    D = sim._const("tone_divisor", 1) or 1
    return (lambda v: (v - 1.0) / D + 1.0), D


def frames_of(sim, onscreen, win):
    conv, D = to_data_units(sim)
    out = []
    for f in range(sim.n_frames):
        pts = []
        for sp, x, y, faded in sim.frame(f, onscreen_only=False):
            dx, dy = conv(x), conv(y)
            if onscreen and win is not None:
                if not (win[0] - 0.4 <= dx <= win[1] + 0.4 and win[2] - 0.4 <= dy <= win[3] + 0.4):
                    continue
            pts.append((sp, dx, dy, faded))
        out.append(pts)
    return out


def compare_frame(A, B, tol, ignore_fade):
    """Species-by-species Hungarian match.  Returns (n_missing, n_phantom, n_mislabelled, maxerr)."""
    bysp_a = collections.defaultdict(list)
    bysp_b = collections.defaultdict(list)
    for sp, x, y, fd in A:
        bysp_a[sp].append((x, y, fd))
    for sp, x, y, fd in B:
        bysp_b[sp].append((x, y, fd))
    miss = phan = fade_diff = 0
    worst = 0.0
    for sp in set(bysp_a) | set(bysp_b):
        a = bysp_a.get(sp, []); b = bysp_b.get(sp, [])
        if not a or not b:
            miss += len(a); phan += len(b)
            continue
        ax = np.array([p[0] for p in a]); ay = np.array([p[1] for p in a])
        bx = np.array([p[0] for p in b]); by = np.array([p[1] for p in b])
        C = np.sqrt((ax[:, None] - bx[None, :]) ** 2 + (ay[:, None] - by[None, :]) ** 2)
        n = max(len(a), len(b))
        big = np.full((n, n), 1e6)
        big[:len(a), :len(b)] = C
        ri, ci = linear_sum_assignment(big)
        ua, ub = set(range(len(a))), set(range(len(b)))
        for r, c in zip(ri, ci):
            if r < len(a) and c < len(b) and C[r, c] <= tol:
                ua.discard(r); ub.discard(c)
                worst = max(worst, float(C[r, c]))
                if not ignore_fade and a[r][2] != b[c][2]:
                    fade_diff += 1
        miss += len(ua); phan += len(ub)
    return miss, phan, fade_diff, worst


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True, help="reference workbook")
    ap.add_argument("--b", required=True, help="workbook under test")
    ap.add_argument("--label-a", default="reference")
    ap.add_argument("--label-b", default="candidate")
    ap.add_argument("--tol", type=float, default=0.02,
                    help="how near two atoms must be, in data sites, to be the same atom")
    ap.add_argument("--offscreen", action="store_true",
                    help="also compare atoms outside the panel (normally excluded: where a block "
                         "goes after it leaves the panel is not in the movie)")
    ap.add_argument("--ignore-fade", action="store_true",
                    help="do not report solid/faded disagreements")
    ap.add_argument("--out", default=None, help="per-frame csv")
    ap.add_argument("--max-report", type=int, default=14)
    args = ap.parse_args()

    A = se_sim.from_workbook(args.a)
    B = se_sim.from_workbook(args.b)
    for lbl, s in ((args.label_a, A), (args.label_b, B)):
        c = s.counts()
        print("%-12s %-46s %d rows, %d atoms ever alive, %d motions, validation %s"
              % (lbl, "", len(s.rows), len(s.atoms),
                 sum(len(a["moves"]) for a in s.atoms), dict(c) if c else "clean"))
    # the reference defines what "on screen" means
    convA, DA = to_data_units(A)
    win = (convA(A.vcmin), convA(A.vcmax), convA(A.vrmin), convA(A.vrmax))
    print("comparison window : data cols %.1f..%.1f  rows %.1f..%.1f%s"
          % (win[0], win[1], win[2], win[3], "  (ignored: --offscreen)" if args.offscreen else ""))

    FA = frames_of(A, not args.offscreen, win)
    FB = frames_of(B, not args.offscreen, win)
    n = min(len(FA), len(FB))
    if len(FA) != len(FB):
        print("!! %d frames vs %d -- comparing the first %d" % (len(FA), len(FB), n))

    rows, same, held, held_same = [], 0, 0, 0
    worst_all = 0.0
    for f in range(n):
        miss, phan, fd, w = compare_frame(FA[f], FB[f], args.tol, args.ignore_fade)
        worst_all = max(worst_all, w)
        at_rest = all(abs(x - round(x)) < 1e-6 and abs(y - round(y)) < 1e-6 for sp, x, y, _ in FA[f])
        if not miss and not phan and not fd:
            same += 1
            if at_rest:
                held_same += 1
        if at_rest:
            held += 1
        rows.append(dict(frame=f, ref=len(FA[f]), cand=len(FB[f]), missing=miss, phantom=phan,
                         fade_mismatch=fd, worst_offset=round(w, 4), at_rest=int(at_rest)))

    print()
    print("FRAMES IDENTICAL          : %d / %d" % (same, n))
    print("  of the %d frames where the reference is entirely at rest: %d identical"
          % (held, held_same))
    print("  worst matched-atom offset: %.4f data sites (tolerance %.3f)" % (worst_all, args.tol))
    bad = [r for r in rows if r["missing"] or r["phantom"] or r["fade_mismatch"]]
    if not bad:
        print("\n%s and %s ARE THE SAME SCHEDULE on screen." % (args.label_a, args.label_b))
    else:
        print("\n%d frames differ.  worst:" % len(bad))
        print("   frame   ref  cand  missing  phantom  fade  at_rest")
        for r in sorted(bad, key=lambda r: -(r["missing"] + r["phantom"] + r["fade_mismatch"]))[:args.max_report]:
            print("   %5d %5d %5d %8d %8d %5d %8d"
                  % (r["frame"], r["ref"], r["cand"], r["missing"], r["phantom"],
                     r["fade_mismatch"], r["at_rest"]))
        print("   first differing frame: %d" % bad[0]["frame"])
    if args.out:
        import csv
        with open(args.out, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, list(rows[0].keys()))
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print("wrote %s" % args.out)
    sys.exit(0 if not bad else 2)


if __name__ == "__main__":
    main()
