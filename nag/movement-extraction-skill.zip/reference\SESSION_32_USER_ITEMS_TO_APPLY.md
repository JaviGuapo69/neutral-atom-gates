# c975 — the USER's six items from the s32 video, read against the pixels, READY TO APPLY (items 52-63)

**Written for: the next Claude session, which has fresh context and will apply these.** Javier watched
`c975_s32_original_vs_rebuild_panels.mp4` on 2026-09-18 and named six windows. This session read every one of
them against the movie's pixels, measured the proposed map against its alternatives, and **stopped without
applying** (the §3 dialogue of `handmade correction method.md`: the user's own items are applied on approval).
Javier's answer was "okay" — **all twelve changes below are approved. Apply them.**

Read `SESSION_32_C975_HAND_CORRECTIONS.md` first for how the s32 book was built; this file only adds the
second pass.

---

## 0. What you are starting from

| | |
|---|---|
| working folder | `run_c975_s32\` |
| the script to extend | `run_c975_s32\apply_s32.py` — it starts from `moves_full_c975_original.json` / `rests_full_c975_original.json` and re-applies items 1-51 every run, so **add items 52-63 at the end, before the "timing hygiene" section**, and re-run the whole thing |
| current book | `c975_s32_blocks.xlsx` — 86 moves, 7 undetermined, AUDIT CLEAN, se_sim clean, render 0 validation entries, score 0.0606 site, AOM 6/6 |
| the movie's frames | `run_c975\frames\p_NNN.png` (never write into `run_c975\`) |

**Where to put the new items.** `apply_s32.py` has a section `# ==== 52. timing hygiene`. The new items must
go BEFORE it (they are ordinary map/comb/window corrections) so the hygiene pass clips them too. Renumber the
hygiene section to 64-65 and its `note()` accordingly.

**The D-labels Javier uses** are the movie's block watermarks, and for c975 they are the six lattice cells:
D1 = cols 1:13 × rows 1:15, D2 = cols 14:26 × rows 1:15, D3 = cols 1:13 × rows 16:30,
D4 = cols 14:26 × rows 16:30, D5 = cols 1:13 × rows 31:45. Which species sits in a cell changes with time —
see the block-position line in `apply_s32.py`'s docstring.

---

## 1. The six items, the evidence, and the exact edit

### Item 52 — f001-f007, D5. "all the rows move, not only the few you drew"

Javier is right and the map is right; only the comb is wrong. The line profiles
(`logs\lp_Z0_cols_000_022.txt`) show **all fifteen rows 31:45 off their column tones on f002-f006**, not the
five of comb A. My `combruns.py` run-detector intersects the moving-line set across a run and eroded that run
to `{32,34,36}`, and I assumed the usual comb A. The two windows after it, f008-f014 and f015-f020, ARE
genuine sub-combs ({32,35,38,41,44} and {33,36,39,42,45}) — leave those alone.

Measured on the whole block: **mean 0.0699, free 0.0305** (fit f0.00-7.50), against 0.0839 / 0.0362 on the
comb. Every rotation was scanned on the whole block: k=+9 mean 0.0699 wins, k=+4 0.1479, k=+10 0.1314.

**Edit — change the existing item 1 in place** (it currently reads `do_rot(m, "Z0", 1, 13, 9, COMB_A_Z, 2, 7, ...)`):

```python
m = moves[find("Z0", "cols", 2, 9)]
do_rot(m, "Z0", 1, 13, 9, None, 2, 7,
       "the map (rotation by +9) is right and so is the window, but the move is on the WHOLE block, not on a "
       "sub-comb: all fifteen rows 31:45 are off their column tones on every frame f002-f006 "
       "(logs\\lp_Z0_cols_000_022.txt). The session-32 first pass read the comb as 31,34,37,40,43 because the "
       "run detector intersects the moving-line set across a run and eroded it; Javier named this on the s32 "
       "video ('in D5 all the rows move, not only the few you drew, the movement of the ones that move is "
       "correct, the rest should do the same'). Scanned on the whole block: k=+9 mean 0.0699 vs k=+4 0.1479, "
       "k=+10 0.1314; on the comb the same map read 0.0839.",
       comb=R(31, 45))
```

(`do_rot` passes `comb=(comb or sub)`, so `sub=None` + `comb=R(31,45)` sets both fields correctly. Keep the
`note()` line under it, changed to say the comb is the whole block.)

### Item 53-54 — f145-f165, D3 (X0 on cols 1:13 × rows 16:30). Two moves the book has none of

All fifteen rows move together in each window; the columns not named sit on their tones on every frame
(`logs\lpbatch.txt`, `gaps.py X0 0 143 167 1 13 0.4 13.6 15.4 30.6`). The empty-tone sets are decisive:

| frames | tones with no marker, every frame | reading |
|---|---|---|
| 145-151 | {1, 10, 13} | a 3-cycle on columns 1, 10, 13 |
| 153-157 | grows to {2,3,5,6,7,12} | **NOT RESOLVED**, see §2 |
| 160-164 | {4, 9, 11} | a 3-cycle on columns 4, 9, 11 |

f145-151: at f145 column 1 is at 1.65 (moving up) and column 10 at 9.53 (moving down); at f151 a marker
arrives at 1 from above (1.27) and one at 13 from below (12.68). Under `1->13 | 13->10 | 10->1` at p = 0.054
the three predicted positions are 1.65, 12.84, 9.51 against 1.65 / — / 9.53 observed, and at p = 0.97 they are
12.64, 10.09, 1.27 against 12.68 / — / 1.27. **mean 0.0674, free 0.0454**; the reverse 3-cycle reads 0.0872.

f160-164: at f160 columns 4 and 9 move up and 11 moves down; `4->9 | 9->11 | 11->4` at p = 0.092 predicts
4.46, 9.18, 10.36 against 4.46, 9.19, 10.35 observed — exact. At f164, p = 0.94 predicts 8.70 against 8.71.
**mean 0.0514, free 0.0373**; the reverse reads 0.0683.

**X0 has no transition covering f145-151** (its rests jump from (133,135) to (152,152)), so one must be
appended. f160-164 needs nothing: the transition X0 f159-175 already spans it.

```python
# ---- 53. f145-151 X0 cols on rows 16:30 (nothing in the book describes it)
z = rests["X0"]
z["transitions"].append(dict(sp="X0", f0=144, f1=152, x0=R(1, 13), y0=R(16, 30),
                            x1=R(1, 13), y1=R(16, 30), kind="permutation"))
z["transitions"].sort(key=lambda t: t["f0"])
z["rests"].append([143, 144, R(1, 13), R(16, 30)])
z["rests"].sort(key=lambda r: r[0])
n = insert(new_move("X0", "cols", "permutation", 145, 151,
                    [[[1], [13]], [[13], [10]], [[10], [1]]], R(16, 30),
                    "NEVER ENUMERATED: X0's columns make three whole-block moves between the f143-144 and "
                    "f183-184 pulses and the book has none of them (its only X0 transition in the stretch is "
                    "the UNDETERMINED f152-158). Javier named the window on the s32 video. Exactly three "
                    "columns leave their tones on every frame f145-f151 -- 1, 10 and 13 -- and all fifteen "
                    "rows carry them. Column 1 moves up (1.65 at f145) and column 10 down (9.53); at f151 a "
                    "marker arrives at 1 from above (1.27) and one at 13 from below (12.68). The map "
                    "predicts 1.65 / 12.84 / 9.51 at p 0.054 and 12.64 / 10.09 / 1.27 at p 0.97. mean 0.0674, "
                    "free 0.0454; the reverse 3-cycle reads 0.0872.",
                    block=R(1, 13), for_tr=["X0", 144, 152]))
refit(n, fr(143, 153), 144.0, 152.0, "the block is on tones at f144 and f152")
measure(n, fr(143, 153))

# ---- 54. f160-164 X0 cols on rows 16:30 (the transition f159-175 already covers it)
n = insert(new_move("X0", "cols", "permutation", 160, 164,
                    [[[4], [9]], [[9], [11]], [[11], [4]]], R(16, 30),
                    "NEVER ENUMERATED, the third of X0's column moves of this interval. Columns 4, 9 and 11 "
                    "are the only tones empty on every frame f160-f164. At f160 columns 4 and 9 move up and "
                    "11 down; the map predicts 4.46 / 9.18 / 10.36 at p 0.092 against 4.46 / 9.19 / 10.35 "
                    "observed, and 8.70 at f164 against 8.71. mean 0.0514, free 0.0373; the reverse 0.0683.",
                    block=R(1, 13), for_tr=["X0", 159, 175]))
refit(n, fr(158, 166), 159.0, 165.0, "the block is on tones at f159 and f165")
measure(n, fr(158, 166))
```

### Items 55-59 — f185-f212, X0 on cols 1:13 × rows 31:45. Four 3-cycles, every map wrong

In each of these four windows exactly three columns leave their tones and the other ten sit on theirs on every
frame. The book's maps move eleven or twelve columns. Evidence: `gaps.py X0 0 183 212 1 13 0.4 13.6 30.4 45.6`
(reproduced in §3 below) and `logs\probe_X0_c185.txt`.

| # | frames | book has | apply | measured (book's map on the same peaks) |
|---|---|---|---|---|
| 55 | 185-190 | `2:7->8:13 \| 8:13->2:7` | `2->13 \| 13->7 \| 7->2` | **0.0685 / 0.0431** (0.1065 / 0.1016) |
| 56 | 190-194 | the `3<->4` swap is written for X0+Z1+Z0 | drop X0, keep Z1+Z0, comb rows 1:30 | — |
| 57 | 193-198 | `11->1 \| 1:10->2:11` | `1->10 \| 10->11 \| 11->1` | **0.0517 / 0.0376** (0.0820 / 0.1039) |
| 58 | 201-205 | UNDETERMINED (X0 f200-206) | `4->6 \| 6->12 \| 12->4` | **0.0532 / 0.0361** |
| 59 | 207-210 | `5->9 \| 6:9->5:8` | `5->9 \| 9->8 \| 8->5` | **0.0382 / 0.0356** (0.0523 / 0.0645) |

The reverse 3-cycle was measured for each and loses every time (0.0784, 0.0691, 0.0621, 0.0518).

Item 56 matters because X0 is provably STILL on f191 and f192 — thirteen peaks, none off its tone — while the
book has it swapping columns 3 and 4 in that batch. The Z blocks do make that swap, so the row stays, without
X0 and with the comb narrowed from rows 1:45 to rows 1:30.

```python
# ---- 55. f185-190 X0 cols: a 3-cycle on 2, 7, 13, not a twelve-column involution
m = moves[find("X0", "cols", 185, 193)]
replace(m, [[[2], [13]], [[13], [7]], [[7], [2]]], R(1, 13),
        "the involution `2:7<->8:13` moves twelve of X0's thirteen columns; the movie moves THREE. Columns 2, "
        "7 and 13 are the only tones with no marker on every frame f185-f190 and the other ten sit on their "
        "tones throughout. At f185 the two visible movers are at 6.61 and 12.55, which `2->13 | 7->2 | 13->7` "
        "predicts at p 0.075 as 2.83 / 6.63 / 12.55 (the first merges with the static column 3); at f190, p "
        "0.926 predicts 12.19 / 2.37 / 7.44 against 12.13 / 2.37 / 7.44 observed. mean 0.0685 free 0.0431 "
        "against the book's 0.1065 / 0.1016 and the reverse cycle's 0.0784. Javier: 'f185-f212 missing or "
        "wrong moves'.", f0=185, f1=190, for_tr=["X0", 184, 191])
refit(m, fr(183, 192), 184.0, 191.0, "the block is on tones at f184 and f191")
measure(m, fr(183, 192))

# ---- 56. f190-194: X0 does not take part in the 3<->4 swap
m = moves[find("X0", "cols", 190, 194, sel=lambda mm: mm["joins"] == ["X0", "Z1", "Z0"])]
replace(m, [[[3], [4]], [[4], [3]]], R(1, 13),
        "X0 is at REST on f191 and f192 -- thirteen column peaks, every one within 0.02 of its tone -- so it "
        "cannot be in this batch. The swap belongs to the two Z blocks; the rectangle is narrowed from rows "
        "1:45 to rows 1:30.", comb=R(1, 30), joins=["Z1", "Z0"])
measure(m, fr(188, 196))

# ---- 57. f193-198 X0 cols: a 3-cycle on 1, 10, 11
m = moves[find("X0", "cols", 192, 201)]
replace(m, [[[1], [10]], [[10], [11]], [[11], [1]]], R(1, 13),
        "`11->1 | 1:10->2:11` moves eleven columns; the movie moves three. Columns 1, 10 and 11 are the only "
        "empty tones on f193-f196. At f198 a marker arrives at 1 from above (1.50) and one at 10 from below "
        "(9.53), which `1->10 | 10->11 | 11->1` predicts at p 0.95 as 9.55 / 10.95 / 1.50 -- exact. mean "
        "0.0517 free 0.0376 against the book's 0.0820 / 0.1039 and the reverse cycle's 0.0691.",
        f0=193, f1=198, for_tr=["X0", 192, 199])
refit(m, fr(191, 200), 192.0, 199.0, "the block is on tones at f192 and f199")
measure(m, fr(191, 200))

# ---- 58. f201-205 X0 cols (the UNDETERMINED transition f200-206)
n = insert(new_move("X0", "cols", "permutation", 201, 205,
                    [[[4], [6]], [[6], [12]], [[12], [4]]], R(31, 45),
                    "UNDETERMINED X0 cols f200-206. Columns 4, 6 and 12 are the only empty tones of the "
                    "window. At f205, p 0.94, the map predicts 5.88 / 11.64 / 4.46 against the observed "
                    "11.63 and 4.46; at f204, p 0.805, it predicts 5.61 / 10.83 / 5.56 against 5.65 and "
                    "10.83. mean 0.0532, free 0.0361; the reverse cycle 0.0621.",
                    block=R(1, 13), for_tr=["X0", 200, 206]))
refit(n, fr(199, 207), 200.0, 206.0, "the block is on tones at f200 and f206")
measure(n, fr(199, 207))
drop_undetermined("X0", 200, 206)

# ---- 59. f207-210 X0 cols: 8 goes to 5, it is not a four-column shift
m = moves[find("X0", "cols", 206, 213)]
replace(m, [[[5], [9]], [[9], [8]], [[8], [5]]], R(1, 13),
        "`5->9 | 6:9->5:8` moves columns 6 and 7, which sit on their tones on every frame of the window "
        "(column 7 only merges with its neighbour at f209). The empty tones are 5, 8 and 9. `5->9 | 9->8 | "
        "8->5` predicts at f207 (p 0.06) 5.24 against 5.24 observed, at f208 (p 0.193) 7.42 / 8.81 against "
        "7.42 / 8.71, and at f210 (p 0.88) 8.52 / 5.36 against 8.40 / 5.35. mean 0.0382 free 0.0356 against "
        "the book's 0.0523 / 0.0645.", f0=207, f1=210, for_tr=["X0", 206, 211])
refit(m, fr(205, 213), 206.0, 212.0, "the block is on tones at f206 and f211")
measure(m, fr(205, 213))
```

### Item 60 — f239-f250, D1 and D3 into D2 and D4. The map is right, the WINDOW is 1.3 frames late

Javier: "wrong move when translating the atoms in D1, D3 to D2, D4". The map is not wrong — both Z blocks do a
rigid thirteen-column +13 translation and every column carries the same displacement on every frame. What is
wrong is the timing: the rebuild eases in too slowly and **lags the movie by up to 1.4 sites** through the
middle of the translation (`watch_s32.txt`, run `Z0 cols f239-f248`):

| frame | movie, column 1 | rebuild, column 1 | lag |
|---|---|---|---|
| f240 | 2.75 | 1.45 | 1.30 |
| f241 | 3.71 | 2.31 | **1.40** |
| f243 | 6.47 | 5.44 | 1.03 |
| f245 | 10.02 | 9.38 | 0.64 |
| f247 | 12.58 | 12.58 | 0.00 |

The cause is mine: the session-32 refit was given the lower bound f238.0, one frame after the gate. The pulse
run is f237-f238 and its instant is **f237**, so the move may start there. With the bound at f237 the movie's
own fit lands at f237.25 — inside the pulse run, the same deviation `extra.json`'s Z carry-in already
documents — and the residual falls from **mean 0.1881 worst 1.390 to mean 0.1257 worst 1.032**, map untouched.

**Edit — in the existing item 42 (`Z1+Z0 cols f239-250`), change the refit bound only:**

```python
refit(m, fr(237, 252), 237.0, 251.0, "gate instant f237 (the pulse run f237-238); on 14:26 at f250 -- the "
      "movie's own fit starts at f237.25, INSIDE the run, and bounding it at f238 made the rebuild lag the "
      "movie by up to 1.4 sites in mid-flight (Javier's item)")
measure(m, fr(237, 252))
```

### Items 61-62 — f278-f290. Two X1 moves found, the two Z moves still open

X1 (cols 1:13 × rows 31:45) has two UNDETERMINED transitions here, f277-283 and f283-288, and both are now
readable. `gaps.py X1 0 276 292 1 13 0.4 13.6 30.4 45.6`:

* **f278-282**, six columns move, 2, 4, 5, 10, 11, 13. The pair 2/13 swaps: at f278 they are at 2.31 and
  12.68 (p 0.028), they cross at 7.19 / 7.68 on f279, and at f282 they are at 12.59 and 2.41 (p 0.963) —
  a ±11 displacement at every frame. The other four make a 4-cycle: at f282 the residuals are +0.25 at
  destination 5 and −0.23 at destination 10 while destinations 4 and 11 are already FULL, which fixes their
  displacements at ∓6 and ∓1 and so the cycle `4->10 | 10->11 | 11->5 | 5->4`. Two independent swaps
  (4↔10, 5↔11) would leave 4 and 11 a fifth of a site off tone at f282 and they are not.
  **mean 0.1280** against 0.1321 for the double-swap variant and 0.1429 for the swap alone.
* **f284-287**, four columns move, 3, 6, 9, 12. At f284 their deltas are +0.22, −0.20, +0.20, −0.28 — equal
  magnitudes with alternating signs, which for a permutation of {3,6,9,12} forces |d| = 3 and therefore the
  two swaps. **mean 0.0779, free 0.0857**, against 0.1064 free for the 4-cycle.

Both transitions already exist, so no rests surgery.

```python
# ---- 61. f278-282 X1 cols (UNDETERMINED)
n = insert(new_move("X1", "cols", "permutation", 278, 282,
                    [[[2], [13]], [[13], [2]], [[4], [10]], [[10], [11]], [[11], [5]], [[5], [4]]], R(31, 45),
                    "UNDETERMINED X1 cols f277-283. Six columns leave their tones -- 2, 4, 5, 10, 11, 13 -- "
                    "and seven stay. Columns 2 and 13 swap: 2.31 / 12.68 at f278 (p 0.028), crossing at "
                    "7.19 / 7.68 on f279, 12.59 / 2.41 at f282 (p 0.963), a uniform +-11. The other four "
                    "make a 4-cycle: at f282 destination 5 is 0.25 above its tone and destination 10 is 0.23 "
                    "below, while destinations 4 and 11 are already FULL -- that fixes the displacements at "
                    "-6, +6 and -+1, i.e. 4->10, 10->11, 11->5, 5->4. Two swaps 4<->10 and 5<->11 would leave "
                    "4 and 11 a fifth of a site off tone at f282 and they are not. mean 0.1280 against "
                    "0.1321 (double swap) and 0.1429 (the 2/13 swap alone).",
                    block=R(1, 13), for_tr=["X1", 277, 283]))
refit(n, fr(276, 284), 277.0, 283.0, "the block is on tones at f277 and f283")
measure(n, fr(276, 284))
drop_undetermined("X1", 277, 283)

# ---- 62. f284-287 X1 cols (UNDETERMINED)
n = insert(new_move("X1", "cols", "permutation", 284, 287,
                    [[[3], [6]], [[6], [3]], [[9], [12]], [[12], [9]]], R(31, 45),
                    "UNDETERMINED X1 cols f283-288. Four columns leave their tones -- 3, 6, 9, 12 -- and on "
                    "the first moving frame f284 their deltas are +0.22, -0.20, +0.20, -0.28: equal "
                    "magnitudes with alternating signs. For a permutation of {3,6,9,12} that forces a common "
                    "|d| = 3 and therefore the two swaps 3<->6 and 9<->12 (|d| = 6 and 9 send a column off "
                    "the block). mean 0.0779 free 0.0857 against the 4-cycle 3->6->9->12->3 at free 0.1064.",
                    block=R(1, 13), for_tr=["X1", 283, 288]))
refit(n, fr(282, 290), 283.0, 289.0, "the block is on tones at f283 and f288")
measure(n, fr(282, 290))
drop_undetermined("X1", 283, 288)
```

### Item 63 — f335-f351, D1 (Z0 on cols 1:13 × rows 1:15). Two sub-comb moves written as one

`logs\lp_Z0_c335.txt` shows two sub-comb column rotations, not one:

| frames | comb | rotation |
|---|---|---|
| 335-341 | rows **2, 5, 8, 11, 14** | +3, `1:10->4:13 \| 11:13->1:3` — **missing from the book** |
| 343-350 | rows **3, 6, 9, 12, 15** | +12, `1->13 \| 2:13->1:12` — the book's map, on the wrong comb and window |

The book has a single move `Z0 cols f337-350` whose comb is the union of the two plus row 4
(`2,3,4,5,6,8,9,11,12,14,15`), so in the rebuild eleven of the fifteen rows do the +12 rotation and the +3 one
never happens. Scanned: f335-341 k=+3 **mean 0.0929, free 0.0449** (k=+4 0.1334, k=+2 0.1507); f343-350 k=+12
**mean 0.0275, free 0.0243** (k=+10 0.0738, k=+11 0.0849).

The move at f335-341 starts inside the rest (334,337), so retime the transition f337-348 to f334-348 and both
moves hang off it.

```python
# ---- 63. f335-350 Z0 cols: two sub-comb rotations, not one merged move
retime_transition("Z0", 337, 348, 334, 348)
m = moves[find("Z0", "cols", 337, 350)]
do_rot(m, "Z0", 1, 13, 12, [3, 6, 9, 12, 15], 343, 350,
       "the map (+12) is right but the comb is the union of TWO sub-combs plus row 4 "
       "(2,3,4,5,6,8,9,11,12,14,15), so the rebuild turns eleven of the fifteen rows when the movie turns "
       "five. The movie has two moves here: rows 2,5,8,11,14 rotate by +3 over f335-f341 and rows "
       "3,6,9,12,15 by +12 over f343-f350 (logs\\lp_Z0_c335.txt). This is the second. Scanned: k=+12 mean "
       "0.0275 vs k=+10 0.0738, k=+11 0.0849. Javier: 'f335-f351 missing or wrong moves in D1'.")
add_rot("Z0", 0, 1, 13, 3, [2, 5, 8, 11, 14], 335, 341, R(1, 15),
        "MISSING: the first of Z0's two sub-comb column rotations after it returns to cols 1:13, on rows "
        "2,5,8,11,14. Scanned: k=+3 mean 0.0929 free 0.0449 vs k=+4 0.1334, k=+2 0.1507.",
        for_tr=["Z0", 334, 348])
```

---

## 2. What is still NOT resolved — do not invent a map for these

1. **X0 cols f153-f157** (inside Javier's f145-f165 window). Five or six of X0's thirteen columns permute;
   the empty-tone set grows from {5,12} at f153 to {2,3,5,6,7,12} by f157, the peaks cross and merge, and no
   cyclic rotation fits (every one of the twelve measures 0.128-0.131). The other two moves of that window are
   items 53 and 54 above, so after applying them this is the only gap left in f145-f165. It will need frame
   crops (`crop.py`) and the outline classes rather than profiles.
2. **Z0 cols f278-f282 and Z1 cols f284-f289** (inside Javier's f278-f290 window). These are the SAME
   movement seven frames apart — Z1's empty-tone set at f288 and f289 is Z0's at f281 and f282, and their
   column deltas agree to two hundredths — so reading either settles both. Eight or nine of the thirteen
   columns move; the residuals at the landing frames do not share one progress under any bijection tried, so
   it is probably two moves with different timings inside one transition. `Z1 f283-290` is already NAMED as an
   undetermined hole in the s32 book (so the audit stays clean); `Z0 f277-283` is the solver's own.
3. The other undetermined transitions from the first pass: X1 f126-128 (a 2-frame window) and X0 f152-158.

After items 52-63 the undetermined count goes from 7 to 4 (X1 f126-128, X0 f152-158, Z0 f277-283,
Z1 f283-290).

---

## 3. The evidence table you will want to quote (X0 columns, f183-f212)

`python gaps.py X0 0 183 212 1 13 0.4 13.6 30.4 45.6` — "EMPTY" is the set of the block's tones with no
marker within 0.15 site, i.e. the columns in flight.

```
f184 [p]  13 peaks | EMPTY -              | off-tone -
f185      12 peaks | EMPTY 2,7,13         | off-tone 6.61 12.55
f186      11 peaks | EMPTY 2,4,7,12,13    | off-tone 4.18 11.73 12.20
f188      11 peaks | EMPTY 2,7,13         | off-tone 9.43
f190      12 peaks | EMPTY 2,7,13         | off-tone 2.37 7.44
f191      13 peaks | EMPTY -              | off-tone -          <- X0 at rest (item 56)
f192      13 peaks | EMPTY -              | off-tone -          <- X0 at rest (item 56)
f193      11 peaks | EMPTY 1,10,11        | off-tone 10.21
f196      11 peaks | EMPTY 1,5,10,11      | off-tone 4.81 10.72
f198      13 peaks | EMPTY 1,10           | off-tone 1.50 9.53
f199      13 peaks | EMPTY -              | off-tone -
f201      12 peaks | EMPTY 4,6,12         | off-tone 4.28 6.56
f204      11 peaks | EMPTY 4,6,11,12      | off-tone 5.65 10.83
f205      13 peaks | EMPTY 4,12           | off-tone 4.46 11.63
f206      13 peaks | EMPTY -              | off-tone -
f207      13 peaks | EMPTY 5              | off-tone 5.24
f209      11 peaks | EMPTY 5,7,8,9        | off-tone 7.18 8.43
f210      12 peaks | EMPTY 5,8,9          | off-tone 5.35 8.40
f211      13 peaks | EMPTY -              | off-tone -
```

`gaps.py` is the tool that made all six items readable and it is worth reaching for first on any
small permutation: a column that leaves tone a and has not reached tone b shows BOTH as empty, so the
empty set over a window IS the set of moving columns, and the off-tone peaks near the last moving frame say
which side each destination is approached from.

---

## 4. Run it

```powershell
cd run_c975_s32
python -u apply_s32.py > apply_s32.log 2>&1
python ..\.claude\skills\se-cycle-blocks\tools\sb_audit.py --moves moves_full.json --rests rests_full.json   # must stay AUDIT CLEAN
python ..\.claude\skills\se-cycle-movies\tools\se_sim.py c975_s32_blocks.xlsx                                # validation clean, census 780
python ..\.claude\skills\se-cycle-blocks\tools\cmp_tol.py ..\run_c975\moves_full.json moves_full.json > s32_vs_c975.txt
python make_list_s32.py
Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-Command',"Set-Location '<abs>\run_c975_s32'; .\deliver_s32.ps1 *> deliver_s32.log" -WindowStyle Hidden   # ~42 min
```

Then copy `c975_s32_blocks.xlsx` and both mp4s to the project root again (same names, they overwrite), and
give Javier the new video. Expect the score to fall from 0.0606; the four X0 column windows of f185-f212 and
the three of f145-f165 are seven of the ten remaining `sb_watch` runs that are not reservoir staging.

**Standing rules:** never change the skill's `tools/`; never write into `run_c975\`; edit the move list and
re-emit, never xlsx cells; a sub-comb move must set BOTH `comb` and `sub_comb_lines` (see
`SESSION_32_C975_HAND_CORRECTIONS.md` §6.1 — only the score notices if you get this wrong).
