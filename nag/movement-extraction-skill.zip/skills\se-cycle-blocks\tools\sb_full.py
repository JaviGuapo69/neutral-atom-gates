"""sb_full.py -- a WHOLE MOVIE -> one workbook.  This is the tool to run for a new movie.

It runs `sb_build`'s chain once per pulse-free INTERVAL, bounded by the pulse runs either side, then
merges the twelve-or-so results and colours the AOMs ONCE over the merged rows.

    python sb_blocks.py --calib calib.json --out blocks.json
    python sb_full.py   --calib calib.json --blocks blocks.json --work . \
                        --xlsx out.xlsx [--extra readouts.json]

WHY NOT IN ONE PASS -- this is the single most important operational fact in this skill.

`sb_build` sizes each species' window as that species' bounding box over the range it is given.
Over a whole movie those boxes grow to cover the panel and overlap each other: on c150 they came
out X0 cols -0.69..6.58, X1 0.42..12.60, Z0 -0.88..12.60, Z1 -0.84..12.60, so Z0's window contains
all of Z1 and X1's contains all of X0.  The FILL masks are per species and survive that, but the
OUTLINE mask is shared across the whole panel, so the appearance read attributes one species'
outline to another and the partitions are nonsense (SKILL.md 1a: "it reported X1's move as Z1's").

Rule 9 makes the fix free: every move lies entirely inside one pulse-free interval, so nothing is
lost by solving one interval at a time, and each interval's windows are tight.  Verified on c150 --
the first two segments reproduce the independently verified frames 0-49 answer exactly.

The segment bounds are derived from the movie's own pulse runs, not configured: for interval (a, b)
the segment is (start of the preceding pulse run, end of the following pulse run).  The bounding
pulse frames must be INCLUDED, because a configuration that exists only on a pulse frame is still a
configuration (rule 15) and is the only thing that makes a move which begins at the seed, or ends
at a pulse, enumerable at all.
"""
import argparse, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sb_read, sb_compose, sb_emit, sb_build, sb_rigid, sb_gaps
from sb_read import Movie, comb

# SESSION 26: after the production chain has run on a segment, the PATCH DETECTOR (sb_gaps) looks
# for sub-comb batches occupancy could not enumerate and solves them with the production routes on
# peaks restricted to the detected comb.  Set from --gaps.  Inert on a movie with no sub-comb move.
GAPS = True


READOUT_JUMP = 3.0        # x: the area ratio that counts as a collapse or a jump (sb_events.JUMP)
READOUT_FLOOR = 300       # px: below this there is effectively nothing of that colour


def readout_bridges(M, trs, events):
    """Transitions that look like a READOUT + LOAD pair rather than one rigid motion.

    `build()` refuses to fit a transition named in `--events`, because a departing block and its
    replacement are not one rigid body.  NOTHING, HOWEVER, CHECKED THAT THE ANALYST HAD ACTUALLY
    NAMED THEM -- and until this was written the Procedure discovered them in step 6, AFTER this
    tool ran.  So a first pass silently produced a wrong answer, and on c300 it produced BOTH
    failure modes at once (session 22, adjudicated on the pixels):

      * the unnamed Z readout at the f147-148 pulse became a transition `Z1 rows 13:18 -> 7:12`.
        No rigid motion connects a departing block to its replacement, so the solver reached into
        the overlapping window and re-emitted a NEIGHBOURING block's column rotation to fill it --
        `X0 cols f149-187`, a duplicate of a real move over a wider window, scored 3.0993 site
        against the 0.10 bar and written to the sheet anyway with ok=false;
      * the unnamed X readout at the f328 pulse was simply left UNDETERMINED, twice.

    The signature is `sb_events.py`'s, applied to the two frames either side of the transition's
    own start instead of to all 384: the species' SOLID area collapses while its FADED area jumps.
    Read ACROSS the pulse the transition starts on -- a gate frame's tint makes both masks
    meaningless (sb_events skips gate frames throughout), so compare the last clean frame at or
    before the start with the first clean frame at or after it.  A transition that does not begin
    at a pulse has fa == fb and is skipped, which is why this costs a handful of `area` calls
    rather than the full 4 x 384 scan that `sb_events` does.

    This REPORTS; it does not skip.  Which transitions are readouts is a measurement the analyst
    confirms with `sb_probe --peaks` on the FADED track before naming them (SKILL.md 7), and
    changing what the solver enumerates on a guess is how a closed movie gets broken.
    """
    vc, vr = M.K["visible_col"], M.K["visible_row"]
    win = (vc[0] - 0.5, vc[1] + 0.5, vr[0] - 0.5, vr[1] + 0.5)
    out = []
    for tr in trs:
        fa = next((f for f in range(tr["f0"], -1, -1) if f not in M.gate), None)
        fb = next((f for f in range(tr["f0"], min(tr["f1"], M.nf - 1) + 1) if f not in M.gate),
                  None)
        if fa is None or fb is None or fa == fb:
            continue                      # no pulse at this transition's start, so no readout here
        sp = tr["sp"]
        sa, sb = M.area(M.fill[sp], win, fa), M.area(M.fill[sp], win, fb)
        da, db = M.area(M.faded[sp], win, fa), M.area(M.faded[sp], win, fb)
        if sa > READOUT_FLOOR and sb < sa / READOUT_JUMP \
                and db > max(READOUT_FLOOR, da * READOUT_JUMP):
            named = bool(events) and any(e["sp"] == tr["sp"] and e["f0"] <= tr["f0"]
                                         and tr["f1"] <= e["f1"] for e in events)
            out.append(dict(tr=tr, fa=fa, fb=fb, sa=sa, sb=sb, da=da, db=db, named=named))
    return out


def segments(runs, ivs):
    """(f0, f1) per pulse-free interval: from the pulse run before it to the pulse run after it."""
    out = []
    for a, b in ivs:
        before = [r for r in runs if r[1] < a]
        after = [r for r in runs if r[0] > b]
        out.append((before[-1][0] if before else a, after[0][1] if after else b))
    return out


def solve_segment(M, f0, f1, blocks, verbose=True, events=None):
    """sb_build's chain over one segment, with that segment's own tight windows.

    RULE 35 APPLIES TO THE WINDOW TOO -- BUT ONLY TO THE EDGE WINDOW (c540, session 16).  A
    segment begins and ends on a bounding pulse run, and `settled`'s rule-9 deduction reads the
    frame just OUTSIDE it -- that is what `sb_build.EdgePeaks` exists for.  But `species_windows`
    was given the segment's own bounds and skips gate frames, so the window is a box around the
    segment's NON-PULSE frames only.  Where a species' rest lives just outside the segment, and
    inside the segment exists only on the bounding pulse frames (rule 15/37 -- exactly the case
    the deduction is for), the window can miss it by a hair and the deduction fails at the one
    frame it matters.

    WIDENING THE MAIN WINDOW INSTEAD IS WRONG, AND c150 SAYS SO.  Measuring `wins` itself over
    [f0-1, f1+1] fixes c540's exchange and breaks c150: in segment 10 the extra frame grows X1's
    box far enough that the SHARED OUTLINE MASK reaches another species, and the gold class comes
    back with EIGHT members on a six-column block -- `cols f307-313 members travel
    [-2,-2,2,2,2,2,2,2], SPLIT into 3:4->1:2 and 5:10->7:12` -- so X1's real `1:2 <-> 3:4` swap at
    f306-313 is lost.  That is this file's own opening warning (SKILL.md 1a) biting.  So the
    segment keeps its TIGHT window for every measurement, and only `EdgePeaks` -- one peak list
    per species per edge frame, used by nothing but the deduction -- gets the wider one.

    c540's Z0/Z1 exchange is that case, and it lost BOTH halves.  Z0 and Z1 swap `13:24 <-> 1:12`
    on rows 19:27 over f060-069, passing through each other.  In segment 2 (f58..97) Z0 stands on
    13:24 only on the gate frames f058-059, so the box came out cols 0.43..23.98 and clipped its
    col 24 peak at 24.01; Z1's came out 1.01..24.62 and clipped its col 1 peak at 0.98.  Both edge
    reads of f057 then returned ELEVEN columns, `rect_at` could not complete a clipped rectangle
    that is not at a panel edge, the deduction returned None for both, and `rect_on_pulse` fell
    through to the shared outline mask -- which handed each species the block the OTHER was
    standing on (rule 23).  The post-exchange configuration was therefore recorded one interval
    early, the exchange itself became invisible, and `sb_audit` reported 432 site clashes at f058.

    Measuring the window over [f0-1, f1+1] costs two frames of peaks and cannot create a rest or a
    transition outside the segment, exactly as rule 35 says of the deduction it serves.
    """
    runs = sb_compose.pulse_runs(M)
    ivs = sb_compose.free_intervals(runs, M.nf)
    # The SEGMENT window keeps its non-pulse bounding box.  Widening it to the segment's OWN gate
    # frames was tried on c540 and is a NET LOSS, so it is recorded here as measured rather than
    # left as an obvious-looking idea for the next session to re-try: it does NOT recover
    # `Z0 cols 13:24 -> 1:12` at f316-327 (undetermined either way, though the clipped window is
    # what stops `uniform_displacement` ever seeing a full 12-column block there), and it costs
    # `Z1 rows f069..f078` -- 78 moves down to 77, 7 undetermined up to 8.  c150 is unmoved by it.
    # Only the EDGE window below takes skip_gate=False, because that one reads pulse-frame
    # configurations and nothing else.
    wins = sb_compose.species_windows(M, f0, f1)
    # skip_gate=False: a pulse-frame configuration must be inside the window used to read it
    edge_wins = sb_compose.species_windows(M, max(0, f0 - 1), min(M.nf - 1, f1 + 1),
                                           skip_gate=False)
    frames = [f for f in range(f0, f1 + 1) if f not in M.gate]
    outlines = sb_read.discover_outlines(M, frames[:40], (0.4, M.K["data_cols"] + 0.6,
                                                          0.4, M.K["data_rows"] + 0.6))
    if verbose:
        print("   windows: %s" % {k: tuple(round(x, 2) for x in v) for k, v in sorted(wins.items())})
        print("   outlines: %s" % ", ".join("rgb(%.0f,%.0f,%.0f)" % c for c in outlines))
    P = sb_compose.Peaks(M, wins, f0, f1)
    bl = {k: tuple(v) for k, v in blocks.items() if k in wins}
    rests = sb_build.settled(P, M, f0, f1, bl, wins, outlines, verbose=False,
                             edge_wins=edge_wins)
    out = sb_build.build(M, P, wins, bl, rests, runs, ivs, f0, f1, outlines, verbose=False,
                         events=events)
    moves, undet, evidence, notes, readouts = out
    if GAPS:
        new, undet, gnotes, ndet = sb_gaps.fill(M, wins, bl, rests, runs, ivs, f0, f1, outlines,
                                                moves, undet, verbose=verbose)
        notes += gnotes
        if verbose:
            print("   patch detector: %d sub-comb group(s) -> %d move(s) added, %d undetermined "
                  "remain" % (ndet, len(new), len(undet)))
    return rests, moves, undet, evidence, notes, readouts


def merge(per_segment):
    """One movie's rests / transitions / moves from the per-segment results.

    Consecutive segments share a pulse run, so the rest that lives on it -- and any transition
    touching it -- is read twice.  Dedup on identity, then fuse rests that are adjacent and equal.
    """
    rests, moves, undet, evidence, notes, readouts = {}, [], [], [], [], []
    for (f0, f1), (r, m, u, e, n, ro) in per_segment:
        for nm, v in r.items():
            d = rests.setdefault(nm, dict(rests=[], transitions=[]))
            d["rests"] += [list(x) for x in v["rests"]]
            d["transitions"] += v["transitions"]
        moves += m
        undet += u
        evidence += e
        for t in ro:
            if not any(q["sp"] == t["sp"] and q["f0"] == t["f0"] and q["f1"] == t["f1"]
                       for q in readouts):
                readouts.append(t)
        notes += ["[f%03d-%03d] %s" % (f0, f1, x) for x in n]

    for nm, v in rests.items():
        seen, keep = set(), []
        for x in sorted(v["rests"], key=lambda x: (x[0], x[1])):
            k = (x[0], x[1], tuple(x[2]), tuple(x[3]))
            if k in seen:
                continue
            seen.add(k)
            keep.append(list(x))
        fused = []
        for x in keep:
            if (fused and fused[-1][2] == x[2] and fused[-1][3] == x[3]
                    and x[0] <= fused[-1][1] + 1):
                fused[-1][1] = max(fused[-1][1], x[1])
            else:
                fused.append(list(x))
        v["rests"] = fused
        seen, keep = set(), []
        for t in sorted(v["transitions"], key=lambda t: t["f0"]):
            k = (t["f0"], t["f1"], tuple(t["x0"]), tuple(t["y0"]),
                 tuple(t["x1"]), tuple(t["y1"]))
            if k in seen:
                continue
            seen.add(k)
            keep.append(t)
        v["transitions"] = keep

    seen, keep = set(), []
    for mv in sorted(moves, key=lambda m: (m["fa"], m["fb"], m["sp"])):
        k = (mv["axis"], mv["sp"],
             tuple(tuple(tuple(v) for v in p) for p in (mv.get("parts") or [])),
             tuple(mv["comb"] or []), round(mv["fa"], 1))
        if k in seen:
            continue
        seen.add(k)
        keep.append(mv)
    return rests, keep, undet, evidence, notes, readouts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--blocks", required=True, help="from sb_blocks.py -- see rule 22")
    ap.add_argument("--work", default=".")
    ap.add_argument("--xlsx", default="")
    ap.add_argument("--extra", default=None,
                    help="JSON list of hand-measured unload/load rows (sb_extra.py, SKILL.md 7)")
    ap.add_argument("--only", default="", help="solve only these segment indices, e.g. 0,1")
    ap.add_argument("--pulse-bound", choices=("last", "first"), default="first",
                    help="which frame of a pulse RUN a move may start on. 'first' is the DEFAULT "
                         "and is right: a Rydberg pulse is far faster than the atoms move, so a "
                         "multi-frame run is one instantaneous gate whose display the animation "
                         "holds. 'last' reproduces sessions 9-14 (c150 and c200 were built that "
                         "way). See sb_rigid.PULSE_BOUND_FIRST for the measurements")
    ap.add_argument("--stationary-rest", choices=("on", "off"), default="on",
                    help="accept a LONE on-grid frame as a rest when the block is measurably "
                         "stationary there (sb_build.stationary). 'on' is the DEFAULT and is "
                         "right: 'two consecutive on-grid frames' is only a proxy for 'the block "
                         "is not moving', and a PIPELINED movie chains moves so tightly that the "
                         "proxy never fires. 'off' reproduces sessions 9-15")
    ap.add_argument("--events", default=None,
                    help="JSON list of the READOUT / LOAD transitions, as "
                         '[{"sp": "Z0", "f0": 156, "f1": 185}, ...].  Section 7 measures these by '
                         "hand; a departing block and its replacement are not one rigid motion, "
                         "so the automatic solver must not be allowed to fit them -- on c150 it "
                         "produces two spurious moves in f123-165 if it is.  sb_events.py finds "
                         "them; confirm each with sb_probe --peaks before listing it here")
    ap.add_argument("--gaps", choices=("on", "off"), default="on",
                    help="after the production chain, run the PATCH DETECTOR (sb_gaps) on each "
                         "segment for sub-comb batches occupancy cannot enumerate. 'on' is the "
                         "default; 'off' reproduces the production se-cycle-blocks behaviour")
    a = ap.parse_args()
    events = json.load(open(a.events)) if a.events else None
    sb_rigid.PULSE_BOUND_FIRST = (a.pulse_bound == "first")
    sb_build.STATIONARY_REST = (a.stationary_rest == "on")
    global GAPS
    GAPS = (a.gaps == "on")
    print("patch detector     : %s" % a.gaps)
    print("pulse bound        : a move may start on the %s frame of a pulse run" % a.pulse_bound)
    print("stationary rest    : %s" % a.stationary_rest)
    print("readout / load     : %s" % (a.events if a.events else
          "NO --events GIVEN. Run sb_events.py FIRST (Procedure step 3a): a readout bridged to its "
          "load is not a rigid motion, and left unnamed it is either fitted to something else or "
          "left undetermined. Every candidate is listed at the end of this run"))

    M = Movie(a.calib, a.frames)
    runs = sb_compose.pulse_runs(M)
    ivs = sb_compose.free_intervals(runs, M.nf)
    segs = segments(runs, ivs)
    blocks = json.load(open(a.blocks))
    want = {int(v) for v in a.only.split(",") if v.strip()} if a.only else None

    print("movie: %d frames, dt %.9f ms, cycle %.4f ms" % (M.nf, M.dt, M.nf * M.dt))
    print("pulse runs         : %s" % runs)
    print("pulse-free windows : %s" % ivs)
    print("block sizes        : %s" % blocks)
    print("%d segments, one per pulse-free interval: %s" % (len(segs), segs))

    per = []
    for i, (f0, f1) in enumerate(segs):
        if want is not None and i not in want:
            continue
        print("\n=========== segment %d: frames %d..%d  (interval %s)" % (i, f0, f1, ivs[i]),
              flush=True)
        r, m, u, e, n, ro = solve_segment(M, f0, f1, blocks, events=events)
        ntr = sum(len(v["transitions"]) for v in r.values())
        print("   %d transitions -> %d moves, %d undetermined" % (ntr, len(m), len(u)))
        for mv in m:
            print("     %-7s %-4s f%03d-%03d  %-30s t %.4f-%.4f  comb %-10s mean %.4f %s"
                  % ("+".join(mv["joins"]) or mv["sp"], mv["axis"], mv["f0"], mv["f1"],
                     " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in (mv.get("parts") or [])),
                     mv["t0"], mv["t1"], comb(mv["comb"] or []), mv["mean"],
                     "OK" if mv["ok"] else "OVER 0.10"))
        for t in u:
            print("     *** UNDETERMINED %-3s %-11s f%03d..f%03d  x %s -> %s  y %s -> %s"
                  % (t["sp"], t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                     comb(t["y0"]), comb(t["y1"])))
        for x in n:
            print("     note: %s" % x)
        per.append(((f0, f1), (r, m, u, e, n, ro)))

    rests, moves, undet, evidence, notes, readouts = merge(per)
    ntr = sum(len(v["transitions"]) for v in rests.values())
    rows = sb_compose.schedule_rows(moves)
    ng, peak = sb_compose.allocate_aom(rows)

    print("\n" + "=" * 78)
    print("WHOLE MOVIE: %d transitions, %d moves, %d undetermined, %d readout/load (hand-measured)"
          % (ntr, len(moves), len(undet), len(readouts)))
    if readouts:
        print("\n%d transition(s) held back as READOUT / LOAD -- section 7 measures these by hand "
              "(sb_events.py finds them, sb_extra.py fits them); the automatic solver invents a "
              "move for them if it is allowed to try:" % len(readouts))
        for t in readouts:
            print("    %-3s %-11s f%03d..f%03d  x %s -> %s  y %s -> %s"
                  % (t["sp"], t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                     comb(t["y0"]), comb(t["y1"])))
    print("             %d schedule rows from the moves; %d AOM groups, peak %d (before the "
          "hand-measured rows)" % (len(rows), ng, peak))
    if undet:
        print("\n*** %d transitions NOTHING DESCRIBES -- the movie shuffles a block and the sheet "
              "does not say so. Probe each one with sb_probe.py before believing the sheet:"
              % len(undet))
        for t in undet:
            print("    %-3s %-11s f%03d..f%03d  x %s -> %s  y %s -> %s"
                  % (t["sp"], t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                     comb(t["y0"]), comb(t["y1"])))
    over = [m for m in moves if not m["ok"]]
    if over:
        print("\n%d moves over the 0.10 site guideline (expected at crossings and where a block "
              "leaves the panel; check each against the outline profiles):" % len(over))
        for m in over:
            print("    %-7s %-4s f%03d-%03d  mean %.4f" % ("+".join(m["joins"]) or m["sp"],
                                                           m["axis"], m["f0"], m["f1"], m["mean"]))

    # The readout check.  Run it ALWAYS, not only when --events is absent: an events file that
    # names three of the four readouts is the same defect, and harder to spot.
    trs_all = sorted([t for nm in rests for t in rests[nm]["transitions"]],
                     key=lambda t: (t["f0"], t["sp"]))
    missed = [b for b in readout_bridges(M, trs_all, events) if not b["named"]]
    if missed:
        print("\n" + "!" * 78)
        print("*** %d transition(s) carry a READOUT signature and are NOT named in --events."
              % len(missed))
        print("    A departing block and its replacement are not one rigid motion, so whatever "
              "this run")
        print("    did with them is wrong in one of two ways, and BOTH are quiet: a spurious move "
              "fitted")
        print("    from a neighbouring block (c300's X0 cols f149-187 scored 3.0993 site and was "
              "written")
        print("    anyway), or an undetermined transition (c300's X carry-ins at f328-383).")
        print("    Confirm each on the FADED track with sb_probe.py --peaks, then list it in "
              "--events")
        print("    and re-run. sb_events.py --calib calib.json does the movie-wide search.")
        for b in missed:
            t = b["tr"]
            print("    %-3s %-11s f%03d..f%03d   solid %6d -> %-6d  faded %6d -> %-6d  "
                  "(read f%03d -> f%03d, across the pulse)"
                  % (t["sp"], t["kind"], t["f0"], t["f1"], b["sa"], b["sb"], b["da"], b["db"],
                     b["fa"], b["fb"]))
        print("!" * 78)

    mv = dict(moves=moves, undetermined=undet, readouts=readouts, aom_groups=ng, aom_peak=peak,
              blocks={k: list(v) for k, v in blocks.items()}, evidence=evidence, notes=notes)
    p = os.path.join(a.work, "moves_full.json")
    json.dump(mv, open(p, "w"), indent=1, default=str)
    json.dump(rests, open(os.path.join(a.work, "rests_full.json"), "w"), indent=1, default=str)
    print("\nwrote %s" % p)

    if a.xlsx:
        sb_emit.emit(a.xlsx, M, mv, rests, runs,
                     sb_compose.Peaks(M, sb_compose.species_windows(M, 0, M.nf - 1), 0, M.nf - 1),
                     0, M.nf - 1, extra=a.extra,
                     scope_note="the WHOLE movie: frames 0-%d, t = 0 .. %.4f ms, all %d pulse runs"
                                % (M.nf - 1, (M.nf - 1) * M.dt, len(runs)))


if __name__ == "__main__":
    main()
