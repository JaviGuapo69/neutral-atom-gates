"""alt_boundary.py -- where to put the boundary between Z0's column move and the row batch.

Rule 14: two boundaries within ~1.5 frames are one boundary measured twice, and the merged
boundary goes WHERE IT COSTS LEAST, not at the cluster mean.  Z0 cols f137-152 wants to finish at
f151.5 (its own free fit; at f150.43 it is 0.4 site ahead of the movie mid-move) and the Z0 / Z1
row descents want to start at f150.43.  Overlapping them costs a crossed pair (the AOM peak goes
2 -> 4 on a 2-AOD machine), so one boundary has to serve all three.  This scans it.
"""
import json, os, sys

sys.path.insert(0, os.path.join("..", "..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_compose
from sb_read import Movie

M = Movie("calib.json")
mv = json.load(open("moves_full_auto_original.json", encoding="utf-8"))
moves = mv["moves"]
runs = sb_compose.pulse_runs(M)
wins = sb_compose.species_windows(M, 0, M.nf - 1)
P = sb_compose.Peaks(M, wins, 0, M.nf - 1)


def get(sp, axis, f0, f1):
    return [m for m in moves if (sp in m["joins"] or m["sp"] == sp) and m["axis"] == axis
            and m["f0"] == f0 and m["f1"] == f1][0]


c = get("Z0", "cols", 137, 152)
r0 = get("Z0", "rows", 152, 167)
r1 = get("Z1", "rows", 152, 167)
fc = [f for f in range(136, 153) if f not in M.gate]
fr0 = [f for f in range(150, 170) if f not in M.gate]


def err(m, fa, fb, frames, axis):
    mean, worst, n = sb_compose.verify(P, m["sp"], axis, m["src"], m["dst"], fa, fb, frames, M)
    return mean, worst


print("boundary   Z0 cols(f135.40->b)   Z0 rows(b->f167.66)   Z1 rows(b->f167.66)   sum")
best = None
for i in range(0, 25):
    b = 150.30 + 0.05 * i
    ec, wc = err(c, 135.40, b, fc, 0)
    e0, w0 = err(r0, b, r0["fb"], fr0, 1)
    e1, w1 = err(r1, b, r1["fb"], fr0, 1)
    s = ec + e0 + e1
    flag = ""
    if best is None or s < best[1]:
        best, flag = (b, s), "  <<"
    print("  f%.2f      %.4f (worst %.3f)      %.4f (%.3f)      %.4f (%.3f)      %.4f%s"
          % (b, ec, wc, e0, w0, e1, w1, s, flag))
print("\nbest boundary f%.2f, sum %.4f" % best)
print("for reference: the automatic book has cols f135.34-150.43 (0.1935) and the rows from "
      "f150.43 (0.0540 / 0.0291)")
