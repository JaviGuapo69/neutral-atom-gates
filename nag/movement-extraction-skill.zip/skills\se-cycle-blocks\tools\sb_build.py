"""sb_build.py -- movie window -> workbook, automatically.  THE TRANSCRIBER.

This is the whole measurement chain in one pass, and it is the tool to run.  It replaces the
hand route that SKILL.md used to prescribe ("enumerate with --transitions, take the partitions the
outline names from sb_read.py --solve, read the remainder off the crossing pattern by hand"), and
it replaces sb_compose.py's --solve entirely, which searched a candidate library instead of
measuring displacements (SB_COMPOSE_OPEN_BUG.md).

    1  SETTLED CONFIGURATIONS  per species, by rest-frame occupancy (rule 2), INCLUDING the
       configurations that exist only on a pulse frame -- read there from the outline colours when
       the tint has corrupted the fill.  Without this the transitions that begin at the seed or end
       at a pulse are never enumerated at all.
    2  TRANSITIONS            endpoints differ = relocation, endpoints identical = same-site
       permutation (rule 12).  Enumerated from occupancy, never from the outline.
    3  PARTITION              by the APPEARANCE TRIPLE: atoms sharing shape + fill + outline move
       as one rigid body (3z).  A direct read, with the rigidity residual as its own proof.
    4  DISPLACEMENT           one uniform integer displacement per class -- all a crossed AOD pair
       can do (3a).  Read on the pre-crossing frames, where peaks are still resolved and ordered.
    5  TIMING                 one easing per move, fitted under the pulse constraint (rule 9),
       then near-coincident boundaries reconciled without leaving the interval (rule 14).
    6  RECTANGLE              grown across species (5): species belongs to the atom, not the row.
    7  AOM                    interval colouring, lowest free index (rule 8 / 6).
    8  WORKBOOK               sb_emit's six sheets.

Usage:
    python sb_build.py --calib calib.json --f0 0 --f1 49 --work . --xlsx out.xlsx
    python sb_build.py --calib calib.json --work . --xlsx c150_full.xlsx        # whole movie
    python sb_build.py ... --extra readouts.json      # unload/load rows measured by hand (7)

Everything it cannot measure it reports: UNDETERMINED transitions, NOT RIGID classes, and TIEs
where more than one grouping is equally minimal.  Never present any of those as measured.
"""
import argparse, json, math, os, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sb_read, sb_compose, sb_rigid, sb_emit
from sb_read import Movie, comb

TOL_PULSE = 0.15        # site: on-tone tolerance for a configuration read on a PULSE frame
ARRIVED = 0.25          # site: the last frame of a partition read must be an arrival, not in flight
COARSE, FINE = 0.25, 0.02

# SESSION 25 EXPERIMENT (2026-09-15): the session-17 S2.1 "one tone short" competition, applied to
# the PRODUCTION baseline (the reset target that reproduces c150 55/55 and c300 64/64) and nothing
# else -- no FIT_PAD, no restructure of the measured route.  The ONLY behavioural change is inside
# build(): when the appearance read holds a tone static that `moving_tones` says provably moves,
# the appearance map is put up against the rotations of the measured moving run and the measured
# displacement candidates, and the same verified error decides.  Where the measurement confirms the
# appearance read, the production code path runs byte-for-byte unchanged.
S21_COMPETITION = True
MOVING_TONE_SEP = 0.30         # no peak can be said to sit on a tone this far away (= MERGE_SEP)
ROTATION_NOISE = 0.03          # site: a 3+-part same-site read must beat the best two-group rotation
                               # of its comb by more than this (crossing noise) to be preferred

# Accept a LONE on-grid frame as a rest when the block is measurably stationary there (see
# `stationary`).  `False` reproduces sessions 9-15, where the only escape hatch was adjacency to a
# pulse.  Set from sb_full's --stationary-rest, the same way PULSE_BOUND_FIRST is.
STATIONARY_REST = True


# ===================================================================== 1. settled configurations
def rect_on_pulse(M, sp, win, f, block, outlines):
    """the species' rectangle on a PULSE frame, or None.

    A pulse frame shows the state AT that instant, so it is the most reliable rest there is -- but
    the tint moves every fill colour ~40 RGB and the fill mask comes back wrong or empty.  On c150's
    f000-001 the fill gives Z0 four peaks where there are six.  The OUTLINE colours are not shifted
    the same way and read all six cleanly, so: try the fill, then every outline, and accept the
    first that is a full block on tones.  This is what makes the seed transition and any move that
    ends at a pulse enumerable at all.

    TWO EXTENSIONS, BOTH TRIED ONLY AFTER THE READ ABOVE HAS FAILED, so neither can change an
    answer the palette already gives.  c300's Z0 at f046-047 needs both, and without them
    `Z0 1:10 -> -9:0` is never enumerated at all: that configuration exists on no other frame,
    because Z0's rows arrive exactly AT the pulse and its columns leave one frame after it, so Z1's
    half of the exchange went into the sheet alone -- two blocks on one another's sites, rule 35.

    1. THE COLOURS ARE MEASURED ON THE FRAME, not assumed.  The fill is not gone under the tint, it
       has MOVED, and by more than the palette tolerance: Z0 renders at rgb(87,120,151) here, 77 RGB
       from its rgb(41,119,213), so the mask catches 63 pixels of ~7800 and reads nine of ten
       columns.  `discover_outlines` cannot supply that colour because it skips gate frames, which
       is exactly where it lives.  `sb_read.colours_on_frame` clusters what is actually there.

    2. THE TWO AXES NEED NOT COME FROM THE SAME COLOUR.  A rectangle is the product of two
       independent axis reads and rule 1 fixes its size, so requiring one colour to resolve both is
       an implementation restriction rather than a rule.  Here the palette fill reads all six ROWS
       on tones (12.97..18.06) and only nine columns.

    The guard against rule 23 -- the mask is shared across the panel, so a read can return ANOTHER
    species' block -- is the species' own fill: whatever the tint has left of it is self-evidence,
    and an accepted axis read must CONTAIN every on-tone peak the fill itself shows.  Another
    species' block stands somewhere else and fails that test; a partial read of this species' own
    block passes it by construction.  `drop_pulse_collisions` is still the backstop.
    """
    w, h = block
    need = {0: w, 1: h}

    def on_tones(pk, n):
        return len(pk) == n and all(abs(v - round(v)) <= TOL_PULSE for v in pk)

    def try_single(colours):
        for colour in colours:
            xs = M.peaks(colour, win, f, 0)
            ys = M.peaks(colour, win, f, 1)
            if on_tones(xs, w) and on_tones(ys, h):
                return [int(round(v)) for v in xs], [int(round(v)) for v in ys]
        return None

    palette = [M.fill[sp]] + list(outlines)
    r = try_single(palette)
    if r is not None:
        return r

    here = [c for c in sb_read.colours_on_frame(M, win, f)
            if not any(math.sqrt(sum((u - v) ** 2 for u, v in zip(c, k))) < 40 for k in palette)]
    r = try_single(here)
    if r is not None:
        return r

    fill_pk = {ax: M.peaks(M.fill[sp], win, f, ax) for ax in (0, 1)}
    anchor = {ax: {int(round(v)) for v in fill_pk[ax]
                   if abs(v - round(v)) <= TOL_PULSE} for ax in (0, 1)}
    got = {}
    for colour in palette + here:
        for ax in (0, 1):
            if ax in got:
                continue
            pk = fill_pk[ax] if colour is M.fill[sp] else M.peaks(colour, win, f, ax)
            if not on_tones(pk, need[ax]):
                continue
            tones = [int(round(v)) for v in pk]
            if not anchor[ax] <= set(tones):
                continue                 # rule 23: not this species' own block
            got[ax] = tones
        if 0 in got and 1 in got:
            return got[0], got[1]
    return None


def sites(rect):
    return {(x, y) for x in rect[0] for y in rect[1]}


def drop_pulse_collisions(M, f0, f1, st_all, keep_all, via, verbose=True):
    """ONE TRAP HOLDS ONE ATOM, so two blocks cannot claim the same site on the same frame.

    A configuration read on a pulse frame comes from the OUTLINE mask when the tint has spoiled the
    fill (rule 15), and that mask is shared across the whole panel -- so a species whose window
    happens to contain another species' block reads that block as its own.  On c150's f329 X1's
    window (cols 6.4..12.6, rows -1..5.6, because X1's stock and its destination are all that is
    left of X1 in that interval) contains Z0 sitting at 7:12 x 1:5, and X1's own solid fill is not
    in the window at all -- area 0 -- so the outline read returned Z0's rectangle as X1's.  That
    invented an X1 "permutation" spanning the entire final interval.

    The collision is the tell, and rule 9 breaks the tie: a claim the adjacent non-pulse frame
    independently confirms is a deduction ("nothing moved during the pulse"), while a claim that
    exists only in the shared outline mask is a guess.  Keep the confirmed one; where neither is
    confirmed, drop BOTH and let the transition be reported undetermined rather than invented.
    """
    for f in range(f0, f1 + 1):
        if f not in M.gate:
            continue
        claims = {nm: keep_all[nm][f] for nm in keep_all if f in keep_all[nm]}
        for nm, rect in list(claims.items()):
            for nm2, rect2 in list(claims.items()):
                if nm2 <= nm or nm not in claims or nm2 not in claims:
                    continue
                if not (sites(rect) & sites(rect2)):
                    continue
                keep_nm = via[nm].get(f) == "adjacent"
                keep_nm2 = via[nm2].get(f) == "adjacent"
                drop = []
                if keep_nm and not keep_nm2:
                    drop = [nm2]
                elif keep_nm2 and not keep_nm:
                    drop = [nm]
                else:
                    drop = [nm, nm2]
                for d in drop:
                    keep_all[d].pop(f, None)
                    claims.pop(d, None)
                    if verbose:
                        print("   f%03d: %s and %s both claim overlapping sites on a pulse frame; "
                              "dropping %s (read from the shared outline mask, unconfirmed by its "
                              "neighbours)" % (f, nm, nm2, d))
    return keep_all


class EdgePeaks:
    """`Peaks` for the one frame either side of the segment, measured on demand.

    `Peaks` is precomputed over [f0, f1] only, so at a segment's FIRST frame the rule-9 deduction
    below has no f-1 to look at, and at its LAST frame no f+1.  Those two frames are exactly the
    bounding pulse runs, so the deduction is unavailable precisely where it is needed most.
    """

    def __init__(self, M, wins):
        self.M, self.wins, self.pk = M, wins, {}

    def __call__(self, nm, f, axis):
        k = (nm, f, axis)
        if k not in self.pk:
            self.pk[k] = self.M.peaks(self.M.fill[nm], self.wins[nm], f, axis)
        return self.pk[k]


def left_its_tones(P, M, nm, fa, fb, rect):
    """Between two IDENTICAL settled configurations, did the block actually MOVE?

    Two rests holding the same rectangle a few frames apart are fused, on the assumption that the
    frames between them are a mask dropout.  That is right for a dropout and WRONG for a short
    same-site permutation -- and a same-site permutation is the one move no render and no
    positional score can ever contradict ('Ways to be confidently wrong' 1: "a block that ends on
    the rectangle it started on has still moved").  Fusing swallows the transition before it is
    ever enumerated, so rule 12 never gets a chance to demand an explanation.

    c200's X0/X1 rows 5 and 6 are the case: they swap over f092-f095 while every other row stands
    still, the rests at f092 and f095 are identical, and the gap is exactly the 3 frames the fuser
    tolerates -- so a real move was missing from the sheet with nothing anywhere reporting it.

    The discriminator is what the intervening frames actually show.  Such a frame is never a rest,
    so either a peak is off its tone (the marker is TRAVELLING) or the count is short with
    everything still on tone (the mask DROPPED OUT).  Only the first is motion, and `TOL_ONGRID` is
    already this project's definition of "on its tone", so no new threshold is invented here.
    """
    tones = {0: rect[0], 1: rect[1]}
    for f in range(fa + 1, fb):
        if f in M.gate:
            continue
        for axis in (0, 1):
            pk = P(nm, f, axis)
            if not pk:
                continue                 # nothing measured on this axis: a dropout, not motion
            if max(min(abs(v - t) for t in tones[axis]) for v in pk) > sb_compose.TOL_ONGRID:
                return True
    return False


def stationary(P, edge, M, nm, f, rect, f0, f1):
    """Is the block MEASURABLY at rest on this lone on-grid frame, rather than passing through?

    Section 2 discards a single on-grid frame unless it is next to a pulse, because "a translating
    block lands on integer tones by coincidence -- c150's X0 does it at f075, f115, f117, f141 and
    f146".  That is right, but "two consecutive on-grid frames" is a PROXY for the thing actually
    meant, which is that the block is not moving; and the proxy fails wherever one move ends and
    the next begins on the following frame.  The quintic easing is flat at both ends, so the frame
    after a move starts is typically only ~0.02-0.15 site off its tones -- just enough to fail the
    0.14 on-grid test -- and the arrival is then invisible.  A PIPELINED movie chains moves like
    this constantly: on c540 it hid X0's `rows 1:9 -> 10:18` (arrives f017, next move starts f018)
    and X1's, so `sb_audit` reported those relocations as having no move on that axis at all, and
    the one transition f001..f025 had to be explained by one move where the movie does two.

    So test the thing itself: the CENTROID of the block's peaks against an adjacent frame.  At a
    genuine rest the easing is flat and the centroid does not move; at a coincidental landing the
    block is at its PEAK speed, which is what makes it land on integers in passing.

    Two populations, measured, and they do not overlap (`run_c540/diag_lone.py`):

        c150, every lone on-grid frame -- all coincidental by SKILL.md 2 -- min |dcentroid| to a
             neighbour, over the frames where the block is UNCLIPPED:  0.276 .. 0.796
        c540, the same statistic:  a tight cluster at 0.000 .. 0.070 (X0 f017 0.034, f023 0.008,
             X1 f086 0.013, Z0 f199 0.006, Z1 f130 0.001 -- all of them arrivals between two
             chained moves), then 0.127 (X0 f140, the arrival of `rows 1:9 -> 10:18` at f131-141)
             and nothing again until 0.229

    The bar is TOL_ONGRID, the project's existing definition of "on its tone" -- no new constant --
    and it sits in the gap between 0.127 and 0.229 with a factor of two either side.

    THE BLOCK MUST BE UNCLIPPED, and that guard is load-bearing rather than tidy.  A block parked
    half off panel has its centroid PINNED at the border while the visible sliver barely changes,
    so it reads stationary while it is moving fast: c150's Z0 at f060 is mid parking-slide at
    `x -4:1`, one column visible, and scores 0.042.  Section 7 already says a sliver at the border
    carries no information.  Every c150 lone frame under the bar is one of those.
    """
    if not STATIONARY_REST:
        return False
    vc, vr = M.K["visible_col"], M.K["visible_row"]
    if not (vc[0] <= min(rect[0]) and max(rect[0]) <= vc[1]
            and vr[0] <= min(rect[1]) and max(rect[1]) <= vr[1]):
        return False                      # clipped: the centroid is pinned, not measured

    def cen(g, axis):
        pk = P(nm, g, axis) if f0 <= g <= f1 else edge(nm, g, axis)
        return (sum(pk) / len(pk), len(pk)) if pk else (None, 0)

    here = [cen(f, ax) for ax in (0, 1)]
    if any(c is None for c, _ in here):
        return False
    for g in (f - 1, f + 1):
        if g < 0 or g >= M.nf or g in M.gate:
            continue
        there = [cen(g, ax) for ax in (0, 1)]
        if any(c is None for c, _ in there):
            continue
        if any(a[1] != b[1] for a, b in zip(here, there)):
            continue                      # different peak counts: the centroids are not comparable
        if all(abs(a[0] - b[0]) < sb_compose.TOL_ONGRID for a, b in zip(here, there)):
            return True
    return False


def run_neighbours(M, f):
    """The settled frames either side of the PULSE RUN containing f -- not of f itself.

    Session 15 corrected rule 9: a Rydberg pulse is far faster than the atoms move, so a pulse RUN
    of several frames is ONE instantaneous gate whose display the animation holds.  Every frame of
    the run therefore shows the SAME configuration, and the frame that determines it is the one
    adjacent to the RUN.  The deduction looked at f-1 and f+1, so on the SECOND frame of a
    two-frame run it looked at the first frame of the same run (a gate, skipped) and at the frame
    after the run, which is one frame into the next move and therefore not settled -- and gave up.

    c540 f058-059 is the case, and it is half of why the Z0/Z1 exchange was lost: f058 could be
    deduced from f057, but f059 could not, because f060 is already 0.5 site into the exchange.  It
    fell through to the shared outline mask, which handed Z0 the block Z1 was standing on.
    """
    lo = hi = f
    while lo - 1 >= 0 and lo - 1 in M.gate:
        lo -= 1
    while hi + 1 < M.nf and hi + 1 in M.gate:
        hi += 1
    return [g for g in (lo - 1, hi + 1) if 0 <= g < M.nf and g not in M.gate]


def settled(P, M, f0, f1, blocks, wins, outlines, verbose=True, edge_wins=None):
    """per species: settled configurations and the transitions between them (rules 2 and 12)."""
    out = {}
    edge = EdgePeaks(M, edge_wins or wins)
    st_all, keep_all, via = {}, {}, {}
    for nm in M.species:
        if nm not in blocks:
            continue
        st = {f: sb_compose.rect_at(P, M, nm, f, blocks[nm]) for f in range(f0, f1 + 1)}
        keep, vv = {}, {}
        for f in range(f0, f1 + 1):
            if f in M.gate:                      # a pulse frame IS a rest; read it specially
                # Rule 9 first: NOTHING MOVES DURING A PULSE, so if the frame immediately next to
                # this one is itself a settled configuration, the pulse frame holds exactly that.
                # Prefer that deduction over reading the pixels, because rect_on_pulse falls back
                # to the OUTLINE mask, which is shared across the panel and can therefore pick up a
                # different species standing inside this species' window.  On c150 that invented an
                # X0 "relocation" from cols -5:0 to 1:6 between f263 and f264 -- a whole block
                # jumping six columns in one frame, across a pulse, which rule 9 forbids twice over
                # -- by reading X1's markers as X0's.
                # The lookup must be allowed OUTSIDE [f0, f1].  A segment begins and ends on a
                # bounding pulse run, so at f == f0 there is no f-1 in range and at f == f1 no f+1,
                # and the deduction silently falls back to the shared outline mask at both ends --
                # which rule 23 then has to drop, leaving the species with NO configuration there.
                # c200's X1 is that case: it stands on cols -3:0 (one column visible) until the
                # pulse at f253-254, and its rest lives only in the PREVIOUS segment, so no segment
                # sees both ends of `X1 -3:0 -> 1:4` and the move is never enumerated at all -- while
                # X0's half of the same swap is written, so the sheet has the two blocks ending up
                # on one another's sites.  Reading one frame further out costs one peak measurement
                # and cannot create a rest or a transition outside the segment.
                r, how = None, None
                for g in run_neighbours(M, f):
                    rg = (st.get(g) if f0 <= g <= f1
                          else sb_compose.rect_at(edge, M, nm, g, blocks[nm]))
                    if rg is not None:
                        r, how = rg, "adjacent"
                        break
                if r is None:
                    # the PULSE-frame window, not the segment's: see species_windows(skip_gate)
                    r, how = (rect_on_pulse(M, nm, (edge_wins or wins)[nm], f, blocks[nm],
                                            outlines), "outline")
                if r is not None:
                    keep[f] = r; vv[f] = how
                continue
            if st[f] is None:
                continue
            run, g = 1, f - 1
            while g >= f0 and st.get(g) == st[f]:
                run += 1; g -= 1
            g = f + 1
            while g <= f1 and st.get(g) == st[f]:
                run += 1; g += 1
            # a lone on-grid frame is a translating block landing on integers by coincidence,
            # unless it is next to a pulse, where the block really is still -- or unless the block
            # is measurably STATIONARY there, which is the thing "two consecutive frames" is a
            # proxy for and the thing a pipelined movie breaks (see `stationary`)
            if (run >= 2 or any((f + d) in M.gate for d in (-2, -1, 1, 2))
                    or stationary(P, edge, M, nm, f, st[f], f0, f1)):
                keep[f] = st[f]
        st_all[nm], keep_all[nm], via[nm] = st, keep, vv

    keep_all = drop_pulse_collisions(M, f0, f1, st_all, keep_all, via, verbose)

    for nm in M.species:
        if nm not in blocks:
            continue
        keep = keep_all[nm]
        segs = []
        for f in sorted(keep):
            if (segs and keep[f] == segs[-1][2] and f - segs[-1][1] <= 3
                    and not left_its_tones(P, M, nm, segs[-1][1], f, keep[f])):
                segs[-1] = (segs[-1][0], f, keep[f])
            else:
                segs.append((f, f, keep[f]))
        tr = []
        for i in range(len(segs) - 1):
            a, b, c0 = segs[i]
            a2, b2, c1 = segs[i + 1]
            if a2 - b <= 1 and c0 == c1 and not left_its_tones(P, M, nm, b, a2, c0):
                continue                          # adjacent and identical: nothing happened
            tr.append(dict(sp=nm, f0=b, f1=a2, x0=c0[0], y0=c0[1], x1=c1[0], y1=c1[1],
                           kind="permutation" if c0 == c1 else "relocation"))
        out[nm] = dict(rests=[(a, b, c[0], c[1]) for a, b, c in segs], transitions=tr)
        if verbose:
            print("\n== %s : %d settled configurations" % (nm, len(segs)))
            for a, b, c in segs:
                print("   rest f%03d-%03d  %-14s x %-12s%s"
                      % (a, b, comb(c[0]), comb(c[1]),
                         "   (read on a pulse frame)" if a in M.gate else ""))
            for t in tr:
                print("      -> %-11s f%03d..f%03d  x %s -> %s   y %s -> %s"
                      % (t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                         comb(t["y0"]), comb(t["y1"])))
    return out


# ===================================================================== 3-4. partition by appearance
def classes(M, sp, win, frames, outlines, keep=None, nlines=1):
    """appearance classes of `sp` in its own window, tolerating a one-frame mask dropout.

    sb_rigid.classes_in_window drops a whole class the moment its mask falls under MIN_CLASS_AREA
    on ANY frame.  During a crossing a one-marker class dips below that for a single frame (c150's
    Z0 gold at f043, where the pale twin still reads it).  Skip the frame, not the class.
    """
    usable = [f for f in frames if f not in M.gate]
    need = max(2, int(CLASS_COVERAGE * len(usable)))
    # A sub-comb (rule 40) shows only a fraction of the block, so the area bar has to scale with
    # it or every class on a two-column comb is dismissed as noise.
    min_area = sb_rigid.MIN_CLASS_AREA
    if keep is not None:
        min_area = max(40.0, min_area * len(keep[1]) / max(1, nlines))
    out = []
    for col in outlines:
        per = {}
        for f in frames:
            if f in M.gate:
                continue
            if M.area(col, win, f, keep=keep) < min_area:
                continue
            per[f] = (M.peaks(col, win, f, 0, keep=keep), M.peaks(col, win, f, 1, keep=keep))
        # A CLASS EXISTS THROUGHOUT THE MOVE (rule 7: shape + fill + outline is the block's
        # identity and all three are constant through a movement).  A colour that shows up on a
        # handful of frames is not a class -- it is a BLEND, appearing only on the frames where two
        # markers overlap enough for their colours to mix at the anti-aliased boundary.
        #
        # This matters beyond tidiness, because one spurious part poisons the whole partition: on
        # c150's f192-203 the real classes read perfectly (mauve cols 1:4 -> 3:6 at 0.044 site,
        # gold 5:6 -> 1:2 at 0.018) but the blend rgb(203,167,90), present on 2 frames of 12,
        # added a third part `3:4 -> 1:2` whose destination collides with gold's, the union stopped
        # being a bijection, and a cleanly measured move was reported UNDETERMINED.
        # A one-frame dropout must still not kill a class (session 12), so the bar is coverage,
        # not perfection.
        if len(per) >= need:
            out.append(dict(sp=sp, colour=tuple(round(float(c), 1) for c in col), per=per))
    return out


def split_class(cls, axis, frames, src, dst):
    """A class whose members do NOT share one displacement is MORE THAN ONE rigid sub-block.

    Rule 3z says the appearance triple names one rigid body.  Where it demonstrably does not, the
    informative response is to split the class, not to throw it away -- and a class can be split
    reliably, because a colour-separated profile stays resolved right through a crossing (that is
    the whole point of 3z: "the two sub-blocks never merge in a colour-separated profile", since
    the partners that cross carry DIFFERENT colours).  So the members' own displacements are
    measurable even where the shared fill has collapsed to fewer peaks.

    c150's f331-350 Z0 is the case that needs it: mauve holds cols 7, 10, 11 travelling -3, -5, -5
    and gold holds 8, 9, 12 travelling -7, -7, -9, so BOTH classes are rejected as not rigid and a
    real four-sub-block move is lost.  Split, and the four groups fall straight out and tile the
    destination set exactly.  (Only fill and outline are used as the appearance key here -- shape
    has never been a discriminator on c150, and SKILL.md flags that as a weak null.  A class that
    needs splitting may be a case where shape does matter.)

    Every group must still be rigid on its own; if any is not, the split is not believed.
    """
    out = []
    for gs, gd in split_by_displacement(src, dst):
        idx = [src.index(v) for v in gs]
        spreads = []
        for f in frames:
            if f not in cls["per"]:
                continue
            pk = cls["per"][f][axis]
            if len(pk) != len(src):
                continue
            offs = [pk[i] - src[i] for i in idx]
            spreads.append(max(offs) - min(offs))
        if not spreads:
            return None
        spreads.sort()
        resid = (spreads[int(0.75 * (len(spreads) - 1))] if len(spreads) >= 4 else spreads[-1])
        if resid > sb_rigid.RIGID_TOL:
            return None
        out.append((tuple(gs), tuple(gd), gd[0] - gs[0], round(resid, 4)))
    return out


def arrived(pk, src, dst, S2):
    """Rule 16's arrival test, with rule 15's escape hatch.

    `dst` is read by ROUNDING the last frame's peaks (sb_rigid.rigid_displacement), so a frame
    still in flight would round to the wrong tone.  Hence the test: every peak within ARRIVED of
    an integer.

    But the partition read may not use gate frames (a pulse tint wrecks the fill mask), and rule 9
    says a move may finish exactly AT the pulse that ends its interval.  When it does, the last
    usable frame is still short of arrival and the whole class is dropped -- along with a move
    that is otherwise measured perfectly.  c200's Z1 f009-016 is that case: at f015 the block is
    ~90 % through, the mauve class reads 1.19 2.18 3.17 6.27 7.28 (0.28 off a tone against the
    0.25 bar) and the four sub-blocks are already rigid to 0.012-0.063 site.

    The escape hatch is rule 18, and it is strictly stronger than the test it replaces: the
    transition's DESTINATION SET is known independently, from the settled configuration on the far
    side -- which rule 15 makes readable even when it lives only on a pulse frame.  A rounded `dst`
    that is injective and lands inside that set cannot have been rounded off a marker in flight,
    and `emit` still has to make the parts tile S2 EXACTLY and be a bijection before anything is
    written.  So this cannot invent a destination the movie does not show.

    BUT THE HATCH IS NEARLY VACUOUS ON A SAME-SITE PERMUTATION, so say which route was taken and
    let the caller prefer a clean arrival (c540).  When S2 is the block's own tone set the markers
    never leave it, so "lands inside S2" is satisfied by almost any mid-flight rounding, and a
    class read off a frame still in flight is admitted alongside the right one.  c540's X0
    f034-043 `cols 1:2 -> 11:12 | 3:12 -> 1:10` (a cyclic shift by -2, and X1 does the identical
    thing at `13:14 -> 23:24 | 15:24 -> 13:22` in the same frames) is the case: gold reads
    `1:2 -> 11:12` D=+10 and arrives cleanly, 0.032 off a tone, while its anti-aliased twin
    rgb(255,249,185) reads `2:3 -> 11:12` D=+9 at 0.273 off -- rejected by the strict test, waved
    through by the hatch.  They collide on tone 2, the union stops being a bijection, `partition`
    shortens its window looking for a clean read, and on the shorter window even gold rounds to
    `1:2 -> 10:11`.  The move was lost.
    Cannot simply be switched off for permutations: c200's Z1 f009-015 rows IS a permutation and
    is exactly the move the hatch was written to save.  Return the ROUTE instead, so rule 30's
    collision ranking can put a strictly-arrived class above a hatched one -- which is what the
    rule already says to do, "keep the claim with the stronger evidence".

    Returns 2 (arrived outright), 1 (admitted by the rule-18 hatch) or 0 (not arrived).
    """
    if len(pk) != len(src):
        return 0
    if max(abs(v - round(v)) for v in pk) <= ARRIVED:
        return 2
    if S2 is not None and len(set(dst)) == len(dst) and set(dst) <= set(S2):
        return 1
    return 0


def class_evidence(cls, axis, frames):
    """How much a class's read is worth, for settling a collision between two of them (rule 24).

    The discriminator rule 24 names is COUNT STABILITY: "a colour whose peak count wanders takes
    its src and dst from dropout frames".  A class that shows the same number of markers on every
    frame is a real appearance class; one whose count moves around is a partial mask.  Frame count
    alone is NOT the measure -- an anti-aliased twin is typically present on every frame and wrong
    on most of them.  Returns (fraction of frames at the modal count, frames at the modal count).
    """
    from collections import Counter
    cnt = [len(cls["per"][f][axis]) for f in frames if f in cls["per"]]
    if not cnt:
        return (0.0, 0)
    modal = Counter(cnt).most_common(1)[0][0]
    n = cnt.count(modal)
    return (n / float(len(cnt)), n)


def partition_on(M, sp, win, axis, frames, outlines, notes, S2=None, keep=None, nlines=1):
    got = []
    for cls in classes(M, sp, win, frames, outlines, keep, nlines):
        ev = class_evidence(cls, axis, frames)
        r = sb_rigid.rigid_displacement(cls, axis, frames)
        if not r:
            continue
        if r.get("bad"):
            # RULE 19's SPLIT MUST NOT MANUFACTURE SINGLE-MEMBER SUB-BLOCKS OUT OF A CLASS RULE 24
            # WOULD HAVE REJECTED (c540).  A one-member sub-block has zero member spread, so it is
            # "rigid to 0.000" whatever it is: splitting a wandering class into singletons launders
            # a dropout read straight into the partition, and each piece then looks like the
            # cleanest evidence in the list.
            #
            # c540's Z1 f248-258 `cols 13:24 -> 1:12` is the case.  The mauve class reads
            # `13:14 -> 11:12` D=-2 correctly (rigid 0.060 over 10 frames) and the pixels show the
            # rest as one rigid `15:24 -> 1:10` D=-14: at f250 the model 13-2p, 14-2p, 15-14p..
            # 24-14p with p=0.19 predicts 12.34 12.62 13.34 13.62 14.34 15.34 .. 21.34 against a
            # measured 12.33 12.68 13.27 13.68 14.33 15.34 .. 21.35.  But the gold's ANTI-ALIASED
            # TWIN rgb(255,251,182) resolves only three markers, with counts wandering over
            # [1,3,4,5,7,11], and reads them as 17->2, 20->4, 22->8 -- displacements -15, -16, -14.
            # Split into three singletons each was "rigid to 0.000", they collide with nothing, and
            # `complete_partition` then paired the remaining seven columns in order.  The move went
            # into the sheet as SEVEN sub-blocks with six distinct displacements instead of two --
            # and seven concurrent rows need seven crossed pairs, which is most of why the reported
            # AOM peak was 8 on a movie whose own title says 4-AOD.
            #
            # Rule 24 already says what to do -- "keep the modal count and drop the frames that
            # disagree", "a colour whose peak count wanders takes its src and dst from dropout
            # frames" -- so require the class to be AT its modal count on a majority of the frames
            # it appears on.  The mauve is at 0.91, the twin at 0.27.  This gates only the split
            # path, where the trivially-rigid singleton is manufactured.
            if ev[0] <= 0.5:
                notes.append("%s rgb(%.0f,%.0f,%.0f) %s f%03d-%03d: its peak count is at its modal "
                             "value on only %.0f%% of the frames it appears on, so its src and dst "
                             "are read off dropout frames (rule 24) -- not split into %d "
                             "single-member sub-blocks, which would each be trivially rigid"
                             % (sp, cls["colour"][0], cls["colour"][1], cls["colour"][2],
                                "cols" if axis == 0 else "rows", frames[0], frames[-1],
                                100 * ev[0], len(r["src"])))
                continue
            parts = split_class(cls, axis, frames, r["src"], r["dst"])
            if not parts:
                continue
            notes.append("%s rgb(%.0f,%.0f,%.0f) %s f%03d-%03d: the appearance triple did NOT name "
                         "one rigid body here -- its members travel %s -- so the class was SPLIT "
                         "into %d rigid sub-blocks %s, each rigid to <= %.3f site"
                         % (sp, cls["colour"][0], cls["colour"][1], cls["colour"][2],
                            "cols" if axis == 0 else "rows", frames[0], frames[-1],
                            [d - s for s, d in zip(r["src"], r["dst"])], len(parts),
                            " and ".join("%s->%s" % (comb(p[0]), comb(p[1])) for p in parts),
                            max(p[3] for p in parts)))
            last = [f for f in frames if f in cls["per"]][-1]
            how = arrived(cls["per"][last][axis], r["src"], r["dst"], S2)
            if not how:
                continue
            for p in parts:
                got.append((p[0], p[1], p[2], p[3], cls["colour"], ev, how))
            continue
        if not r["rigid"]:
            notes.append("%s rgb(%.0f,%.0f,%.0f) %s f%03d-%03d: NOT RIGID, member spread %.3f site"
                         % (sp, cls["colour"][0], cls["colour"][1], cls["colour"][2],
                            "cols" if axis == 0 else "rows", frames[0], frames[-1],
                            r["rigid_residual"]))
            continue
        if r["D"] == 0:
            continue
        # the last frame used must be an ARRIVAL, or dst is rounded off a marker still in flight
        last = [f for f in frames if f in cls["per"]][-1]
        how = arrived(cls["per"][last][axis], r["src"], r["dst"], S2)
        if not how:
            continue
        got.append((tuple(r["src"]), tuple(r["dst"]), r["D"], r["rigid_residual"], cls["colour"],
                    ev, how))
    uniq = {}
    for src, dst, D, res, col, nf, how in got:   # one class may carry two colours (anti-aliased edge)
        k = (src, dst)
        if k not in uniq or res < uniq[k][3]:
            uniq[k] = (src, dst, D, res, col, nf, how)

    # THE SAME ATOMS SEEN THROUGH A SECOND COLOUR ARE NOT A SECOND SUB-BLOCK.  An outline is drawn
    # with an anti-aliased edge, so c150 carries rgb(255,250,182) alongside the gold rgb(247,187,70)
    # and rgb(184,133,90) alongside the mauve -- SKILL.md 3z names both ("tracks the gold; same
    # outline, anti-aliased edge").  Where such a twin resolves only part of its parent's markers it
    # arrives as a SUBSET part with the SAME displacement, its tones collide with the parent's, the
    # union stops being a bijection and the whole move is thrown away: on c150's f192-203 the twin
    # contributed `6 -> 2` against gold's `5:6 -> 1:2` and lost the move.  Exact-key dedup cannot
    # see this because the keys differ.  Same displacement plus a shared tone means one rigid body,
    # so merge them into the union.
    parts = sorted(uniq.values(), key=lambda t: t[0])
    merged = True
    while merged:
        merged = False
        for i in range(len(parts)):
            for j in range(i + 1, len(parts)):
                a, b = parts[i], parts[j]
                if a[2] != b[2] or not (set(a[0]) & set(b[0])):
                    continue
                s = tuple(sorted(set(a[0]) | set(b[0])))
                d = tuple(v + a[2] for v in s)
                parts[i] = (s, d, a[2], max(a[3], b[3]),
                            a[4] if len(a[0]) >= len(b[0]) else b[4], max(a[5], b[5]),
                            max(a[6], b[6]))
                parts.pop(j)
                merged = True
                break
            if merged:
                break

    # ONE ATOM CANNOT TRAVEL TWO DISTANCES.  Where two parts still claim the same SOURCE tone with
    # DIFFERENT displacements, one of them is rule 24's anti-aliased twin seen through a partial
    # mask -- "the same atoms seen through a second colour are not a second sub-block" -- and not a
    # real sub-block.  The merge above only fuses twins that AGREE on D; a twin whose peak count
    # wanders reads its dst off dropout frames and disagrees, so it survives as a colliding part,
    # the union stops being a bijection, and `emit` throws the whole move away.
    #
    # c200's X0/X1 f162-170 is the case: gold reads `5,10 -> 1,6` on 8 frames with a stable count
    # of 2 and a residual of 0.013, while its twin rgb(255,249,185) reads `5 -> 2` on 6 frames with
    # counts wandering over [1, 2, 3]. Keep the part with the stronger evidence -- more frames
    # first, then the lower rigidity residual -- and drop the claim that loses.
    #
    # AND A CLASS THAT ARRIVED OUTRIGHT OUTRANKS ONE ADMITTED BY RULE 18's HATCH (c540).  On a
    # same-site permutation the hatch is nearly vacuous -- see `arrived` -- so the twin that read
    # its dst off a frame still in flight gets in beside the parent that is plainly on its tones.
    # A clean arrival is strictly better evidence than "the rounded dst is somewhere in the block",
    # so it is the first key; c540's X0 f034-043 needs exactly this and nothing else changes,
    # because where no class is hatched the order is what it always was.
    kept, taken = [], set()
    for p in sorted(parts, key=lambda t: (-t[6], -t[5][0], -t[5][1], t[3])):
        if set(p[0]) & taken:
            continue
        taken |= set(p[0])
        kept.append(p)
    return sorted(kept, key=lambda t: t[0])


def partition(M, sp, win, axis, frames, outlines, notes, S2=None, keep=None, nlines=1):
    """Read the partition on the LONGEST PREFIX of the window that still resolves it.

    3a: the informative frames are the early, pre-crossing ones.  Past arrival every outline colour
    covers the whole block again and the classes dissolve into one -- c150's Z0 seed swap arrives at
    f006 and by f007 all six columns carry every outline.  So shorten the read window from the far
    end until the classes resolve.  The TIMING is still fitted against every frame of the window.
    """
    # THE OUTLINE MARKS A ROLE, NOT AN ATOM, AND THE ROLE BELONGS TO A PARTICULAR MOVE.  A
    # transition's window opens on the SETTLED frame that ends the previous rest, and on that frame
    # the block is between two moves and still wearing the PREVIOUS move's colouring -- so `src`,
    # which `rigid_displacement` reads off the first frame, comes out mislabelled and every class
    # is wrong from the start.  3a says it directly: take "the first frames AFTER motion starts".
    #
    # c200's X1 f322-328 is the case. On f322, at rest, gold sits on rows 1,3,6,8 and mauve on
    # 2,4,7,9 -- interleaved, which is the f318-321 move's grouping. On f323, one frame into the
    # move, gold is on rows 3,4,8,9 and mauve on 1,2,6,7, and it stays that way for the rest of the
    # window. Reading f322 gave `1->1 | 3->2 | 6->6 | 8->7`, which predicts peaks at 1.00, 2.39,
    # 2.61, 4.00 ... on f325 where the movie plainly shows 1.78, 2.25, 2.79, 3.26 -- the signature
    # of `1:2 -> 3:4` crossing `3:4 -> 1:2`, which is what the move actually is.
    lead = 0
    for k, f in enumerate(frames):
        if f in M.gate:
            continue
        pk = M.peaks(M.fill[sp], win, f, axis, keep=keep)
        if pk and max(abs(v - round(v)) for v in pk) > sb_compose.TOL_ONGRID:
            lead = k
            break
    if lead and len(frames) - lead >= 3:
        frames = frames[lead:]

    ONE = None
    for k in range(0, max(1, len(frames) - 2)):
        sub = frames[:len(frames) - k]
        part = partition_on(M, sp, win, axis, sub, outlines, notes if k == 0 else [], S2,
                            keep, nlines)
        if len(part) >= 2:
            return part, sub
        if len(part) == 1 and ONE is None:
            ONE = (part, sub)
    # ONE class that marks only PART of the block still determines the WHOLE move, because the
    # complement rule of 3 is exact: B = S \ A, B2 = S2 \ A2, paired in increasing order.  3 says
    # so directly -- "that subset IS the moving sub-block, and it is what makes the partition
    # recoverable at all" -- and `complete_partition` already implements it; the >= 2 bar simply
    # never let it see the case.  Returning nothing here throws away a measurement.
    #
    # c200's X1 f275-282 is why: the mauve class reads rows 1:3,6:8 -> 3:5,8:10 rigid to 0.043
    # site, and the complement gives 4:5,9:10 -> 1:2,6:7 -- which the gold class had independently
    # measured and which was rejected only because the two sub-blocks cross through each other on
    # most of the five frames gold resolves, inflating its robust spread to 0.171 against the 0.15
    # bar (rule 26's premise is that contamination is rare; in a crossing this short it is not).
    #
    # A single class covering the WHOLE block is a different thing -- that is k = 1, a plain
    # translation -- and it must still go to the measured-displacement route (3a), so the caller
    # checks for a proper subset before using this.
    if ONE:
        return ONE
    return [], frames


# ============================================== 4b. the k=1 case: ONE rigid class, whole block
RIGID_SPREAD = 0.15     # site: rule 3z's bar for "this class really is one rigid body"
MIN_MOTION = 0.15       # site: below this a frame carries no displacement information
REF_MOTION = 0.30       # site: travel a reference frame needs before its RATIOS beat the peak noise
# SESSION 27: 16 -> 27.  c540's `Z0/Z1 cols 13:24 -> 1:12` at f315-328 is a relocation composed
# with a wrap, `13:22 -> 3:12 | 23:24 -> 1:2`, i.e. per-tone displacements -10 and -22, and with
# the cap at 16 the |D| = 22 part could not be GENERATED, so the transition was undetermined and
# everything after f328 was twelve columns out in every book.  The cap is not a guard against wrong
# maps -- `_measured_from` pins every scale by requiring the displaced source set to equal the
# block's own destination set, and the rank-1 direction is measured, so a plain translation
# (v = 1 on every tone) lands on exactly one scale whatever the cap.  27 is the largest lattice
# extent of any movie so far (c540's 27 rows); no sub-block can travel further on panel.
MAX_SPAN = 27           # site: largest |displacement| a single sub-block is allowed
MIN_SPAN = 0.40         # fraction of its travel a move must complete inside its own window
MIN_CONFLICT_OVERLAP = 1.0  # frames two moves must share before they can contend for one atom
CLASS_COVERAGE = 0.6    # fraction of the window's frames an appearance class must appear on


def complete_partition(part, S, S2):
    """Add the sub-block the outline did not mark, by the COMPLEMENT RULE (3).

    The outline names *a* moving sub-block, not necessarily all of them, so a read can cover a
    proper subset of the block.  Left incomplete the model has fewer predictions than the block has
    markers and `verify` scores every unmodelled marker against the wrong prediction: on c150's
    f272-281 X1 read `1:2 -> 3:4 | 3:4 -> 1:2` for a SIX column block and came back 0.41 site,
    which looks like a wrong partition and is really a missing third of one.

    Given the block's tone set S before and S2 after, and the classes' unions A and A2,

        B = S \\ A      B2 = S2 \\ A2      paired in increasing order

    is exact rather than heuristic: a rectangle's tone map is strictly increasing (guide I.2), so
    once the two source sets and the two destination sets are known the pairing is forced.
    """
    A = [v for p in part for v in p[0]]
    A2 = [v for p in part for v in p[1]]
    B = sorted(set(S) - set(A))
    B2 = sorted(set(S2) - set(A2))
    if not B and not B2:
        return list(part), True
    if len(B) != len(B2):
        return list(part), False
    return list(part) + [(tuple(B), tuple(B2), None, None, "(complement of the marked classes)")], True


def split_by_displacement(src, dst):
    """one (src, dst) map -> the rigid sub-blocks it is made of, i.e. runs of equal displacement.

    A crossed AOD pair holds a comb and shifts it by ONE frequency offset (3a), so one row can only
    realise one uniform displacement.  A part carrying two different displacements must be two rows.
    """
    out, cur = [], [(src[0], dst[0])]
    for s, d in zip(src[1:], dst[1:]):
        if d - s == cur[-1][1] - cur[-1][0]:
            cur.append((s, d))
        else:
            out.append(cur); cur = [(s, d)]
    out.append(cur)
    return [([p[0] for p in g], [p[1] for p in g]) for g in out]


def measured_partition(P, M, sp, axis, src, dst, frames):
    """The partition read from the DISPLACEMENTS, when no outline resolves it (3a).

    This is the skill's own rules 5 and 6 done numerically, and it covers the cases the appearance
    read cannot:

      * k == 1, a plain translation of the whole block -- one appearance class, so `partition`
        returns fewer than two and the transition falls through.  Most of c150 after the first
        0.7 ms is this: the parking slides and the load carries.
      * a same-site permutation with no outline drawn.  c150 has six of these (X1 f050-055,
        X0 f167-178 / f181-190 / f192-203 / f205-215, X1 f306-313).

    The physics that makes it work: a move is k rigid sub-blocks each with ONE uniform integer
    displacement, and they all share one easing, so at every frame d_i = D_i * s(f).  The RATIOS
    d_i / d_j = D_i / D_j are therefore exact and constant, independent of the timing -- one
    mid-move frame with all peaks resolved gives every relative displacement at once, n
    measurements for one unknown scale.  Only the scale has to be searched, and it is pinned by
    requiring the displaced source set to be exactly the known destination set.  So this is a
    one-integer search, NOT a search over bijections -- 'Ways to be confidently wrong' 10.

    Read on the early frames, where the peak count still equals the tone count: peak i IS tone i
    and the correspondence is free.  The crossing frames are the worst place to look, not the best
    (rule 11 of that list), because peaks merge there and the correspondence is destroyed.
    """
    src, dst = sorted(src), sorted(dst)
    if len(src) != len(dst):
        return None

    # THE SORTED CORRESPONDENCE IS ONLY VALID BEFORE A CROSSING, and an equal peak count does NOT
    # prove there has not been one: once two sub-blocks have passed through each other the count is
    # back to normal but the ORDER is scrambled.  On c150's f341 Z0's six columns read
    # 3.65 4.63 5.13 6.37 6.88 7.89 while the tones that own them are 8, 9, 7, 12, 10, 11 -- so
    # `sorted(meas)[i]` is tone 8, not tone 7, and every displacement read off that frame is wrong.
    #
    # But two markers cannot SWAP ORDER without first coming within ~0.3 pitch of each other, and
    # that merges their peaks and drops the count.  So the count dropping marks the boundary
    # exactly: the correspondence is free on the leading run of frames that still show every peak,
    # and nowhere after.  Take that run and stop.  (This is also why the crossing frames are the
    # worst place to look, not the best -- 'Ways to be confidently wrong' 11.)
    #
    # AND THE COUNT-DROP TEST FAILS OPEN WHEN ONE MARKER OVERTAKES THE OTHERS ONE AT A TIME
    # (c540).  "Two markers cannot swap order without merging first" is true, but the merge has to
    # last a frame to be seen.  A cyclic shift wraps one marker across the whole block at ~8x the
    # speed of the rest, so it passes each of them inside a single frame and the count never drops:
    # c540's X1 `19:26 -> 20:27 | 27 -> 19` on cols {13,19} reads NINE peaks on every frame of
    # f201-f204 while its correspondence is already scrambled by f202 -- at f203 the sixth sorted
    # peak, 24.04, belongs to tone 27 and not to tone 24 -- so the rank-1 fit was being handed
    # three scrambled rows out of four and returned no candidate at all.
    #
    # There IS a provable bound, and it needs no new threshold: no marker can have overtaken
    # another while the SPREAD of the measured displacements is less than the smallest gap between
    # consecutive source tones.  So collect candidates from that certainly-valid prefix as well as
    # from rule 20's leading run, and let the caller's verified error choose between them.  A pure
    # translation has zero spread and is unaffected; a split is unaffected until its sub-blocks are
    # a whole tone apart, which is well after the early frames 3a asks for.  One frame is enough
    # there -- 3a says so ("one mid-move frame in which all peaks are still resolved gives every
    # relative displacement at once", verified on c150 "from one or two frames each").
    obs = []
    for f in frames:
        meas = P(sp, f, axis)
        if len(meas) != len(src):
            break
        obs.append((f, [m - s for m, s in zip(sorted(meas), src)]))
    if not obs or max(abs(v) for _f, d in obs for v in d) < REF_MOTION:
        return None
    gap = min((b - a for a, b in zip(src, src[1:])), default=1.0)
    strict = [(f, d) for f, d in obs if max(d) - min(d) < gap]
    runs = [obs] if len(obs) >= 2 else []
    if strict and strict != obs:
        runs.append(strict)
    if not runs:
        return None
    out, seen_D = [], set()
    for obs_run in runs:
        for r in (_measured_from(obs_run, src, dst) or []):
            if tuple(r["D"]) in seen_D:
                continue
            seen_D.add(tuple(r["D"]))
            out.append(r)
    return out or None


def _measured_from(obs, src, dst):
    """the rank-1 fit and its integer scales, for one run of observation frames"""
    if not obs:
        return None

    # JOINT rank-1 fit, not a single frame's rounding.  All sub-blocks share one easing, so
    # d_i(f) = D_i * s_f is exactly a rank-1 matrix and its leading right singular vector IS the
    # displacement direction, with the ~0.03-0.05 site per-frame peak noise averaged down over
    # every usable frame.  Rounding one frame instead is fragile precisely where it matters: on
    # Z0's f331-348 the best single frame gives tone 9 a ratio of 0.71 against a true 0.778, which
    # rounds to -6 where the answer is -7, the destination set then fails to match, and a real
    # four-sub-block move is reported undetermined.  This is SKILL.md 3a step 2 -- "fit each tone's
    # velocity ACROSS those frames (averages the ~0.03 site per-frame noise)" -- done properly.
    A = np.array([d for _f, d in obs], float)
    try:
        _u, _s, vt = np.linalg.svd(A, full_matrices=False)
    except np.linalg.LinAlgError:
        return None
    v = vt[0]
    if np.dot(A[-1], v) < 0:
        v = -v                             # orient along the direction of travel
    amax = float(np.max(np.abs(v)))
    if amax < 1e-9:
        return None
    v = v / amax

    cands = {}
    for Dmax in range(1, MAX_SPAN + 1):
        D = [int(round(val * Dmax)) for val in v]
        if max(abs(x) for x in D) != Dmax or all(x == 0 for x in D):
            continue
        if sorted(s + dd for s, dd in zip(src, D)) != dst:
            continue                       # wrong scale: it does not land on the block's own
        key = tuple(D)                     # destination set
        if key in cands:
            continue
        den = float(sum(dd * dd for dd in D))
        tot = n = 0.0
        seq = []
        for f, d in obs:
            s_f = sum(dv * dd for dv, dd in zip(d, D)) / den
            tot += sum((dv - dd * s_f) ** 2 for dv, dd in zip(d, D)); n += len(d)
            seq.append((f, s_f))
        resid = (tot / n) ** 0.5
        # rule 11: a correct partition explains every frame AND gives a monotone progress sequence
        seq.sort()
        mono = sum(max(0.0, a - b) for (_, a), (_, b) in zip(seq, seq[1:]))
        if resid > RIGID_SPREAD:
            continue
        cands[key] = (resid + mono, resid, mono, D)

    if not cands:
        return None
    out = []
    for _score, resid, mono, D in sorted(cands.values()):
        parts = split_by_displacement(src, [s + dd for s, dd in zip(src, D)])
        out.append(dict(parts=[(tuple(a), tuple(b), b[0] - a[0], round(resid, 3),
                                "(measured displacements, read on f%03d-f%03d)"
                                % (obs[0][0], obs[-1][0])) for a, b in parts],
                        resid=round(resid, 3), mono=round(mono, 3),
                        read_on=[obs[0][0], obs[-1][0]], D=[int(x) for x in D]))
    return out


def rotation_amount(P, sp, axis, S, frames):
    """The rotation named by the MINORITY-SIGN COUNT, on the first provably unscrambled frame.

    A rotation by +j moves n-j tones by +j and the remaining j by -(n-j), so the number of tones
    travelling against the majority IS j.  That count survives at ~0.02 site of travel, where the
    ratio between the two displacements does not (see `rotation_candidates`), and it needs only the
    SIGN of each reading rather than its magnitude.

    Read it on a frame where the sorted correspondence is provably intact -- the spread of the
    displacements is still under one tone gap, so no marker can yet have overtaken another.
    On c540's X1 f201 the eight carried rows read +0.02..+0.10 and the wrap row -0.59: eight
    positive, one negative, so the rotation is +1 (and -8, which is the same map on nine tones).
    """
    gap = min((b - a for a, b in zip(S, S[1:])), default=1.0)
    for f in frames:
        pk = P(sp, f, axis)
        if len(pk) != len(S):
            continue
        d = [m - s for m, s in zip(sorted(pk), S)]
        if max(d) - min(d) >= gap or max(abs(v) for v in d) < 0.05:
            continue                       # scrambled, or not moving yet
        pos = sum(1 for v in d if v > 0)
        neg = sum(1 for v in d if v < 0)
        if pos and neg:
            return f, pos, neg
    return None


def rotation_candidates(S, S2, amounts=None):
    """A same-site permutation of a CONTIGUOUS tone set, as the rotations it could be.

    NOT a bijection library -- `SB_COMPOSE_OPEN_BUG.md` is right that searching one is the wrong
    shape of answer.  3a fixes the shape: a move is k rigid sub-blocks each carrying ONE uniform
    integer displacement, and for a same-site permutation of a contiguous set the TWO-sub-block
    maps are exactly the rotations (shift n-j tones by +j and the other j by -(n-j)).  So this
    enumerates the two-part family the physics allows, and each member is still scored by the same
    verified peak-matching error as everything else; nothing is accepted on its shape alone.

    It exists because the measured route cannot always reach a rotation, and c540 says why.  A
    rotation wraps one marker across the whole block at (n-1)x the speed of the rest, so:
      * the peak count never drops -- it passes each marker inside one frame -- and rule 20's
        leading-run guard therefore fails open, handing the rank-1 fit scrambled rows;
      * on the one frame that is provably unscrambled the majority has moved only ~0.07 site,
        which is the peak noise, so its ratio to the wrap marker rounds inconsistently: c540's
        X1 f201 gives [1,1,1,1,0,0,1,0,-8] where the answer is [1,1,1,1,1,1,1,1,-8].
    What IS measurable on that frame is the SIGN pattern -- eight markers at +0.02..+0.10 and one
    at -0.59 -- and the number of minority-sign tones names the rotation.  Enumerating both
    directions and scoring is the same answer with no reliance on the sign of a 0.02 site reading.
    """
    n = len(S)
    if n < 2 or S != S2 or S != list(range(S[0], S[0] + n)):
        return []
    ks = amounts if amounts else [j * d for j in range(1, n) for d in (1, -1)]
    out, seen = [], set()
    for k in ks:
        k %= n
        if not k or k in seen:
            continue
        seen.add(k)
        dst = [S[(i + k) % n] for i in range(n)]
        parts = [(tuple(a), tuple(b)) for a, b in split_by_displacement(S, dst)]
        if len(parts) != 2:
            continue
        out.append([(a, b, b[0] - a[0], None,
                     "(rotation by %+d of a contiguous same-site permutation, 3a: two rigid "
                     "sub-blocks with uniform displacements)" % (k - n if k > n // 2 else k))
                    for a, b in parts])
    return out


def periodic_rotations(S):
    """A same-site permutation that rotates each consecutive group of m tones by k, m | n, m < n.

    SESSION 27, LAST RESORT ONLY.  c540's Z0 rows f380-383 reads, on f381, rows 19, 22 and 25 moving
    UP by the same amount and the other six moving DOWN by half of it: each triple (19,20,21),
    (22,23,24), (25,26,27) rotates within itself, `19,22,25 -> 21,24,27 | 20:21,23:24,26:27 ->
    19:20,22:23,25:26`.  Shayne's hand book writes exactly that (+2 on rows 19, 22, 25).  It is a
    legal move under 3a -- two rigid groups, uniform integer displacements +2 and -1, one crossed
    pair each (the +2 group is a comb of pitch 3) -- but it is not a rotation of a contiguous run,
    so `rotation_candidates` cannot reach it, and the best contiguous rotation scores 0.12 on the
    free per-frame progress and is correctly refused.  m = n is the ordinary rotation and is left
    to `rotation_candidates`.
    """
    n = len(S)
    if n < 4 or S != list(range(S[0], S[0] + n)):
        return []
    out = []
    for m in range(2, n):
        if n % m:
            continue
        for k in range(1, m):
            dst = []
            for g in range(0, n, m):
                grp = S[g:g + m]
                dst += [grp[(i + k) % m] for i in range(m)]
            parts = [(tuple(a), tuple(b)) for a, b in split_by_displacement(S, dst)]
            # two rigid groups: the tones moving +k and the tones moving -(m-k)
            byD = {}
            for a, b in parts:
                byD.setdefault(b[0] - a[0], ([], []))
                byD[b[0] - a[0]][0].extend(a); byD[b[0] - a[0]][1].extend(b)
            out.append([(tuple(a), tuple(b), D, None,
                         "(rotation by %+d within each group of %d tones, session 27 last resort)"
                         % (k if k <= m // 2 else k - m, m))
                        for D, (a, b) in sorted(byD.items())])
    return out


def relocation_rotations(S, S2):
    """A RELOCATION of a contiguous run composed with a rotation, as the one-integer family it is.

    SESSION 27, LAST RESORT ONLY.  c540's `Z0/Z1 cols 13:24 -> 1:12` at f315-328 is `13:22 -> 3:12
    | 23:24 -> 1:2`: the block translates by -12 and wraps two columns, per-tone displacements -10
    and -22.  No production route can reach it.  The displacement route (3a) reads the leading run
    of frames whose peak count equals the tone count and needs two of them; here the two wrap
    markers travel at 2.2x the body's speed and scramble the sorted correspondence from the SECOND
    moving frame (f317 reads eleven peaks), and on the one clean frame the body has moved 0.2-0.3
    site -- peak noise -- so the ratios do not round to a consistent scale.  `uniform_displacement`
    correctly says the tones do not share one displacement, and `rotation_candidates` is silent on
    anything that is not same-site.

    The family: shift by k the destination run, k = 0 (the plain translation) .. n-1, every member
    two rigid groups (k = 0: one) with uniform integer displacements, scored by the same verified
    error as everything else.  The v2 fork had this family and it BROKE c300 (`X0 cols f246-261`,
    a plain translation, came out as a rotation by +1 at a marginally better score), because it
    competed against a translation an earlier route had already read correctly.  So it lives in
    the last resort and nowhere else: it is asked only for a transition every route has failed on
    and no other species' rectangle carries.  On such a transition the alternative is UNDETERMINED.
    """
    n = len(S)
    if n < 2 or len(S2) != n or S == S2:
        return []
    if S != list(range(S[0], S[0] + n)) or S2 != list(range(S2[0], S2[0] + n)):
        return []
    out = []
    for k in range(n):
        dst = [S2[(i + k) % n] for i in range(n)]
        parts = [(tuple(a), tuple(b)) for a, b in split_by_displacement(S, dst)]
        if len(parts) > 2:
            continue
        out.append([(a, b, b[0] - a[0], None,
                     "(relocation %s -> %s composed with a rotation by %+d, session 27 last resort)"
                     % (comb(S), comb(S2), k - n if k > n // 2 else k)) for a, b in parts])
    return out


def uniform_displacement(P, M, sp, axis, src, frames):
    """Is the whole block ONE rigid body over these frames?  Measured, never assumed.

    3a: a move is k rigid sub-blocks each with one uniform integer displacement, and the outline
    partition is how k >= 2 is read.  But k == 1 -- a plain translation of the whole block -- has
    exactly one appearance class, so `partition` returns fewer than two classes and the transition
    falls through as UNDETERMINED.  Most of c150 after the first 0.7 ms is this case: the parking
    slides, the readout descents and the loads are all whole-block translations.

    Do NOT take rigidity from the endpoints.  'Ways to be confidently wrong' 2 is exactly this:
    c150's X blocks go from rows 1:5 to rows 6:10, which looks like a clean +5 and SCORES well as
    one, but is two sub-blocks at +7 and +2 crossing through each other.  The endpoints cannot tell
    the difference and neither can any positional score.  The per-tone displacements can: they are
    equal for a rigid body and unequal for a split, and the ratios are exact at every frame
    regardless of the timing (3a).  So measure them on the early, pre-crossing frames -- where the
    peak count still equals the tone count, so peak i IS tone i and the correspondence is free.

    JUDGE RIGIDITY ON A ROBUST QUANTILE OF THE PER-FRAME SPREAD, NOT ON THE MAX (rule 26).  A hard
    `return None` on the first wide frame throws the whole measurement away on the evidence of the
    one frame that is worth least, and on a block sliding ONTO the panel that frame is guaranteed to
    exist: while the block is a sliver at the border its leading marker is clipped, so its centroid
    is pulled and the peak sits outside the visible range altogether.  Section 7 already says this
    ("a load's leading edge is pinned at the panel border while the block is still a sliver and
    those frames carry no information -- track its trailing edge instead").
    c300's Z1 f048-062 is the case: `cols -9:0 -> 1:10`, one visible peak growing to ten, spread
    0.04 site on four frames and 0.16 on f058 alone, where the leading peak reads -0.48 -- so a
    0.15 bar on the max rejected a translation that is rigid to 0.04, and the Z0/Z1 exchange lost
    Z1's half.  Same convention as `sb_rigid`: the 75th percentile once there are four frames to
    take it over, the max below that, and the max is reported either way.

    JUDGE IT ON THE JOINT RANK-1 FIT, NOT ON A QUANTILE OF PER-FRAME SPREADS (rule 20, c540).
    The per-frame statistic asks the question once per frame and then argues about which frames to
    believe; rule 20 already says how to do better -- `d_i(f) = D_i * s_f` is EXACTLY rank 1, so the
    leading singular vector IS the per-tone displacement direction with the per-frame noise
    averaged down, and rule 20 states it in as many words: "never by rounding a single frame".
    Rule 26's "robust quantile" was the right instinct and the p75 was the wrong estimator: it is
    robust to ONE contaminated frame (c300's block entering the panel) and not to a run of them.

    c540's Z0/Z1 exchange is the case that breaks the quantile, and it breaks it SYMMETRICALLY,
    which is what makes the diagnosis certain.  Z0 `13:24 -> 1:12` and Z1 `1:12 -> 13:24` are one
    exchange on rows 19:27, the two blocks passing THROUGH each other over f060-069, and the movie
    draws Z1 in front.  Measured per frame, the two halves are the same move: mean displacements
    -2.79/+2.81, -6.74/+6.73, -10.16/+10.12, -12.007/+12.001.  But Z0 is the occluded one, so its
    peaks are pulled on the three frames of deepest overlap and its per-frame spreads run
    0.124 0.122 0.166 0.186 0.164 0.099 0.022 -- p75 = 0.164, over the 0.15 bar -- while Z1's give
    p75 = 0.135, under it.  Half the exchange was written and half was not, which puts two blocks
    on one another's sites; `sb_audit` reported 432 site clashes.

    The joint fit is not close to the bar, on either half:

        Z0   per-tone D  -11.99 -12.01 -12.00 -11.99 -11.98 -11.99 -11.99 -12.00 -12.00 -12.02
                         -12.06 -12.04      spread 0.0825   s2/s1 0.0027
        Z1   per-tone D  +12.00 +11.99 +11.98 +12.00 +12.00 +12.02 +12.00 +12.00 +11.99 +11.99
                         +12.03 +12.01      spread 0.0450   s2/s1 0.0028

    and it does not weaken the test, which is what rule 26 requires of any such change: a genuine
    split has STRUCTURALLY unequal D_i, so the rank-1 vector shows it at full size rather than at
    noise size (c150's `rows 1:5 -> 6:10` is +7 and +2, a spread of 5 site, not 0.08).  The
    per-frame quantile is still measured and still reported -- it is evidence about the crossing,
    just not the thing that decides rigidity.

    Returns (D, rank1_spread, n_frames_used, worst_per_frame_spread, p75_per_frame) or None.
    """
    ds, res, rows = [], [], []
    for f in frames:
        meas = P(sp, f, axis)
        if len(meas) != len(src):
            continue                       # peaks merged: past a crossing, correspondence is gone
        d = [m - s for m, s in zip(sorted(meas), sorted(src))]
        if abs(sum(d) / len(d)) < MIN_MOTION:
            continue                       # not moving yet; nothing to measure
        ds.append(sum(d) / len(d)); res.append(max(d) - min(d)); rows.append(d)
    if len(ds) < 2 or len(src) < 2:
        return None
    worst = max(res)
    p75 = sorted(res)[int(0.75 * (len(res) - 1))] if len(res) >= 4 else worst

    A = np.array(rows)                     # frames x tones
    v = np.linalg.svd(A, full_matrices=False)[2][0]
    if abs(v.mean()) < 1e-9:
        return None                        # no common direction at all
    w = v / v.mean()                       # per-tone displacement, in units of the mean
    D = max(ds, key=abs)
    spread = float(w.max() - w.min()) * abs(D)
    if spread > RIGID_SPREAD:
        return None                        # the members do NOT share one displacement: a split
    return D, spread, len(ds), worst, p75


# ======================================== 4c. RULE 40: the comb on the other axis is a MEASUREMENT
def sub_comb(M, sp, win, axis, other, frames):
    """Which lines on the NON-MOVING axis actually take part in this move?

    A crossed AOD pair holds two independent frequency combs, and nothing requires the one on the
    axis that is not moving to span the whole block.  Every move in c150, c200 and c300 happened
    to use the block's full extent, so `extend_comb` reads the comb off the joining species' rest
    configuration -- the whole block -- and that was never wrong before c540.

    c540 breaks it constantly, because it is pipelined and does gate moves on a SUB-COMB.  Eleven
    of its transitions are a row permutation carried on a proper subset of the block's columns,
    and the subsets are arithmetic progressions -- exactly what an AOD produces:

        X1 f203-205  cols {13,19}                    X1 f183-189  cols {14,16,18,20,22,24}
        Z0 f210-212  cols {14,20}                    Z0 f266-272  cols {2,4,6,8,10,12}
        Z0 f224-228  cols {16,22}                    Z1 f266-272  cols {2,4,6,8,10,12}
        X1 f232-234  cols {17,23}                    Z0 f235-237  cols {17,23}
        X1 f236-238  cols {17,23}                    X1 f240-242  cols {18,24}
        X1 f285-287  cols {16,22}

    The signature is unmistakable in the profile: X1 has NINE rows, and on f204 its row profile
    shows EIGHTEEN peaks -- every row twice, once on its tone and once ~0.57 site below.  Nine
    rows cannot split into eighteen groups, so the split is across the other axis.  Profiling one
    column at a time settles it: cols 13 and 19 read 19.66 20.60 21.61 22.31 22.71 23.61 24.59
    25.51 26.51 while the other ten read within 0.10 of their tones.  The move is the cyclic shift
    `19:26 -> 20:27 | 27 -> 19` on the rectangle {13,19} x 19:27.

    Assuming the full extent instead predicts EVERY marker moving, so `verify` scores ten
    correctly-static columns against a moving prediction and the move is rejected outright -- it
    does not come out wrong, it comes out UNDETERMINED.

    A line takes part if, on SOME frame inside the transition, its markers leave their tones.  The
    bar is TOL_ONGRID, the project's existing definition of "on its tone" -- measured on c540 the
    two populations are 0.04-0.10 (static) against 0.31-0.50 (carried), so nothing hangs on it.
    Taking the MAX over frames rather than reading one frame matters: at half progress a swap of
    adjacent tones merges into peaks that sit back on the tones (rule 10).
    """
    part = []
    for t in other:
        worst = 0.0
        for f in frames:
            w = ((win[0], win[1], t - 0.45, t + 0.45) if axis == 0
                 else (t - 0.45, t + 0.45, win[2], win[3]))
            pk = M.peaks(M.fill[sp], w, f, axis)
            if pk:
                worst = max(worst, max(abs(v - round(v)) for v in pk))
        if worst > sb_compose.TOL_ONGRID:
            part.append(t)
    return part


def sub_window(M, sp, win, axis, lines, iv, fa, fb, bounds=None):
    """Re-derive a sub-comb move's frame window from the SUB-COMB, not from the whole block.

    The transition's own window comes from occupancy over the WHOLE block (rule 2), and a
    sub-comb move is nearly invisible to that: ten static columns dominate the profile and the two
    carried ones contribute peaks that merge into the static ones, so the block reads "at rest"
    while part of it is plainly moving.  The transition therefore names the right species and the
    right axis and gets the TIMES wrong, and a window that starts mid-move has no settled frame to
    read `src` from -- rule 32's failure, arrived at from the other direction.

    c540's X1 f203-205 is the case.  Read on the sub-comb {13,19}, column 13's rows are:

        f200  19.01 20.01 21.01 22.02 22.96 24.03 25.03 26.04 26.91      at rest
        f201  19.06 20.10 21.07 22.08 23.02 24.03 25.09 26.02 26.41      p = 0.075
        f203  19.30 20.36 21.37 22.37 23.38 24.10 24.49 25.39 26.39      p = 0.37
        f206  19.83 20.90 21.90 22.85 23.85 24.91 25.92 26.92            p = 0.90, two merged
        f208  19.01 20.01 21.01 22.02 23.01 24.01 25.03 26.04 27.01      at rest

    which is `19:26 -> 20:27 | 27 -> 19` over f201-f207, fitting every frame to about 0.03 site.
    Cut to f203..f205 the read has no settled frame at either end and the answer came out
    `21:23 -> 22:24 | 24 -> 21` -- which scores 0.2921 on the one informative frame against the
    right map's 0.0513, while its mean over the padded window is a plausible-looking 0.1128.

    So extend outwards while the sub-comb is off its tones, staying inside the pulse-free interval,
    and keep one settled frame each side for the timing (rule 16).

    AND STOP AT THE NEIGHBOURING TRANSITION.  A pipelined movie chains sub-comb moves back to
    back, so the sub-comb is off its tones continuously across two or three of them and an
    unclamped extension fuses them: c540's X1 has transitions at f232..f234, f236..f238 and
    f240..f242, and extending the first two freely gave windows f231-238 and f232-239 which both
    returned the SAME rotation -- one move written twice and two of the movie's moves lost.  The
    transition list is the independent evidence for where one move ends and the next begins, so
    `bounds` clamps the extension to the gap between this transition and its neighbours for the
    same species.
    """
    keep = (1 - axis, tuple(lines))

    def off(f):
        pk = M.peaks(M.fill[sp], win, f, axis, keep=keep)
        return bool(pk) and max(abs(v - round(v)) for v in pk) > sb_compose.TOL_ONGRID

    blo, bhi = iv
    if bounds:
        blo, bhi = max(blo, bounds[0]), min(bhi, bounds[1])
    a, b = fa, fb
    while a - 1 >= blo and (a - 1) not in M.gate and off(a - 1):
        a -= 1
    while b + 1 <= bhi and (b + 1) not in M.gate and off(b + 1):
        b += 1
    read = [f for f in range(a, b + 1) if f not in M.gate]
    fit = [f for f in range(max(iv[0], a - 1), min(iv[1], b + 1) + 1) if f not in M.gate]
    return read, fit


class SubPeaks:
    """`sb_compose.Peaks` restricted to a comb of lines on the other axis (rule 40).

    Precomputed over the move's own frames only, so 1a still holds -- the measuring code is never
    called from inside a fit loop.  Every species is measured through the same restriction, so the
    cross-species join test of section 5 keeps working on a sub-comb move.
    """

    def __init__(self, M, wins, keep, frames):
        self.pk = {}
        for nm, w in wins.items():
            for f in frames:
                for ax in (0, 1):
                    self.pk[(nm, f, ax)] = M.peaks(M.fill[nm], w, f, ax, keep=keep)

    def __call__(self, nm, f, axis):
        return self.pk.get((nm, f, axis), [])


# ===================================================================== 5. timing
def fit_timing(P, M, sp, axis, src, dst, frames, lo, hi):
    """ONE easing for the whole move -- all sub-blocks share it -- confined to [lo, hi] (rule 9).

    The objective is the full SYMMETRIC peak-matching error on the species' fill with the partition
    held fixed, so this is rule 11's 'find the partition and the timing separately', done against
    the measured map rather than against a candidate library.  Coarse sweep then local refinement:
    the error surface is a polynomial and has no fine structure to miss.  Never call the measuring
    code from inside this loop -- P is precomputed (1a).
    """
    best = None
    for a in np.arange(lo, hi - 1.5 + 1e-9, COARSE):
        for b in np.arange(a + 1.5, hi + 1e-9, COARSE):
            m = sb_compose.verify(P, sp, axis, src, dst, float(a), float(b), frames, M)[0]
            if m == m and (best is None or m < best[0]):
                best = (m, float(a), float(b))
    if best is None:
        return None
    _, a0, b0 = best
    for a in np.arange(max(lo, a0 - 0.3), min(hi - 1.5, a0 + 0.3) + 1e-9, FINE):
        for b in np.arange(max(a + 1.5, b0 - 0.3), min(hi, b0 + 0.3) + 1e-9, FINE):
            m = sb_compose.verify(P, sp, axis, src, dst, float(a), float(b), frames, M)[0]
            if m == m and m < best[0]:
                best = (m, float(a), float(b))
    return best


def reconcile_bounded(moves, runs, P, M):
    """rule 14, with the merged boundary confined to each touched move's pulse-free interval.

    sb_compose.reconcile refuses to merge ACROSS a pulse but does not stop the merged boundary from
    landing INSIDE the next pulse run: on c150's frames 0-49 it put the f16.73 / f17.00 cluster at
    f17.18, i.e. after the pulse at f17 had already fired.  Rule 9 says a move must be finished by
    the moment the next pulse's first frame is shown, so intersect the trial range with [lo, hi].
    """
    def same_boundary(v, w):
        if abs(w - v) > sb_compose.RECONCILE_FR:
            return False
        a, b = min(v, w), max(v, w)
        return not any(a <= p0 and p1 <= b for p0, p1 in runs)

    # A MOVE'S OWN TWO ENDPOINTS ARE NEVER ONE BOUNDARY MEASURED TWICE -- they are the two ends of
    # one move, and merging them collapses it to zero duration.  fit_timing's shortest admissible
    # span is exactly RECONCILE_FR (1.5 frames), so a genuinely short move hits this: on c150's
    # f192-221 window it put both ends of a 1.5-frame move in one cluster, every trial boundary then
    # failed the `fb - fa >= 1.0` test, the target fell back to the cluster mean, and verify()
    # divided by (b - a) == 0.  Physically a swap of a block onto its own sites can be fast; it
    # cannot be instantaneous.
    own = set()
    for mv in moves:
        own.add((round(mv["fa"], 4), round(mv["fb"], 4)))
        own.add((round(mv["fb"], 4), round(mv["fa"], 4)))

    def joinable(cur, v):
        if not (same_boundary(cur[-1], v) and same_boundary(cur[0], v)):
            return False
        return not any((u, v) in own for u in cur)

    pts = sorted({round(v, 4) for mv in moves for v in (mv["fa"], mv["fb"])})
    if not pts:
        return []
    clusters, cur = [], [pts[0]]
    for v in pts[1:]:
        if joinable(cur, v):
            cur.append(v)
        else:
            clusters.append(cur); cur = [v]
    clusters.append(cur)

    remap, log = {}, []
    for cl in clusters:
        if len(cl) == 1:
            remap[cl[0]] = cl[0]; continue
        cls = set(cl)
        touched = [mv for mv in moves
                   if round(mv["fa"], 4) in cls or round(mv["fb"], 4) in cls]
        blo = max(mv["lo"] for mv in touched)
        bhi = min(mv["hi"] for mv in touched)
        best = None
        for trial in np.arange(max(blo, min(cl) - 0.4), min(bhi, max(cl) + 0.4) + 1e-9, FINE):
            tot, ok = 0.0, True
            for mv in touched:
                fa = float(trial) if round(mv["fa"], 4) in cls else mv["fa"]
                fb = float(trial) if round(mv["fb"], 4) in cls else mv["fb"]
                if fb - fa < 1.0:
                    ok = False; break
                axis = 0 if mv["axis"] == "cols" else 1
                tot += sb_compose.verify(P, mv["sp"], axis,
                                         mv.get("src") or (mv["A"] + mv["B"]),
                                         mv.get("dst") or (mv["A2"] + mv["B2"]),
                                         fa, fb, list(range(mv["f0"], mv["f1"] + 1)), M)[0]
            if ok and (best is None or tot < best[0]):
                best = (tot, float(trial))
        # placed where it costs LEAST, not at the cluster mean -- the mean is arbitrary and simply
        # trades one move's accuracy for another's
        tgt = best[1] if best else sum(cl) / len(cl)
        for v in cl:
            remap[v] = tgt
        log.append((cl, tgt))

    for mv in moves:
        fa2, fb2 = remap[round(mv["fa"], 4)], remap[round(mv["fb"], 4)]
        if (fa2, fb2) == (mv["fa"], mv["fb"]):
            continue
        if fb2 - fa2 < 1.0:          # belt and braces: never reconcile a move into nothing
            continue
        axis = 0 if mv["axis"] == "cols" else 1
        m, w, n = sb_compose.verify(P, mv["sp"], axis,
                                    mv.get("src") or (mv["A"] + mv["B"]),
                                    mv.get("dst") or (mv["A2"] + mv["B2"]),
                                    fa2, fb2, list(range(mv["f0"], mv["f1"] + 1)), M)
        mv["fa"], mv["fb"] = round(fa2, 3), round(fb2, 3)
        mv["t0"], mv["t1"] = round(fa2 * M.dt, 4), round(fb2 * M.dt, 4)
        mv["mean"], mv["worst"], mv["ok"] = round(m, 4), round(w, 3), bool(m <= sb_compose.ACCEPT)
    return log


def drop_conflicting_joins(moves, rests, notes):
    """ONE ATOM IS ON ONE RECTANGLE AT ONE INSTANT -- so a species being carried by its OWN
    rectangle cannot also be riding somebody else's at the same time (c540).

    Section 5 grows a move's rectangle across species by testing the fitted tone map against every
    other species, and rule 31 already narrows that by demanding the species actually move on the
    axis.  Neither guard can see the case where BOTH species have their own move on that axis in
    the same batch, with DIFFERENT maps: each move's join test passes -- the maps differ on only a
    few of the nine rows, and rule 31's dilution lets a mean over all peaks through at 0.09 and
    0.11 -- so each rectangle grows to span the other's columns and the two then claim the same
    atoms.

    c540 f018-025 is the case, and `se_sim` catches it downstream as 588 `check4` entries:

        move 5  X0 rows  t 0.5381-0.6952  x 1:24  y 13:15 -> 16:18 | 16:18 -> 13:15
        move 6  X1 rows  t 0.5381-0.6952  x 1:24  y 17:18 -> 14:15 | 14:16 -> 16:18

    X0 stands on cols 1:12 and X1 on cols 13:24, so the rectangles should be x 1:12 and x 13:24;
    written as x 1:24 each, they are two crossed pairs both holding all 24 columns and driving
    the same atoms two different ways.  At most one of the two joins can be true, and since each
    species demonstrably has its own move here, neither is: drop the foreign species from both and
    let each rectangle keep its owner's own comb.
    """
    def span(m):
        return (min(m["fa"], m["fb"]), max(m["fa"], m["fb"]))

    for a in moves:
        for b in moves:
            if a is b or a["axis"] != b["axis"]:
                continue
            (a0, a1), (b0, b1) = span(a), span(b)
            if min(a1, b1) - max(a0, b0) <= MIN_CONFLICT_OVERLAP:
                continue                      # not live at the same time (rule 14)
            nm = b["sp"]
            if nm == a["sp"] or nm not in a["joins"]:
                continue
            if (list(a["src"]), list(a["dst"])) == (list(b["src"]), list(b["dst"])):
                continue                      # same map: they really are one rectangle
            a["joins"] = [j for j in a["joins"] if j != nm]
            notes.append("%s %s f%03d-%03d: %s dropped from this rectangle -- it has its own %s "
                         "move over the same frames with a DIFFERENT map (%s -> %s against "
                         "%s -> %s), and one atom cannot be on two rectangles at once"
                         % (a["sp"], a["axis"], a["f0"], a["f1"], nm, a["axis"],
                            comb(b["src"]), comb(b["dst"]), comb(a["src"]), comb(a["dst"])))
    for a in moves:
        if not a.get("sub_comb_lines"):
            a["comb"] = sb_compose.comb_for(a["joins"], rests,
                                            0 if a["axis"] == "cols" else 1, a["f0"])


# ============ 4b'. SESSION 17 S2.1: THE COMB ON THE MOVING AXIS IS A MEASUREMENT TOO
def moving_tones(P, M, sp, axis, S, frames):
    """WHICH TONES ACTUALLY LEAVE THEIR SITE, on the axis that moves.

    A tone that is genuinely static has a peak sitting on it on every MOVING frame -- still true
    when a marker passes through it, because two markers closer than MERGE_SEP merge at their
    midpoint (rule 10), at most half a separation away.  A tone that moves has no peak on it at
    mid-progress.  So take the WORST over the moving frames of the distance from the tone to the
    nearest peak, and call the tone moving when nothing can be said to sit on it.

    A tone outside the visible range is SKIPPED (rule 21: an absent prediction is not evidence), so
    a block entering or leaving the panel reports only on the tones the movie can show.

    Returns (moving, static, worst_per_tone) or None when the window has no moving frame.
    """
    vis = sb_compose.visible_range(M, axis)
    mvf = [f for f in frames
           if f not in M.gate and P(sp, f, axis)
           and max(abs(v - round(v)) for v in P(sp, f, axis)) > sb_compose.TOL_ONGRID]
    if not mvf:
        return None
    worst = {}
    for t in S:
        if vis and not (vis[0] - 0.4 <= t <= vis[1] + 0.4):
            continue
        d = 0.0
        for f in mvf:
            pk = P(sp, f, axis)
            if pk:
                d = max(d, min(abs(v - t) for v in pk))
        worst[t] = d
    mov = [t for t in S if worst.get(t, 0.0) > MOVING_TONE_SEP]
    sta = [t for t in S if t in worst and worst[t] <= MOVING_TONE_SEP]
    return mov, sta, worst


def contradicted(parts, mov):
    """tones the measurement says MOVE that this candidate holds static"""
    held = set()
    for p in parts:
        for s, d in zip(p[0], p[1]):
            if s == d:
                held.add(s)
    return sorted(held & set(mov))


def candidate_runs(mov, S):
    """the contiguous runs worth trying as the moving set: the measured set, and its convex hull.

    A tone reads static only when something sits on it, so the measured moving set is a LOWER
    bound on what moves and can have a hole in it (a marker passing within MOVING_TONE_SEP of a
    tone at some progress).  The hull is the natural second hypothesis.
    """
    mov = sorted(mov)
    if not mov:
        return []
    out = []
    if mov == list(range(mov[0], mov[0] + len(mov))):
        out.append(mov)
    hull = [t for t in S if mov[0] <= t <= mov[-1]]
    if hull and hull not in out and hull == list(range(hull[0], hull[0] + len(hull))):
        out.append(hull)
    return out


def rotations_of(sub, S):
    """rotations of a contiguous RUN `sub` of the comb, the remaining tones of S held static.

    `rotation_candidates` enumerates rotations of the WHOLE comb only.  Shayne's `y 13:15 <->
    16:18` is a rotation by +3 of the run {13..18} inside a nine-row block whose rows 10:12 stand
    still, and no rotation of the whole comb is that map.  Still a one-integer family (3a), and
    every member is scored by the same verified error as everything else.
    """
    n = len(sub)
    if n < 2 or sub != list(range(sub[0], sub[0] + n)):
        return []
    rest = [t for t in S if t not in sub]
    out = []
    for k in range(1, n):
        dst = [sub[(i + k) % n] for i in range(n)]
        parts = [(tuple(a), tuple(b)) for a, b in split_by_displacement(sub, dst)]
        if len(parts) != 2:
            continue
        p = [(a, b, b[0] - a[0], None,
              "(rotation by %+d of the measured moving run %s)"
              % (k - n if k > n // 2 else k, comb(sub))) for a, b in parts]
        if rest:
            p.append((tuple(rest), tuple(rest), 0, None,
                      "(%s measured static: a peak sits on each of them on every moving frame)"
                      % comb(rest)))
        out.append(p)
    return out


# ===================================================================== main
def build(M, P, wins, blocks, rests, runs, ivs, f0, f1, outlines, verbose=True, events=None):
    """`events` names the READOUT / LOAD transitions, which section 7 measures BY HAND.

    A readout is not a move: the block desaturates and descends off panel while a fresh block of
    the same species is created at the reservoir, so the transition the occupancy test enumerates
    runs from the DEPARTING block's rectangle to the ARRIVING one's and no rigid motion connects
    them.  Left to the automatic solver it invents one.  On c150 those transitions used to be
    absorbed and never enumerated at all, so nothing tried; once they ARE enumerated -- which is
    more correct, rule 36 -- the solver produces two spurious moves in f123-165, one of them a
    duplicate of a real move fitted over a wider window, and a duplicate costs a crossed pair it
    does not need.

    So name them and skip them, which is the division of labour section 7 already describes:
    `sb_events.py` FINDS them, the analyst confirms them with `sb_probe --peaks`, and the rows are
    written by hand into `extra.json`.  They are reported as `readouts`, not as undetermined --
    they are accounted for, just not by this tool.
    """
    moves, undet, evidence, notes = [], [], [], []
    readouts = []
    last_resort = []            # session 27: (transition, (move, evidence), n candidates)
    trs = sorted([t for nm in rests for t in rests[nm]["transitions"]],
                 key=lambda t: (t["f0"], t["sp"]))
    for tr in trs:
        if events and any(e["sp"] == tr["sp"] and e["f0"] <= tr["f0"] and tr["f1"] <= e["f1"]
                          for e in events):
            readouts.append(tr)
            notes.append("%s %s f%03d-%03d: READOUT / LOAD -- hand-measured per SKILL.md 7, not "
                         "fitted (a departing block and its replacement are not one rigid motion)"
                         % (tr["sp"], tr["kind"], tr["f0"], tr["f1"]))
            continue
        iv = sb_rigid.interval_of(ivs, tr["f0"], tr["f1"])
        if iv is None:
            undet.append(tr); continue
        lo, hi = sb_rigid.pulse_bounds(runs, *iv)
        frames = [f for f in range(max(tr["f0"], iv[0]), min(tr["f1"], iv[1]) + 1)
                  if f not in M.gate]
        if len(frames) < 3:
            undet.append(tr); continue
        # The TIMING is fitted over a slightly wider window than the PARTITION is read on: a couple
        # of settled frames past arrival are strong evidence that the block has stopped, and they
        # pin t_finish, which the flat tail of the easing otherwise leaves very soft.  They must NOT
        # enter the partition read -- at rest every outline colour covers the whole block again, so
        # the class dissolves and rigid_displacement would take the whole block as one class.
        fit_frames = [f for f in range(max(tr["f0"], iv[0]), min(tr["f1"] + 2, iv[1]) + 1)
                      if f not in M.gate]

        def emit(axis, parts, how, read_on, extra=None, commit=True, Pv=None, comb_lines=None,
                 fit_on=None):
            """one transition + one axis + a complete partition -> a verified move, or None.

            Every guard here is load-bearing, and each one caught a wrong sheet:
              * the map must COVER the whole block -- a partial cover scores every unmodelled
                marker against a foreign prediction (0.41 site on X1's f272-281);
              * it must be a BIJECTION -- two sub-blocks claiming one destination is two atoms
                driven into one trap, which no crossed pair can do (X0's f192-203);
              * each emitted ROW carries one uniform displacement, so a part holding two is split.
            """
            S = sorted(tr["x0"] if axis == 0 else tr["y0"])
            S2 = sorted(tr["x1"] if axis == 0 else tr["y1"])
            src = [v for p in parts for v in p[0]]
            dst = [v for p in parts for v in p[1]]
            if len(src) != len(dst) or src == dst:
                return None, None
            if sorted(src) != S or sorted(dst) != S2:
                # print the RAW lists, not comb(): comb() de-duplicates, so a repeated tone renders
                # as a clean range and the note reads as a contradiction
                notes.append("%s %s f%03d-%03d %s: %s -> %s does not cover the block %s -> %s "
                             "exactly, so it is rejected, not written"
                             % (tr["sp"], tr["kind"], tr["f0"], tr["f1"],
                                "cols" if axis == 0 else "rows",
                                sorted(src), sorted(dst), S, S2))
                return None, None
            if len(set(src)) != len(src) or len(set(dst)) != len(dst):
                notes.append("%s %s f%03d-%03d %s: %s -> %s is not a bijection (two sub-blocks "
                             "claim one destination), so it is rejected, not written"
                             % (tr["sp"], tr["kind"], tr["f0"], tr["f1"],
                                "cols" if axis == 0 else "rows", comb(src), dst))
                return None, None
            order = np.argsort(src)
            src = [src[i] for i in order]; dst = [dst[i] for i in order]
            # Pv is P restricted to a sub-comb (rule 40); everything below must use the SAME peak
            # source the partition was read from, or the timing is fitted against the static
            # majority the rectangle does not carry.
            Pe = Pv if Pv is not None else P
            ff = fit_on if fit_on is not None else fit_frames
            ft = fit_timing(Pe, M, tr["sp"], axis, src, dst, ff, lo, hi)
            if ft is None:
                return None, None
            m, fa, fb = ft
            # A MOVE MUST ACTUALLY HAPPEN INSIDE THE FRAMES IT CLAIMS TO EXPLAIN.  The easing is
            # flat at both ends, so a fit can push the whole move past the end of the window and
            # sit at progress ~0 throughout -- which reproduces a block that never moved, and
            # scores beautifully for exactly that reason.  That is the fit saying "there is no move
            # here", and it must be read as a rejection, not as a result: on c150's f192-203 a
            # blend colour split into a fictitious `rows 12 -> 13 | 13 -> 12` swap and was fitted
            # to f203.4-f222.0, entirely outside its own f192-205 window, for a mean of 0.0199
            # while X0's rows sat dead still on 11:15 the whole time.
            prog = [float(sb_read.smoothstep((f - fa) / (fb - fa))) for f in ff]
            span = max(prog) - min(prog)
            if span < MIN_SPAN:
                notes.append("%s %s f%03d-%03d %s: %s -> %s rejected -- the fitted easing "
                             "(f%.2f-f%.2f) covers only %.2f of its travel inside f%03d-f%03d, so "
                             "it describes a block that does not move in this window"
                             % (tr["sp"], tr["kind"], tr["f0"], tr["f1"],
                                "cols" if axis == 0 else "rows", comb(src), comb(dst),
                                fa, fb, span, ff[0], ff[-1]))
                return None, None
            joins, detail, cb = sb_compose.extend_comb(Pe, M, axis, src, dst, fa, fb, ff,
                                                       blocks, rests, tr["f0"])
            if comb_lines is not None:
                cb = sorted(comb_lines)   # measured, not taken from the block's extent (rule 40)
                joins = [tr["sp"]]       # a sub-comb rectangle carries only its own block
            _, w, _ = sb_compose.verify(Pe, tr["sp"], axis, src, dst, fa, fb, ff, M)
            # RULE 31's DILUTION, IN THE TIME DIMENSION.  `mean` is averaged over the whole fit
            # window, and rule 16 puts SETTLED frames in that window on purpose -- they pin
            # t_finish.  But they agree with every candidate map by construction, so on a short
            # transition they drown the evidence: c540's X1 f203-205 has four resting frames and
            # ONE moving frame, and the wrong map scores 0.1128 overall while scoring 0.2921 on
            # f204 alone against the right map's 0.0513.  So keep `mean` -- it is the number every
            # score in this project is quoted as -- and rank candidate maps on the frames that
            # actually carry information.
            mvf = [f for f in ff
                   if Pe(tr["sp"], f, axis)
                   and max(abs(v - round(v)) for v in Pe(tr["sp"], f, axis))
                   > sb_compose.TOL_ONGRID]
            mm = (sb_compose.verify(Pe, tr["sp"], axis, src, dst, fa, fb, mvf, M)[0]
                  if mvf else float("nan"))
            if mm != mm:
                mm = m
            rows = []
            for a2, b2 in ((list(p[0]), list(p[1])) for p in parts):
                for g in split_by_displacement(a2, b2):
                    if g[1][0] - g[0][0] != 0:          # a sub-block that does not move needs no row
                        rows.append((list(g[0]), list(g[1])))
            if not rows:
                return None, None
            # WHICH TRANSITION THIS MOVE WAS FITTED FOR, recorded rather than inferred.  `sb_audit`
            # matches moves to transitions by rule 29's midpoint test, which is the right guard
            # against "overlap is not explanation" but is only a proxy for provenance -- and a
            # sub-comb move (rule 40) is fitted over a window re-derived from the sub-comb, so its
            # midpoint can land a frame outside the transition it explains.  On c540 that turned
            # four correctly-solved X1 permutations into reported SILENT HOLES.
            mv = dict(for_tr=[tr["sp"], tr["f0"], tr["f1"]],
                      sp=tr["sp"], axis="cols" if axis == 0 else "rows", kind=tr["kind"],
                      f0=ff[0], f1=ff[-1], iv=list(iv),
                      parts=rows, src=src, dst=dst,
                      A=rows[0][0], A2=rows[0][1],
                      B=[v for g in rows[1:] for v in g[0]],
                      B2=[v for g in rows[1:] for v in g[1]],
                      fa=round(fa, 3), fb=round(fb, 3), lo=lo, hi=hi,
                      t0=round(fa * M.dt, 4), t1=round(fb * M.dt, 4),
                      mean=round(m, 4), mean_moving=round(mm, 4), n_moving=len(mvf),
                      worst=round(w, 3), mono=0.0, span=1.0,
                      joins=joins, detail=detail, comb=cb, how=how,
                      sub_comb_lines=(sorted(comb_lines) if comb_lines is not None else None),
                      ok=bool(m <= sb_compose.ACCEPT))
            ev = dict(sp=tr["sp"], axis=mv["axis"], kind=tr["kind"], how=how,
                      read_on=list(read_on), fit_on=[ff[0], ff[-1]],
                      bounds=[lo, hi], fa=mv["fa"], fb=mv["fb"], mean=mv["mean"],
                      joins=joins, join_scores=detail,
                      classes=[dict(colour=p[4], src=list(p[0]), dst=list(p[1]),
                                    D=p[2], rigid_residual=p[3]) for p in parts])
            if extra:
                ev.update(extra)
            if commit:
                moves.append(mv)
                evidence.append(ev)
            return mv, ev

        done = False
        for axis in (0, 1):
            S = sorted(tr["x0"] if axis == 0 else tr["y0"])
            S2 = sorted(tr["x1"] if axis == 0 else tr["y1"])
            part, sub = partition(M, tr["sp"], wins[tr["sp"]], axis, frames, outlines, notes, S2)
            # One class covering the whole block is k = 1 and belongs to the measured-displacement
            # route (3a).  One class covering only PART of it is completed exactly by the
            # complement rule -- see `partition`.
            if not part or (len(part) == 1 and set(part[0][0]) >= set(S)):
                continue
            part, ok = complete_partition(part, S, S2)
            if not ok:
                continue
            # SESSION 25 / S2.1: does the appearance read hold a tone static that provably moves?
            mt = moving_tones(P, M, tr["sp"], axis, S, frames) if S21_COMPETITION else None
            app_bad = contradicted(part, mt[0]) if mt else []
            if not app_bad:
                # the measurement confirms the appearance read (or S2.1 is off): PRODUCTION PATH
                got0 = emit(axis, part, "appearance triple (rule 3z): the outline colours name the "
                                        "sub-blocks directly", [sub[0], sub[-1]])
                if got0[0]:
                    done = True
                    # SESSION 26: A SAME-SITE PERMUTATION READ IN MORE THAN TWO PARTS AND OVER THE
                    # GUIDELINE competes against the rotations of its own comb.  c540's Z1 rows
                    # f200-208 is the case: the appearance read gives `10:13->14:17 | 15->18 |
                    # 14->10 | 16:18->11:13` at 0.11 -- the hand book's rotation by +4 with rows 14
                    # and 15's destinations transposed.  Every tone moves, so `moving_tones` has
                    # nothing to contradict, and gate 3 of the patch detector leaves whole-block
                    # moves alone.  A crossed pair rotates a contiguous comb in TWO rigid groups
                    # (3a), so a 3+-part read that also fails the guideline is the appearance
                    # route saying it could not resolve the crossing -- exactly when the
                    # one-integer family should be asked.  Replaced only under ACCEPT and better
                    # by 0.01 on the moving frames; otherwise the appearance read stands.
                    m0 = got0[0]
                    # THE GUIDELINE IS NOT THE TRIGGER; THE PART COUNT IS.  Z1's 4-part read scores
                    # 0.078 on the moving frames -- UNDER the bar -- because swapping rows 14 and
                    # 15's destinations predicts nearly the same peak positions mid-flight (rule
                    # 31's dilution over the correspondence, c540_v3_diagnosis.md M2).  So: a same-
                    # site read in 3+ parts competes against the two-group rotations of its comb and
                    # is kept only if it BEATS the best rotation by more than crossing noise
                    # (ROTATION_NOISE), the rule c540_faults_vs_shayne.md 2.1 fix 2 proposed.  The
                    # rotation has one free parameter against the read's n; where the score cannot
                    # separate them the simpler AOM configuration is the answer (this skill's stated
                    # aim).  A genuine 3+-group move (c150's Z0 f331-350, displacements -3/-5/-7/-9)
                    # is nothing like a rotation and wins by far more than 0.03.
                    if S21_COMPETITION and S == S2 and len(m0["parts"]) > 2:
                        alts = [(rot, "rotation of the whole comb (session 26): a 3+-part "
                                      "appearance read over the guideline competes against the "
                                      "one-integer family")
                                for rot in rotation_candidates(S, S2)]
                        if mt and mt[0]:
                            for run in candidate_runs(mt[0], S):
                                for rot in rotations_of(run, S):
                                    alts.append((rot, "rotation of the measured moving run %s "
                                                      "(session 26 competition)" % comb(run)))
                        bestA = None
                        for parts_, how_ in alts:
                            g2 = emit(axis, parts_, how_, [frames[0], frames[-1]], commit=False,
                                      extra=dict(over_guideline_competition=dict(
                                          appearance_map=[(list(s), list(d)) for s, d in m0["parts"]],
                                          appearance_mean_moving=m0["mean_moving"])))
                            if g2[0] is not None and (bestA is None or
                                                      g2[0]["mean_moving"] < bestA[0]["mean_moving"]):
                                bestA = g2
                        if (bestA is not None and bestA[0]["mean_moving"] <= sb_compose.ACCEPT
                                and bestA[0]["mean_moving"] < m0["mean_moving"] + ROTATION_NOISE):
                            notes.append("%s %s f%03d-%03d %s: the appearance read %s has %d parts "
                                         "and scores %.4f on the moving frames; the two-group "
                                         "rotation %s scores %.4f on the same frames, within %.2f of "
                                         "it, and REPLACES it (session 26 competition: the simpler "
                                         "AOM configuration wins a tie)"
                                         % (tr["sp"], tr["kind"], tr["f0"], tr["f1"],
                                            "cols" if axis == 0 else "rows",
                                            " | ".join("%s->%s" % (comb(s), comb(d))
                                                       for s, d in m0["parts"]),
                                            len(m0["parts"]), m0["mean_moving"],
                                            " | ".join("%s->%s" % (comb(s), comb(d))
                                                       for s, d in bestA[0]["parts"]),
                                            bestA[0]["mean_moving"], ROTATION_NOISE))
                            moves[moves.index(m0)] = bestA[0]
                            evidence[evidence.index(got0[1])] = bestA[1]
                        elif bestA is not None:
                            notes.append("%s %s f%03d-%03d %s: the appearance read has %d parts and "
                                         "scores %.4f on the moving frames; the best two-group "
                                         "rotation %s scores %.4f -- appearance read KEPT (session "
                                         "26 competition)"
                                         % (tr["sp"], tr["kind"], tr["f0"], tr["f1"],
                                            "cols" if axis == 0 else "rows", len(m0["parts"]),
                                            m0["mean_moving"],
                                            " | ".join("%s->%s" % (comb(s), comb(d))
                                                       for s, d in bestA[0]["parts"]),
                                            bestA[0]["mean_moving"]))
                continue
            # CONTRADICTED: the appearance map must COMPETE (rule 42).  Candidates are the
            # appearance map itself, the rotations of the measured moving run (and of its hull),
            # and the measured-displacement candidates; mean over the MOVING frames decides.
            mov, sta, worst = mt
            ex = dict(moving_tone_read=dict(moving=list(mov), static=list(sta),
                                            contradicts_appearance_read=list(app_bad)))
            notes.append("%s %s f%03d-%03d %s: the appearance read holds %s static, but no peak "
                         "sits within %.2f of %s on the moving frames -- the rotations of the "
                         "measured run %s are scored against it (S2.1 competition)"
                         % (tr["sp"], tr["kind"], tr["f0"], tr["f1"],
                            "cols" if axis == 0 else "rows", comb(app_bad), MOVING_TONE_SEP,
                            comb(app_bad), comb(mov)))
            tries = [(part, "appearance triple (rule 3z): the outline colours name the "
                            "sub-blocks directly -- CONTRADICTED by the moving-tone read, kept "
                            "only because it out-scored every rotation of the measured run",
                      [sub[0], sub[-1]], dict(ex))]
            for run in candidate_runs(mov, S):
                for rot in rotations_of(run, S):
                    tries.append((rot, "rotation of the MEASURED moving run %s (session 17 S2.1): "
                                       "the tones held static are the ones a peak provably sits "
                                       "on throughout" % comb(run),
                                  [frames[0], frames[-1]], dict(ex)))
            cands = measured_partition(P, M, tr["sp"], axis, S, S2, frames)
            for r in (cands or [])[:6]:
                tries.append((r["parts"],
                              "measured displacements (3a), competing against a contradicted "
                              "appearance read",
                              r["read_on"],
                              dict(ex, displacement_read=dict(
                                  per_tone_D=r["D"], rank1_residual=r["resid"],
                                  monotone_penalty=r["mono"], read_on=r["read_on"],
                                  candidates_considered=len(cands or [])))))
            best, best_i = None, -1
            for i_, (parts_, how_, read_, ex_) in enumerate(tries):
                got = emit(axis, parts_, how_, read_, commit=False, extra=ex_)
                if got[0] is not None and (best is None or
                                           got[0]["mean_moving"] < best[0]["mean_moving"]):
                    best, best_i = got, i_
            # THE BEST OF A BAD SET IS NOT AN ANSWER (session 25, c540 f093-095).  A generated
            # candidate replaces the production answer only if it MEETS THE GUIDELINE on the
            # moving frames.  X0's f093-095 appearance read was rejected by MIN_SPAN in production
            # and the transition was then correctly carried by X1's rectangle; ungated, the best
            # rotation candidate scored 0.2193 and was committed anyway, giving X0 its own wrong
            # move.  So: a non-appearance winner over ACCEPT falls back to exactly what production
            # does -- emit the appearance map if it emits, else leave it to the later routes.
            # The bar is the guideline plus crossing noise (session 26, on the user's instruction):
            # `X0 rows f140-144`'s correct rotation scored 0.1004 against a 0.10 bar and was
            # refused by four ten-thousandths.  ACCEPT + ROTATION_NOISE is the same tolerance the
            # 3+-part rule below uses, so it is one rule, not a tuned constant; f093-095's 0.2193
            # is still refused by a wide margin.
            bar = sb_compose.ACCEPT + ROTATION_NOISE
            if best is not None and best_i > 0 and best[0]["mean_moving"] > bar:
                notes.append("%s %s f%03d-%03d %s: S2.1 competition's best candidate %s scores "
                             "%.4f on the moving frames, over the %.2f bar (guideline + crossing "
                             "noise) -- NOT taken; the production route decides as before"
                             % (tr["sp"], tr["kind"], tr["f0"], tr["f1"],
                                "cols" if axis == 0 else "rows",
                                " | ".join("%s->%s" % (comb(s), comb(d))
                                           for s, d in best[0]["parts"]),
                                best[0]["mean_moving"], bar))
                best = None
                if emit(axis, part, "appearance triple (rule 3z): the outline colours name the "
                                    "sub-blocks directly", [sub[0], sub[-1]])[0]:
                    done = True
                continue
            if best is not None:
                notes.append("%s %s f%03d-%03d %s: S2.1 competition won by %s (mean over moving "
                             "frames %.4f) among %d candidates"
                             % (tr["sp"], tr["kind"], tr["f0"], tr["f1"],
                                "cols" if axis == 0 else "rows",
                                " | ".join("%s->%s" % (comb(s), comb(d))
                                           for s, d in best[0]["parts"]),
                                best[0]["mean_moving"], len(tries)))
                moves.append(best[0]); evidence.append(best[1])
                done = True

        # No outline resolved it.  Read the partition from the DISPLACEMENTS instead (3a) -- this
        # is what recovers a plain whole-block translation (one appearance class, so the read above
        # returns fewer than two) and a same-site permutation that carries no outline at all.
        if not done:
            for axis in (0, 1):
                S = sorted(tr["x0"] if axis == 0 else tr["y0"])
                S2 = sorted(tr["x1"] if axis == 0 else tr["y1"])
                cands = measured_partition(P, M, tr["sp"], axis, S, S2, frames)
                if not cands:
                    continue
                # More than one integer scale can land on the block's own destination set, and the
                # rank-1 residual is measured over the few pre-crossing frames only, so it is too
                # weak to choose between them.  Decide with the SAME symmetric peak-matching error
                # used everywhere else, over the whole window: on c150's f210-221 the residual
                # preferred `1 -> 5 | 2:5 -> 1:4` where the movie plainly shows the opposite
                # cyclic shift, `1:4 -> 2:5 | 5 -> 1`, which the verified error picks correctly.
                best = None
                for r in cands[:6]:
                    got = emit(axis, r["parts"],
                               "measured displacements (3a): one uniform integer displacement per "
                               "sub-block, scale pinned by the block's own destination set",
                               r["read_on"], commit=False,
                               extra=dict(displacement_read=dict(
                                   per_tone_D=r["D"], rank1_residual=r["resid"],
                                   monotone_penalty=r["mono"], read_on=r["read_on"],
                                   candidates_considered=len(cands))))
                    # `emit` returns the TUPLE (None, None) when it rejects, and a non-empty tuple
                    # is always truthy -- so `if got` accepted every rejection.  With one candidate
                    # that put a literal None into `moves` and the sort at the end of build() died
                    # on it; with two it died comparing best[0]["mean"].  Test the move itself.
                    if got[0] is not None and (best is None or
                                                got[0]["mean_moving"] < best[0]["mean_moving"]):
                        best = got
                if best is not None:
                    moves.append(best[0]); evidence.append(best[1])
                    done = True

        # Still nothing.  The remaining case is rule 19's k == 1 -- a plain translation -- of a
        # block that is CLIPPED at a panel edge for the early frames of its own transition.
        # `measured_partition` cannot see it: rule 20 makes it read only the LEADING RUN of frames
        # whose peak count equals the tone count, and a block sliding ONTO the panel starts with
        # fewer peaks than tones, so the run is empty and it returns at once.  That guard is right
        # about crossings and wrong here -- the peaks are missing because they are off panel, which
        # rule 21 says cannot be required to be visible, not because two markers merged.
        #
        # `uniform_displacement` is the measurement for exactly this and skips short frames instead
        # of stopping at them; it was written for it and then never called from anywhere.  It does
        # NOT read the translation off the endpoints -- 'Ways to be confidently wrong' 2 forbids
        # that, because c150's `rows 1:5 -> 6:10` is really +7 and +2 crossing -- it measures every
        # tone's displacement and returns None unless they share one value.  The endpoints only pin
        # the integer SCALE, the same way they do in `measured_partition`.
        #
        # c200's X1 f253-263 and Z0 f057-067 are the case: `cols -3:0 -> 1:4`, three of the four
        # columns off panel at the start, one visible peak growing to four.
        if not done:
            for axis in (0, 1):
                S = sorted(tr["x0"] if axis == 0 else tr["y0"])
                S2 = sorted(tr["x1"] if axis == 0 else tr["y1"])
                if len(S) != len(S2):
                    continue
                offs = {b - a for a, b in zip(S, S2)}
                if len(offs) != 1:
                    continue                    # the endpoints are not a single translation
                D = offs.pop()
                if D == 0:
                    continue                    # a same-site permutation, not a translation
                u = uniform_displacement(P, M, tr["sp"], axis, S, frames)
                if u is None:
                    continue                    # the tones do NOT share one displacement
                if D * u[0] <= 0 or abs(u[0]) > abs(D) + 0.5:
                    continue                    # measured travel disagrees with the endpoint map
                got = emit(axis, [(tuple(S), tuple(S2), D, round(u[1], 3),
                                   "(uniform displacement, %.2f site measured over %d frames)"
                                   % (u[0], u[2]))],
                           "measured uniform displacement (3a, rule 19 k=1): every tone shares one "
                           "displacement over the frames where the block is on panel; the integer "
                           "scale is pinned by the block's own destination set",
                           [frames[0], frames[-1]],
                           extra=dict(uniform_read=dict(measured_D=round(u[0], 3),
                                                        member_spread=round(u[1], 4),
                                                        member_spread_worst=round(u[3], 4),
                                                        per_frame_p75=round(u[4], 4),
                                                        n_frames=u[2])))
                if got[0]:
                    done = True
                    break

        # RULE 40, LAST: the rectangle's comb on the NON-MOVING axis may be a proper SUBSET of the
        # block.  Everything above assumes the block's full extent, which is what c150, c200 and
        # c300 always do -- so this runs only after all of it has failed, and cannot change any
        # answer those movies gave.  `sub_comb` measures which lines actually take part; the
        # partition, the timing and the join test are then all redone through a peak source
        # restricted to them, so the static majority stops swamping the carried minority.
        if not done:
            for axis in (0, 1):
                S = sorted(tr["x0"] if axis == 0 else tr["y0"])
                S2 = sorted(tr["x1"] if axis == 0 else tr["y1"])
                other = sorted(tr["y0"] if axis == 0 else tr["x0"])
                lines = sub_comb(M, tr["sp"], wins[tr["sp"]], axis, other, frames)
                if not lines or len(lines) >= len(other):
                    continue            # nothing moves on this axis, or the whole comb does
                keep = (1 - axis, tuple(lines))
                # TWO WINDOWS, AND THE SCORE DECIDES.  The transition's own window comes from
                # WHOLE-BLOCK occupancy, which a sub-comb move is nearly invisible to, so it can
                # start mid-move (c540's X1: the move runs f201-f207 and the transition says
                # f203..f205).  `sub_window` re-derives it from the sub-comb -- but a pipelined
                # movie chains sub-comb moves back to back, and then the extension runs straight
                # through the next one and fuses two moves into a wrong single map.  Neither window
                # is right in general, so try both and keep whichever explains the MOVING frames
                # better, the same symmetric error used to choose everywhere else in this file.
                nb = [t2 for t2 in trs if t2["sp"] == tr["sp"] and t2 is not tr]
                blo = max([t2["f1"] for t2 in nb if t2["f1"] <= tr["f0"]] or [iv[0]])
                bhi = min([t2["f0"] for t2 in nb if t2["f0"] >= tr["f1"]] or [iv[1]])
                ext = sub_window(M, tr["sp"], wins[tr["sp"]], axis, lines, iv,
                                 max(tr["f0"], iv[0]), min(tr["f1"], iv[1]), (blo, bhi))
                trials = [(frames, fit_frames)]
                if ext[0] and ext[0] != frames:
                    trials.append(ext)
                best = None
                for rd, ff in trials:
                    if len(rd) < 3:
                        continue
                    Psub = SubPeaks(M, wins, keep, sorted(set(rd) | set(ff)))
                    note = ("measured sub-comb (rule 40): the rectangle's %s comb is {%s}, a "
                            "subset of the block's {%s} -- the other lines stay on their tones "
                            "throughout. Read on f%03d-f%03d%s"
                            % ("rows" if axis == 0 else "cols", comb(lines), comb(other),
                               rd[0], rd[-1],
                               "" if rd == frames else ", re-derived from the sub-comb because "
                               "whole-block occupancy put the transition at f%03d..f%03d"
                               % (tr["f0"], tr["f1"])))
                    tries = []
                    part, sub = partition(M, tr["sp"], wins[tr["sp"]], axis, rd, outlines,
                                          notes if rd == frames else [], S2, keep, len(other))
                    if part and not (len(part) == 1 and set(part[0][0]) >= set(S)):
                        part2, ok = complete_partition(part, S, S2)
                        if ok:
                            tries.append((part2, "appearance triple on a sub-comb; " + note,
                                          [sub[0], sub[-1]], None))
                    cands = measured_partition(Psub, M, tr["sp"], axis, S, S2, rd)
                    for r in (cands or [])[:6]:
                        tries.append((r["parts"],
                                      "measured displacements on a sub-comb; " + note,
                                      r["read_on"],
                                      dict(displacement_read=dict(
                                          per_tone_D=r["D"], rank1_residual=r["resid"],
                                          monotone_penalty=r["mono"], read_on=r["read_on"],
                                          candidates_considered=len(cands)))))
                    ra = rotation_amount(Psub, tr["sp"], axis, S, rd)
                    if ra:
                        for rot in rotation_candidates(S, S2, [ra[2], -ra[1]]):
                            tries.append((rot, "rotation on a sub-comb; " + note,
                                          [rd[0], rd[-1]],
                                          dict(rotation_read=dict(
                                              frame=ra[0], n_positive=ra[1], n_negative=ra[2]))))
                    for parts_, how_, read_, ex in tries:
                        ex = dict(ex or {})
                        ex["sub_comb"] = list(lines)
                        got = emit(axis, parts_, how_, read_, commit=False, Pv=Psub,
                                   comb_lines=lines, fit_on=ff, extra=ex)
                        if got[0] is not None and (best is None or
                                                   got[0]["mean_moving"] < best[0]["mean_moving"]):
                            best = got
                if best is not None:
                    moves.append(best[0]); evidence.append(best[1])
                    done = True
                    break

        if not done:
            undet.append(tr)
            # SESSION 27 LAST RESORT, COMPUTED HERE AND COMMITTED LATER.  Every route above has
            # failed: no outline resolved the block (the classes read NOT RIGID or off dropout
            # frames), the displacement fit could not find a scale, no uniform translation, no
            # sub-comb.  c540's Z0 f001-007 (a 12-column rotation by +6 done in six frames) is
            # the case: both Z0 outline classes are NOT RIGID from the first moving frame, so the
            # S2.1 competition -- which is triggered by a CONTRADICTED appearance read -- never
            # runs, and production hid the movement inside a phantom X1+Z0 join.  The one-integer
            # family the physics allows for a same-site permutation of a contiguous run is its
            # rotations (3a), and `moving_tones` says which run moves.  Score them with the same
            # verified error as everything else; the winner is only a CANDIDATE here.
            #
            # WHY IT IS NOT COMMITTED HERE (session 25, `seg0_last_resort_TEST.log`): placed inside
            # this loop it also fired on X1 f023-026, a transition production correctly treats as
            # CARRIED BY X0's rectangle (the X0+X1 rows swap), and invented a 5-cycle for it at
            # 0.0995 -- then `drop_conflicting_joins` split the genuine joined rectangle.  The
            # "carried" test lives after the loop because it needs every other move first, so the
            # candidate is stored and committed only for a transition that test does NOT explain.
            if S21_COMPETITION:
                bestL, nL, gateL = None, 0, None
                for axis in (0, 1):
                    S = sorted(tr["x0"] if axis == 0 else tr["y0"])
                    S2 = sorted(tr["x1"] if axis == 0 else tr["y1"])
                    fam = []
                    if S == S2:
                        # SAME-SITE: the rotations of the measured moving run and of its hull
                        # (`moving_tones` says which tones leave their site), plus the rotations
                        # within each consecutive group of m tones (`periodic_rotations`)
                        mt = moving_tones(P, M, tr["sp"], axis, S, frames)
                        if not mt or not mt[0]:
                            continue
                        for run in candidate_runs(mt[0], S):
                            for rot in rotations_of(run, S):
                                fam.append((rot, "rotation of the measured moving run %s" % comb(run),
                                            dict(moving=list(mt[0]), static=list(mt[1]),
                                                 run=list(run))))
                        for rot in periodic_rotations(S):
                            fam.append((rot, "rotation within each group of the comb %s" % comb(S),
                                        dict(moving=list(mt[0]), static=list(mt[1]))))
                    else:
                        # A RELOCATION every route failed on: the translation composed with each
                        # rotation of the run (k = 0 is the plain translation) -- see
                        # `relocation_rotations` for why this family may live here and nowhere else
                        for rot in relocation_rotations(S, S2):
                            fam.append((rot, "relocation %s -> %s composed with a rotation"
                                        % (comb(S), comb(S2)), dict(src=list(S), dst=list(S2))))
                    # RANKED AND GATED ON THE FREE PER-FRAME PROGRESS, NOT ON THE SMOOTHSTEP FIT.
                    # `progress_per_frame` is "the heart of the method" (sb_compose): a partition is
                    # judged by whether SOME progress explains each frame, and a wrong one cannot
                    # explain every frame with a monotone sequence.  Measured on c540 (session 27):
                    #   * f316-327 `13:22->3:12 | 23:24->1:2` (the hand book): every frame to
                    #     0.02-0.08 site, p rising 0.03 -> 0.98; the joint smoothstep fit gives it
                    #     0.23 -- a 22-site wrap in 13 frames turns a 1% easing error into 0.2
                    #     site, the comb's unit pitch saturates that error against neighbouring
                    #     peaks, and the fit prefers a wrong member whose p-sequence plateaus twice;
                    #   * f330-335 X0 `13:17->20:24 | 18:24->13:19` and Z0 `1:7->6:12 | 8:12->1:5`
                    #     (both the hand book's): 0.03 free, monotone; the smoothstep fit put both
                    #     at 0.23 and chose the rotations one tone over, at 0.19-0.20;
                    #   * f248-256 X1 `13->24 | 14:24->13:23`: 0.04 either way -- they agree.
                    # THE MONOTONE PENALTY BREAKS TIME REVERSAL: the mirror rotation explains each
                    # frame equally well with p running 1 -> 0 (X0 f330-335: 0.032 both ways, the
                    # mirror's p-sequence 0.95 .. 0.10).  But a two-group SWAP -- rotation by n/2,
                    # c540's Z0 f001-007 -- is its own inverse: the configuration at p equals the
                    # one at 1 - p, so the per-frame p is arbitrary between the two and the
                    # penalty is noise (0.223 on the correct map).  Time reversal of an involution
                    # is the same map, so there is nothing to break; the penalty is skipped for it.
                    # The smoothstep fit is still what gives the move its timing and its quoted
                    # `mean`, which may read OVER the guideline here, honestly.
                    scored = []
                    for rot, howL, exL in fam:
                        src_ = [v for p in rot for v in p[0]]
                        dst_ = [v for p in rot for v in p[1]]
                        order = np.argsort(src_)
                        src_ = [src_[i] for i in order]; dst_ = [dst_[i] for i in order]
                        seq = sb_compose.progress_per_frame(P, tr["sp"], axis, src_, dst_,
                                                            frames, M)
                        if len(seq) < 3:
                            continue
                        free = sum(s[2] for s in seq) / len(seq)
                        fwd = dict(zip(src_, dst_))
                        involution = all(fwd.get(d) == s for s, d in zip(src_, dst_))
                        mono = 0.0 if involution else sb_compose.monotone_penalty(seq)
                        scored.append((free + mono, free, mono, rot, howL, exL, seq))
                    scored.sort(key=lambda x: x[0])
                    nL += len(scored)
                    for tot, free, mono, rot, howL, exL, seq in scored[:2]:  # best fitted; one spare
                        got = emit(axis, rot,
                                   "LAST-RESORT %s (session 27): no outline and no displacement fit "
                                   "described this transition, so the one-integer family is ranked "
                                   "on the FREE per-frame progress (mean error %.4f site, monotone "
                                   "penalty %.3f); committed only because no other species' "
                                   "rectangle carries the transition" % (howL, free, mono),
                                   [frames[0], frames[-1]], commit=False,
                                   extra=dict(last_resort=dict(
                                       exL, family=howL, free_progress_error=round(free, 4),
                                       monotone_penalty=round(mono, 4),
                                       per_frame=[(s[0], round(s[1], 3), round(s[2], 3))
                                                  for s in seq],
                                       family_scores=[(round(t_, 4),
                                                       " | ".join("%s->%s" % (comb(p[0]), comb(p[1]))
                                                                  for p in r_))
                                                      for t_, _f, _m, r_, _h, _e, _s in scored])))
                        if got[0] is not None and (gateL is None or tot < gateL):
                            bestL, gateL = got, tot
                            break
                if bestL is not None:
                    last_resort.append((tr, bestL, nL, gateL,
                                        "free per-frame progress error + monotone penalty"))

    # SESSION 27: COMMIT THE LAST-RESORT CANDIDATES, but only for a transition no other species'
    # rectangle carries (the same midpoint test the reporting filter below uses -- joins and frame
    # windows are fixed by now, and neither reconciliation nor de-duplication changes them), and
    # only under the S2.1 bar (guideline + crossing noise).  On c150, c200 and c300 nothing reaches
    # here: every transition of those movies is described by an earlier route or carried.
    for tr, (mvL, evL), nL, gateL, statL in last_resort:
        if tr not in undet:
            continue
        if any(tr["sp"] in m["joins"] and tr["f0"] <= (m["f0"] + m["f1"]) / 2.0 <= tr["f1"]
               for m in moves):
            continue                            # the filter below reports it as carried
        # the guideline itself, on the free per-frame progress error plus the monotone penalty:
        # the free fit has one parameter per frame, so it is held to the stricter bar
        bar = sb_compose.ACCEPT
        if gateL > bar:
            notes.append("%s %s f%03d-%03d %s: no route described this transition and the "
                         "LAST-RESORT family's best candidate %s scores %.4f (%s), over the %.2f "
                         "bar -- NOT taken, left UNDETERMINED"
                         % (tr["sp"], tr["kind"], tr["f0"], tr["f1"], mvL["axis"],
                            " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in mvL["parts"]),
                            gateL, statL, bar))
            continue
        notes.append("%s %s f%03d-%03d %s: no route described this transition and no other "
                     "species' rectangle carries it; the LAST-RESORT family gives %s (%s %.4f, "
                     "smoothstep fit mean %.4f, %d candidates)"
                     % (tr["sp"], tr["kind"], tr["f0"], tr["f1"], mvL["axis"],
                        " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in mvL["parts"]),
                        statL, gateL, mvL["mean"], nL))
        moves.append(mvL); evidence.append(evL)
        undet.remove(tr)

    moves.sort(key=lambda m: (m["fa"], m["fb"]))
    log = reconcile_bounded(moves, runs, P, M)
    # AFTER reconciliation, never before: rule 14's whole point is that two moves which really are
    # sequential can overlap by a sub-frame in their raw fits, and judging a conflict on that
    # unmerged overlap drops a legitimate cross-species join (it split c150's X0+Z0 cols f019-030`n    # off Z0's own f030-037 swap, which begins exactly where it ends).
    drop_conflicting_joins(moves, rests, notes)
    if verbose:
        for cl, tgt in log:
            print("  reconciled %s -> f%.3f" % (", ".join("f%.2f" % v for v in cl), tgt))

    uniq, seen = [], set()
    for mv in moves:
        k = (mv["axis"], tuple(mv["A"]), tuple(mv["A2"]), tuple(mv["B"]), tuple(mv["B2"]),
             tuple(mv["comb"] or []), round(mv["fa"], 1))
        if k in seen:
            continue
        seen.add(k); uniq.append(mv)

    # A transition is NOT undetermined merely because its own species' outline did not resolve it:
    # a rectangle spans species (5), so it is accounted for if some emitted move both joins that
    # species and overlaps its frames.  Report only what nothing describes.
    # OVERLAP IS NOT EXPLANATION.  The move must be the one fitted FOR this transition, not merely
    # a move of the same species whose frames happen to touch it -- otherwise a species' own
    # previous move swallows its next transition, and the move is lost with nothing reporting it.
    # Two of c200's missing moves were this: X0/X1's `rows f162..f170` double cyclic shift was
    # absorbed by their `rows f154-163` move (which ends one frame INTO it), and Z1's `rows
    # f009..f016` by its own `cols f002-010`, on a different axis entirely.  A move fitted for a
    # transition sits inside it, so require the move's MIDPOINT to fall within the transition's
    # frames; c150's genuine case (X1's f001-016 relocation carried by X0's f002-015 rectangle)
    # passes this easily, since 8.5 lies inside [1, 16].
    still = []
    for t in undet:
        if any(t["sp"] in mv["joins"]
               and t["f0"] <= (mv["f0"] + mv["f1"]) / 2.0 <= t["f1"]
               for mv in uniq):
            notes.append("%s %s f%03d-%03d: carried by another species' rectangle"
                         % (t["sp"], t["kind"], t["f0"], t["f1"]))
            continue
        still.append(t)

    # TIE: three or more classes sharing one displacement at one instant.  Any two may ride one
    # crossed pair; all three cannot without the merged rectangle capturing a foreign atom.
    bykey = {}
    for mv in uniq:
        for tag, s, d in (("a", mv["A"], mv["A2"]), ("b", mv["B"], mv["B2"])):
            if s:
                bykey.setdefault((round(mv["t0"], 4), mv["axis"], d[0] - s[0]), []).append(mv)
    for (t0, ax, D), ms in sorted(bykey.items()):
        sps = sorted({s for mv in ms for s in (mv["joins"] or [mv["sp"]])})
        if len(sps) >= 3:
            notes.append("TIE at t=%.4f on %s D=%+d: classes from %s all share this displacement "
                         "and any two may ride one crossed pair, but not all three. Other "
                         "groupings are equally minimal and THE PIXELS DO NOT DECIDE."
                         % (t0, ax, D, "+".join(sps)))
    return uniq, still, evidence, notes, readouts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--f0", type=int, default=0)
    ap.add_argument("--f1", type=int, default=None)
    ap.add_argument("--work", default=".")
    ap.add_argument("--xlsx", default="")
    ap.add_argument("--extra", default=None,
                    help="JSON list of hand-measured unload/load rows (readouts and loads, 7)")
    ap.add_argument("--scope", default="")
    ap.add_argument("--blocks", default=None,
                    help="JSON {species: [w, h]} measured over the WHOLE movie (see block_size). "
                         "Required when a block spends a whole interval off panel, or its clipped "
                         "rectangle cannot be completed and its move is never enumerated.")
    a = ap.parse_args()

    M = Movie(a.calib, a.frames)
    f1 = a.f1 if a.f1 is not None else M.nf - 1
    runs = sb_compose.pulse_runs(M)
    ivs = sb_compose.free_intervals(runs, M.nf)
    print("movie: %d frames, dt %.9f ms, cycle %.4f ms" % (M.nf, M.dt, M.nf * M.dt))
    print("pulse runs         : %s" % runs)
    print("pulse-free windows : %s" % ivs)

    wins = sb_compose.species_windows(M, a.f0, f1)
    print("windows (cols lo,hi / rows lo,hi):")
    for nm in sorted(wins):
        print("   %-3s %.2f..%.2f x %.2f..%.2f" % (nm, *wins[nm]))

    frames_all = [f for f in range(a.f0, f1 + 1) if f not in M.gate]
    # the lattice comes from the CALIBRATION, never from a constant: c150 is 12x15, c200 12x20 and
    # c300 20x18, and a hardcoded 12x15 window simply never looks at c300's cols 13:20 or rows
    # 16:18, so any outline colour that only ever appears there is missed.  sb_full.py already
    # does it this way; this is the same window, so the frames 0-49 acceptance test is unaffected.
    outlines = sb_read.discover_outlines(M, frames_all[:40], (0.4, M.K["data_cols"] + 0.6,
                                                              0.4, M.K["data_rows"] + 0.6))
    print("outline colours discovered: %s"
          % ", ".join("rgb(%.0f,%.0f,%.0f)" % c for c in outlines))

    print("measuring peaks once, frames %d..%d ..." % (a.f0, f1), flush=True)
    P = sb_compose.Peaks(M, wins, a.f0, f1)
    if a.blocks:
        # Block size is a property of the BLOCK (rule 1: one rigid size throughout), so it must be
        # measured over the whole movie and not over one window.  A block can sit off panel for an
        # entire pulse-free interval -- c150's Z0 is at cols -5:0 with one column visible from f064
        # to f122 -- and a window that never sees it whole cannot supply the width that `rect_at`
        # needs to complete the clipped rectangle.  Without it the parking slides are not
        # enumerated at all and the block stays on screen in the rebuild.
        blocks = {k: tuple(v) for k, v in json.load(open(a.blocks)).items() if k in wins}
        print("block sizes (measured over the whole movie): %s" % blocks)
    else:
        blocks = {nm: v for nm, v in
                  ((n, sb_compose.block_size(P, M, n, a.f0, f1)) for n in wins) if v}
        print("block sizes (from this window only -- pass --blocks for the movie-wide "
              "measurement): %s" % blocks)

    rests = settled(P, M, a.f0, f1, blocks, wins, outlines)
    nrel = sum(1 for nm in rests for t in rests[nm]["transitions"] if t["kind"] == "relocation")
    nper = sum(1 for nm in rests for t in rests[nm]["transitions"] if t["kind"] == "permutation")
    print("\n%d relocations + %d permutation windows = %d transitions to account for"
          % (nrel, nper, nrel + nper))
    json.dump(rests, open(os.path.join(a.work, "transitions.json"), "w"), indent=1)

    print("\nsolving ...", flush=True)
    moves, undet, evidence, notes, _ro = build(M, P, wins, blocks, rests, runs, ivs, a.f0, f1,
                                               outlines)

    print("\n== %d moves" % len(moves))
    for mv in moves:
        print("  %-6s %-4s f%03d-%03d  %-16s -> %-16s | %-12s -> %-12s  t %.4f-%.4f  "
              "comb %-10s mean %.4f %s"
              % ("+".join(mv["joins"]) or mv["sp"], mv["axis"], mv["f0"], mv["f1"],
                 comb(mv["A"]), comb(mv["A2"]), comb(mv["B"]) if mv["B"] else "-",
                 comb(mv["B2"]) if mv["B2"] else "-", mv["t0"], mv["t1"],
                 comb(mv["comb"] or []), mv["mean"], "OK" if mv["ok"] else "OVER 0.10"))

    rows = sb_compose.schedule_rows(moves)
    ng, peak = sb_compose.allocate_aom(rows)
    print("\n%d schedule rows, AOM groups used %d, peak concurrent %d" % (len(rows), ng, peak))
    if undet:
        print("\n*** %d transitions UNDETERMINED -- reported, not invented:" % len(undet))
        for t in undet:
            print("    %-3s %-11s f%03d..f%03d  x %s -> %s  y %s -> %s"
                  % (t["sp"], t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                     comb(t["y0"]), comb(t["y1"])))
    if notes:
        print("\n%d note(s) -- reported, not swept under the rug:" % len(notes))
        for n in notes:
            print("   %s" % n)

    mvj = os.path.join(a.work, "moves.json")
    json.dump(dict(moves=moves, undetermined=undet, aom_groups=ng, aom_peak=peak,
                   blocks={k: list(v) for k, v in blocks.items()},
                   evidence=evidence, notes=notes),
              open(mvj, "w"), indent=1, default=str)
    print("wrote %s" % mvj)

    if a.xlsx:
        sb_emit.emit(a.xlsx, M, json.load(open(mvj)), rests,
                     [r for r in runs if r[0] <= f1], P, a.f0, f1,
                     extra=a.extra,
                     scope_note=a.scope or "frames %d-%d, t = %.4f .. %.4f ms"
                                           % (a.f0, f1, a.f0 * M.dt, f1 * M.dt))


if __name__ == "__main__":
    main()
