"""se_emit.py -- stage 4 of movie -> workbook.  The four CSVs into one .xlsx.

Sheets Constants / Seed / Schedule / Gates, in the order and with the column names render.ps1
expects.  Written with openpyxl; this project lives in OneDrive, where a .xlsx can be locked by
sync or by Excel, so the file is written to a scratch path first and then copied with a retry.
"""
import argparse, csv, os, shutil, sys, tempfile, time
import openpyxl
from openpyxl.styles import Font, Alignment


def read(path):
    if not path or not os.path.exists(path):
        return []
    with open(path, encoding="utf-8-sig", newline="") as fh:
        return list(csv.reader(fh))


def num(v):
    try:
        f = float(v)
        return int(f) if f == int(f) and "." not in str(v) else f
    except (TypeError, ValueError):
        return v


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--constants", required=True)
    ap.add_argument("--seed", required=True)
    ap.add_argument("--schedule", required=True)
    ap.add_argument("--gates", required=True)
    ap.add_argument("--title", default=None)
    args = ap.parse_args()

    wb = openpyxl.Workbook()
    for i, (name, path, widths) in enumerate((
            ("Constants", args.constants, (22, 40, 60)),
            ("Seed", args.seed, (10, 16, 16, 40)),
            ("Schedule", args.schedule, (7, 6, 9, 9, 10, 10, 22, 26, 22, 26, 60)),
            ("Gates", args.gates, (7, 10, 10)))):
        ws = wb.active if i == 0 else wb.create_sheet()
        ws.title = name
        rows = read(path)
        if not rows:
            print("!! %s is empty" % path)
        for r, row in enumerate(rows, start=1):
            for c, v in enumerate(row, start=1):
                ws.cell(row=r, column=c, value=(v if r == 1 else num(v)))
        for c, w in enumerate(widths, start=1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width = w
        for c in range(1, (len(rows[0]) if rows else 1) + 1):
            cell = ws.cell(row=1, column=c)
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal="left")
        ws.freeze_panes = "A2"
        print("%-10s %d rows" % (name, max(0, len(rows) - 1)))

    tmp = os.path.join(tempfile.gettempdir(), "se_emit_%d.xlsx" % os.getpid())
    wb.save(tmp)
    ok = False
    for attempt in range(6):
        try:
            shutil.copyfile(tmp, args.out)
            ok = True
            break
        except OSError as e:
            print("   copy attempt %d failed (%s); retrying" % (attempt + 1, e))
            time.sleep(2.0)
    os.remove(tmp)
    if not ok:
        sys.exit("could not write %s -- it is probably open in Excel or locked by OneDrive" % args.out)
    print("wrote %s" % args.out)


if __name__ == "__main__":
    main()
