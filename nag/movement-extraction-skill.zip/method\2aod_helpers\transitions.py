"""List the transitions the occupancy test will enumerate, WITHOUT solving them.

`--events` windows have to CONTAIN the transition sb_build enumerates (sb_build.build: the
event matches when `e.f0 <= tr.f0 and tr.f1 <= e.f1`), and guessing those frames from the
dark runs is how an event gets named too narrowly -- or, worse, too widely, swallowing a
real move.  This runs sb_full's own chain as far as `sb_build.settled` for every segment
and prints the rests and transitions, which costs the peak measurement but none of the
candidate fitting, so the windows can be written from the frames the solver will actually
see.

Usage:  python transitions.py <run dir> [--only 0,1,2]
"""
import argparse, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SB = os.path.abspath(os.path.join(HERE, "..", ".claude", "skills", "se-cycle-blocks", "tools"))
sys.path.insert(0, SB)
import sb_read, sb_compose, sb_build, sb_full  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--only", default=None)
    a = ap.parse_args()

    cal = os.path.join(a.run, "calib.json")
    M = sb_read.Movie(cal)
    blocks = json.load(open(os.path.join(a.run, "blocks.json")))
    runs = sb_compose.pulse_runs(M)
    ivs = sb_compose.free_intervals(runs, M.nf)
    segs = sb_full.segments(runs, ivs)
    only = set(int(v) for v in a.only.split(",")) if a.only else None

    for k, (f0, f1) in enumerate(segs):
        if only is not None and k not in only:
            continue
        wins = sb_compose.species_windows(M, f0, f1)
        edge_wins = sb_compose.species_windows(M, max(0, f0 - 1), min(M.nf - 1, f1 + 1),
                                               skip_gate=False)
        frames = [f for f in range(f0, f1 + 1) if f not in M.gate]
        outlines = sb_read.discover_outlines(M, frames[:40], (0.4, M.K["data_cols"] + 0.6,
                                                              0.4, M.K["data_rows"] + 0.6))
        P = sb_compose.Peaks(M, wins, f0, f1)
        bl = {kk: tuple(v) for kk, v in blocks.items() if kk in wins}
        rests = sb_build.settled(P, M, f0, f1, bl, wins, outlines, verbose=False,
                                 edge_wins=edge_wins)
        print("=== segment %2d  f%03d..f%03d" % (k, f0, f1))
        for nm in sorted(rests):
            for r in rests[nm].get("rests", []):
                fa, fb, xs, ys = r[0], r[1], r[2], r[3]
                print("   %-3s REST       f%03d..f%03d  x %s  y %s" % (nm, fa, fb, xs, ys))
            for t in rests[nm].get("transitions", []):
                print("   %-3s %-10s f%03d..f%03d  %s -> %s"
                      % (nm, t["kind"], t["f0"], t["f1"],
                         (t.get("x0"), t.get("y0")), (t.get("x1"), t.get("y1"))))
        print()


if __name__ == "__main__":
    main()
