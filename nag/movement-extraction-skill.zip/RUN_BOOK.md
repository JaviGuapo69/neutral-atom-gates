# Run book — the commands, in order

One page to keep open while working. The *why* for every line is in `README.md`, in
`skills\se-cycle-blocks\SKILL.md` (§"Procedure — A NEW MOVIE, END TO END") and in
`method\handmade correction method.md`.

**Do not go past a step whose check fails.** Every downstream number will be wrong in a way that
still looks plausible.

---

## Shell setup — once per PowerShell window

```powershell
$SB = "<project>\.claude\skills\se-cycle-blocks\tools"
$SE = "<project>\.claude\skills\se-cycle-movies\tools"
$env:PYTHONIOENCODING = "utf-8"
New-Item -ItemType Directory -Force -Path run_<movie> | Out-Null ; Set-Location run_<movie>
```

---

## A. Automatic solve — 4-AOD

```powershell
# 1. frames + calibration  ── --cycle-ms comes from the movie's OWN header text
New-Item -ItemType Directory -Force -Path frames, logs | Out-Null
ffmpeg -y -v error -i <movie>.mp4 -fps_mode passthrough -start_number 0 frames\p_%03d.png
python $SE\se_calib.py --frames frames --out calib.json --cycle-ms <N>
python -c "import json;c=json.load(open('calib.json'));print(c['n_frames'],c['gate_frames'])"
python <pkg>\method\templates\hdr.py <f0> <f1>     # -> hdr.png: the header strip, one line per frame
#    CHECK: n_frames == PNG count, and gate_frames == EXACTLY the frames whose header says
#           "global pulse".  Watch for 1-FRAME gate runs (c300 has two: f328, f383).
#           "reset" is a separate token and is NOT a gate marker; it can appear alone or alongside
#           "global pulse".

# 2. palette, including the OUTLINE colours
python $SB\sb_read.py --calib calib.json --palette
#    CHECK: >=1 outline colour found (ideally 2). None => sub-block moves unreadable by appearance

# 3. block sizes, movie-wide
python $SB\sb_blocks.py --calib calib.json --out blocks.json
#    CHECK: one size per species. Skipping this silently loses off-panel moves

# 3a. READOUTS AND LOADS, BEFORE SOLVING  ── sb_full takes these as an INPUT
python $SB\sb_events.py --calib calib.json --full > logs\events_full.txt
python $SB\sb_probe.py  --calib calib.json --peaks --sp <SP> --axis 1 --f0 <A> --f1 <B>   # confirm each
#    then WRITE events.json by hand (NOT with Out-File -Encoding utf8 -- it adds a BOM and
#    json.load then dies with "Expecting value: line 1 column 1"):
#    [{"sp":"Z1","f0":147,"f1":189,"why":"Z readout at the f147-148 pulse, Z load at f149"}]
#
#    READOUTS COME IN SPECIES PAIRS. sb_events flags only the more visible half of each pair
#    (on c300: Z1 and X1 only -- the real list has FOUR entries, Z0/Z1 and X0/X1).
#    The detector is the "parked stock" list in the SAME output: every species whose stock run
#    ENDS mid-movie is loaded there, so its old batch was read out there. Write one entry per
#    species, then confirm each on the FADED track.
#
#    A readout moves solid area INTO faded (X1 f329: solid 8741->2552, faded 1560->11874).
#    An OCCLUSION does not (Z0 f055: solid 6156->0, faded flat ~1650 -- Z0 and Z1 cross THROUGH
#    each other). An occlusion gets NO events.json entry.

# 4. solve  ── ALWAYS --events.  Writes only at the END of the run
python -u $SB\sb_full.py --calib calib.json --blocks blocks.json --events events.json `
        --xlsx <movie>_blocks.xlsx *> logs\full.log
#    long movies: run in parts of ~6 segments, at most 2 processes at once (~1.2 GB each)
#    !! --work DOES NOT CREATE THE DIRECTORY, and sb_full only writes at the very END. A missing
#       dir => the solve completes, prints everything, then dies with FileNotFoundError and the
#       WHOLE RUN IS LOST. Create them first:
New-Item -ItemType Directory -Force -Path half_a, half_b | Out-Null
#    python -u $SB\sb_full.py ... --work half_a --only 0,1,2,3,4,5,6,7,8,9,10,11 *> logs\half_a.log
#    python -u $SB\sb_full.py ... --work half_b --only 12,13,14,15,16,17,18,19,20,21,22 *> logs\half_b.log
#    python $SB\merge_halves.py --calib calib.json --blocks blocks.json --out . --xlsx <book>.xlsx half_a half_b

# 4a. prove completeness
python $SB\sb_audit.py    --moves moves_full.json --rests rests_full.json     # AUDIT CLEAN, 0 IDLE, 0 SILENT
python $SB\sb_mapcheck.py --calib calib.json --moves moves_full.json          # maps, independent of timing

# 5. probe anything odd
python $SB\sb_probe.py --calib calib.json --peaks --sp X0 --axis 0 --f0 447 --f1 466 "--win=0.4,20.6,25.4,27.6"
python $SB\sb_probe.py --calib calib.json --classes --seg <N> --tr <N>        # why a partition was rejected

# 6. readouts / loads by hand  ── write jobs.json first (recipe in sb_extra.py's docstring)
python $SB\sb_extra.py --calib calib.json --jobs jobs.json                    # -> extra.json

# 7. census
python $SE\se_sim.py <book>.xlsx
#    CHECK: validation clean; a DEFICIT vs the seed is a defect, a surplus during a readout is fine

# 8. render + score
python $SE\se_calibtxt.py --calib calib.json --out-txt movie_calib.txt `
       --out-json render_calib.json --render-frames $PWD\rframes --tone-divisor 1
& $SE\render.ps1 -Xlsx <book>.xlsx -OutDir $PWD\rframes -LogCsv $PWD\render_log.csv `
       -MatchCalib $PWD\movie_calib.txt
python $SB\sb_score.py --movie-calib calib.json --render-calib render_calib.json --out score.txt
#    CHECK: render_log.csv has ONLY its header. No MISSING-BLOCK cases in the score

# 9. watch
python $SB\sb_watch.py --movie-calib calib.json --render-calib render_calib.json `
       --thresh 0.35 --min-run 3 > watch.txt
& $SB\sb_video.ps1 -MovieFrames frames -RenderFrames rframes -Calib calib.json `
       -OutPanels panels.mp4 -OutFull full.mp4
#    CHECK: account for EVERY run of >=3 frames as one of the four legitimate causes
#           (integer staging / entering-leaving panel / occlusion / crossing).  Then WATCH the video.

# 10. report
python $SB\sb_report.py --calib calib.json --moves moves_full.json --extra extra.json `
       --score score.txt --xlsx <book>.xlsx --out <movie>_report.txt
#    then APPEND by hand the "what is a CONVENTION" section
```

---

## B. Automatic solve — 2-AOD, the extra steps

Full text in `method\2AOD_SETUP.md`. `$H = "<...>\method\2aod_helpers"`.

```powershell
# 0. FIRST: crop the CZ-firing footer on all 24 gate frames -- it prints the whole circuit
python $H\sheet.py <run> ...            # footer band is roughly x 400..1300, y 1045..1080

# 0b. ONLY if the legend is drawn INSIDE the panel (c300 is) -- do this BEFORE se_calib
python $H\depaint_legend.py <run> --band 55,88 --ref 10 --x 312,1374      # originals -> frames_raw\

python $SE\se_calib.py --frames frames --out calib.json --cycle-ms <title>
#    STOP if it prints "!! ring centres do not sit on one comb" -- the pitch came back a SUBMULTIPLE
python $H\fix_lattice_2aod.py <run> --floor 30      # then check residual (bar 0.18) + data extent

python $H\fix_calib_2aod.py <run>       # ALWAYS. 71% blend => se_calib reports 6 species and mislabels all
#    CHECK the legend crop before trusting the species mapping

python $SB\sb_read.py   --calib calib.json --palette      # expect gold + purple outlines
python $SB\sb_blocks.py --calib calib.json --out blocks.json
python $H\skeleton.py <run> --faded > logs\skeleton.txt   # where every block sits, interval by interval
python $H\darkruns.py  <run>          > logs\darkruns.txt # the faded/idle runs
python $SB\sb_events.py --calib calib.json --full > logs\sb_events_full.txt
python $H\transitions.py <run>        > logs\transitions.txt
#    -> write events.json so each window CONTAINS exactly the transitions the solver will see.
#       A faded block here is usually IDLE IN PLACE, not a readout: prove it by probing the FADED
#       track on both axes over the dark run (peaks frozen to the pixel), then name it in events.json.

# ... then steps 4-10 above, solved as halves.  Deliver with:
python $H\census_2aod.py <run> <book>.xlsx --block 100
.\deliver_2aod.ps1 -Run <run> -Xlsx <book>.xlsx -Tag <movie>_2aod_<tag> -RDir rframes_<tag>   # from the 2aod folder
```

---

## C. Hand correction session

```powershell
# 1. new folder, copying the PREVIOUS run's inputs AND untouched originals
New-Item -ItemType Directory -Force -Path run_<movie>_sNN | Out-Null
Copy-Item run_<movie>_<PREV>\calib.json, run_<movie>_<PREV>\blocks.json, `
          run_<movie>_<PREV>\events.json, run_<movie>_<PREV>\extra.json, `
          run_<movie>_<PREV>\moves_full.json, run_<movie>_<PREV>\rests_full.json  run_<movie>_sNN\
Copy-Item run_<movie>_<PREV>\moves_full.json run_<movie>_sNN\moves_full_<PREV>_original.json
Copy-Item run_<movie>_<PREV>\rests_full.json run_<movie>_sNN\rests_full_<PREV>_original.json
Copy-Item <pkg>\method\templates\apply_s28.py     run_<movie>_sNN\apply_sNN.py
Copy-Item <pkg>\method\templates\deliver_s28.ps1  run_<movie>_sNN\deliver_sNN.ps1
Copy-Item <pkg>\method\templates\dump_sched.py, <pkg>\method\templates\list_moves.py, `
          <pkg>\method\templates\crop.py  run_<movie>_sNN\
# edit deliver_sNN.ps1: replace every s28 / c540 and the -MovieFrames path

# 2. survey  (frame = t_ms / dt_ms ; dt_ms is in calib.json)
python $SE\se_sim.py ..\run_<movie>_<PREV>\<PREV book>.xlsx      # read the check3/check4 lines FIRST
python list_moves.py moves_full.json                             # every move with frames and mean
Select-String -Path ..\run_<movie>_<PREV>\logs\full.log -Pattern "OVER 0.10|undetermined|NOT taken|gate 4"
python dump_sched.py <PREV book>.xlsx <t_lo_ms> <t_hi_ms>        # the rows for one window
python crop.py OUT <f0> <f1> <c0> <c1> <r0> <r1>                 # montage a block's region

# 3. apply  ── EDIT THE MOVE LIST, NEVER THE XLSX CELLS
python -u apply_sNN.py | Tee-Object apply_sNN.log

# 4. prove
python $SB\sb_audit.py --moves moves_full.json --rests rests_full.json
python $SE\se_sim.py <new book>.xlsx
python $SB\cmp_tol.py ..\run_<movie>_<PREV>\moves_full.json moves_full.json
#    CHECK: replaced maps = MAP DIFFERS, added moves = "no counterpart", EVERYTHING ELSE matched exactly

# 5. render ONCE, detached
Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-Command', `
  "Set-Location '<abs>\run_<movie>_sNN'; .\deliver_sNN.ps1 *> deliver_sNN.log" -WindowStyle Hidden
Get-Content run_<movie>_sNN\deliver_sNN.log -Tail 20            # poll; ~14 min for 384 frames
```

**Then deliver:** the compact report table (`# | frames | block | what the book has / what is wrong |
applied | mean / free`), the checks table automatic-vs-corrected, the generated
`sNN_correction_list.md`, the book and both videos copied to the root under the session's name.

---

## D. The closing checklist

| check | required value |
|---|---|
| `sb_audit` | `AUDIT CLEAN`, 0 IDLE, 0 SILENT, every transition explained |
| undetermined | **0** |
| `se_sim` | validation clean, census never short of the seed count |
| `render_log.csv` | header only — **0 validation entries** |
| `sb_score` | ~0.03–0.06 site, no `MISSING-BLOCK` |
| AOM peak | equals the AOD count in the movie's title (4, or 2 for a 2-AOD movie) |
| `cmp_tol` | exactly the intended differences and nothing else |
| `sb_watch` | every run of ≥3 frames named as one of the four legitimate causes |
| the reviewer | has watched the video and said the movie is correct |

Then: write the session report, copy the book and both videos to `closed videos\` with an MD5, add it
to the manifest, and state plainly in the report **what was measured and what is a convention**.
