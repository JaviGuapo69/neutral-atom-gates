"""se_aom.py -- classify a schedule by AOM trap group, and check the hardware can execute it.

A schedule row says which atoms move where.  It does NOT say which device carries them, and an
engineer programming the machine needs exactly that: for each AOM, the x tone comb and the y tone
comb, before and after every move.  This tool answers it, and checks the answer is physically
possible.

WHAT AN AOM GROUP IS.  One crossed pair of acousto-optic deflectors driven by an x comb and a y
comb.  Traps appear at EVERY combination of an x tone and a y tone, so a group holding x tones X
and y tones Y illuminates the whole product X x Y -- not just the sites some row happens to name.

THE FOUR CHECKS

  1  tone counts        a row's start and finish lists must be the same length (guide I.6)
  2  non-crossing       within one comb the tone order is fixed for the whole motion (guide I.2),
                        so a row's own tone map must be strictly increasing
  3  comb merge         two rows on ONE group must agree wherever their combs overlap, and the
                        combined map must still be strictly increasing
  4  atom capture       the subtle one.  Merging rows onto one group makes its comb the full
                        product of the unions, which creates traps OUTSIDE the rectangles those
                        rows named.  If an atom belonging to a different group is standing on one
                        of those traps it gets picked up by two combs at once.  Bare empty
                        cross-traps are harmless and are reported separately as informational.

Check 4 needs to know where every atom actually is at the instant the batch begins, so the state
comes from se_sim -- the same replica of render.ps1 the composer validates against.

Usage:
    python se_aom.py --xlsx wb.xlsx [--max-aom 8] [--emit aom_layout.xlsx] [--report r.txt]
"""
import argparse, collections, itertools, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import se_sim


# ----------------------------------------------------------------- tone helpers
def tones(cell):
    return se_sim.split_elements(cell)


def tone_map(s, f):
    a, b = tones(s), tones(f)
    if len(a) != len(b):
        return None
    return dict(zip(a, b))


def increasing(m):
    ks = sorted(m)
    vs = [m[k] for k in ks]
    return all(vs[i] < vs[i + 1] for i in range(len(vs) - 1))


def merge(maps):
    m = {}
    for mi in maps:
        if mi is None:
            return None
        for k, v in mi.items():
            if k in m and m[k] != v:
                return None
            m[k] = v
    return m if increasing(m) else None


# ----------------------------------------------------------------- the checks
def check(path, max_aom):
    S = se_sim.from_workbook(path)
    rows = S.rows                      # already parsed, with xm/ym tone maps
    by_t = collections.defaultdict(list)
    for p in rows:
        by_t[p["t0"]].append(p)

    problems = []
    info = []
    per_batch = []

    for t0 in sorted(by_t):
        batch = [p for p in by_t[t0] if p["ev"] != "load"]
        if not batch:
            continue
        state = S.state_at(t0)         # trap -> (atom index, species) just before the batch

        # --- group by the sheet's own AOM index
        groups = collections.OrderedDict()
        for p in batch:
            groups.setdefault(p["slot"], []).append(p)

        if len(groups) > max_aom:
            problems.append("t=%.4f  needs %d AOM groups, budget is %d"
                            % (t0, len(groups), max_aom))

        for g, ps in groups.items():
            # 1 + 2 are already guaranteed for parsed rows except non-crossing
            for p in ps:
                if not increasing(p["xm"]):
                    problems.append("t=%.4f AOM%s  %s: x tones cross" % (t0, g, p["tag"]))
                if not increasing(p["ym"]):
                    problems.append("t=%.4f AOM%s  %s: y tones cross" % (t0, g, p["tag"]))
            # 3 comb merge
            mx = merge([p["xm"] for p in ps])
            my = merge([p["ym"] for p in ps])
            if mx is None or my is None:
                problems.append("t=%.4f AOM%s  %d rows cannot share one comb"
                                % (t0, g, len(ps)))
                continue
            # 4 atom capture
            owned = set()
            for p in ps:
                for x in p["xm"]:
                    for y in p["ym"]:
                        owned.add((x, y))
            stolen, empty = [], 0
            for x in mx:
                for y in my:
                    if (x, y) in owned:
                        continue
                    if (x, y) in state:
                        stolen.append((x, y, state[(x, y)][1]))
                    else:
                        empty += 1
            if stolen:
                problems.append("t=%.4f AOM%s  captures %d atom(s) it does not own, e.g. %s"
                                % (t0, g, len(stolen), stolen[:4]))
            if empty:
                info.append("t=%.4f AOM%s  %d empty cross-traps (harmless)" % (t0, g, empty))
        per_batch.append((t0, len(groups), len(batch)))

    return S, per_batch, problems, info


# ----------------------------------------------------------------- the emitter
def emit(path, out, max_aom, S=None):
    """Write Shayne's AOM-column layout: two rows per move, one column pair per AOM.

    Gate moves are interleaved as moves of their own, the way the hand-written reference does it.
    At a gate the array is at rest, so the row shows the configuration being HELD -- which is not
    in the schedule at all (a schedule row is a motion; atoms nobody moves have no row) and has to
    be recovered by simulating up to that instant and factorising the live configuration into
    Cartesian blocks.  Those blocks are the combs that must be driven while the pulse fires.
    """
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb["Schedule"]
    h = [c.value for c in ws[1]]
    rows = [dict(zip(h, r)) for r in ws.iter_rows(min_row=2, values_only=True) if r[0] is not None]
    rows = [r for r in rows if r.get("t_start") is not None]
    gates = [(r[1], r[2]) for r in wb["Gates"].iter_rows(min_row=2, values_only=True)
             if r[0] is not None]

    # a "move" in the layout is a batch: everything sharing one t_start
    by_t = collections.OrderedDict()
    for r in sorted(rows, key=lambda r: (float(r["t_start"]), int(r["slot"]))):
        by_t.setdefault(round(float(r["t_start"]), 6), []).append(r)

    # Renumber onto real AOM columns.  A sheet may use its `slot` field as bookkeeping -- v4
    # numbers its load rows 9..12, which are not a ninth and tenth trap group -- so each batch is
    # packed onto distinct indices, keeping the sheet's own number wherever it fits.  A `load` is
    # a fresh batch generated on a comb of its own, so it does get a column.
    naom = max(len(rs) for rs in by_t.values())
    naom = min(max(naom, 1), max_aom)
    for rs in by_t.values():
        used, free = set(), [k for k in range(1, naom + 1)]
        for r in rs:
            k = int(r["slot"])
            if k <= naom and k not in used:
                r["_aom"] = k; used.add(k)
        for r in rs:
            if "_aom" not in r:
                k = next((c for c in free if c not in used), None)
                if k is None:
                    raise SystemExit("batch at t=%s has more rows than %d AOM columns"
                                     % (r["t_start"], naom))
                r["_aom"] = k; used.add(k)

    nb = openpyxl.Workbook()
    s = nb.active; s.title = "Combined"
    hdr = ["Move", "", "Rydberg?", "Start time", "Finish time"]
    for k in range(1, naom + 1):
        hdr += ["AOM%d x tones" % k, "AOM%d y tones" % k]
    hdr += ["event", "species", "note"]
    s.append(hdr)

    # interleave the gates: (t_start, kind, payload), sorted by time
    timeline = [(t0, "batch", rs) for t0, rs in by_t.items()]
    timeline += [(float(a), "gate", (float(a), float(b))) for a, b in gates]
    timeline.sort(key=lambda e: (e[0], 0 if e[1] == "gate" else 1))

    i = 0
    for t0, kind, payload in timeline:
        i += 1
        if kind == "gate":
            ga, gb = payload
            held, worst = [], 0.0
            if S is not None:
                # The easing has zero derivative at both ends, so an atom at 99.9% of its journey
                # is not meaningfully moving.  Asking for exact integers calls that "in transit"
                # and cries wolf; measure how far anything actually is instead, sampling the whole
                # window rather than only its first instant.
                for k in range(11):
                    tt = ga + (gb - ga) * k / 10.0
                    for at in S.atoms:
                        if not (at["born"] <= tt < at["dies"]):
                            continue
                        px, py = S.position(at, tt)
                        worst = max(worst, abs(px - round(px)), abs(py - round(py)))
                snapped = [(int(round(S.position(at, ga)[0])), int(round(S.position(at, ga)[1])))
                           for at in S.atoms if at["born"] <= ga < at["dies"]]
                held = se_sim.rectangles(sorted(set(snapped)))
            cells = [""] * (2 * naom)
            for j, (xs, ys) in enumerate(held[:naom]):
                cells[2 * j] = se_sim.compact(xs)
                cells[2 * j + 1] = se_sim.compact(ys)
            note = "gate; the columns are the configuration being held"
            if worst > 0.05:
                note += (". WARNING the furthest atom is %.3f site off a tone during this pulse -- "
                         "the window overlaps the tail of a move" % worst)
            else:
                note += " (all atoms within %.3f site of a tone)" % worst
            if len(held) > naom:
                note += " (%d blocks held, only the first %d fit)" % (len(held), naom)
            s.append([i, ga, "Rydberg", ga, ""] + cells + ["gate", "", note])
            s.append([i, gb, "Rydberg", "", gb] + cells + ["", "", ""])
            continue
        rs = payload
        tf = max(float(r["t_finish"]) for r in rs)
        evs = sorted(set(str(r.get("event") or "move") for r in rs) - {"move"})
        sps = sorted(set(str(r.get("species") or "") for r in rs) - {""})
        notes = sorted(set(str(r.get("note") or "") for r in rs) - {""})
        start = [""] * (2 * naom)
        fin = [""] * (2 * naom)
        for r in rs:
            k = r["_aom"]
            start[2 * (k - 1)] = r["x_start"];  start[2 * (k - 1) + 1] = r["y_start"]
            fin[2 * (k - 1)] = r["x_finish"];   fin[2 * (k - 1) + 1] = r["y_finish"]
        tail = [",".join(evs), ",".join(sps), " | ".join(notes)[:500]]
        s.append([i, t0, "", t0, ""] + start + tail)
        s.append([i, tf, "", "", tf] + fin + ["", "", ""])

    # keep the executable sheets alongside, so the book still renders and still simulates
    for name in ("Constants", "Seed", "Schedule", "Gates"):
        src = wb[name]
        d = nb.create_sheet(name)
        for r in src.iter_rows(values_only=True):
            d.append(list(r))
    nb.save(out)
    return naom, i


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", required=True)
    ap.add_argument("--max-aom", type=int, default=8)
    ap.add_argument("--emit")
    ap.add_argument("--report")
    a = ap.parse_args()

    S, per_batch, problems, info = check(a.xlsx, a.max_aom)
    out = []
    out.append("AOM feasibility: %s" % os.path.basename(a.xlsx))
    out.append("=" * 70)
    dist = collections.Counter(n for _, n, _ in per_batch)
    out.append("batches                    : %d" % len(per_batch))
    out.append("AOM groups used per batch  : %s" % dict(sorted(dist.items())))
    out.append("peak concurrent AOM groups : %d   (budget %d)"
               % (max(n for _, n, _ in per_batch), a.max_aom))
    # `slot` is what decides which rows share a crossed pair.  se_moves.py writes it as a running
    # counter, and read literally that is one AOM group PER ROW -- so the peak above would just be
    # the largest batch's row count, a fact about the transcription and not about the hardware.
    # c150's automatic sheet reported 39 this way where the correct schedule needs 4.
    nslot = len({p["slot"] for p in S.rows})
    if nslot == len(S.rows) and len(S.rows) > 1:
        out.append("")
        out.append("*** WARNING: `slot` holds %d distinct values over %d rows -- it is a RUNNING"
                   % (nslot, len(S.rows)))
        out.append("*** COUNTER, not an AOM index, so the peak above is merely the largest batch's")
        out.append("*** row count and says nothing about the hardware. Run")
        out.append("***     python se_repack.py --in-xlsx <this> --out-xlsx packed.xlsx")
        out.append("*** and re-run this report on packed.xlsx for a number that means something.")
        out.append("")
    sim = S.counts()
    out.append("renderer self-check        : %s" % (dict(sim) if sim else "CLEAN"))
    out.append("")
    out.append("check 1 tone counts, 2 non-crossing, 3 comb merge, 4 atom capture")
    if problems:
        out.append("VIOLATIONS: %d" % len(problems))
        for p in problems[:40]:
            out.append("   " + p)
        if len(problems) > 40:
            out.append("   ... and %d more" % (len(problems) - 40))
    else:
        out.append("VIOLATIONS: none -- every batch is executable on %d crossed AOM pairs"
                   % a.max_aom)
    out.append("")
    out.append("informational (empty cross-traps, harmless): %d groups" % len(info))
    for i in info[:8]:
        out.append("   " + i)
    if len(info) > 8:
        out.append("   ... and %d more" % (len(info) - 8))

    txt = "\n".join(out)
    print(txt)
    if a.report:
        with open(a.report, "w", encoding="utf-8") as fh:
            fh.write(txt + "\n")
    if a.emit:
        naom, nmoves = emit(a.xlsx, a.emit, a.max_aom, S)
        print("\nwrote %s -- %d moves across AOM1..AOM%d" % (a.emit, nmoves, naom))


if __name__ == "__main__":
    main()
