# c540: the faults in the derived workbook, found by structural comparison with Shayne's hand book

`c540_full_blocks.xlsx` (session 16, produced by `se-cycle-blocks` from
`se_cycle_c540_d18_C9C3C4_4aod.mp4`) against `c540_v3_shayne_handwritten.xlsx`.

This supersedes nothing in `c540_vs_shayne.md`; it goes underneath it. That document aligned the
two books' moving rectangles by time and adjudicated three disagreements. This one asks the
prior question — **do the two books describe the same movements?** — with a comparison that is
blind by construction to the three things that are not faults: which AOM drives what, how many
AOMs a book chooses to write, and a batch time rounded to two decimals.

**Scope of this run, as agreed:** report only. No workbook was changed, no tool was patched, no
hole was filled, and no new pixel measurement was made. Every claim below is either a structural
fact about the two books, a number the derived workbook already published about itself, or a
pixel measurement made in an earlier session and cited as such. Where the structure does not
settle a disagreement I say so and name what would.

---

## 1. Method, and what it cannot see

Three tests, in `run_c540/cmp_struct.py`. Run:

```powershell
cd run_c540
python cmp_struct.py ..\c540_v3_shayne_handwritten.xlsx ..\c540_full_blocks.xlsx
python aom_peak.py   ..\c540_v3_shayne_handwritten.xlsx ..\c540_full_blocks.xlsx
python cmp_resid.py
```

**Test 1 — the net site permutation of each pulse-free interval.** Every move lies inside one
pulse-free interval (rule 9) and all 13 Rydberg spans agree frame-for-frame between the books, so
the 12 intervals are a canonical alignment immune to rounded times. A crossed pair is a product of
two combs, so its map is index-wise on both axes: `(xs[i], ys[j]) -> (xf[i], yf[j])`. Composing
every rectangle of an interval in time order gives one site→site permutation per interval. This
makes both notation differences vanish automatically — "he writes the whole block and I write only
the moving part", and "I merge two blocks onto one crossed pair" — because composition and
identity-completion are exactly what those differences are.

Inside an interval the comparison is cut at the **boundaries the two books share** (matched within
1.5 frames, and never at a boundary a move straddles). A boundary only one book has is that book's
own decomposition of one movement and must not create a segment.

**Test 2 — the configuration at every pulse**, simulated from the seed, with readouts removing
atoms and loads creating them.

**Test 3 — per-book validity**: every rectangle keeps its size on both axes (rule 1); every
union is injective; no source site is empty; **no atom is driven by two crossed pairs at the same
instant**; no rectangle spans a pulse.

### Two things I had to fix in the comparison before its output meant anything

Both are traps for anyone repeating this, and one of them is a fault in the derived workbook in
its own right (§2.6).

1. **Concurrent rectangles must be applied simultaneously, not in sequence.** `x 1:3 -> 10:12`
   followed by `x 4:12 -> 1:9` applied one after the other makes the second pick up the very atoms
   the first just delivered to 10:12. But concurrency is *sharing a start instant*, not overlapping
   in time — grouping by overlap is worse than useless, because in a pipelined movie the overlaps
   chain transitively and swallow the whole interval into one group.
2. **Shayne writes a move that spans two batches by leaving the intermediate rows blank.** His X
   row rotation `1:2 -> 8:9 | 3:9 -> 1:7` opens in batch 21's start row (t 3.18) and closes in
   batch 22's finish row (t 3.43); batch 21's finish and batch 22's start are both blank because
   the block is in flight. Pairing rows within a batch reads that as two static rectangles and
   loses the move — and then invents a disagreement, because the derived book has it.

### The headline count

| | |
|---|---|
| shared segments compared | **41** |
| segments where the two books' net permutations are **identical** | **17** |
| segments that differ | **24** |
| intervals whose whole net permutation agrees | 2 of 12 (f155–189, f303–314) |
| Shayne's book: validity complaints | **0** |
| derived book: validity complaints | **16** |

---

## 2. Faults in the derived workbook

Ordered by how much they matter. §2.1 and §2.2 account for 22 of the 24 differing segments
between them.

### 2.1 The partition is short by one tone: "one line left static, the rest shifted by one less"

**This is one bug with thirteen instances, on both axes, in every part of the movie.**
`c540_vs_shayne.md` §3.1 found it in two places and called it systematic; it is systematic and it
is much wider than two.

| segment | what moves | Shayne | derived | derived's own note |
|---|---|---|---|---|
| f001–008 | X0 cols `x 1:12`, `y 1:9` | `1:7→6:12 \| 8:12→1:5` — one 12-cycle, rotate **+5** | `2:8→6:12 \| 9:12→2:5`, **col 1 static** | 0.1786 (worst 2.383) |
| f001–008 | X1 cols `x 13:24`, `y 1:9` | `13:19→18:24 \| 20:24→13:17` — rotate **+5** | `14:20→18:24 \| 21:24→14:17`, **col 13 static** | 0.1842 (worst 2.360) |
| f001–008 | the `y 19:27` block, `x 13:24` | `13:18→19:24 \| 19:24→13:18` — rotate **+6** | given X1's map by a phantom join — see §2.3 | 0.1842 (worst 2.360) |
| f018–022 | X1 rows `x 13:24` | `13:15 ↔ 16:18` | **row 13 static**, `14:16→16:18 \| 17:18→14:15` | 0.1092 (worst 1.007) |
| f026–033 | X0+X1 rows `x 1:24` | 8-cycle on rows 10:17 (`11:17→10:16 \| 10→17`) | 5-cycle on rows 10:14, **rows 15,16,17 static** | 0.1276 (worst 0.831) |
| f044–049 | X0 rows `x 1:12` | `13:15 ↔ 16:18` | **row 18 static**, `13:14→16:17 \| 15:17→13:15` | 0.1430 (worst 1.494) |
| f053–058 | X0+X1 rows `x 1:24` | `12:14 ↔ 15:17` | 4-cycle on rows 13:16, **rows 12,17 static** | 0.1305 (worst 1.030) |
| f096–104 | X0 cols `x 1:12` | `1:6 ↔ 7:12` — rotate **+6** | **col 12 static**, `1:5→7:11 \| 6:11→1:6` | 0.1628 (worst 3.022) |
| f096–104 | X1 cols `x 13:24` | `13:18 ↔ 19:24` — rotate **+6** | **nine of twelve columns static**; only `17:18→19:20`, `19→17`, `20→21`, `21→18` | 0.2768 (worst 3.010) |
| f096–104 | the `y 19:27` block | `13:17→20:24 \| 18:24→13:19` — rotate **+7** | **cols 13,14,17 static**; `15:16→23:24`, `18→22`, `19:24→16:21` | 0.2402 (worst 2.925) |
| f140–151 | X0 rows `x 1:12` | net `12→18, 15→12, 18→15` | net `15→18, 16→15, 17→16, 18→17`, **row 12 static** | 0.1193 (worst 0.889) |
| f151–155 | X0+X1 rows `x 1:24` | three identical 3-cycles: (10,11,12), (13,14,15), (16,17,18) | one 3-cycle and **two 2-cycles** — rows 12 and 15 static | 0.1612 (worst 0.736) |
| f199–215 | rows 10:18 `x 13:24` | `10:14→14:18 \| 15:18→10:13` — rotate **+4** | rotate +4 **with 14 and 15's destinations transposed**: `14→10, 15→18` | 0.1938 (worst 1.304) |

**Why Shayne is right and the sheet is wrong, without a new pixel measurement.**

* Two of these were already adjudicated against the pixels in session 16 and Shayne won both:
  f001–008 X0 cols **0.2126 against 0.2432**, f096–104 X0 cols **0.1942 against 0.2352**. The
  remaining eleven are the same shape of error in the same code path.
* **Internal consistency, which is the strongest structural argument here.** At f151–155 the movie
  does the *same* 3-cycle to each of three row-triples; the derived read gives a 3-cycle for one
  triple and 2-cycles for the other two. At f001–008 Shayne's X0 and X1 both rotate by +5; the
  derived read makes both "one column static, shift by 4". At f199–215 Shayne rotates rows 1:9
  by +4 and rows 10:18 by +4; the derived read has 1:9 correct at +4 and 10:18 with two
  destinations swapped. A gate layer applies one permutation to every block it touches, and the
  derived book breaks that pattern every time — never Shayne's.
* **Cyclic closure fails arithmetically.** For a two-part cyclic rotation of an *n*-tone comb with
  displacements `D₁ > 0` and `D₂ < 0`, `D₁ − D₂ = n` exactly. Shayne's f001–008 X0: `+5 − (−7) =
  12` = the block width ✓. The derived book's: `+4 − (−7) = 11 ≠ 12`, with one column left over.
  Every one of the thirteen rows above fails this test; not one of Shayne's does.
* **The AOM count points straight at it** (rule 8: a batch needing more crossed pairs than the
  machine has is a segmentation error upstream). At f043 the derived book needs **6** pairs and
  Shayne's reading of the same instant needs **4**; the excess is precisely the f044–049 X0 row
  rectangles, which fail to merge with X1's only because X0's map is wrong. At f099 the derived
  book needs **5** and Shayne needs **4**, and the excess is precisely the f096–104 read. See §4.

**Why it happens.** Rule 20 says the sorted peak↔tone correspondence is valid only up to the first
frame where the peak count drops. In a full-comb cyclic rotation the two markers at the ends of the
comb travel farthest, so they are the first to come within ~0.3 pitch of a neighbour and merge —
often on the very first moving frame at that end of the comb. `measured_partition`'s strict prefix
of full-count frames is then empty or one frame long *at the end of the comb*, so there is no
evidence for the outermost tone, the class read excludes it, and the remainder fits as a shorter
rotation. Then nothing complains, because:

* rule 18's cover-and-bijection test passes — a rotation read one tone short is still two parts
  that are each bijections onto their own images, and their union still tiles the tones they claim;
* rule 34's complement rule (`B = S \ A`) is used to *complete a partition into two parts*, never
  to *extend the union to the block's full comb*, so a tone missing from both parts stays missing;
* rule 31's dilution reappears in the **tone** dimension. The tone that was left static agrees with
  the wrong map on every frame by construction, so `verify`'s mean over all peaks is barely moved:
  0.2432 against 0.2126 on the first case, a difference of 0.03 site inside the crossing noise. The
  fit genuinely cannot pick the winner, and it should not be asked to.

**The fix, in order of value.**

1. **A cyclic-closure test in `emit`, and it is three lines.** For a *k* = 2 move whose parts have
   displacements of opposite sign on one axis, require `D₁ − D₂ == n`, where *n* is the extent of
   the union of the parts' source combs, **and** require that union to be the block's whole comb on
   that axis (rule 22's movie-wide size). If a tone is static while the rest rotate, `D₁ − D₂` comes
   out one short. On failure, fold the static tone into whichever part makes the closure exact and
   re-score. This one test catches all thirteen instances above and needs no pixel work.
2. **Enumerate whole-comb rotations as explicit candidates.** `rotation_candidates` already exists
   (session 16's defect 9) but is only reached on the sub-comb path. On any axis where the block's
   comb is contiguous, add rotate-by-1 … rotate-by-*n*−1 to the candidate set, and require the
   measured partition to beat the best rotation by more than the crossing noise (~0.03 site) before
   it is preferred. Where it does not, prefer the rotation: it is the hypothesis with one free
   parameter against a partition with *n*.
3. **Rank candidates on the frames that move, not on the window mean.** Rule 40's third consequence
   already says this for the time dimension; §2.1's mechanism is the same statistic failing in the
   tone dimension. Score only the tones and frames where the two candidates actually differ.

### 2.2 Ten movements are missing, and none of them appears in any list

Not in the moves, not in the notes, not in the undetermined list, and `sb_audit` reports
`0 SILENT` holes. This is rule 36's worst case — a move that was never *enumerated* — and it is
distinct from the seven transitions the sheet correctly reports as undetermined.

| segment | in Shayne's book, absent from the derived book |
|---|---|
| f199–215 | `x {14,20}`: rows 10:18 rotate +4, and rows 19:27 rotate +5 (the sheet has only rows 1:9) |
| f215–222 | `x {15,21}`: rows 1:9 +6, rows 10:18 +6, rows 19:27 +7 — **the entire batch is absent** |
| f222–231 | `x {16,22}`: rows 10:18 +1 and rows 19:27 −1 (the sheet has only rows 1:9) |
| f231–238 | `x {17,23}`: rows 10:18 +3 (the sheet has rows 1:9 and rows 19:27) |
| f238–245 | `x {18,24}`: rows 1:9 +4 and rows 10:18 +4 (the sheet has only rows 19:27) |
| f265–273 | `x {14,20}`: rows 19:27 +1 |
| f273–281 | `x {15,21}`: rows 19:27 +6 |
| f288–295 | `x {17,23}`: rows 19:27 +3 |
| f295–303 | `x {18,24}`: rows 19:27 +7 |
| f348–355 | `x 13:24 y 1:9`: `13:18→19:24 \| 19:24→13:18` — a **full-block** 12-column rotation, not a sub-comb |

**Why it happens.** Nine of the ten are sub-comb moves, and rule 40's first consequence says
whole-block occupancy cannot see one: the static majority dominates the profile and the block reads
"at rest" while two of its columns are plainly moving. So the transition is never enumerated, and
`sub_window` only re-derives the window of a transition that *was* enumerated. The pattern in the
data says exactly how the loss happens: c540's sub-comb moves act on **all three row bands** of two
columns (rows 1:9, 10:18 and 19:27), those three bands carry three different species, and the
solver found the move on one band — usually whichever band's profile seeded the `sub_comb`
measurement — and never looked at the other two.

The tenth, f348–355, is a different and more worrying case: a full 12-column rotation of the block
sitting at `13:24 × 1:9`, on a block that has just arrived there at f348 and departs at f354. It is
a same-site permutation, so rule 27 applies in full: invisible to the census, to the score and to
render validation. It was most likely lost to rest detection — the block's stay is six frames long
and bounded by two moves — and it is the clearest illustration that "0 undetermined" and
"`sb_audit` clean" say nothing about completeness.

**The fix.**

1. **Sweep the sub-combs movie-wide.** Once `sub_comb` has identified a set of participating lines
   for any one move, re-run the rest/occupancy enumeration **restricted to those lines, for every
   species that has atoms on them, over the whole movie**. c540 uses six or seven distinct
   sub-combs (`{13,19}`, `{14,20}`, `{16,22}`, `{17,23}`, `{18,24}`, `{14,16,…,24}`,
   `{2,4,…,12}`); the sweep is cheap and it is the only thing that makes these transitions
   enumerable at all.
2. **Add the sub-comb sweep to `sb_audit` as a completeness check.** For each sub-comb any move
   uses, profile it independently and assert that every rest-to-rest change on those lines has a
   move whose midpoint lies inside it. `sb_audit` currently audits the move list against the
   transition list; when the transition list is itself incomplete it cannot help, and it said
   `0 SILENT` here.
3. **Add a cycle-closure check, and make it a hard failure.** Simulate the emitted schedule from
   the seed and assert that the configuration at f382/f383 **equals the seed**. The handover already
   records "the cycle closes exactly on the seed at f382" as a measurement. Shayne's book closes on
   the seed; the derived book does not — at f383 it has a block at `x 13:24 × y 10:18` that should
   not exist and is missing one that should. This single check catches §2.2 and §2.3 together and
   costs nothing.

### 2.3 A phantom cross-species join at f001–008 — now provable, not just suspected

`c540_vs_shayne.md` §3.2 flagged this as "worth checking by eye". The structure settles it.

The derived book writes one rectangle `x 14:20 → 18:24` on `y 1:9,19:27`, carrying both the X1
block (rows 1:9) and the `y 19:27` block on one crossed pair. Shayne gives them **different**
maps: X1 rotates by +5 (`13:19→18:24 | 20:24→13:17`) and the `y 19:27` block by +6
(`13:18→19:24 | 19:24→13:18`). Two blocks with different maps cannot share one crossed pair, so the
join is wrong however the underlying maps are read — and §2.1's evidence says both underlying maps
are Shayne's.

**Why it happens.** Rule 31's own text: `verify`'s join test is a mean over all of a species'
peaks, so where two blocks move by *nearly* the same displacement the join passes on the strength
of how similar they are. Here the two rotations differ by one site in the wrap position only, so
the mean separation between "shares X1's map" and "has its own map" is small.

**The fix.** Rule 31's guard (`sb_compose.moves_on_axis`) requires the joining species to *move*.
Strengthen it to require the joining species to move **by the candidate rectangle's own map**:
score the joining species against the rectangle's map and against its own best independent map, and
refuse the join unless the rectangle's map is at least as good. A join must not be cheaper than
the truth.

### 2.4 A duplicated move

`Schedule` moves **59** (f231–239, t 7.0639–7.2968) and **60** (f235–236, t 7.1901–7.2284) are the
identical pair of rectangles with the identical map — `x {17,23}: y 19:22→24:27 | y 23:27→19:23` —
nested in time. Rendering the sheet applies that rotation **twice**, so the block ends at rotate +8
instead of +4. `Notes` calls move 59 "X1 rows, frames 231-237" and move 60 "Z0 rows, frames
235-239": the same physical movement was enumerated once for X1 and once for Z0 and fitted twice.
It is the only duplicate in the book (checked over all 80 moves).

**Why it happens.** In the pipelined phase the block on rows 19:27 is being handed between species
labels, so both species' transition lists contain it. The cross-species join is what is supposed to
collapse those two transitions onto one move; here it did not, and `sb_audit`'s check 2 cannot see
the failure because it counts the joins that *were* made ("18 moves carry more than one
transition") and has no way to notice a join that should have been made.

**The fix.** Assert, after emit, that no two moves carry the same `(x_start, y_start, x_finish,
y_finish)` with overlapping time spans; on a hit, merge them into one move with both species
joined. Two lines in `sb_audit`.

### 2.5 Three places where an atom is driven by two crossed pairs at once

Physically impossible, and it is what inflates the AOM peak to 6.

| instant | the two live rectangles | overlap |
|---|---|---|
| f043 | `x 1:2 y 10:18` and `x 3:12 y 10:18` (f033–044, a column move) against `x 1:12 y 15:17` and `x 1:12 y 13:14` (f043–049, row moves) — 60 sites | 1 frame |
| f067 | `x 13:24 y 19:27` (f058–069, the Z exchange) against `x 13:15 y 19:27` and `x 16:24 y 19:27` (f067–079) — 108 sites | 2 frames |
| f077 | `x 13:15 / 16:24 y 19:27` (f067–079, columns) against `x 13:24 y 23:25 / 26:27` (f077–083, rows) — 60 sites | 2 frames |

Shayne's book has **none** — his batch structure gives consecutive moves a shared boundary by
construction.

**Why it happens.** Rule 14 says boundaries within ~1.5 frames are one boundary measured twice, and
names this exact consequence: "the sub-frame overlap makes the AOM colouring believe both moves are
live at once and allocate a fresh crossed pair". The reconciliation is being applied within a
species and axis but not across the chain of consecutive moves that act on the *same atoms* on
*different axes* or under *different species labels*.

**The fix.** After fitting, reconcile globally: collect every `t_start`/`t_finish`, cluster within
1.5 frames, snap each to the representative that costs least (rule 14 already prescribes "where it
costs least", not the cluster mean), never across a pulse — then assert the no-double-drive check
passes. It is a post-condition, not a heuristic: if it fails, something is wrong.

### 2.6 `sb_emit`'s `Combined` sheet is lossy — 11 of 160 rectangles are missing from it

`Combined` writes one `(x, y)` cell per AOM column per row:

```python
for gi, x, y in (ev["c1"] if is_start else ev["c2"]):
    if gi < NCOL:
        ws.cell(row=r, column=6 + 2 * gi, value=x)      # sb_emit.py:204-207
        ws.cell(row=r, column=7 + 2 * gi, value=y)
```

Where two rectangles of one move **correctly** share a crossed pair — rule 8's merge, e.g. move
29's `y 2 → 1` and `y 5,7,9 → 4,6,8`, whose merged map `{2,5,7,9} → {1,4,6,8}` is still strictly
increasing — the second cell overwrites the first and that rectangle vanishes from the sheet.
Affected moves: **26, 29, 31, 32, 48, 55, 63**; 11 rectangles lost; `Schedule` has 160 movement
rectangles and `Combined` only 149.

This matters more than a formatting bug, because `Combined` is the sheet in Shayne's format — the
one a person reads, and the one `aom_min.py` and `cmp_shayne.py` read. In it, move 29 reads
`y 1,4,6,8 → 2,5,7,9` and `y 5,7,9 → 4,6,8`, which is **not a bijection**: row 2 is not a source
and two atoms land on it. The move in `Schedule` is correct. Every apparent non-bijection I found
in my first pass came from this, and none survived reading `Schedule`. It also means
`c540_vs_shayne.md`'s rectangle count ("208 vs 147") is partly this artefact.

**The fix.** Accumulate per `(row, slot)` and write the **union** of the combs with the merged map,
or give the rectangles distinct slots. Also worth asserting that `Combined` and `Schedule` describe
the same movements before delivery — they are two views of one thing and only one of them was
checked.

### 2.7 The first gate row misstates the configuration it says it is holding

`Combined` row 1 (the pulse over frames 0–1) reads `x 2:11,14:23 y 1:9` and `x 1:12,14:23 y 19:27`.
The configuration held over frames 0–1 is the seed: `x 1:24 y 1:9` and `x 1:24 y 19:27`, which is
what the `Seed` sheet correctly says.

**Why.** `sb_emit.held(ref)` picks `ref = p0 - 1 if (p0 - 1) >= f0 … else p1 + 1`. For the run at
f0–1 there is no `p0 - 1`, so it reads **frame 2** — a frame on which the first move has already
started. Only the first run is affected; every other run uses `p0 - 1`, a settled frame.

Display-only, but it is also a symptom worth keeping: a 12-column block rounds to **ten** distinct
peaks on f2. That is the very merging §2.1's mechanism depends on, visible in the deliverable.

**The fix.** For the first run take the configuration from the `Seed`, or read it on the pulse
frames themselves from the outline colours (rule 15) — never from the frame after the run.

### 2.8 The known structural hole, and the corruption downstream of it

`Z0/Z1 cols 13:24 → 1:12` at f315–328 and the whole of f329–336 are missing (correctly reported as
6 of the 7 undetermined transitions). What has not been said before is how far the damage travels:
from f328 the sheet's **state** is twelve columns out from the movie's, and the sheet becomes
internally inconsistent, not merely incomplete.

* `se_sim` already reports it: `check3 move 74 t=10.286: picked up 0 of 108 sites` and
  `check3 move 76 t=10.8357: picked up 0 of 108 sites`.
* My simulation adds: at f336–348 the move `x 1:12 y 1:9 → x 13:24 y 1:9` has **every source site
  empty** and **all 108 landing sites already occupied**.
* Test 2: the configurations at f328, f336 and f383 all differ from Shayne's by exactly that
  12-column offset, and the derived book does not close on the seed.

**The fix.** Nothing after f328 should be trusted or scored until this is filled, and **`se_sim`'s
`check3` should be a hard failure, not a note** — a move that picks up 0 of 108 sites is never
legitimate. On the map itself, Shayne reads `13:22→3:12 | 23:24→1:2`; session 16 showed the fit
cannot separate his rotate-by-2 (0.2654) from rotate-by-3 (0.2458), so this one does need pixels,
and §5 says what to run.

---

## 3. Faults in Shayne's book

Fewer, and none of them is a wrong movement.

1. **The X1 readout is missing.** At f337 the movie desaturates and drops X0 at `cols 13:24` *and*
   X1 at `cols 25:36` — parked off panel at f305–313, only its col 25 visible. Shayne writes
   `x 13:24 y 19:27 → readout` only, so 108 atoms stay parked at `25:36 × 19:27` for the rest of
   his book and his configuration at f383 is the seed **plus** a stale block there. The derived
   book's `x 13:36 y 19:27 → 28:36` is right. This is the natural cost of transcribing by eye from
   the panel, and it is the one place where the derived book is more complete than the hand book.
2. **Every post-pulse batch starts on the pulse run's LAST frame.** Verified on all twelve runs:
   f0–1 → t 0.0300 (f0.98), f33–34 → 1.0400 (f34.02), f58–59 → 1.8000 (f58.88), and so on. Under
   rule 9 as corrected in session 15 a Rydberg pulse is instantaneous and the gate's instant is the
   run's **first** frame, so all of his post-pulse starts are one frame late. This is not a movement
   error — and it is where the project's own old, wrong convention came from (c540_v4's `Gates`
   row 1).
3. **Elsewhere his timings are good.** Of 60 matched boundaries, 54 agree with the derived book's
   fitted values to within one frame and 58 within two; mean difference +0.15 frames, median +0.04.
   So timing is not a source of disagreement in either direction beyond point 2.
4. **A rectangle in flight across a batch boundary is written as a blank**, which is unambiguous
   only if you track each AOM open→closed rather than pairing rows within a batch. Worth
   documenting, not fixing; it cost me an hour and two false findings.
5. **His gate rows are not full configurations** — they list the blocks participating in the gate,
   and omit static rectangles and the no-data parking block at `1:12 × 19:27`. So they cannot be
   used as configuration checkpoints, which is why Test 2 simulates from the seed instead.
6. **He writes up to 6 crossed pairs where 4 suffice** in 38 of 55 non-gate batches. Not a fault —
   the AOM assignment is arbitrary — but it does mean the AOM columns of his book are not a
   hardware count. See §4.

---

## 4. The AOM question, answered properly

You said the AOM configuration is arbitrary, that Shayne may have used more than necessary, and
that what matters is the movements. All three are right, and the numbers are now like-for-like.
`run_c540/aom_peak.py` computes the minimum concurrent crossed pairs from each book's **complete**
rectangle list (`Schedule` for the derived book, so §2.6 does not distort it).

| | rectangles written concurrently, at worst | crossed pairs actually needed |
|---|---|---|
| Shayne v3 | 6 | **4** — and no instant in the whole movie needs more |
| derived | 10 | **6**, at f043 |

`aom_min.py`'s merge criterion is only half of rule 8's. A crossed pair drives the whole product
(x comb) × (y comb) with one map per axis, so two rectangles can share a pair only if their union is
again a product, which leaves exactly two cases:

```
X1 == X2  and  fx1 == fx2  and  fy1 U fy2 strictly increasing     -- union the y combs
Y1 == Y2  and  fy1 == fy2  and  fx1 U fx2 strictly increasing     -- union the x maps
```

`aom_min.py` implements only the second, so it over-counts: at Shayne's t 5.81 it reports 6 pairs
for three copies of `x 13:22 → 15:24` on `y 1:9`, `y 10:18` and `y 19:27` plus three of
`x 23:24 → 13:14`, which is really **2** pairs on the comb `y 1:27`. Both books' peaks above use
the full criterion.

**So no AOM difference in this comparison is a fault.** But the derived book's 6 is not slack
either — it is rule 8's diagnostic firing, and it points at §2.1 and §2.5:

* **f043 needs 6.** Four of the six are the f044–049 row rectangles, two on `x 1:12` and two on
  `x 13:24`. Shayne gives X0 and X1 the *same* row map, so his two pairs of rectangles merge by
  the union-of-x-combs rule into `y 13:15→16:18 on x 1:24` and `y 16:18→13:15 on x 1:24` — two
  pairs, not four. **The derived book needs four only because X0's map is wrong** (§2.1, row 6).
  The other two of the six are there only because of the 1-frame overlap of §2.5.
* **f099 needs 5** where Shayne's reading of the same instant needs 4 — the excess is the garbled
  f096–104 read (§2.1, rows 8–10).

Fixing §2.1 and §2.5 should take the derived book to 4, which is what the movie's own title
("4-AOD pipelined SE cycle") says the machine has.

---

## 5. What the structure cannot settle — these need `adjudicate.py`

Four disagreements survive every structural argument. All four are bijections in both books, all
four close cyclically, and neither book is internally inconsistent about them.

1. **f231–238, rows 1:9 on `x {17,23}`.** Shayne rotates **+3**, the derived book **+5**. The
   internal-consistency argument leans to Shayne — every other sub-comb move in *both* books
   applies one rotation to both data bands, and Shayne has +3 on rows 1:9 and +3 on rows 10:18,
   while the derived book has +5 on rows 1:9 and nothing on rows 10:18 (§2.2) — but the
   neighbouring sub-combs rotate by 6, 1, 3 and 4, so there is no pattern to appeal to. **This is
   the one I would insist on measuring.**
2. **f078–093, rows 5 and 6 on `x 1:12`.** Shayne `5→6, 6→7` (order-preserving); the derived book
   `5→7, 6→6`. The derived reading requires the two markers to cross inside a short window, which
   rule 10 says is the classic artefact, so Shayne is the more likely — but it is one pair of atoms
   and the argument is weak.
3. **f104–112 and f368–383, the `y 19:27` row permutations.** Both books give bijections of the
   nine rows that differ in detail (48 and 108 atoms). Nothing structural separates them.
4. **f315–328 (`13:22→3:12 | 23:24→1:2`) and f329–336.** Shayne's maps are the only candidates on
   the table, and session 16 showed the fit cannot separate rotate-by-2 from rotate-by-3. Filling
   these needs a measurement designed for the question, not a rescore.

For 1–3, extend `run_c540/adjudicate.py`'s `JOBS` with the two candidate maps and its own frame
window; it fits both freely inside rule 9's bounds and scores them with the project's own symmetric
peak-matching error. For 4, the discriminating evidence is the **ratio of the two sub-blocks'
speeds on the first two or three moving frames**, before anything merges — session 16 measured
2.46 against Shayne's predicted 2.2, which is suggestive and not decisive; profiling column by
column (`diag_subcol.py`) on f316–318 alone should separate rotate-by-2 from rotate-by-3, because
the two predict two-column and three-column wrap groups with different speeds.

---

## 6. One caution about using the score as a detector

It is tempting to conclude from §2.1's table that the derived book's own `verified` numbers already
flagged the bad moves. They correlate, but weakly, and it would be wrong to rely on them
(`run_c540/cmp_resid.py`):

| | moves | mean `verified` | median | mean `worst` | over the 0.10 guideline |
|---|---|---|---|---|---|
| in segments that **agree** with Shayne | 36 | 0.1011 | 0.0919 | 0.798 | 15 |
| in segments that **differ** | 42 | 0.1214 | 0.1151 | 1.140 | 25 |

Ten of the twelve worst-scoring moves are in differing segments — but two are not, and the very
worst `worst` in the whole book (0.2480 mean, **worst 9.169**, the Z0/Z1 exchange at f058–069) is
in a segment whose map is **exactly right**, because the two Z blocks pass through each other
there. Fifteen agreeing moves are over the guideline. The residual is a hint about where to look;
the structural invariants of §2.1–§2.5 are what actually decide. That is the same lesson as rule
27's, in yet another place: **the checks that catch these faults are the ones that do not look at
pixels at all.**

---

## 7. What I would do first

1. **§2.6 and §2.7** — `sb_emit` fixes, minutes each, and until §2.6 is fixed the delivered
   `Combined` sheet is wrong in a way that makes the book look worse than it is.
2. **§2.1's cyclic-closure test** — the highest ratio of faults fixed to code written in this
   list: thirteen movements, three lines of arithmetic, no new measurement.
3. **§2.2's three checks** — the sub-comb sweep, the sub-comb audit, and cycle closure onto the
   seed. Cycle closure is the single most valuable check missing from this project: it is one
   assertion, it needs no pixels, and it would have failed on this sheet.
4. **§2.4 and §2.5** — the duplicate check and the global boundary reconciliation, then re-measure
   the AOM peak and expect 4.
5. **§5.1's measurement**, then §2.8's hole.
6. Only then render and score. Under §2.8 the sheet is inconsistent after f328, so a score computed
   now would be measuring the hole.

And when the sheet is rebuilt: **re-run `cmp_struct.py`.** All 41 segments should agree, both books'
validity should be 0 complaints, the derived AOM peak should be 4, and both books should close on
the seed.

---

## 8. Files

| file | what |
|---|---|
| `run_c540/cmp_struct.py` | the three structural tests; the tool this report is built on |
| `run_c540/cmp_struct.txt` | its full output, segment by segment, with both books' rectangles and axis maps |
| `run_c540/aom_peak.py` | minimum concurrent crossed pairs from a book's complete rectangle list, with rule 8's full merge criterion |
| `run_c540/cmp_resid.py` | §6's correlation between the derived book's own residuals and the disagreements |
| `c540_vs_shayne.md` | session 16's move-level comparison — still correct, and this report's §2.1/§2.3 are the wider form of its §3.1/§3.2 |
| `run_c540/adjudicate.py` | the pixel arbiter for §5, unmodified |
