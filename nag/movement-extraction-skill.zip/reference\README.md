# Reference — where the method came from

These are the original session reports, shipped unedited. They refer to folders in the project they
were written in (`run_c780_s31\`, `2aod\`, `closed videos\`, `HANDOVER.md`); the mapping to this
package is at the top of `..\method\handmade correction method.md`.

**You do not need any of these to do the work** — `..\README.md`, `..\RUN_BOOK.md`,
`..\skills\se-cycle-blocks\SKILL.md` and `..\method\handmade correction method.md` are sufficient.
Read these when you want to know *why* something is the way it is, or when you want a worked example
of a decision like the one in front of you.

## Why the solver behaves as it does

| file | |
|---|---|
| `SESSION_23_PATCH_ROUTE.md` | reading movements from marker *appearance patches* instead of rest-frame occupancy — for the movements a movie never shows a rest frame for. Tested, not promoted as the default |
| `SESSION_25_C540_ROOT_CAUSE.md` | the "one tone short" fault: a cyclic rotation read one tone short is **the** commonest derived-book error. Test `D1 − D2 == n`. This is where the S2.1 competition in `sb_build.py` comes from |
| `SESSION_26_PATCH_DETECTOR.md` | `sb_gaps.py` — the patch route repurposed as a *detector* feeding the production solver, for sub-comb batches occupancy cannot enumerate. This is `sb_full --gaps on`, the default |
| `SESSION_27_LAST_RESORT.md` | the last-resort families for transitions no route describes and no rectangle carries, ranked on the **free per-frame progress** rather than the smoothstep fit. §1.3 is the reason you judge a hand map on the free fit |

## Worked hand-correction sessions

Read at least one in full before your first correction pass. They are in increasing order of how
close they are to current practice; **`SESSION_31` is the reference.**

| file | movie | what it teaches |
|---|---|---|
| `SESSION_28_HAND_CORRECTIONS.md` | c540 | the first session done this way; where "render once, at the end" and the new-folder convention come from |
| `SESSION_29_C500_HAND_CORRECTIONS.md` | c500 | the static-rows-as-identity fix (maps reading 0.27–0.43 → 0.03–0.15) and the shared-`t_start` rule for exchange halves |
| `SESSION_30_C630_HAND_CORRECTIONS.md` | c630 | AOM inflation from 0.2–0.6-frame step overlaps — a fault kind that shows up only as a count |
| `SESSION_31_C780_HAND_CORRECTIONS.md` | c780 | **the reference.** 54 corrections found and applied by the session without being told what to do. The division of labour in §0 of the method document is this session's result. Its folder is `..\worked sessions\4aod_c780_s31\` |
| `SESSION_32_C975_HAND_CORRECTIONS.md` | c975 | the hardest movie: small permutations that are two disjoint 3-cycles, not rotations |
| `SESSION_32_USER_ITEMS_TO_APPLY.md` | c975 | **a real §3 dialogue.** What the reviewer asked for, and the fixed-format answer to each. Use it as the template for your own replies |
| `SESSION_34_C975_SECOND_PASS.md` | c975 | closing a movie: 96 moves, 0 undetermined, 102/102 explained, score 0.0575 |

## Against an external human transcription

`c540_faults_vs_shayne.md` — the automatic c540 book compared fault by fault against
`..\worked sessions\c540_v3_shayne_handwritten.xlsx`, the only independently hand-written
book in existence for any of these movies. Also the origin of the warning that `cmp_full.py` compares
displacement *sets*, not maps.
