import json, sys
p = sys.argv[1]
d = json.load(open(p, encoding="utf-8"))
print(type(d).__name__, (list(d.keys()) if isinstance(d, dict) else len(d)))
mv = d["moves"] if isinstance(d, dict) and "moves" in d else d
print(len(mv), "moves")
print("first move keys:", list(mv[0].keys()))
print(json.dumps(mv[0], indent=1)[:2500])
print("=" * 100)
for i, m in enumerate(mv):
    keys = m.keys()
    sp = m.get("species") or m.get("sp") or m.get("name")
    ax = m.get("axis")
    f0 = m.get("f0"); f1 = m.get("f1")
    mean = m.get("mean")
    mp = m.get("map") or m.get("label") or ""
    note = m.get("note") or m.get("notes") or ""
    print(f"{i:3d} {str(sp):10s} ax={ax} f{f0}-{f1} mean={mean} {str(mp)[:70]} | {str(note)[:80]}")
