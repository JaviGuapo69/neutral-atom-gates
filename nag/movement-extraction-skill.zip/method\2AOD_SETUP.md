> ### Note for this handover package
>
> This document was written inside the original working project. In this package:
>
> | referred to as | here |
> |---|---|
> | `2aod\fix_calib_2aod.py`, `skeleton.py`, `transitions.py`, `sheet.py`, `deliver_2aod.ps1`, … | `2aod_helpers\` (all nine scripts) |
> | `SE_cycle_movies\movies_2aod\mitten_codes` | `..\movies\movies_2aod\mitten_codes\` |
> | `..\..\.claude\skills\se-cycle-blocks\tools` (`$SB`) | wherever you installed the skill — see `..\README.md` §3 |
> | `..\..\.claude\skills\se-cycle-movies\tools` (`$SE`) | likewise |
> | `2aod\run_c150_2aod\` | `..\worked sessions\2aod_c150\` — a complete worked 2-AOD run |
> | `2aod\cNNN_2aod_s33_corrections.md` | `..\..\closed videos\` (c150, c200, c300) |
>
> The scripts in `2aod_helpers\` were written to be run from the folder *above* the per-movie run
> folder, i.e. `python ..\2aod_helpers\fix_calib_2aod.py run_c150_2aod`. Keep that layout, or adjust
> the relative paths inside them.
>
> Condensed version of everything below: `..\README.md` §9 and `..\RUN_BOOK.md` §B.

# The 2-AOD movies — what differs from the 4-AOD family, and the run book

**Written for: the next session working on `SE_cycle_movies\movies_2aod\mitten_codes`.** Everything
here was measured on c150 (2026-09-18) and is expected to hold for the other seven, but every number
is re-measured per movie — nothing about a palette, a lattice or a reservoir transfers (SKILL.md 39).

The skill itself is UNCHANGED and must stay so. All of the adaptation below lives in the per-movie
input files (`calib.json`, `blocks.json`, `events.json`, `extra.json`), which is where it belongs.

---

## 1. What is different about these movies

| | 4-AOD (`movies_4aod`, the closed family) | 2-AOD (`movies_2aod\mitten_codes`) |
|---|---|---|
| frames | 384 | **568–574** |
| header | `t 0.00/5.49 ms · phase 1 Z:D5 \|\| X:D1-4 · global pulse` | `t 0/8,829 us (0%) · last CZ gate: +1.0 us` |
| cycle time | in the title, ms | in the title, ms (`2-AOD SE cycle: 8.83 ms`); the header prints µs |
| gate runs | 2 frames | **4 frames** |
| AOD groups | 4 (legend AOD1–AOD4) | **2** (legend AOD1 gold, AOD2 purple) |
| species | X0 X1 Z0 Z1, all live at once | the same four, but **Z works first, then X** — the cycle is serialised |
| faded stock | solid blended **55 %** into white | solid blended **71 %** into white (α = 0.288) |
| readout | block desaturates and descends to a reservoir | mostly a plain translation off the panel edge |
| idle blocks | always solid | **drawn FADED while idle** (see §3) — new, and it is the trap |
| footer | none | `CZ firing: Z0→D1: R(x·s) \| Z1→D3: R(x·s)` — **the circuit, frame by frame** |

**The footer is the single most useful thing in these movies.** Cropping it on every gate frame
(`sheet.py`-style, x 400..1300, y 1045..1080) prints the whole cycle in 24 lines: which ancilla fires
against which data block at which gate. It tells you which blocks are supposed to be idle, so §3's
fades are explained before you ever probe a pixel. Do this FIRST on a new movie.

## 2. `se_calib` mis-reads the palette here — fix it with `fix_calib_2aod.py`

`se_calib.py` folds a species' faded form into its solid on the rule `faded = solid + (255-solid)*0.55`.
At 71 % the merge misses, so every faded form comes back as an extra **SPECIES** (six, not four) and
the top-to-bottom naming heuristic then mislabels all of them — on c150 it called the pink block `Z0`
and the pale gold `X0`. Downstream nothing recovers from that.

```powershell
python ..\.claude\skills\se-cycle-movies\tools\se_calib.py --frames frames --out calib.json --cycle-ms 8.829
python ..\fix_calib_2aod.py run_c150_2aod          # keeps se_calib's original as calib.json.se_calib
```

`fix_calib_2aod.py` writes the four species the movie's own legend names, with `faded` at the measured
blend and `marker_area` / `marker_offset` re-measured over those four colours only. **Check the legend
crop before trusting it** — the mapping on c150 is Z0 blue `(42,118,213)`, Z1 green `(0,129,1)`,
X0 pink `(232,121,163)`, X1 orange `(236,159,1)`, identical RGB to the 4-AOD movies.

**Two faded tracks are polluted and you must not read areas off them naively.** Pale pink (X0) is 22 RGB
from the gate tint and 48 from white, pale green (Z1) is 34 RGB from the data-ring grey — both inside
`Movie.mask`'s 34 tolerance. X0's faded area therefore sits at a ~10 000 px baseline all movie and Z1's
at ~5 000. The SOLID track is clean for every species; use it, and read the faded track only through a
tight `--win` on the block, where the ring bleed is a constant offset you can see.

## 3. THE TRAP: a faded block here is IDLE, not read out

In these movies a block that has no gate to fire and no move to make is drawn faded, in place, and
then turns solid again. c150 does it four times (Z1 f137–151 and f172–217, X1 f399–409 and f421–480).
It is not a readout: the atoms never leave, and the rectangle before and after is identical.

Proof, per case, is cheap and is what `events.json` must quote: probe the FADED track on both axes over
the dark run. On c150's Z1 f137–151 the faded peaks are frozen to the pixel — cols `7.05 8.05 9.05
10.05 11.05 12.05`, rows `5.94 6.95 7.94 8.95 9.94`, mask area 6492/6493 on **every** frame — and the
solid block returns on exactly those tones at f152.

What it costs you: the occupancy test bridges the dark run and enumerates a **same-site permutation**
that does not exist. Name it in `events.json` and the solver skips it; leave it and the solver invents
a permutation (SKILL.md 3a). A dark run that has no rest on one side produces no transition at all and
needs no entry — check with `transitions.py` rather than guessing.

`transitions.py <run>` runs sb_full's chain as far as `sb_build.settled` and prints every rest and
transition **without solving**, so `events.json` windows can be written to contain exactly the
transitions the solver will see. Use it before the solve, every time; it costs a few minutes.

## 3b. TWO MORE CALIBRATION TRAPS, both first met on c300

**The pitch can come back as a SUBMULTIPLE.** `se_calib.comb_fit` maximises `|sum exp(2*pi*i*v/p)|`
over p from 6.0 px upward, and every submultiple of the true pitch scores the *same* magnitude —
points on a comb of pitch p are also on a comb of p/k — so on a fine lattice the scan settles on p/2
or p/3 on noise alone. c300_2aod came back 16.038 × 24.056 px where the rings are 47.8 apart, with
a 58 × 38 data extent for a 20 × 18 movie. It announces itself: `!! ring centres do not sit on one
comb`, worst residual 0.208 site. **Do not go past that line.** `fix_lattice_2aod.py <run> --floor 30`
re-runs se_calib's own derivation with the search floor raised and rewrites only the lattice fields;
check the printed residual (se_calib's bar is 0.18) and the data extent against the movie.

**The legend may be drawn INSIDE the panel.** c150 and c200 put it to the left, outside; c300 puts
it along the top, inside the panel box, and its four species swatches land at **row −0.47** — where
the movie's own blocks reach (f295 has X0 and X1 at row −0.45). So every species' mask carries one
phantom marker at a fixed non-integer column on every frame and no window separates it from row 0.
`depaint_legend.py <run> --band 55,88 --ref 10 --x 312,1374` takes the band's non-background pixels
from one clean frame as a stencil — the legend is static, so those pixels are identical on every
frame — and repaints exactly those positions with the frame's own background. Keep `--x` inside the
panel border so the right-hand tables stay in the full-frame video. Originals go to `frames_raw\`.
**Do it before `se_calib`**, and note that re-running `se_calib` on the cleaned frames can fail its
panel detection: keep the original `calib.json`, and re-run only `fix_lattice_2aod.py` and
`fix_calib_2aod.py` against the cleaned frames.

## 4. The run book (c150, 2026-09-18)

```powershell
$SB = "..\..\.claude\skills\se-cycle-blocks\tools"; $env:PYTHONIOENCODING = "utf-8"
ffmpeg -y -v error -i <movie>.mp4 -fps_mode passthrough -start_number 0 frames\p_%03d.png   # ffmpeg 9: -fps_mode, NOT -vsync
python $SE\se_calib.py --frames frames --out calib.json --cycle-ms <title>
python ..\fix_calib_2aod.py <run>                       # ALWAYS, see §2
python $SB\sb_read.py   --calib calib.json --palette    # expect gold + purple outlines, and one anti-aliased twin
python $SB\sb_blocks.py --calib calib.json --out blocks.json
python ..\skeleton.py <run> --faded > logs\skeleton.txt # where every block sits, interval by interval
python $SB\sb_events.py --calib calib.json --full > logs\sb_events_full.txt
python ..\transitions.py <run> > logs\transitions.txt   # then write events.json (§3)
# solve as two halves, at most two solvers at once (each holds ~1.2 GB):
python $SB\sb_full.py --calib calib.json --blocks blocks.json --work half_a --events events.json --only 0,...,11 *> logs\half_a.log
python $SB\sb_full.py --calib calib.json --blocks blocks.json --work half_b --events events.json --only 12,...,22 *> logs\half_b.log
python $SB\merge_halves.py --calib calib.json --blocks blocks.json --out . --xlsx <movie>_2aod_blocks.xlsx half_a half_b
python $SB\sb_audit.py --moves moves_full.json --rests rests_full.json
python ..\..\.claude\skills\se-cycle-movies\tools\se_sim.py <movie>_2aod_blocks.xlsx
.\deliver_2aod.ps1 -Run <run> -Xlsx <book>.xlsx -Tag <movie>_2aod_<tag>       # from 2aod\, detached
```

Helper scripts in `2aod\`: `fix_calib_2aod.py`, `skeleton.py`, `transitions.py`, `sheet.py` (contact
sheets and per-block montages, `--win c0,c1,r0,r1`, `--rframes` for the rebuild), `deliver_2aod.ps1`.

## 5. c150's structure, as a shape to expect

24 gate runs of 4 frames, 23 pulse-free intervals, four 6×5 blocks on a 12×15 lattice. Gates 1–12 are
the Z phase (Z0→D1/D2, Z1→D3/D4, six rounds; then Z0→D5 ×3 and Z1→D5 ×3), gates 13–24 the X phase
(X0→D1/D3, X1→D2/D4, six rounds; then X0→D5 ×3 and X1→D5 ×3). Z0 and Z1 start on the panel at
cols 1:6, rows 1:5 and 6:10; the X blocks arrive from **above** (rows −4:0) at f279. Readouts leave by
translation: Z0 and X0 to the **left** (1:6 → −5:0), Z1 **downward** past row 15. X1 is still on the
panel when the movie ends.
