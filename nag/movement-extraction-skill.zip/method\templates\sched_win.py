"""sched_win.py -- print the Schedule rows of one workbook whose time window overlaps a frame range.
The species is not a column of its own; it is the first word of the note ("Z0 cols a; verified ...").

    python sched_win.py BOOK.xlsx F0 F1 [SPECIES]
"""
import sys
from openpyxl import load_workbook

DT = 0.038020833
path, f0, f1 = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
want = sys.argv[4] if len(sys.argv) > 4 else None
wb = load_workbook(path, data_only=True)
ws = wb["Schedule"]
hdr = [c.value for c in ws[1]]
out = []
for row in ws.iter_rows(min_row=2, values_only=True):
    d = dict(zip(hdr, row))
    t0, t1 = d.get("t_start"), d.get("t_finish")
    if t0 is None or t1 is None:
        continue
    a, b = float(t0) / DT, float(t1) / DT
    if b < f0 or a > f1:
        continue
    note = str(d.get("note") or "")
    if want and not note.startswith(want):
        continue
    out.append("f%7.2f-%7.2f  %-14s  %-10s %-16s -> %-10s %s"
               % (a, b, note.split(";")[0][:14], str(d.get("x_start"))[:10], str(d.get("y_start"))[:16],
                  str(d.get("x_finish"))[:10], str(d.get("y_finish"))[:16]))
print("%s -- %d rows over f%.0f-%.0f%s" % (path, len(out), f0, f1, (" for " + want) if want else ""))
for line in sorted(out):
    print("  " + line)
