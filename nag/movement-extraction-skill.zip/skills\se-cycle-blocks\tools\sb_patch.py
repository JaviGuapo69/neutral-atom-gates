"""sb_patch.py -- PATCH-BASED movement extraction (session 23, the user's model).

THE PROBLEM THIS SOLVES.  Everything else in this skill enumerates a movement from two REST
configurations found by occupancy (rule 2), and a movement that has no visible rest frame at
either end therefore cannot be enumerated at all.  The video's frame rate does not oblige: the
last frame on which a block is still held by the old AOM configuration is often a fraction of a
site off its tones, so the rest test rejects it, the transition window runs on into the next
movement, and the partition read is taken over frames that span two different AOM configurations.

c540 f023-f027 is the worked example and it is worth keeping in view.  D3 (X0) and D4 (X1) perform
the SAME double swap -- rows 12<->13 and 15<->16 -- and the row profiles agree to 0.05 site.  At
f025 X0's worst marker sits 0.130 off its tone and X1's sits 0.160, against TOL_ONGRID = 0.14.  So
X0 rests at f025 and X1 does not; X1's window runs to f026, which belongs to the NEXT movement; the
appearance read finds no class rigid across it and returns nothing; and the fallback rotation family
-- which can only express two groups on a contiguous run -- writes a 5-cycle.  A 0.03 site pixel
difference, and the two zones come out with different movements.

THE MODEL (user, session 23).

  * While a Rydberg pulse is on, every AOM is off.  Nothing can be distinguished on screen and
    nothing moves, so the configuration during a pulse is the one from just before it.
  * The first frame AFTER a pulse shows the AOM configuration.  Markers sharing FILL + OUTLINE +
    SHAPE are a PATCH: one rigid body, driven by one crossed pair.  A patch is the only thing
    guaranteed to move rigidly -- it is not the same as an AOM, because two patches may share one
    AOM.  Merge patches into AOM groups afterwards (rule 8), never before.
  * The first and last frames on which a patch is visible need NOT be rest frames.  Take the
    SOURCE slots to be the nearest slots, and on a tie the slot OPPOSITE the direction of travel
    (the patch has already begun to move, so its origin is behind it).  Take the DESTINATION slots
    to be the nearest slots, and on a tie the slot IN the direction of travel (the patch has not
    quite arrived, so its destination is ahead of it).
  * Rigidity is mandatory, so ROUND PER PATCH, never per marker: fix the patch's internal comb and
    round its anchor once.  Rounding members independently can split a rigid patch across two
    source combs, which is a movement the hardware cannot perform.
  * Where no rest frame exists, a movement BOUNDARY is where the rigid-body rule breaks: if the
    markers cannot be carried from one frame to the next as one rigid body, the two frames belong
    to different AOM configurations.  At such a boundary the displacement from the lattice is small
    -- that is why rounding to the nearest slot is safe there.

WHAT THIS IS FOR, AND WHAT IT IS NOT FOR (user, session 23, answer 6).  **Rest detection stays the
default.**  This module is for movements whose rest position is never shown, and as a DOUBLE CHECK
on movements whose rest was borderline -- a block accepted or rejected as settled by a hair.  It
does not replace `sb_build.settled`.

WHY THE MEASUREMENT IS EASY WHEN THE ENUMERATION WAS NOT.  Measured on c540's segment 6, the
outline colour names the sub-comb the batch actually drives, with no search at all:

    f203  X1  rgb(152,124,185)  cols 13.05 18.99   rows 19.39 .. 26.37  (8 members, +1)
          X1  rgb(247,188, 70)  cols 12.99 18.95   rows 24.10           (1 member, the wrap)
    f211  X1  rgb(152,124,185)  cols 14.04 20.00                        (the NEXT batch)

Rule 40's whole difficulty -- "the rectangle's comb on the non-moving axis is a measurement" -- is
answered by reading it off the outline mask.  And the two rigid groups of a rotation carry
different outline colours, so the partition is a direct read rather than a scored search.

TWO THINGS THE COLOURS DO THAT MUST BE FILTERED, both measured on segment 6:

  * some outline colours are DECORATION -- their peaks are identical to two decimals on every
    frame of the segment (`rgb(202,167,90)` reads 13.19 14.19 15.82 ... unchanged from f201 to
    f213).  Those are not atoms; a colour whose peaks never move is dropped.
  * some colours mark a set that is NOT rigid -- `rgb(184,132,100)` covers all nine rows of the
    sub-comb, i.e. both groups of the rotation, which travel +1 and -8.  The rigidity test is what
    rejects it, and that is exactly the user's point that only the triple is guaranteed rigid.
    Where a colour's members do not share one displacement, it is not a patch marker.
"""
import collections
import itertools

import numpy as np

import sb_read
import sb_compose
from sb_read import comb

# --------------------------------------------------------------------------- tunables
STATIC_EPS = 0.08      # site: a colour whose peaks never move further than this is DECORATION
RIGID_TOL = 0.15       # site: ROBUST spread of member displacements a patch must stay inside
RIGID_MAX = 0.45       # site: worst single member deviation, reported and capped (rule 26)
STEP_TOL = 0.25        # site: per-FRAME spread above which the rigid-body rule is broken
MIN_TRAVEL = 0.35      # site: a patch must travel at least this far to be called moving
TIE_EPS = 0.08         # site: |frac - 0.5| below this is a TIE, broken by direction of travel
MAX_MEMBER_JUMP = 0.60 # site: a member moving further than this between frames is not the same one
MIN_RUN = 3            # frames a coherent run needs before a movement is read from it
TOL_ONGRID = 0.14      # site: sb_build's own bar for "this peak is on its tone" (rule 2)
REPAIR_SHIFT = 1       # site: how far a mid-flight slot read may be corrected by the bijection


def _robust_spread(d):
    """rule 26: judge rigidity on a robust quantile of the member deviations, not on the max.

    A rotation's members are measured while other markers pass through their profiles, so one
    member reading 0.2 site out at mid-travel is normal and is not evidence that the set is not
    rigid.  Measured on c540's X1 patch at f201-f205 the member displacements are
    [0.68 0.46 0.65 0.63 0.66 0.68 0.71 0.87]: the max spread is 0.41 and the robust spread is
    0.04, and the set is plainly one rigid body.  Judging on the max rejected it.
    """
    if len(d) < 2:
        return 0.0, 0.0
    med = float(np.median(d))
    dev = sorted(abs(v - med) for v in d)
    q = dev[int(0.8 * (len(dev) - 1))]
    return float(q), float(dev[-1])


# ===================================================================== 1. measure
def tracks(M, wins, outlines, frames, species=None):
    """{(sp, colour): {frame: (cols, rows)}} -- every outline colour profiled per species.

    Measured ONCE, frame-major, exactly as `sb_compose.Peaks` is and for the same reason (1a):
    the decoded frame cache clears whole above 40 frames, so touching each frame once and
    measuring everything while it is in hand is worth several times the cost on a long segment.
    """
    out = collections.defaultdict(dict)
    names = [nm for nm in (species or M.species) if nm in wins]
    for f in frames:
        for nm in names:
            for c in outlines:
                xs = M.peaks(c, wins[nm], f, 0)
                ys = M.peaks(c, wins[nm], f, 1)
                if xs and ys:
                    out[(nm, tuple(c))][f] = (xs, ys)
    return dict(out)


def is_decoration(track):
    """True when this colour's peaks never move -- an overlay, not atoms.

    A decoration colour is the commonest false patch on c540: it has a plausible member count and
    a plausible comb, and it would be read as a block standing still, which is harmless, or worse
    as a block moving by the sub-pixel noise, which is not.
    """
    for axis in (0, 1):
        vals = [v[axis] for v in track.values()]
        n = collections.Counter(len(v) for v in vals).most_common(1)[0][0]
        keep = [v for v in vals if len(v) == n]
        if len(keep) < 2:
            continue
        a = np.array(keep, float)
        if (a.max(axis=0) - a.min(axis=0)).max() > STATIC_EPS:
            return False
    return True


# ===================================================================== 2. coherent runs
def _match(prev, cur, maxjump=None):
    """member-wise displacement from `prev` to `cur`, or None if they are not the same members.

    Both lists are sorted profile peaks, so the correspondence is positional as long as nothing
    has overtaken anything -- rule 20's condition, and it holds here because a patch is rigid and
    a rigid set cannot reorder itself.  A changed member count means the AOM was reprogrammed or
    a marker dropped out; either way this frame does not continue the run.

    `maxjump` IS A PER-STEP TEST AND MUST NOT BE APPLIED TO A WHOLE RUN.  Between neighbouring
    frames a marker moves a fraction of a site, so a jump of a whole site means the peaks are not
    the same markers.  Over a whole run a marker is SUPPOSED to travel a site or more -- that is
    the movement being measured -- and capping it there rejects every move of exactly the kind this
    module exists to find: c540's X1 f200-f207 travels +0.95 per member and came back as "member
    MISMATCH 8 -> 8".  Pass `None` for a run-scale comparison, and scale the per-step bound by the
    frame gap so that skipping a dropout frame does not itself look like a jump.
    """
    if len(prev) != len(cur):
        return None
    d = [b - a for a, b in zip(prev, cur)]
    if maxjump is not None and max(abs(v) for v in d) > maxjump:
        return None
    return d


def _continues(track, pf, f):
    """can frame `f` be carried from frame `pf` as ONE rigid body?  (the user's boundary rule)"""
    jump = MAX_MEMBER_JUMP * max(1, f - pf)
    for axis in (0, 1):
        d = _match(track[pf][axis], track[f][axis], jump)
        if d is None:
            return False
        if len(d) > 1:
            q, _ = _robust_spread(d)
            if q > STEP_TOL * max(1, f - pf):
                return False
    return True


def runs_by_static_comb(track, static_axis):
    """split a colour's frames by the ROUNDED comb on `static_axis` -- the AOM's own frequency comb.

    THIS IS THE PRIMARY BOUNDARY DETECTOR, and it is better than the frame-to-frame rigidity test
    for the reason the physics gives: a crossed AOD pair holds two frequency combs, and the comb on
    the axis that is NOT moving is constant for exactly as long as that configuration is loaded.
    When the AOM is reprogrammed the comb changes, and on c540's segment 6 it changes cleanly and
    unmistakably -- `rgb(152,124,185)` on X1 reads cols {13,19} over f200-207, {14,20} over
    f208-214, {15,21} over f215-222, {16,22} over f223-231, {17,23} over f232-238 and {18,24} over
    f239-245.  Those are the six column-pair batches of the hand book, read with no search.

    The frame-to-frame test stays as a SECONDARY detector (`_continues`), because two consecutive
    batches can share a comb; but it must not be the primary one, because a marker merging with
    its neighbour at mid-travel breaks it and cuts a run in half.  A run cut in half reports a
    fraction of the movement -- c540's `Z0 1:5 -> 5:9` came back as `1:5 -> 2:6` and `4:8 -> 5:9`,
    two partial +1 steps instead of one +4 -- which is worse than reporting nothing.
    """
    out, cur, sig = [], [], None
    for f in sorted(track):
        pk = track[f][static_axis]
        s = tuple(sorted({int(round(v)) for v in pk}))
        if not s:
            continue
        if sig is not None and s == sig and (not cur or f - cur[-1] <= 3):
            cur.append(f)
        else:
            if cur:
                out.append((sig, cur))
            cur, sig = [f], s
    if cur:
        out.append((sig, cur))
    return [(s, r) for s, r in out if len(r) >= MIN_RUN]


def coherent_runs(track, frames):
    """split a colour's frames into runs over which it behaves as ONE rigid body.

    THE BOUNDARY RULE (user, session 23).  Within one AOM configuration a patch is rigid: every
    member shares one displacement, and its membership does not change.  The moment that fails --
    the member count changes, a member jumps a site, or the members stop sharing a displacement --
    the frames either side belong to DIFFERENT AOM configurations, and that is a movement boundary
    whether or not either side shows a rest frame.  On c540's segment 6 the tell is unambiguous:
    `rgb(152,124,185)` marks cols {13,19} over f201-f207 and cols {14,20} over f211-f215, and the
    frames between carry a member count that matches neither.

    A SINGLE-FRAME DROPOUT MUST NOT BREAK A RUN.  A marker can fail to resolve for one frame, or
    two members can merge at a crossing and the count drop by one (rule 20).  That is a missing
    observation, not a reprogrammed AOM, so a frame that cannot be carried is SKIPPED if the next
    one can be carried from the same place -- the same tolerance `sb_build.classes` already allows.
    """
    fs = sorted(track)
    runs, cur, skipped = [], [], []
    for i, f in enumerate(fs):
        if not cur:
            cur = [f]
            continue
        pf = cur[-1]
        if f - pf > 3:                             # a gap this wide is not a dropout
            runs.append(cur); cur = [f]; skipped = []; continue
        if _continues(track, pf, f):
            cur.append(f)
            continue
        nxt = fs[i + 1] if i + 1 < len(fs) else None
        if nxt is not None and nxt - pf <= 3 and _continues(track, pf, nxt):
            skipped.append(f)                      # one-frame dropout: skip it, keep the run
            continue
        runs.append(cur); cur = [f]; skipped = []
    if cur:
        runs.append(cur)
    return [r for r in runs if len(r) >= MIN_RUN]


# ===================================================================== 3. slots, per patch
def _round_dir(v, direction, at_start):
    """nearest slot, ties broken by the direction of travel (user, session 23, answer 3).

    At the START the patch has already begun to move, so on a tie its origin is the slot BEHIND
    it -- opposite the direction of travel.  At the END it has not quite arrived, so on a tie its
    destination is the slot AHEAD -- in the direction of travel.  Away from a tie the nearest slot
    is taken, which is what the user's "the displacement from the rest position is small" makes
    safe.
    """
    frac = v - np.floor(v)
    if abs(frac - 0.5) <= TIE_EPS and direction:
        back = (direction < 0) if at_start else (direction > 0)
        return int(np.ceil(v)) if back else int(np.floor(v))
    return int(round(v))


def slots_for(pos, direction, at_start):
    """round a PATCH as a unit so rigidity survives (user, session 23, answer 4).

    Rounding each member on its own can send two members of one rigid patch to combs a site apart,
    which is a movement no crossed pair can perform.  A patch's internal geometry is fixed, so
    only ONE number needs rounding: take the members' offsets from the first member, round those
    to the comb they form, then round the anchor once and lay the comb on it.
    """
    if not pos:
        return []
    g = [p - pos[0] for p in pos]
    G = [int(round(v)) for v in g]
    # the anchor is the member-mean with the comb removed -- more robust than member 0 alone
    anchor = float(np.mean([p - q for p, q in zip(pos, G)]))
    a0 = _round_dir(anchor, direction, at_start)
    return [a0 + q for q in G]


# ===================================================================== 4. movements
def movement_from_run(M, sp, colour, track, run, static_axis=None, comb_sig=None):
    """one coherent run of one patch -> one movement, or None.

    The moving axis is the one that actually travels; the other axis supplies the rectangle's comb
    (rule 40) and is read off the SAME outline mask, which is what makes a sub-comb move a direct
    read here instead of a search.

    THE ENDPOINTS ARE THE FIRST AND LAST FRAMES ON WHICH THE PATCH FULLY RESOLVES, not simply the
    first and last frames of the run.  At mid-travel two markers can merge and the member count
    drop (rule 20), and a frame where the count is short cannot say where every member was.  The
    modal count over the run is the patch's true size, so the endpoints are taken from frames that
    show it.
    """
    axis = (1 - static_axis) if static_axis is not None else None
    if axis is None:
        a0, b0 = run[0], run[-1]
        trav0 = {}
        for ax in (0, 1):
            d = _match(track[a0][ax], track[b0][ax])
            trav0[ax] = abs(float(np.mean(d))) if d else 0.0
        axis = 0 if trav0[0] >= trav0[1] else 1
    other = 1 - axis

    n = collections.Counter(len(track[f][axis]) for f in run).most_common(1)[0][0]
    full = [f for f in run if len(track[f][axis]) == n]
    if len(full) < 2:
        return None
    a, b = full[0], full[-1]

    trav = {}
    for ax in (0, 1):
        d = _match(track[a][ax], track[b][ax])
        if d is None:
            return None
        trav[ax] = float(np.mean(d))
    if abs(trav[axis]) < MIN_TRAVEL:
        return None                               # the patch does not move in this run
    if abs(trav[other]) > MIN_TRAVEL:
        return None                               # both axes move: not one crossed-pair motion

    # rigidity, reported as its own evidence (rule 26: a robust quantile, max kept separately)
    d = _match(track[a][axis], track[b][axis])
    spread, worst = _robust_spread(d)
    if spread > RIGID_TOL or worst > RIGID_MAX:
        return None

    direction = 1 if trav[axis] > 0 else -1
    src = slots_for(track[a][axis], direction, True)
    dst = slots_for(track[b][axis], direction, False)
    if len(src) != len(dst) or src == dst:
        return None
    D = [q - p for p, q in zip(src, dst)]
    if len(set(D)) != 1:
        return None                               # rounding broke rigidity -- refuse it
    # the comb on the static axis, measured on this patch's own mask (rule 40, read not assumed)
    cb = sorted(comb_sig) if comb_sig else sorted({_round_dir(v, 0, True) for v in track[a][other]})
    return dict(sp=sp, colour=tuple(round(float(v), 1) for v in colour),
                colour_raw=tuple(colour),
                axis="cols" if axis == 0 else "rows",
                f0=a, f1=b, src=src, dst=dst, D=D[0], comb=cb,
                travel=round(trav[axis], 3), rigid_residual=round(spread, 3),
                rigid_worst=round(worst, 3), n=len(src))


def patch_movements(M, wins, outlines, frames, species=None, verbose=False):
    """every patch movement in this frame range, with the decoration and non-rigid colours dropped.

    Two patches marked by two colours that describe the SAME motion on the same lines are one
    movement seen twice (an outline and its anti-aliased edge), so they are collapsed.
    """
    tr = tracks(M, wins, outlines, frames, species)
    moves, dropped = [], []
    for key, track in sorted(tr.items()):
        sp, colour = key
        if is_decoration(track):
            dropped.append((sp, colour, "decoration: peaks never move"))
            continue
        # PRIMARY: segment by the static comb, once per axis -- a patch moving on rows holds a
        # constant column comb and vice versa, and we do not know which a priori.  SECONDARY: the
        # frame-to-frame rigidity test, which catches two batches that happen to share a comb.
        got, nrun = 0, 0
        for static_axis in (0, 1):
            for sig, run in runs_by_static_comb(track, static_axis):
                nrun += 1
                for sub in (coherent_runs({f: track[f] for f in run}, run) or [run]):
                    mv = movement_from_run(M, sp, colour, track, sub, static_axis, sig)
                    if mv is not None:
                        moves.append(mv)
                        got += 1
        if not got:
            dropped.append((sp, colour, "%d run(s), none rigid and moving" % nrun))

    # collapse duplicates: same species, axis, map and comb, overlapping frames
    uniq = []
    for mv in sorted(moves, key=lambda m: (m["f0"], m["sp"], m["axis"])):
        hit = None
        for q in uniq:
            if (q["sp"], q["axis"], tuple(q["src"]), tuple(q["dst"]), tuple(q["comb"])) != \
                    (mv["sp"], mv["axis"], tuple(mv["src"]), tuple(mv["dst"]), tuple(mv["comb"])):
                continue
            if min(q["f1"], mv["f1"]) - max(q["f0"], mv["f0"]) >= 0:
                hit = q
                break
        if hit is None:
            mv["colours"] = [mv["colour"]]
            uniq.append(mv)
        else:
            hit["colours"].append(mv["colour"])
            hit["f0"] = min(hit["f0"], mv["f0"])
            hit["f1"] = max(hit["f1"], mv["f1"])
            if mv["rigid_residual"] < hit["rigid_residual"]:
                hit["rigid_residual"] = mv["rigid_residual"]
    if verbose:
        for sp, c, why in dropped:
            print("   dropped %-3s rgb(%3.0f,%3.0f,%3.0f): %s" % (sp, c[0], c[1], c[2], why))
    return uniq, dropped, tr


def block_tones(M, wins, sp, f, axis):
    """the species' full tone set on `axis` at frame `f`, rounded off its own fill profile."""
    pk = M.peaks(M.fill[sp], wins[sp], f, axis)
    return sorted({int(round(v)) for v in pk})


def block_tone_set(M, wins, sp, axis, a, b, size, frames):
    """THE BLOCK'S TONE SET READ AT A FRAME WHERE IT IS ACTUALLY READABLE (rule 2).

    `batches` completes a batch into a bijection of the block's tone set, so that set has to be
    right.  `block_tones` reads it off the batch's FIRST frame, and on c540's segment 6 that was
    always a frame where the species' own profile is on its tones -- a sub-comb movement drives 2 of
    12 columns, so the other ten sit exactly on the lattice and the read is clean.  Over the whole
    movie it is routinely not: a batch that starts on the first frame after a pulse starts on a
    frame where the WHOLE block is in flight and its markers have merged.  Measured on c540's X0 at
    f002 the column profile reads

        1.66 2.61 3.56 4.66 5.67 6.62 7.18 7.57 8.15 9.16 10.17 11.17

    and rounds to {2..11} -- TEN tones for a twelve-column block, two of them wrong.  Completion
    against that set cannot succeed, and on segment 0 all eleven batches failed for this reason.

    Rule 2 is the statement: never read a configuration off a partly filled zone.  So take the
    nearest frame at which the read has the block's KNOWN size (rule 22) and every peak is on its
    tone, preferring frames inside the batch.  GATE FRAMES ARE ALLOWED and are often the answer:
    nothing moves during a pulse (rule 9) and a pulse-frame configuration is still a configuration
    (rule 15), so the pulse bounding a segment is the most reliable rest in it -- c540's X0 reads
    twelve columns at 0.94 2.02 ... 12.05 on f000 and f001, to two decimals.

    Returns None when no frame in range gives a complete on-grid read, and the caller then keeps
    the old behaviour, so this can only ever repair a batch that was going to fail.
    """
    if not size or not frames:
        return None
    for f in sorted(frames, key=lambda f: (0 if a <= f <= b else 1, min(abs(f - a), abs(f - b)))):
        pk = M.peaks(M.fill[sp], wins[sp], f, axis)
        if len(pk) != size:
            continue
        if max(abs(v - round(v)) for v in pk) > TOL_ONGRID:
            continue
        s = sorted({int(round(v)) for v in pk})
        if len(s) == size:
            return s
    return None


def _complete(S, parts, T=None):
    """(parts + complement, pair) if `parts` completes into a uniform bijection S -> T, else None.

    Rule 18 (the map must COVER the block and be a BIJECTION), rule 3's complement, and 3a's "every
    part carries ONE uniform displacement, the complement included".  Factored out so `repair` can
    ask the question of a candidate instead of only of the measurement.

    `T` IS THE DESTINATION TONE SET AND IT IS NOT ALWAYS `S`.  This defaulted to `S` until session
    23's whole-movie run, and that single assumption made every whole-block RELOCATION structurally
    inexpressible: the batch could only ever be a permutation of the tones it started on, so
    `X rows 1:9 -> 10:18`, `Z0/Z1 cols 13:24 -> 1:12` and the f304 `+12` shift were not written
    wrongly, they were dropped -- 24 of the hand book's 53 movement events were missing and the
    render left rows 19:27 empty at f300 while the movie has X0/X1 standing on them.  The class of
    movement that vanished was TRANSPORT, which is most of a cycle; the gate permutations, which
    are same-site and so satisfied T == S by accident, all came through.  A batch is a bijection
    from the tones the block occupies at its FIRST frame onto the tones it occupies at its LAST.
    """
    T = S if T is None else T
    if len(T) != len(S):
        return None
    Sset, Tset = set(S), set(T)
    used_s, used_d = set(), set()
    for s_, d_ in parts:
        ss, dd = set(s_), set(d_)
        if len(ss) != len(s_) or len(dd) != len(d_):
            return None
        if ss & used_s or dd & used_d or not ss <= Sset or not dd <= Tset:
            return None
        used_s |= ss
        used_d |= dd
    rest_s = [t for t in S if t not in used_s]
    rest_d = [t for t in T if t not in used_d]
    if len(rest_s) != len(rest_d):
        return None
    allp = [(list(s_), list(d_)) for s_, d_ in parts]
    if rest_s:
        allp.append((sorted(rest_s), sorted(rest_d)))
    pair = {}
    for s_, d_ in allp:
        for u, v in zip(s_, d_):
            pair[u] = v
    if sorted(pair) != sorted(S) or sorted(pair.values()) != sorted(T):
        return None
    if not all(len({v - u for u, v in zip(s_, d_)}) == 1 for s_, d_ in allp if s_):
        return None
    return allp, pair


def repair(S, base, shift=REPAIR_SHIFT, T=None):
    """LET THE BIJECTION DECIDE THE INTEGER THE ROUNDING COULD NOT.

    Rule 42 rounds a patch's source slots to the nearest lattice slots, on the premise that "at a
    movement boundary the displacement from the lattice is small".  That premise fails wherever the
    first frame a patch is VISIBLE is not the first frame of its movement -- and the patch route
    skips gate frames, so for every batch that starts immediately after a pulse the first visible
    frame is already most of a site into travel.  Measured on c540's X0 cols f002-f008: the moving
    group is at 7.18 8.15 9.16 10.17 11.17 on f002 and arrives exactly on 1 2 3 4 5 by f008, so the
    nearest-slot rule reads `7:11 -> 1:5`, D = -6, where the movie and the hand book both do
    `8:12 -> 1:5`, D = -7.  The destination is sound (it is an arrival, on its tones to 0.05 site);
    it is the SOURCE that is a site out.

    Rule 18 supplies what the pixels at that frame cannot: the batch is a bijection of the block's
    tone set with a uniform displacement per part.  For X0 that is decisive -- with `8:12 -> 1:5`
    the complement is `1:7 -> 6:12`, a clean +5, and with `7:11 -> 1:5` the leftovers pair up as
    `1->6 ... 6->11, 12->12`, which is not one displacement and no crossed pair can perform it.

    So each patch is allowed to have its source and its destination shifted by at most `shift`
    sites, every combination is tested, and a repair is ACCEPTED ONLY IF THE CHEAPEST COMBINATION
    THAT WORKS IS UNIQUE.  Two different maps that both complete is a measurement that does not
    determine the movement, and inventing one of them is exactly what this skill spends its rules
    forbidding; those are refused and reported.

    THIS IS ONLY EVER REACHED WHEN THE MEASUREMENT ITSELF DOES NOT COMPLETE -- cost 0 is the
    unshifted reading -- so no batch that already worked can change.  c540's segment 6, whose
    twenty-one batches all complete as measured, is bit-for-bit unaffected.
    """
    opts = []
    for s_, d_ in base:
        # A SHIFT MAY NOT CHANGE WHAT WAS MEASURED, ONLY WHICH SLOT IT LANDED ON.  The patch was
        # accepted because it TRAVELLED at least MIN_TRAVEL in a definite direction, so a candidate
        # that cancels that travel, or reverses it, contradicts the measurement it is repairing.
        # Without this the bijection is satisfied by the map that moves nothing: run on c540's
        # segment 6 it added three movements of the form `22:23 -> 22:23 | 13:21,24 -> 13:21,24`,
        # every tone onto itself, scored 0.28 site and written as a movement.  An identity part is
        # legitimate in the COMPLEMENT -- tones the batch simply does not move, as in c540's
        # `26->27 | 27->26 | 19:25->19:25` -- which is why the bar is on the measured parts only.
        D0 = d_[0] - s_[0]
        o = []
        for ds in range(-shift, shift + 1):
            for dd in range(-shift, shift + 1):
                D1 = D0 + dd - ds
                if D1 == 0 or (D1 > 0) != (D0 > 0):
                    continue
                o.append((abs(ds) + abs(dd), [u + ds for u in s_], [v + dd for v in d_]))
        if not o:
            return None, 0, None
        opts.append(sorted(o))
    best, sols = None, {}
    for combo in itertools.product(*opts):
        cost = sum(c for c, _, _ in combo)
        if best is not None and cost > best:
            continue
        got = _complete(S, [(s_, d_) for _, s_, d_ in combo], T)
        if got is None:
            continue
        allp, pair = got
        if all(v == u for u, v in pair.items()):
            continue                      # the batch moves nothing: not a movement
        if best is None or cost < best:
            best, sols = cost, {}
        sols[tuple(sorted(pair.items()))] = allp
    if best is None:
        return None, 0, None
    if len(sols) != 1:
        return None, len(sols), best
    return list(sols.values())[0], 1, best


def remeasure(M, tr, mv, a, b):
    """re-read one patch's map over the WHOLE batch window [a, b], not over its own run.

    A colour can resolve for only part of a batch -- c540's Z0 on comb {17,23} is read over
    f235-237 alone and reports `3:8 -> 4:9`, a +1 step, where the movie does `1:6 -> 4:9`, a +3.
    The run was not wrong about rigidity; it was short, and a short window sees a fraction of the
    travel.  Once the batch's own window is known from the comb signature, every patch in it is
    re-read between the first and last frames of THAT window on which it fully resolves.
    """
    track = tr.get((mv["sp"], tuple(mv["colour_raw"]))) if mv.get("colour_raw") else None
    if track is None:
        return mv
    ax = 0 if mv["axis"] == "cols" else 1
    run = [f for f in sorted(track) if a <= f <= b]
    if len(run) < 2:
        return mv
    got = movement_from_run(M, mv["sp"], mv["colour_raw"], track, run, 1 - ax,
                            tuple(mv["comb"]))
    if got is None:
        return mv
    got["colours"] = mv.get("colours", [])
    got["colour_raw"] = mv["colour_raw"]
    return got


def batches(M, wins, moves, tr=None, verbose=False, frames=None, sizes=None, tone_frames=None,
            tone_wins=None, tone_lookup=None):
    """group patch movements into BATCHES and complete each one into a bijection.

    A batch is one AOM configuration: one species, one axis, one comb on the static axis, one
    overlapping stretch of frames.  Two jobs here, and both are deductions rather than searches:

    SELECTION.  A colour can be read over a run that covers only part of a movement, giving a
    fragment -- c540's `Z0 1:5 -> 5:9` also produces a spurious `4:8 -> 5:9` measured over three
    frames in the middle of it.  Two patches of one batch cannot claim the same source, so where
    they collide the better-evidenced one wins: more members first, then a longer window, then a
    smaller rigidity residual.

    COMPLETION (rule 3's complement rule, and it is exact).  A patch first seen at mid-flight has a
    wrong source slot -- c540's X1 wrap marker is first resolved at row 24.10 when it started at
    27, so the nearest-slot rule reads `24 -> 19` where the movie does `27 -> 19`.  But the batch as
    a whole is a bijection of the block's tones, so once the well-measured patches are placed the
    leftovers are FORCED: sources and destinations left over, paired in increasing order, because a
    rectangle's tone map is strictly increasing.  On X1's {13,19} batch the `19:26 -> 20:27` patch
    leaves source 27 and destination 19, which is the answer, with no reliance on the frame the
    wrap marker happened to become visible on.
    """
    key = lambda m: (m["sp"], m["axis"], tuple(m["comb"]))
    groups = collections.defaultdict(list)
    for mv in moves:
        groups[key(mv)].append(mv)
    out = []
    for k, g in sorted(groups.items()):
        g.sort(key=lambda m: m["f0"])
        clusters = []
        for mv in g:
            for c in clusters:
                if min(c[-1]["f1"], mv["f1"]) - max(c[-1]["f0"], mv["f0"]) >= 0:
                    c.append(mv)
                    break
            else:
                clusters.append([mv])
        for c in clusters:
            sp, axis = c[0]["sp"], c[0]["axis"]
            ax = 0 if axis == "cols" else 1
            a = min(m["f0"] for m in c)
            b = max(m["f1"] for m in c)
            if tr is not None:
                c = [remeasure(M, tr, m, a, b) for m in c]
            keep, used_s, used_d = [], set(), set()
            for mv in sorted(c, key=lambda m: (-m["n"], -(m["f1"] - m["f0"]),
                                               m["rigid_residual"])):
                if set(mv["src"]) & used_s or set(mv["dst"]) & used_d:
                    continue
                keep.append(mv)
                used_s |= set(mv["src"])
                used_d |= set(mv["dst"])
            # THE TONE SET MUST BE READ AT A FRAME WHERE THE BLOCK IS ON GRID -- ALWAYS PREFER
            # `block_tone_set`, and a COUNT TEST IS NOT ENOUGH.  This used to consult it only when
            # the count was wrong, and that missed the case that actually matters: at c540's f316,
            # Z0's twelve-column profile reads
            #     12.82 13.82 14.73 ... 21.71 22.34 23.38
            # which is TWELVE peaks for a twelve-column block -- the count is right -- and rounds to
            # {13..22, 22, 23}: column 22 twice and column 24 missing, because the block is already
            # in flight on the segment's first non-pulse frame.  The size check passed while the
            # SET was wrong, completion against it could not succeed, and `Z0/Z1 cols 13:24 -> 1:12`
            # at f315-328 -- the movement the user saw as "a huge mistake at 9.70" -- was reported
            # undetermined even though both of its parts had been measured correctly.
            #
            # `tone_frames` must include the GATE frames.  Rule 15: a configuration that exists only
            # on a pulse frame is still a configuration, and rule 9 says nothing moves during a
            # pulse, so the pulse bounding a segment is the most reliable rest in it.  Here the true
            # source exists ONLY on f314/f315 and the true destination only on f328/f329; passing
            # the segment's non-pulse frames alone made rule 15 unreachable.
            tf = tone_frames or frames
            # AND THE WINDOW MUST INCLUDE THE PULSE FRAMES TOO (rule 35).  `species_windows` boxes a
            # species over the segment's NON-PULSE frames, so a block that stands on its source
            # configuration only while a pulse is on is clipped by its own window: at f314-315 Z0
            # occupies cols 13:24, but its non-pulse box is 1.00..23.93 and column 24 falls outside
            # it.  Reading the tone set through that window returns ELEVEN tones, and the batch then
            # completes as `13:22 -> 3:12 | 23 -> 2` -- an eleven-tone map for a twelve-column block,
            # which is wrong in exactly the way rule 18 exists to catch.  `tone_wins` is the
            # skip_gate=False box, used for these reads and nothing else, the same division of
            # labour `sb_full.solve_segment` already makes with `edge_wins`.
            tw = tone_wins or wins
            want = (sizes or {}).get(sp)
            # FIRST CHOICE: THE REST RECORD THE DEFAULT ROUTE ALREADY BUILT.  `sb_build.settled`
            # solves the pulse-frame problem properly -- rule 9's deduction from a neighbouring
            # frame, and `rect_on_pulse` reading the OUTLINE colours where the tint has spoiled the
            # fill -- and none of that is reachable from a fill mask here, because a pulse frame's
            # fill comes back empty or wrong and `block_tone_set` simply finds nothing.  c540's Z0
            # is exactly that case: it stands on cols 13:24 ONLY on the gate frames f314-315, so
            # every fill-based read of its source is short and the batch completed as an eleven-tone
            # map for a twelve-column block.  Rest detection is the default route -- where it knows
            # the configuration, that is the answer, and this measurement should not re-derive it.
            look = tone_lookup(sp, ax, a, b) if tone_lookup else None
            # (a, a) not (a, b): `block_tone_set` prefers frames INSIDE the window it is given, and
            # every frame inside a batch is by definition mid-movement.  Anchoring on the batch's
            # first frame makes it search outward from there, which reaches the pulse before it.
            S = (look[0] if look else None) \
                or (block_tone_set(M, tw, sp, ax, a, a, want[ax], tf) if want else None) \
                or block_tones(M, tw, sp, a, ax)
            T = (look[1] if look else None) \
                or (block_tone_set(M, tw, sp, ax, b, b, want[ax], tf) if want else None) \
                or block_tones(M, tw, sp, b, ax)
            if len(T) != len(S):
                T = S

            base = [(list(m["src"]), list(m["dst"])) for m in keep]
            # EVERY PART MUST CARRY ONE UNIFORM DISPLACEMENT, the complement included (3a).  That
            # is all a crossed AOD pair can do, so a part that does not is not a movement -- and it
            # is the filter that removes the three artefacts segment 6 produces on its cols axis,
            # where a colour that marks the COMB ITSELF drifts with the comb and the leftover tones
            # pair up into a map with no common displacement (`13:22 -> 13:20,23:24`).
            got = _complete(S, base, T)
            repaired, amb = False, 0
            if got is None:
                fixed, n, cost = repair(S, base, T=T)
                if fixed is not None:
                    got = _complete(S, fixed[:len(base)], T)
                    repaired = True
                else:
                    amb = n
            ok = got is not None
            parts = got[0] if ok else base
            pair = got[1] if ok else {}
            filled = None
            if ok and len(parts) > len(base):
                filled = dict(sp=sp, axis=axis, f0=a, f1=b,
                              src=list(parts[-1][0]), dst=list(parts[-1][1]),
                              D=None, comb=list(k[2]), n=len(parts[-1][0]),
                              colour=None, colours=[], rigid_residual=None,
                              rigid_worst=None, travel=None,
                              how="complement (rule 3): the tones the measured patches leave over, "
                                  "paired in increasing order")
            out.append(dict(sp=sp, axis=axis, f0=a, f1=b, comb=list(k[2]),
                            block=S, block_dst=T, relocation=(sorted(T) != sorted(S)),
                            parts=parts, pair=pair, complete=ok,
                            patches=keep, filled=filled, repaired=repaired, ambiguous=amb,
                            measured=base))
            if verbose:
                print("   batch %-3s %-4s f%03d-%03d comb %-12s %s%s%s"
                      % (sp, axis, a, b, comb(list(k[2])),
                         " | ".join("%s->%s" % (comb(s_), comb(d_)) for s_, d_ in parts),
                         "   [slot repaired by the bijection]" if repaired else "",
                         "" if ok else "   *** NOT A BIJECTION OF %s%s"
                         % (comb(S), " (%d equally cheap repairs -- refused)" % amb if amb else "")))
    return out


def describe(mv):
    return ("%-3s %-4s f%03d-%03d  %s -> %s  (D=%+d, n=%d) on %s %s  rigid %.3f"
            % (mv["sp"], mv["axis"], mv["f0"], mv["f1"], comb(mv["src"]), comb(mv["dst"]),
               mv["D"], mv["n"], "rows" if mv["axis"] == "cols" else "cols", comb(mv["comb"]),
               mv["rigid_residual"]))


def main():
    import argparse, json, os, sys
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--f0", type=int, required=True)
    ap.add_argument("--f1", type=int, required=True)
    ap.add_argument("--out", default="")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()
    M = sb_read.Movie(a.calib, a.frames)
    frames = [f for f in range(a.f0, a.f1 + 1) if f not in M.gate]
    wins = sb_compose.species_windows(M, a.f0, a.f1)
    outs = sb_read.discover_outlines(M, frames[:40], (0.4, M.K["data_cols"] + 0.6,
                                                      0.4, M.K["data_rows"] + 0.6))
    print("frames f%03d..f%03d (%d non-pulse)" % (a.f0, a.f1, len(frames)))
    print("%d outline colours: %s" % (len(outs), ", ".join("rgb(%.0f,%.0f,%.0f)" % c for c in outs)))
    mvs, dropped, tr = patch_movements(M, wins, outs, frames, verbose=a.verbose)
    print("\n%d patch movements:" % len(mvs))
    for mv in mvs:
        print("   " + describe(mv))
    bs = batches(M, wins, mvs, tr, verbose=False)
    print("\n%d batches (one AOM configuration each):" % len(bs))
    for b in bs:
        print("   %-3s %-4s f%03d-%03d  comb %-12s %s%s"
              % (b["sp"], b["axis"], b["f0"], b["f1"], comb(b["comb"]),
                 " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in b["parts"]),
                 "" if b["complete"] else "   *** incomplete on block %s" % comb(b["block"])))
    if a.out:
        json.dump(dict(patches=mvs, batches=[{k: v for k, v in b.items()
                                              if k not in ("patches", "filled")} for b in bs]),
                  open(a.out, "w"), indent=1, default=str)
        print("\nwrote %s" % a.out)


if __name__ == "__main__":
    import os, sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    main()
