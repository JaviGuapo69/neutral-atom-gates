"""rotscan.py -- for a window in which a block's tones T0..T1 rotate cyclically, measure EVERY rotation
amount on the movie's own peaks (optionally restricted to a sub-comb of lines on the other axis) and print
them ranked, so the right one is chosen by measurement and not by eye.

    python rotscan.py SP AXIS F0 F1 T0 T1 LO HI [sub tones, comma separated]
      F0 F1   frames of the transition; LO HI the timing bounds (pulse-free interval)
"""
import os, sys
sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_build, sb_compose
from sb_read import Movie

sp, axis, f0, f1 = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
t0, t1 = int(sys.argv[5]), int(sys.argv[6])
lo, hi = float(sys.argv[7]), float(sys.argv[8])
sub = [int(v) for v in sys.argv[9].split(",")] if len(sys.argv) > 9 else None
M = Movie("calib.json")
wins = sb_compose.species_windows(M, 0, M.nf - 1)
frames = list(range(f0, f1 + 1))
P = sb_build.SubPeaks(M, wins, (1 - axis, sub), frames) if sub else sb_compose.Peaks(M, wins, f0, f1)
src = list(range(t0, t1 + 1))
n = len(src)
out = []
for k in range(1, n):
    dst = [t0 + ((i - t0 + k) % n) for i in src]
    best = sb_build.fit_timing(P, M, sp, axis, src, dst, frames, lo, hi)
    if best is None:
        continue
    _, a, b = best
    mean, worst, nn = sb_compose.verify(P, sp, axis, src, dst, a, b, frames, M)
    seq = sb_compose.progress_per_frame(P, sp, axis, src, dst, frames, M)
    free = [s[2] for s in seq if 0.02 < s[1] < 0.98]
    out.append(((sum(free) / len(free)) if free else 9.9, mean, worst, k, a, b, len(free)))
out.sort()
print("%s %s f%03d-%03d tones %d:%d%s" % (sp, "cols" if axis == 0 else "rows", f0, f1, t0, t1,
                                          (" sub %s" % sub) if sub else ""))
for fr, mean, worst, k, a, b, nf in out:
    lab = "%d:%d->%d:%d | %d:%d->%d:%d" % (t0, t1 - k, t0 + k, t1, t1 - k + 1, t1, t0, t0 + k - 1)
    print("   k=%+3d  FREE %.4f  mean %.4f worst %.3f  f%.2f-%.2f (%d fr)   %s" % (k, fr, mean, worst, a, b, nf, lab))
