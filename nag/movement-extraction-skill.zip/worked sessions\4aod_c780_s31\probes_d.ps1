# probes batch D -- segments 9-11 (f298-383)
$env:PYTHONIOENCODING = "utf-8"
$SB = "..\.claude\skills\se-cycle-blocks\tools"
function P($name, $sp, $ax, $f0, $f1, $win) {
  cmd /c "python $SB\sb_probe.py --calib calib.json --peaks --sp $sp --axis $ax --f0 $f0 --f1 $f1 --win=$win > logs\probe_$name.txt 2>&1"
  Write-Output "done $name $(Get-Date -Format HH:mm:ss)"
}
P "Z0_rows_298_320"  Z0 1 298 320 "13.4,26.6,0.4,12.6"
P "Z1_rows_298_320"  Z1 1 298 320 "13.4,26.6,12.4,24.6"
P "X1_rows_305_347"  X1 1 305 347 "0.4,13.6,24.4,36.6"
P "Z1_cols_331_343"  Z1 0 331 343 "13.4,26.6,12.4,24.6"
P "Z0_rows_332_349"  Z0 1 332 349 "13.4,26.6,0.4,12.6"
P "Z1_rows_343_350"  Z1 1 343 350 "13.4,26.6,12.4,24.6"
P "Z0_cols_348_378"  Z0 0 348 378 "0.4,26.6,0.4,12.6"
P "Z0_rows_371_383"  Z0 1 371 383 "0.4,13.6,24.4,36.6"
