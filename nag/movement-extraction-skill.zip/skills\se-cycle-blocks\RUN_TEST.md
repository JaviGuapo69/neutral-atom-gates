# Test run: c150 → movements, with the appearance-triple method

Prepared end of session 11 for a fresh session. Everything here has been executed at least once;
the expected output below is real, not predicted.

> ## ⚠ SESSION 15 — THE EXPECTED WHOLE-MOVIE NUMBERS DEPEND ON THE PULSE BOUND
>
> Rule 9's lower bound was corrected in session 15: a move may start on the **first** frame of a
> pulse run, not the last (`sb_rigid.PULSE_BOUND_FIRST = True`, the default). **This changes
> TIMINGS on both c150 tests, so neither is bit-for-bit comparable across the change.**
>
> * **STRUCTURE is the regression test now, not the timings.** Both tests must still give exactly
>   what they always gave, and they do:
>   frames 0–49 → **8 moves, the same eight maps, 16 rows, 4 AOM groups, 0 undetermined,
>   11 transitions**; the whole movie → **69 transitions, 55 moves, 0 undetermined, 102 rows,
>   4 AOM groups**.
>   **SESSION 22: with `--events` the whole-movie transition count reads 73, not 69** — 69 solved
>   plus the **4 readout/load bridges held back and named**, which `settled` used to absorb and
>   never enumerate. Moves, rows and AOM groups are unchanged, and `sb_audit` prints AUDIT CLEAN
>   with `4 holes (0 reported undetermined, 4 held-back readout/load, 0 SILENT)`. Verified
>   2026-09-14: 55/55 moves identical to `reg_c150\moves_full.json`.
> * **To compare against a pre-session-15 log, run with `--pulse-bound last` — then it IS
>   bit-for-bit.** That is the correct way to regression-test a change to anything else.
> * **The timing change is a net improvement on c150 but NOT a uniform one**, and you will see
>   individual moves get worse. Measured over the whole movie: 22 of 50 comparable moves improve
>   and 28 worsen, but the improvements are large and the regressions small, so the mean of the
>   per-move errors goes **0.0620 → 0.0558** and moves over the 0.10 guideline go **10 → 6**.
>   The biggest winners are the moves that actually sat on the bound (`X0 cols f224-239`
>   0.1599 → 0.0451, `X1 cols f224-239` 0.1433 → 0.0424); the biggest loser is
>   `X1+X0 rows f030-046`, 0.0764 → 0.1312.
>   **On the frames 0–49 window specifically the balance is unfavourable** — 3 moves better,
>   4 worse, 1 unchanged, and over-guideline 2 → 5 — because that window is short and dominated by
>   moves that are chained to each other rather than to a pulse. Do not read that window alone as
>   evidence either way.
> * **c150 has NOT been re-scored end to end under the new bound** (its `extra.json` was not kept,
>   so the readout/load rows would have to be reconstructed from the delivered workbook first).
>   The end-to-end evidence for the correction is c300's: **0.0618 → 0.0534 site**.
>
> **Session 15 also added three checks that are part of the suite now** — run them on whatever you
> transcribe: `sb_audit.py` (must print AUDIT CLEAN), `sb_mapcheck.py` (no wrong maps),
> `sb_watch.py` (account for every run of ≥3 frames).
>
> ## ⚠ SESSION 14 — THE FRAMES 0–49 TEST IS NOT SUFFICIENT ON ITS OWN
>
> **It is a SINGLE `sb_build` call over one frame range, so it can never exercise anything that
> acts ACROSS a segment boundary** — and four of session 14's nine defects did exactly that. It
> stayed bit-for-bit identical through all nine while the c200 sheet was missing real moves.
>
> **After ANY change, run BOTH:**
>
> 1. **frames 0–49** (cheap, ~1 min) — must be bit-for-bit identical;
> 2. **c150's WHOLE movie** through `sb_full` (~10 min, and it parallelises with whatever else you
>    are running) — must give **69 transitions, 55 moves, 0 undetermined, 102 schedule rows**
>    (4 AOM groups before the hand-measured rows; 5 with them).
>
> Session 14 changed nine things and both tests held throughout, which is the only reason the
> changes could be trusted. A note on comparing: session 14's rule-32 fix legitimately shifts the
> frame labels quoted inside `NOT RIGID` **note text** by one frame, because the read window starts
> one frame later. Diff with note lines excluded, and require every move, map, timing, comb and
> count to be identical.
>
> ## ⚠ SESSION 13 — WHAT THIS FILE IS FOR NOW
>
> **c150 is finished.** This file is no longer a route to a deliverable; it is the **regression
> suite** for the tools. It holds two tests:
>
> | test | where |
> |---|---|
> | **frames 0–49** — 11 transitions, 8 moves, 16 rows, 4 AOM groups, 0 undetermined, 0.046 site | the box below. **Cheap. Run it after EVERY change to any tool** — but see the session-14 box above: it is necessary, not sufficient |
> | **the whole movie** — 69 transitions, 55 moves, 110 rows, 0 undetermined, 0.047 site, and **4 crossed pairs driven** (`allocate_aom`'s peak over all rows reads 5 — the extra index goes to the X readout `unload`, which drives no AOM tone columns) | "Then the whole movie", below. ~20 minutes. **This is the one that covers the multi-segment path** |
>
> **To transcribe a DIFFERENT movie, work from `SKILL.md`'s "Procedure — A NEW MOVIE, END TO END".**
> Do not follow the c150-specific steps here: the frame paths, the segment bounds and every measured
> number in this file are c150's.
>
> ## ⚠ SESSION 12: START WITH `sb_build.py`, NOT WITH THE THREE-STEP ROUTE BELOW
>
> ```powershell
> python $SB\sb_build.py --calib calib.json --f0 0 --f1 49 --work . --xlsx c150_first_0p70.xlsx
> ```
>
> **Expected, and it is the acceptance test for any change to these tools:**
>
> ```
> 4 relocations + 7 permutation windows = 11 transitions to account for
> == 8 moves
>   Z0     cols f002-008  1,3,5 -> 2,4,6 | 2,4,6 -> 1,3,5   t 0.0143-0.1002  comb 11:15  mean 0.0871
>   X1+X0  rows f002-016  1:3   -> 8:10  | 4:5   -> 6:7     t 0.0143-0.2429  comb 1:12   mean 0.1638
>   Z0     rows f008-016  11:12 -> 14:15 | 13:15 -> 11:13   t 0.1002-0.2429  comb 1:6    mean 0.1068
>   X1     cols f019-030  7:9   -> 10:12 | 10:12 -> 7:9     t 0.2573-0.4163  comb 6:10   mean 0.0530
>   X0+Z0  cols f019-030  1:3   -> 4:6   | 4:6   -> 1:3     t 0.2573-0.4163  comb 6:15   mean 0.0565
>   X1+X0  rows f030-046  6     -> 5     | 7:10  -> 1:4     t 0.4163-0.6562  comb 1:12   mean 0.0764
>   Z0     cols f030-037  1,3,5 -> 2,4,6 | 2,4,6 -> 1,3,5   t 0.4163-0.5158  comb 11:15  mean 0.0260
>   Z0     rows f037-047  11:14 -> 12:15 | 15    -> 11      t 0.5158-0.6863  comb 1:6    mean 0.0630
> 16 schedule rows, AOM groups used 4, peak concurrent 4
>   8 moves -> 16 schedule rows, 4 AOM groups (peak 4), 3 gates, 0 undetermined
> ```
>
> then `se_sim` (validation clean, census never short of 120), `render.ps1 -MatchCalib`
> (`validation log entries: 0`) and the profile score (**0.046 site**, ~3800 comparisons, 14 of 44
> frames within 0.25 — after removing the registration bias of rule 17; raw is 0.095).
>
> **The two "known gaps" listed at the bottom of this file are FIXED** — `sb_build` reads
> configurations on pulse frames from the outline colours (rule 15), which is what recovers Z0's
> f002-008 column swap and its f037-047 cyclic row shift. That is why the transition count is 11
> here and 9 from `sb_compose --transitions`.
>
> The three-step route below still works and is worth running to *inspect* one window's appearance
> classes and their rigidity residuals. It is no longer how a workbook gets built.

---

## The rule being tested

> Atoms sharing the triple **(shape, fill colour, outline colour)** and moving at a given frame
> move **as one rigid body**. In general only the triple moves rigidly.
>
> Two such groups may happen to perform the **same** motion, in which case one AOM can drive both —
> and when that is possible **it must be done**, to keep the structure as simple as possible.

Implemented in `tools/sb_rigid.py`. Three steps: **classify** by the triple, **measure** each
class's single displacement, **merge** classes with identical motion (mandatory).

---

## Setup

Frames and calibration already exist — do not re-extract, it is the slow part:

```
..\..\..\..\SE_cycle_ARCHIVE_2026-09-08\run_c150\frames\      384 PNGs
..\..\..\..\SE_cycle_ARCHIVE_2026-09-08\run_c150\calib.json
```

Copy `calib.json` somewhere writable and repoint its `frames_dir` at that `frames` directory
(`SB_COMPOSE_BUG_calib.json` in the project root is already such a copy — check its path).

```powershell
$SB = "<project>\.claude\skills\se-cycle-blocks\tools"
mkdir work; cd work
# calib.json here, frames_dir pointing at the archive
```

## Step 1 — enumerate the transitions (trusted; run this first)

```powershell
python $SB\sb_compose.py --calib calib.json --f0 0 --f1 49 --transitions --work .
```

Expected: `4 relocations + 5 permutation windows = 9 transitions to account for`, and
`Z1 : 1 settled configuration` (Z1 is genuinely frozen over frames 0–49 — it is the noise-floor
control, 0.008 site from its tones on every frame).

For the whole movie use `--f0 0 --f1 383`; expected **29 relocations + 39 permutation windows = 68**.

## Step 2 — read the movements

```powershell
python $SB\sb_rigid.py --calib calib.json --f0 0 --f1 49 --work .
```

It prints, per transition, every appearance class it found with that class's displacement and the
**rigidity residual** (the spread of member displacements — the rule's testable prediction), then
the mandatory merge, then any notes.

### Expected output for frames 0–49, verified against `c150_first_0p70ms_blocks.xlsx`

```
discovered outline colours (candidate appearance classes):
   rgb(247,187, 69)   <- carries one sub-block
   rgb(152,123,185)   <- carries the other (the session-9 mauve)
   rgb(254,249,185)   <- tracks the gold; same outline, anti-aliased edge
   rgb(227,139, 99)   rgb(103,120,200)   rgb(186,132, 90)   <- blends; rejected as NOT RIGID

X0/X1 relocation f002-016
   CLASS rgb(247,187,70)  rows 1:3  -> 8:10   D=+7  rigid 0.036 / 0.048
   CLASS rgb(152,123,185) rows 4:5  -> 6:7    D=+2  rigid 0.139 / 0.149
   -> AOM X0+X1 rows 1:3 -> 8:10, other x 1:12      (2 classes merged)
   -> AOM X0+X1 rows 4:5 -> 6:7,  other x 1:12      (2 classes merged)

Z0 permutation f008-019
   CLASS rgb(247,187,70)  rows 11:12 -> 14:15  D=+3  rigid 0.088
   CLASS rgb(152,123,185) rows 13:15 -> 11:13  D=-2  rigid 0.105

X0/X1/Z0 permutation f019-028
   X0: gold  cols 1:3   -> 4:6    D=+3       mauve cols 4:6   -> 1:3    D=-3
   X1: gold  cols 7:9   -> 10:12  D=+3       mauve cols 10:12 -> 7:9    D=-3
   Z0: gold  cols 4:6   -> 1:3    D=-3       mauve cols 1:3   -> 4:6    D=+3

X0/X1 relocation f030-044
   CLASS rgb(247,187,70)  rows 7:10 -> 1:4   D=-6  rigid 0.032 / 0.049
   CLASS rgb(152,123,185) row  6    -> 5     D=-1  rigid 0.000

Z0 permutation f030-035
   CLASS rgb(247,187,70)  cols 2,4,6 -> 1,3,5  D=-1  rigid 0.034
   CLASS rgb(152,123,185) cols 1,3,5 -> 2,4,6  D=+1  rigid 0.036

12 AOM-level rows over 5 move events
```

Every class is rigid to **0.00–0.15 site**, which is the rule's prediction holding. Compare against
the delivered answer: `c150_first_0p70ms_blocks.xlsx` (8 moves, 16 rows, 4 AOM groups) and
`c150_0p70ms_rebuild_score.txt` (0.0467 site).

---

## What to look at, in order

1. **Rigidity residuals.** Every accepted class should be well under 0.15 site. A large one means
   the triple was read wrong or two classes share a colour — the rule failing is the most
   informative outcome you could get.
2. **`NOT RIGID` notes.** On c150 these are blend colours at marker boundaries
   (`rgb(227,139,99)` between pink and gold, `rgb(103,120,200)` between blue and mauve) and the
   rejection is correct. If a *pure* palette colour is rejected, that is a real finding.
3. **`no appearance class resolved a rigid move here` notes.** These are the gaps. On frames 0–49
   expect them for Z0's f002-006 column swap (the seed→first-rest window, see Known gaps) and
   Z0's f036-047 cyclic row shift.
4. **`TIE` notes.** Where three fill colours share one displacement, any two may ride one crossed
   pair but not all three, so more than one grouping is equally minimal. c150 f019-028 is exactly
   this: X0+X1 and X0+Z0 both give 4 groups. The hand-built sheet chose X0+Z0 (`y 6:15`). **The
   pixels do not decide this** — do not let the tool present its choice as measured.

## Known gaps — expected, not bugs to be surprised by

* **FIXED IN SESSION 12 — the seed → first-rest window, and any move that ends AT a pulse.**
  `sb_compose --transitions` needs a settled configuration on both sides, and at frames 0-1 the
  opening pulse tint corrupts the *fill* mask for Z0/Z1 (it reads X0/X1 correctly and mangles the
  blue and green), so Z0's `2,4,6 ↔ 1,3,5` swap over f002-008 is missed — as is its f037-047 cyclic
  row shift, which arrives exactly at the f048 pulse and so has no pulse-free rest frame after it.
  **`sb_build.py` reads those configurations from the OUTLINE colours on the pulse frame** (rule
  15), which are not shifted the way the fills are, and both moves come back automatically. This is
  why `sb_build` reports 11 transitions on frames 0-49 where `sb_compose` reports 9. **Expect the
  same correction movie-wide: 68 is a floor, not the count.**
* **Readouts and loads are not automated.** A readout has no outline and no solid fill — the block
  desaturates and descends off panel. Method and the measured c150 numbers are in `SKILL.md` §7;
  feed them to `sb_emit.emit(..., extra=<json>)`.
* **`sb_compose.py --solve` is the OLD candidate-search path and picks wrong partitions.** Use
  `sb_rigid.py` instead. See `SB_COMPOSE_OPEN_BUG.md`. `--transitions` from `sb_compose` is fine.

## Then the whole movie — DONE in session 13, and this is its acceptance test

`sb_full.py` does the whole thing — it solves each pulse-free interval with its own tight windows,
merges, and colours the AOMs once. **Never run `sb_build.py` over all 384 frames**: its windows go
panel-wide and overlap, and the shared outline mask then attributes one species' outline to another
(SKILL.md §1a).

```powershell
python $SB\sb_blocks.py --calib calib.json --out blocks.json        # rule 22, always first
python $SB\sb_full.py --calib calib.json --blocks blocks.json --work . `
                      --xlsx c150_full.xlsx --extra extra.json --events events.json
```

**`--events events.json` is part of the test, not an optional extra.** c150's copy is
`reg_c150\events.json` (Z0/Z1 f121-167, X0/X1 f329-383) and every c150 regression run since
session 16 has used it. Without it the readout→load bridges are fitted as if they were moves and
the counts below do not hold — `sb_full` now prints a `READOUT signature ... NOT named in
--events` block at the end of a run that is missing them. See SKILL.md Procedure step 3a.

The 12 segments it derives from c150's pulse runs are
`(0,18) (17,49) (48,88) (87,107) (106,122) (121,167) (166,191) (190,223) (222,265) (264,298)
(297,329) (329,383)`.

**Expected, and it is the whole-movie acceptance test:**

```
69 transitions, ALL accounted for -- 0 undetermined
55 measured moves -> 102 schedule rows, + 8 hand-measured readout / load rows = 110
4 crossed pairs driven (Combined populates AOM1..AOM4); allocate_aom's peak over all rows
        reads 5, the extra index going to the X readout unload, which drives no AOM columns
block sizes 6x5 for all four species
se_sim: validation clean, census never short of 120 atoms (39 frames carry a surplus, max 180 --
        a readout block still descending while its replacement exists; expected)
render.ps1 -MatchCalib: validation log entries 0
score: 0.0472 site mean, 28457 comparisons, 360 non-pulse frames, 143 frames all within 0.25
```

Per-segment move counts, for checking a partial run: 3, 5, 8, 3, 2, 3, 3, 5, 7, 6, 6, 3.

Ten moves land at 0.10–0.16 site. Each is a crossing or a block leaving the panel with one column
left to measure; the full per-move evidence is in `c150_full_blocks_report.txt`.

**Segments 0+1 must reproduce the frames 0–49 answer exactly** (3 + 5 = 8 moves, same maps, same
timings). That is the cheap check that segmenting has not changed anything.

## Scoring a rebuild

Render through the **untouched** `render.ps1` with `-MatchCalib`, then compare **profile peaks**,
each side masked with **its own palette** (`render.ps1` uses its own fixed colours; c150's Z0
differs by 47 RGB between movie and render, more than the 34 RGB mask tolerance).

**Do not use `se_compare.py`** — its extractor suppresses detections closer than 0.62 pitch, which
deletes the crossing frames on both sides and flatters the result.
