# Session 28 (2026-09-16) — c540 CLOSED by hand correction

**Written for: the user (Javier) and the next session.** Follows `SESSION_27_LAST_RESORT.md`. The
skill was not touched. The session-27 book was corrected by hand in the two places session 27 left
open plus one more the user found on the first corrected video (f140-144); the user confirmed all
three against the movie, and c540 is declared **CLOSED AND CORRECT**. The
procedure used here is now the standard for every other movie: `handmade correction method.md`.

## 0. Where everything is

| | |
|---|---|
| **the final c540 book** | `run_c540_s28\c540_s28_blocks.xlsx` (copy at the project root) — 94 moves, 180 schedule rows + 8 readout/load rows, 6 AOM groups |
| **the final videos** | `run_c540_s28\c540_s28_original_vs_rebuild_panels.mp4` / `_full.mp4` (copies at the root) |
| the correction script | `run_c540_s28\apply_s28.py` (+ `apply_s28.log` with the measured residuals) — the template for the next movie |
| helpers | `run_c540_s28\dump_sched.py` (workbook rows for a time window), `list_moves.py` (every move with frames and residual), `deliver_s28.ps1` |
| checks | `audit_s28.txt`, `sim_s28.txt`, `s28_vs_s27.txt` (cmp_tol), `s28_vs_shayne.txt` (cmp_full), `score_s28.txt`, `deliver_s28.log` |
| the untouched s27 move list | `run_c540_s28\moves_full_s27_original.json`; the s27 book and videos stay in `run_c540_s27\` |

## 1. What the user asked for, and how it was done

The user's instruction: the skill is final; list the frames where the s27 run reported movements as
wrong or undetermined; for every "wrong movement between frames A and B" look at the rebuild, say
what is wrong and propose the correct move as a table of workbook rows; apply what is approved;
render once at the end; close the movie; write the handover; make the procedure a standard.

The list given to the user (from `s27_vs_shayne.txt`, the two half logs and `moves_full.json`):
two known faults (f348-355 missing, f152-154 disagreeing with the hand book), 31 moves over the
0.10 guideline that all matched the hand book (four of them with a refused detector read), three
tie-break replacements, and the readout/load rows that are not defects. The user checked the movie
and confirmed that the two known faults were the only ones.

## 2. The three corrections (all user-approved; 2.1 and 2.2 are the hand book's maps, 2.3 the user's own finding)

### 2.1 f348-355 — Z0 columns, block at 13:24 × 1:9 — ADDED

The s27 book kept Z0 still here; whole-block occupancy reads the block at rest before and after and
never enumerated a transition, so no route was ever asked (session 27 §5 item 1). The pixels
(`sb_probe --peaks --sp Z0 --axis 0 --f0 346 --f1 357`): on f348 a gold outline class sits on cols
13:18 and a mauve one on 19:24; gold runs 13.53→18.85 and mauve 18.47→13.18 over f349-354, the two
cross at f351 (gold 15.72..20.73, mauve 16.25..21.24), and f355 has all twelve columns on tones.

| slot | t_start | t_finish | x_start | y | x_finish | displacement |
|---|---|---|---|---|---|---|
| 1 | 10.6336 | 10.8357 | 13:18 | 1:9 | 19:24 | +6 |
| 2 | 10.6336 | 10.8357 | 19:24 | 1:9 | 13:18 | −6 |

Timing: the free fit wants about f347.3-f355.1; clipped to start when the `1:12->13:24` slide ends
(10.6336 = f347.81) and finish when the `rows 1:9->19:27` move starts (10.8357 = f354.42), so the
same atoms never carry two motions. Measured with `sb_compose.verify`: smoothstep mean 0.1477 over
231 peaks (the fast-wrap over-read of session 27 §1.3, worst 0.57 at f353), free per-frame error
0.019-0.045 on every moving frame. `rests_full.json` now enumerates the transition (the f337-355
relocation is split at f348 and a f348-355 permutation added) so `sb_audit` sees the move as
explaining a transition.

### 2.2 f152-155 — X0+X1 rows, blocks on 10:18 × 1:24 — REPLACED

The s27 book: `10,13->11,14 | 16->18 | 11->10 | 14->13 | 17:18->16:17` (rows 12 and 15 static,
0.161 site, S2.1 refused its best rotation at 0.178). The pixels: on f152 gold outline on rows 10,
13, 16 and mauve on 11, 12, 14, 15, 17, 18; on f154 the fill peaks are 10.35 11.26 13.33 14.35
16.29 17.41 — no peak at 12 or 15, so those rows move; the book's map predicts peaks at 12.0 and
15.0 and none near 11.3 or 14.3. The hand book's triple rotation predicts 10.3 11.35 13.3 14.35 16.3
17.35 at 70 % progress and matches every peak.

| slot | t_start | t_finish | x | y_start | y_finish | displacement |
|---|---|---|---|---|---|---|
| 1 | 4.6431 | 4.7388 | 1:24 | 10,13,16 | 12,15,18 | +2 |
| 2 | 4.6431 | 4.7388 | 1:24 | 11:12,14:15,17:18 | 10:11,13:14,16:17 | −1 |

Timing unchanged (ends at the f155 pulse). Measured: mean **0.0568** (was 0.1612), moving-frame
error 0.007 and 0.038 on f153/f154, X1 joins at 0.069.

### 2.3 f140-144 — X0 rows, block D3 at 1:12 × 10:18 — DROPPED, X0 rides X1's rectangle

Found by the user on the first s28 video: D3 and D4 perform the SAME movement in the movie, but the
rebuild gave D3 (X0) a five-row cyclic shift `13:17->14:18 | 18->13` (S2.1 competition, 0.100) and
D4 (X1) `13:14,16:17->14:15,17:18 | 15,18->13,16` (appearance read, 0.066). The pixels agree with
the user: X0's outline classes on f140 are mauve on rows 13.01 14.02 16.04 17.00 and gold on 14.97
17.99 — identical to X1's — and on f142 both blocks show the same peaks (13.5/13.8/14.6 and
16.4/16.9/17.6). The comparator had called both "MATCH" because it compares displacement SETS at a
time boundary, and {−2, +1} is the same set for both maps — a blind spot worth knowing.

| slot | t_start | t_finish | x | y_start | y_finish | displacement |
|---|---|---|---|---|---|---|
| 1 | 4.2802 | 4.4010 | 1:24 | 13:14,16:17 | 14:15,17:18 | +1 |
| 2 | 4.2802 | 4.4010 | 1:24 | 15,18 | 13,16 | −2 |

The X0 move is dropped and X1's move joins X0+X1 over cols 1:24: one rectangle instead of two, so
the batch uses two crossed pairs instead of four (the user's point). Measured: X1 0.0838, X0 joins
at 0.1028 over f139-147 (the window overlaps the next X0+X1 rows move at f144-153); on the moving
frames f141-143 the free per-frame error is 0.014-0.027 site.

## 3. Checks on the corrected book

| check | result |
|---|---|
| `sb_audit` | **AUDIT CLEAN** — 122 transitions, 118 explained, 4 held back as readout/load, 0 undetermined, 0 silent, 0 idle, 0 rest clashes over 87 804 claims |
| `se_sim` | validation clean; census never short of 432 atoms |
| `cmp_tol` s27 → s28 | 91 moves identical; exactly 1 `MAP DIFFERS` (f152-154), the two f140-146 moves replaced by one X0+X1 move, and 1 new move (f348-355); nothing else changed |
| `cmp_full` vs Shayne's hand book | **93 of 98 sheet movements match; 217 of 217 hand-book displacement entries accounted for; 53 of 53 events.** The 5 non-matches are the 4 readout/load/carry-in rows the hand book omits and the t 3.44 comparator artefact (session 27 §3) |
| render (`deliver_s28.ps1`) | see `deliver_s28.log` / `score_s28.txt`; results in §4 |

## 4. Render, score, video (`deliver_s28.ps1`; final run 15:06-15:23 after the third correction)

384 frames rendered, **0 validation entries**, "the workbook is self-consistent". Profile score
(`score_s28.txt`, static control X0 f174-302, registration bias −0.002 / −0.017 site):

| | s27 book | **s28 book (final)** |
|---|---|---|
| mean over 360 non-pulse frames | 0.0493 (raw 0.0470) | **0.0487 (raw 0.0463)** |
| frames with every peak within 0.25 site | 137 | **138** |
| per species | X0 0.0446, X1 0.0497, Z0 0.0595, Z1 0.0432 | X0 0.0443, X1 0.0494, **Z0 0.0576**, Z1 0.0432 |
| f349-353 (the added rotation) mean / worst | 0.111-0.142 / up to 2.78 | **0.053-0.089 / 0.49-0.56** |
| f153-154 (the replaced map) mean / worst | 0.051, 0.074 / 0.37, 0.77 | **0.027, 0.046 / 0.09, 0.38** |
| f141-142 (D3 on D4's rectangle) worst | 0.77, 0.92 | **0.44, 0.40** |

The whole-movie mean barely moves, as rule 27 predicts for three short same-site permutations; the
frames they live on improve two- to five-fold, and the rebuilt f142 now shows D3 and D4 with the
same two bunched row pairs the movie shows. The evidence that the book is right is the hand-book
comparison in §3 and the user's confirmation on the video, not the number. Videos:
`c540_s28_original_vs_rebuild_panels.mp4` / `_full.mp4` in `run_c540_s28\` and at the root.

## 5. Status

**c540 is CLOSED and CORRECT (the user's declaration, 2026-09-16).** Together with c150, c200 and
c300, four movies are closed. The next movie follows `handmade correction method.md`: run the skill
(HANDOVER run book), list the doubts in frames, correct what the user names, render once, close.
