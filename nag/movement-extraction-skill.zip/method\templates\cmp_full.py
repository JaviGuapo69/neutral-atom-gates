"""cmp_full.py -- the WHOLE patch sheet against Shayne's hand book, movement by movement.

Generalised from the session-23 `cmp_seg6.py`, with one change to how the hand book is read and one
addition.

COMPARED ON DISPLACEMENT SETS AT A SHARED TIME BOUNDARY.  That is the level
`c540_faults_vs_shayne.md` established as the right one for comparing two books: it is blind to AOM
NUMBERING (which crossed pair a batch is written on is an allocation, not a measurement) and to how
one movement is SPLIT ACROSS RECTANGLES (a rotation is two rigid groups, and a book may put them on
two AOMs or one).  What it is not blind to is what actually matters -- which lines move, how far,
on which axis, and when.

THE HAND BOOK IS READ BY ROW PAIR, NOT BY DIFFING CONSECUTIVE STATES.  Shayne's `Combined` sheet
writes each event as TWO rows: the start row carries the start time in column D and every AOM's
START tones, the finish row carries the finish time in E and the FINISH tones.  So a movement is a
difference WITHIN a pair.  `cmp_seg6.py` diffed each AOM's successive states instead, which also
sees those differences but additionally sees every REPROGRAMMING between one event's finish and the
next event's start -- an AOM being handed a different block is not a movement, and on a whole movie
there are many more of those than there are on segment 6.  Both readings agree on segment 6; the
pair reading is the one that stays right over the movie.

BOTH DIRECTIONS ARE REPORTED.  Per sheet movement: MATCH, or `no hand-book change`.  Then the
reverse -- hand-book displacements that NO sheet movement accounts for, which is the direction that
finds what the transcription is MISSING, and the direction the session-16 comparison found the real
errors in.
"""
import argparse, collections, json, os

import openpyxl

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOL = 0.12          # ms: how far apart two books may place the same boundary (~4 frames)


def parse_comb(s):
    out = []
    if s is None:
        return out
    for tok in str(s).replace(" ", "").split(","):
        if not tok or tok == "None":
            continue
        if ":" in tok:
            a, b = tok.split(":")
            out += list(range(int(a), int(b) + 1))
        else:
            try:
                out.append(int(float(tok)))
            except ValueError:
                pass
    return out


def hand_movements(path):
    """[(t_start, t_finish, aom, axis, displacement, start, finish)] from the hand book."""
    ws = openpyxl.load_workbook(path)["Combined"]
    hdr = [c.value for c in ws[1]]
    naom = sum(1 for h in hdr if h and "x tones" in str(h))
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    out = []
    for i in range(0, len(rows) - 1, 2):
        ra, rb = rows[i], rows[i + 1]
        if (ra[2] and "ryd" in str(ra[2]).lower()) or (rb[2] and "ryd" in str(rb[2]).lower()):
            continue                                   # a gate, not a movement
        try:
            t0 = float(ra[3])
        except (TypeError, ValueError):
            t0 = None
        try:
            t1 = float(rb[4])
        except (TypeError, ValueError):
            t1 = None
        if t1 is None:
            continue
        for k in range(naom):
            for axis, ci in (("cols", 5 + 2 * k), ("rows", 6 + 2 * k)):
                a, b = parse_comb(ra[ci]), parse_comb(rb[ci])
                if not a or not b or len(a) != len(b) or a == b:
                    continue
                for dv in sorted({q - p for p, q in zip(a, b)} - {0}):
                    out.append(dict(t0=t0, t1=t1, aom=k + 1, axis=axis, d=dv, pair=i // 2,
                                    src=ra[ci], dst=rb[ci], hit=False))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--moves", default="patch_moves_full.json")
    ap.add_argument("--hand", default=os.path.join(ROOT, "c540_v3_shayne_handwritten.xlsx"))
    ap.add_argument("--extra", default="extra.json")
    ap.add_argument("--tol", type=float, default=TOL)
    ap.add_argument("--t0", type=float, default=None)
    ap.add_argument("--t1", type=float, default=None)
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    hand = hand_movements(a.hand)
    d = json.load(open(a.moves))
    sheet = []
    for m in d["moves"]:
        disp = sorted({dd[0] - s[0] for s, dd in m["parts"] if s})
        sheet.append(dict(who="+".join(m["joins"]), axis=m["axis"], t1=m["t1"], t0=m["t0"],
                          f0=m["f0"], f1=m["f1"], disp=disp, kind="patch",
                          text=" | ".join("%s->%s" % (s[0], dd[0]) if len(s) == 1 else
                                          "%d:%d->%d:%d" % (s[0], s[-1], dd[0], dd[-1])
                                          for s, dd in m["parts"])))
    # The hand-measured readout / load / carry-in rows are part of the delivered sheet too (they are
    # in extra.json and emitted into the workbook), so they take part in the comparison; leaving
    # them out would report every one of them as a hand-book movement the sheet is missing.
    if a.extra and os.path.exists(a.extra):
        for ev in json.load(open(a.extra)):
            xs, xf = parse_comb(ev["x_start"]), parse_comb(ev["x_finish"])
            ys, yf = parse_comb(ev["y_start"]), parse_comb(ev["y_finish"])
            for axis, p, q in (("cols", xs, xf), ("rows", ys, yf)):
                if len(p) == len(q) and p != q:
                    sheet.append(dict(who=ev["species"], axis=axis,
                                      t1=float(ev["t_finish"]), t0=float(ev["t_start"]),
                                      f0=-1, f1=-1, kind=ev["event"],
                                      disp=sorted({v - u for u, v in zip(p, q)} - {0}),
                                      text="%s->%s" % (ev["x_start" if axis == "cols"
                                                          else "y_start"],
                                                       ev["x_finish" if axis == "cols"
                                                          else "y_finish"])))
    sheet.sort(key=lambda s: (s["t1"], s["who"]))
    if a.t0 is not None:
        sheet = [s for s in sheet if s["t1"] >= a.t0 - 0.06]
        hand = [h for h in hand if h["t1"] >= a.t0 - 0.06]
    if a.t1 is not None:
        sheet = [s for s in sheet if s["t1"] <= a.t1 + 0.06]
        hand = [h for h in hand if h["t1"] <= a.t1 + 0.06]

    L = []
    P = L.append
    P("=" * 118)
    P("c540 PATCH SHEET vs SHAYNE'S HAND BOOK -- whole movie, displacement sets at a shared "
      "time boundary (tol %.2f ms)" % a.tol)
    P("=" * 118)
    P("%-11s %-5s %-9s %-34s %-12s %s" % ("species", "axis", "t_finish", "map", "displ",
                                          "hand book"))
    P("-" * 118)
    nmatch = 0
    for s in sheet:
        near = [h for h in hand if h["axis"] == s["axis"] and abs(h["t1"] - s["t1"]) <= a.tol]
        got = []
        for dv in s["disp"]:
            hs = [h for h in near if h["d"] == dv]
            if hs:
                got.append(dv)
                for h in hs:
                    h["hit"] = True
        ok = bool(s["disp"]) and len(got) == len(s["disp"])
        nmatch += ok
        P("%-11s %-5s %-9.4f %-34s %-12s %s"
          % (s["who"], s["axis"], s["t1"], s["text"][:34],
             ",".join("%+d" % v for v in s["disp"]),
             "MATCH" if ok else "no hand-book change with displ %s near t=%.2f"
             % (",".join("%+d" % v for v in s["disp"] if v not in got), s["t1"])))
    P("-" * 118)
    P("%d of %d sheet movements match the hand book on displacement and timing"
      % (nmatch, len(sheet)))

    P("")
    P("=" * 118)
    P("REVERSE DIRECTION -- hand-book displacements that NO sheet movement accounts for")
    P("(this is the direction that finds what the transcription is MISSING)")
    P("=" * 118)
    miss = [h for h in hand if not h["hit"]]
    bytime = collections.defaultdict(list)
    for h in miss:
        bytime[(round(h["t1"], 4), h["axis"], h["d"])].append(h)
    P("%-9s %-5s %-7s %-28s %s" % ("t_finish", "axis", "displ", "hand map", "AOM(s)"))
    P("-" * 118)
    for (t1, axis, dv), g in sorted(bytime.items()):
        P("%-9.4f %-5s %-7s %-28s %s"
          % (t1, axis, "%+d" % dv, "%s -> %s" % (g[0]["src"], g[0]["dst"]),
             ",".join(str(h["aom"]) for h in g)))
    if not miss:
        P("   (none -- every hand-book displacement is accounted for)")
    P("-" * 118)
    P("%d hand-book displacement entries, %d accounted for, %d NOT (%d distinct "
      "(time, axis, displacement) triples)"
      % (len(hand), len(hand) - len(miss), len(miss), len(bytime)))
    # An entry is one AOM's displacement, so a movement written across six crossed pairs counts six
    # times.  Roll them back up to the hand book's own EVENTS -- one row pair each -- which is the
    # number to quote for "how many of Shayne's movements does this sheet not have".
    P("")
    ev = collections.defaultdict(lambda: [0, 0])
    for h in hand:
        ev[h["pair"]][0 if h["hit"] else 1] += 1
    full = sum(1 for v in ev.values() if v[1] == 0)
    none_ = sum(1 for v in ev.values() if v[0] == 0)
    part = len(ev) - full - none_
    P("Rolled up to the hand book's own EVENTS (one row pair each): %d events carry a movement; "
      "%d fully accounted for, %d partly, %d NOT AT ALL." % (len(ev), full, part, none_))

    txt = "\n".join(L)
    print(txt)
    if a.out:
        open(a.out, "w").write(txt + "\n")


if __name__ == "__main__":
    main()
