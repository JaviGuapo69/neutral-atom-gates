"""depaint_legend.py -- remove a legend drawn INSIDE the panel box from the extracted frames.

WHY (2026-09-18, c300_2aod).  c150 and c200 draw the legend to the LEFT of the panel, outside it,
so it never enters a mask.  c300 draws it along the TOP, INSIDE the panel box, and its four
species swatches land at row -0.47 -- and the movie's blocks really do reach row -0.45 (f295).
So every species' mask carries one phantom marker on every frame, at a fixed non-integer column,
and no choice of window separates it from the real row 0.

The legend is STATIC: identical pixels on every frame.  So this takes the band's non-background
pixels from one clean frame as a stencil and repaints exactly those pixel positions with the
frame's own background on every frame.  A real marker is only touched where it overlaps a legend
pixel (at most a couple of pixel columns on one frame of c300), and nothing else changes.

    python depaint_legend.py <run dir> --band 58,86 [--ref 10] [--bg-x 300,370] [--dry-run]

--band   y0,y1 in pixels: the strip to clean.  Read it off the frame; it must contain the whole
         legend and no part of any row the movie uses.
--bg-x   x0,x1 of a strip in the same band that is always background, used for the repaint colour.

Originals are copied to frames_raw\ the first time, so this is reversible and re-runnable.
"""
import argparse, json, os, shutil, sys

import numpy as np
from PIL import Image


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--band", required=True, help="y0,y1 in pixels")
    ap.add_argument("--ref", type=int, default=10, help="a frame whose band holds ONLY the legend")
    ap.add_argument("--bg-x", default="300,370", help="x0,x1 of an always-empty strip in the band")
    ap.add_argument("--x", default=None,
                    help="x0,x1: limit the stencil to this column range. Use it to keep the panel "
                         "BORDER and the right-hand tables out of it -- they are drawn in the same "
                         "band and repainting them would change the full-frame video")
    ap.add_argument("--tol", type=float, default=24.0, help="RGB distance that counts as 'drawn'")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    y0, y1 = [int(v) for v in a.band.split(",")]
    bx0, bx1 = [int(v) for v in a.bg_x.split(",")]
    K = json.load(open(os.path.join(a.run, "calib.json")))
    nfr = K["n_frames"]
    fd = os.path.join(a.run, "frames")
    raw = os.path.join(a.run, "frames_raw")

    if not os.path.isdir(raw):
        if a.dry_run:
            print("(dry run: would copy %s -> %s)" % (fd, raw))
        else:
            shutil.copytree(fd, raw)
            print("kept the untouched frames as", raw)
    src = raw if os.path.isdir(raw) else fd

    ref = np.asarray(Image.open(os.path.join(src, "p_%03d.png" % a.ref)).convert("RGB")).astype(int)
    band = ref[y0:y1]
    bg = np.median(band[:, bx0:bx1].reshape(-1, 3), axis=0)
    stencil = np.sqrt(((band - bg) ** 2).sum(axis=2)) > a.tol
    if a.x:
        kx0, kx1 = [int(v) for v in a.x.split(",")]
        keep = np.zeros(stencil.shape[1], bool)
        keep[kx0:kx1] = True
        stencil &= keep[None, :]
    ys, xs = np.nonzero(stencil)
    print("stencil from f%03d, band y %d..%d: %d pixels, x %d..%d, background rgb(%d,%d,%d)"
          % (a.ref, y0, y1, stencil.sum(), xs.min(), xs.max(), *(int(v) for v in bg)))
    if a.dry_run:
        return

    for f in range(nfr):
        p = os.path.join(src, "p_%03d.png" % f)
        im = np.asarray(Image.open(p).convert("RGB")).astype(np.uint8).copy()
        sub = im[y0:y1]
        own = np.median(sub[:, bx0:bx1].reshape(-1, 3), axis=0)   # white, or the gate tint
        sub[stencil] = own.astype(np.uint8)
        im[y0:y1] = sub
        Image.fromarray(im).save(os.path.join(fd, "p_%03d.png" % f))
    print("repainted the band on %d frames in %s (originals in frames_raw\\)" % (nfr, fd))


if __name__ == "__main__":
    main()
