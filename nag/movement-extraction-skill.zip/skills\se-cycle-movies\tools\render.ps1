<#
  render.ps1 -- workbook -> movie frames. Implements part II of the rebuild guide.

  Reads ONE .xlsx with sheets Constants / Seed / Schedule / Gates and writes one PNG per frame,
  plus a calibration file describing the geometry it drew with, so the same extractor can be
  pointed at these frames and at the real movie's frames and score them the same way.

  Nothing movie-specific is hard-coded. Lattice size, block layout, timing, easing and the visible
  window all come from `Constants`; the palette is assigned by species order and is, per the
  guide's part II.3, an arbitrary choice.

  Fill colour and marker shape say WHICH SPECIES an atom is. The marker OUTLINE says WHICH CROSSED
  AOD PAIR is holding it: one colour per `Schedule.slot`, worn for exactly as long as that pair is
  moving the atom -- from the row's `t_start` to its `t_finish`, and not one frame longer. A parked
  atom wears no outline at all. So at any instant the atoms sharing an outline colour are exactly
  the group one AOM has hold of, which is what makes two blocks crossing through each other
  readable. See the $AOMPAL block and the "who holds what" block.

  Validation log (-LogCsv) is empty when the workbook is self-consistent. A `check3` line means a
  row picked up fewer atoms than its rectangle has sites, which is nearly always a motion the
  schedule is missing.
#>
param(
  [Parameter(Mandatory=$true)][string]$Xlsx,
  [Parameter(Mandatory=$true)][string]$OutDir,
  [string]$LogCsv,
  [string]$CalibTxt,                 # defaults to <OutDir>\calib.txt
  [int]$Pitch = 33,
  [string]$MatchCalib,               # a movie's calibration file: draw the same window at the same
                                     # scale, so a side-by-side lines up frame for frame
  [string]$Title
)
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.Threading.Thread]::CurrentThread.CurrentCulture = [System.Globalization.CultureInfo]::InvariantCulture

# ---------------------------------------------------------------- read the workbook
function Read-Sheets([string]$path) {
  $zip = [System.IO.Compression.ZipFile]::OpenRead((Resolve-Path $path).Path)
  function Txt($n) {
    $e = $zip.GetEntry($n); if (-not $e) { return $null }
    $sr = New-Object System.IO.StreamReader($e.Open(), [Text.Encoding]::UTF8)
    $t = $sr.ReadToEnd(); $sr.Dispose(); return $t
  }
  $shared = @()
  $sst = Txt 'xl/sharedStrings.xml'
  if ($sst) {
    $x = New-Object System.Xml.XmlDocument; $x.LoadXml($sst)
    foreach ($si in $x.DocumentElement.ChildNodes) {
      $sb = New-Object System.Text.StringBuilder
      foreach ($t in $si.SelectNodes('.//*[local-name()="t"]')) { [void]$sb.Append($t.InnerText) }
      $shared += $sb.ToString()
    }
  }
  $wb = New-Object System.Xml.XmlDocument; $wb.LoadXml((Txt 'xl/workbook.xml'))
  $names = @()
  foreach ($sh in $wb.SelectNodes('//*[local-name()="sheet"]')) { $names += $sh.GetAttribute('name') }

  $out = @{}
  for ($i = 1; $i -le $names.Count; $i++) {
    $doc = New-Object System.Xml.XmlDocument; $doc.LoadXml((Txt "xl/worksheets/sheet$i.xml"))
    $rows = New-Object System.Collections.ArrayList
    foreach ($row in $doc.SelectNodes('//*[local-name()="row"]')) {
      $cells = @{}; $maxc = 0
      foreach ($c in $row.SelectNodes('./*[local-name()="c"]')) {
        $m = [regex]::Match($c.GetAttribute('r'), '^([A-Z]+)')
        $ci = 0; foreach ($ch in $m.Groups[1].Value.ToCharArray()) { $ci = $ci*26 + ([int][char]$ch - 64) }
        if ($ci -gt $maxc) { $maxc = $ci }
        $ty = $c.GetAttribute('t')
        $isn = $c.SelectSingleNode('./*[local-name()="is"]')
        $vn  = $c.SelectSingleNode('./*[local-name()="v"]')
        if ($ty -eq 'inlineStr' -and $isn) { $cells[$ci] = $isn.InnerText }
        elseif ($vn) { if ($ty -eq 's') { $cells[$ci] = $shared[[int]$vn.InnerText] } else { $cells[$ci] = $vn.InnerText } }
      }
      $arr = @(); for ($k = 1; $k -le $maxc; $k++) { $arr += $(if ($cells.ContainsKey($k)) { $cells[$k] } else { '' }) }
      [void]$rows.Add($arr)
    }
    $out[$names[$i-1]] = $rows
  }
  $zip.Dispose()
  return $out
}
function ConvertTo-Objects($rows) {
  $hdr = $rows[0]
  $out = New-Object System.Collections.ArrayList
  for ($i = 1; $i -lt $rows.Count; $i++) {
    $o = @{}
    for ($k = 0; $k -lt $hdr.Count; $k++) { $o[$hdr[$k]] = $(if ($k -lt $rows[$i].Count) { $rows[$i][$k] } else { '' }) }
    [void]$out.Add($o)
  }
  return $out
}

$sheets = Read-Sheets $Xlsx
foreach ($need in 'Constants','Seed','Schedule','Gates') {
  if (-not $sheets.ContainsKey($need)) { throw "the workbook has no sheet named '$need'" }
}
$K = @{}
foreach ($r in (ConvertTo-Objects $sheets['Constants'])) { if ($r['key'] -ne '') { $K[$r['key']] = $r['value'] } }
$seedRows  = ConvertTo-Objects $sheets['Seed']
$schedRows = ConvertTo-Objects $sheets['Schedule']
$gateRows  = ConvertTo-Objects $sheets['Gates']

foreach ($need in 'lattice_cols','lattice_rows','frames','dt_ms') {
  if (-not $K.ContainsKey($need)) { throw "Constants is missing '$need'" }
}
$NCOL = [int][double]$K['lattice_cols']
$NROW = [int][double]$K['lattice_rows']
$NFR  = [int][double]$K['frames']
$DT   = [double]$K['dt_ms']
# NB the parameter must not be $k: PowerShell variables are case-insensitive, so $k would be the
# same variable as the $K holding Constants.
function Const([string]$ckey, $dflt) {
  if ($K.ContainsKey($ckey) -and "$($K[$ckey])" -ne '') { return [int][double]$K[$ckey] }
  return $dflt
}
$VCMIN = Const 'visible_col_min' 1;      $VCMAX = Const 'visible_col_max' $NCOL
$VRMIN = Const 'visible_row_min' 1;      $VRMAX = Const 'visible_row_max' $NROW

# The tone grid may be finer than the data lattice (guide I.1a). lattice_cols/rows count TONE
# positions; a data site sits every tone_divisor-th tone. A renderer that draws a disc at every
# tone would put data qubits in the staging gaps.
$TDIV  = Const 'tone_divisor' 1
if ($TDIV -lt 1) { $TDIV = 1 }
$DCOLS = Const 'data_cols' ([int][Math]::Floor(($NCOL - 1) / $TDIV) + 1)
$DROWS = Const 'data_rows' ([int][Math]::Floor(($NROW - 1) / $TDIV) + 1)

# ---------------------------------------------------------------- grammar (guide I.6)
function Split-Elements([string]$cell) {
  $txt = ($cell -replace '\s','')
  $el = New-Object System.Collections.ArrayList
  foreach ($tok in ($txt -split ',')) {
    if ($tok -eq '') { continue }
    $m = [regex]::Match($tok, '^(-?\d+):(-?\d+)$')
    if ($m.Success) {
      $run = @(); for ($v=[int]$m.Groups[1].Value; $v -le [int]$m.Groups[2].Value; $v++) { $run += $v }
      [void]$el.Add($run)
    } else { [void]$el.Add(@([int]$tok)) }
  }
  return ,$el.ToArray()
}
function Expand($el) { $o=@(); foreach ($e in $el) { foreach ($t in $e) { $o += $t } }; return ,$o }

# Regions with no data qubits. `block_parking` is the key the c540 workbook uses; `no_data_sites`
# takes a semicolon-separated list of the same "a:b x c:d" form.
$noSite = @()
foreach ($key in 'block_parking','no_data_sites') {
  if (-not $K.ContainsKey($key)) { continue }
  foreach ($part in ("$($K[$key])" -split ';')) {
    $m = [regex]::Match($part, '^\s*(.+?)\s*[xX]\s*(.+?)\s*$')
    if (-not $m.Success) { continue }
    $cs = Expand (Split-Elements $m.Groups[1].Value)
    $rs = Expand (Split-Elements $m.Groups[2].Value)
    if ($cs.Count -eq 0 -or $rs.Count -eq 0) { continue }
    $h = @{}
    foreach ($c in $cs) { foreach ($r in $rs) { $h["$c,$r"] = $true } }
    $noSite += $h
  }
}
function Test-HasSite([int]$c, [int]$r) {
  if ((($c - 1) % $TDIV) -ne 0 -or (($r - 1) % $TDIV) -ne 0) { return $false }   # a staging tone
  if ($c -gt (($DCOLS - 1) * $TDIV + 1) -or $r -gt (($DROWS - 1) * $TDIV + 1)) { return $false }
  foreach ($h in $noSite) { if ($h.ContainsKey("$c,$r")) { return $false } }
  return $true
}

$logRows = New-Object System.Collections.ArrayList
function Write-Log($kind,$detail) { [void]$logRows.Add([pscustomobject]@{ kind=$kind; detail=$detail }) }

# ---------------------------------------------------------------- seed (guide II.2 step 1)
$atoms = New-Object System.Collections.ArrayList
function New-Atom($sp,$x,$y,$born) {
  return [pscustomobject]@{ sp=$sp; x=[double]$x; y=[double]$y
                            baseX=[double]$x; baseY=[double]$y
                            born=[double]$born; dies=[double]::MaxValue; fadeFrom=[double]::MaxValue }
}
foreach ($r in $seedRows) {
  if ($r['species'] -eq '') { continue }
  foreach ($xx in (Expand (Split-Elements $r['x_tones']))) {
    foreach ($yy in (Expand (Split-Elements $r['y_tones']))) { [void]$atoms.Add((New-Atom $r['species'] $xx $yy 0.0)) }
  }
}
$species = @($atoms | ForEach-Object { $_.sp } | Sort-Object -Unique)
"seeded $($atoms.Count) atoms of $($species.Count) species: $($species -join ', ')"

# ---------------------------------------------------------------- motions (guide II.2 steps 2-4)
$plan = New-Object System.Collections.ArrayList
$parsed = New-Object System.Collections.ArrayList
foreach ($r in $schedRows) {
  if ($r['t_start'] -eq '') { continue }
  $ev = $r['event']; if ($ev -eq '') { $ev = 'move' }
  $sfx = Expand (Split-Elements $r['x_start']);  $ffx = Expand (Split-Elements $r['x_finish'])
  $sfy = Expand (Split-Elements $r['y_start']);  $ffy = Expand (Split-Elements $r['y_finish'])
  if ($sfx.Count -ne $ffx.Count) { Write-Log 'check1' "move $($r['move']) slot $($r['slot']): x tone counts differ"; continue }
  if ($sfy.Count -ne $ffy.Count) { Write-Log 'check1' "move $($r['move']) slot $($r['slot']): y tone counts differ"; continue }
  $xm = @{}; for ($i=0;$i -lt $sfx.Count;$i++) { $xm[$sfx[$i]] = $ffx[$i] }
  $ym = @{}; for ($i=0;$i -lt $sfy.Count;$i++) { $ym[$sfy[$i]] = $ffy[$i] }
  # `slot` is the crossed AOD pair this row runs on -- what the Combined sheet's AOM1..AOM8 columns
  # count, and what sb_emit.py writes here. A row with no numeric slot simply gets no outline.
  $aomIx = 0
  if ("$($r['slot'])" -match '^\s*(\d+)\s*$') { $aomIx = [int]$matches[1] }
  [void]$parsed.Add([pscustomobject]@{
    move=$r['move']; slot=$r['slot']; aom=$aomIx; event=$ev; species=$r['species']
    t0=[double]$r['t_start']; t1=[double]$r['t_finish']
    fx=$ffx; fy=$ffy; xm=$xm; ym=$ym; want=($sfx.Count * $sfy.Count)
  })
}

# Every row with a numeric slot contributes one AOM assignment: the pair, the instant it takes
# hold, the instant it lets go (the row's own t_finish -- see the "who holds what" block), and the
# atoms it took. A `load` row counts too -- its atoms are born already in that pair's grip -- but
# its atoms have no index until they are appended, so it is resolved after the batch.
$aomHold = New-Object System.Collections.ArrayList

$batches = $parsed | Group-Object { $_.t0 } | Sort-Object { [double]$_.Name }
foreach ($batch in $batches) {
  $claim = @{}; $moves = New-Object System.Collections.ArrayList
  $retire = @{}; $born = New-Object System.Collections.ArrayList
  $loadHold = New-Object System.Collections.ArrayList
  foreach ($p in $batch.Group) {
    if ($p.event -eq 'load') {
      $n0 = [int]$born.Count
      foreach ($xx in $p.fx) { foreach ($yy in $p.fy) { [void]$born.Add((New-Atom $p.species $xx $yy $p.t0)) } }
      $n1 = [int]$born.Count
      if ([int]$p.aom -gt 0 -and $n1 -gt $n0) {
        [void]$loadHold.Add([pscustomobject]@{ aom=[int]$p.aom; t=[double]$p.t0; tEnd=[double]$p.t1
                                               from=$n0; n=($n1 - $n0) })
      }
      continue
    }
    $got = 0
    $mine = New-Object System.Collections.ArrayList
    for ($k = 0; $k -lt $atoms.Count; $k++) {
      $a = $atoms[$k]
      if ($a.dies -lt [double]::MaxValue) { continue }
      $ix = [int][Math]::Round($a.x); $iy = [int][Math]::Round($a.y)
      if ($p.xm.ContainsKey($ix) -and $p.ym.ContainsKey($iy)) {
        if ($claim.ContainsKey($k)) { Write-Log 'check4' "t=$($p.t0) move $($p.move)/$($p.slot): atom ($ix,$iy) already claimed by $($claim[$k])" }
        $claim[$k] = "$($p.move)/$($p.slot)"
        [void]$moves.Add(@($k, $p.t0, $p.t1, [double]$ix, [double]$iy, [double]$p.xm[$ix], [double]$p.ym[$iy]))
        if ($p.event -eq 'unload') { $retire[$k] = $p }
        [void]$mine.Add($k)
        $got++
      }
    }
    if ($p.aom -gt 0 -and $mine.Count -gt 0) {
      [void]$aomHold.Add([pscustomobject]@{ t=$p.t0; tEnd=$p.t1; aom=$p.aom; atoms=@($mine) })
    }
    if ($got -ne $p.want) { Write-Log 'check3' "move $($p.move)/$($p.slot) t=$($p.t0): picked up $got of $($p.want) sites" }
  }
  foreach ($m in $moves) {
    $a = $atoms[$m[0]]
    [void]$plan.Add([pscustomobject]@{ idx=$m[0]; t0=$m[1]; t1=$m[2]; x0=$m[3]; y0=$m[4]; x1=$m[5]; y1=$m[6] })
    $a.x = $m[5]; $a.y = $m[6]
  }
  foreach ($k in $retire.Keys) { $atoms[$k].fadeFrom = $retire[$k].t0; $atoms[$k].dies = $retire[$k].t1 }
  $base = $atoms.Count
  foreach ($b in $born) { [void]$atoms.Add($b) }
  foreach ($lh in $loadHold) {
    $ids = @(); for ($j = 0; $j -lt $lh.n; $j++) { $ids += ($base + $lh.from + $j) }
    [void]$aomHold.Add([pscustomobject]@{ t=$lh.t; tEnd=$lh.tEnd; aom=$lh.aom; atoms=$ids })
  }
}
"schedule rows parsed: $($parsed.Count);  motions planned: $($plan.Count);  atoms ever alive: $($atoms.Count)"

$byAtom = @{}
foreach ($m in $plan) {
  if (-not $byAtom.ContainsKey($m.idx)) { $byAtom[$m.idx] = New-Object System.Collections.ArrayList }
  [void]$byAtom[$m.idx].Add($m)
}
foreach ($k in @($byAtom.Keys)) { $byAtom[$k] = @($byAtom[$k] | Sort-Object t0) }

# ---------------------------------------------------------------- who holds what, and until when
# An atom wears the colour of the pair that is MOVING it, for exactly as long as the move lasts:
# the row's own t_start to its own t_finish. Parked atoms wear nothing.
#
# ---- THIS RULE IS MEASURED, NOT CHOSEN. Read this before changing it. ----
#
# It used to end the interval at the pair's NEXT assignment instead ("kept on past the move while
# the atoms sit parked"). Both halves of that are contradicted by the movie. Counting ring pixels
# per column per frame in c540 (run_c540/frames, segment 6, against run_c540_v3/c540_seg6_patch)
# gives a ~500 px noise floor with no ring and ~2000-4000 px with one, and the columns light up
# exactly over each move's own [t_start, t_finish):
#
#   col 13,19  moves 1-4  t 5.785-6.3653  ->  ringed f191-207, BARE f208-245
#   col 14,20  moves 5-7  t 6.2922-6.5775 ->  ringed f191-214, BARE f215-245
#   col 15,21  moves 8-10 t 6.5408-6.8242 ->  ringed f191-206 and f215-222, BARE f207-214, f223-245
#   col 16,22  moves 11-13 t 6.7643-7.0892 -> ringed f191-206 and f222-231, BARE f207-221, f232-245
#
# The old rule got this wrong in BOTH directions at once, and the second one is the worse:
#
#   * it kept rings on parked atoms -- slots 5 and 6 are used by one row each, so their assignment
#     had no successor and cols 13,19 stayed ringed from f199 to the end of the render (1442 px at
#     f245 where the movie has 520);
#   * it CANCELLED rings on atoms still in flight. sb_emit packs several concurrent sub-moves onto
#     one pair, and their fitted t_start values differ by a thousandth of a millisecond -- a
#     thirtieth of a frame. Ending the interval at the pair's next assignment therefore let each
#     row in a batch cancel the previous row's ring instantly, so only the LAST row on that pair
#     wore one. At f211 the render drew 1022 ring px on col 14 where the movie has 3356: moves 5
#     and 6 (Z1 and Z0, both mid-flight on pair 1) had been stripped by move 7.
#
# So the interval is the row's own [t0, t1). Overlap between two rows claiming one atom is still
# resolved most-recent-wins, by clipping the earlier interval -- an atom is held by one pair at a
# time -- but that is now a guard, not the mechanism.
$aomAt = @{}                                   # pair -> its assignment times, ascending
foreach ($g in $aomHold) {
  if (-not $aomAt.ContainsKey($g.aom)) { $aomAt[$g.aom] = New-Object System.Collections.ArrayList }
  [void]$aomAt[$g.aom].Add([double]$g.t)
}
foreach ($s in @($aomAt.Keys)) { $aomAt[$s] = @($aomAt[$s] | Sort-Object -Unique) }

# NB the claims and the intervals are pscustomobjects, not @(a,b) pairs. `@($x | Sort-Object)` on a
# ONE-element list of arrays returns the inner array instead of a list holding it, so every atom
# with a single claim would read its fields off the wrong axis and silently lose its ring.
$heldBy = @{}                                  # atom -> the (t0, t1, pair) claims on it
foreach ($g in $aomHold) {
  foreach ($k in $g.atoms) {
    if (-not $heldBy.ContainsKey($k)) { $heldBy[$k] = New-Object System.Collections.ArrayList }
    [void]$heldBy[$k].Add([pscustomobject]@{ ta=[double]$g.t; tb=[double]$g.tEnd; aom=[int]$g.aom })
  }
}
$hold = @{}                                    # atom -> disjoint intervals {t0, t1, aom}
foreach ($k in @($heldBy.Keys)) {
  $seq = @($heldBy[$k] | Sort-Object ta)
  $iv = New-Object System.Collections.ArrayList
  for ($i = 0; $i -lt $seq.Count; $i++) {
    $ta = [double]$seq[$i].ta
    $end = [double]$seq[$i].tb                 # the ring lasts exactly as long as the move does
    if ($i + 1 -lt $seq.Count -and [double]$seq[$i+1].ta -lt $end) { $end = [double]$seq[$i+1].ta }
    if ($end -gt $ta) { [void]$iv.Add([pscustomobject]@{ t0=$ta; t1=$end; aom=[int]$seq[$i].aom }) }
  }
  if ($iv.Count -gt 0) { $hold[$k] = @($iv) }
}
$aomUsed = @($aomAt.Keys | Sort-Object)
"AOM pairs in the sheet: $(if ($aomUsed.Count) { $aomUsed -join ', ' } else { 'none -- no numeric slot, so no outlines' })"

$spOf = @(); $seedPos = @(); $bornAt = @(); $diesAt = @(); $fadeAt = @()
foreach ($a in $atoms) { $spOf += $a.sp; $seedPos += ,@($a.baseX, $a.baseY); $bornAt += $a.born; $diesAt += $a.dies; $fadeAt += $a.fadeFrom }

$gates = @()
foreach ($g in $gateRows) { if ($g['t_start'] -ne '') { $gates += ,@([double]$g['t_start'], [double]$g['t_finish']) } }

# ---------------------------------------------------------------- drawing (guide II.3: style is free)
$PALETTE = @(
  [System.Drawing.Color]::FromArgb(231,122,163), [System.Drawing.Color]::FromArgb(236,160,0),
  [System.Drawing.Color]::FromArgb(80,121,186),  [System.Drawing.Color]::FromArgb(0,130,0),
  [System.Drawing.Color]::FromArgb(150,80,190),  [System.Drawing.Color]::FromArgb(0,150,150)
)
$COL = @{}; $SHAPE = @{}
for ($i = 0; $i -lt $species.Count; $i++) {
  $COL[$species[$i]]   = $PALETTE[$i % $PALETTE.Count]
  $SHAPE[$species[$i]] = $(if ($i % 2 -eq 0) { 'square' } else { 'diamond' })
}
$GATECOL = [System.Drawing.Color]::FromArgb(254,231,218)
$SITECOL = [System.Drawing.Color]::FromArgb(178,178,178)

# One colour per crossed AOD pair, indexed by `Schedule.slot`. The first four matter most: c150,
# c200 and c300 all use exactly four pairs, and these four are >=259 RGB apart.
#
# ---- THESE COLOURS ARE MEASURED, NOT CHOSEN. Read this before changing one. ----
#
# sb_score.py finds a species by taking every pixel within 34 RGB of that species' FILL colour. A
# ring puts new colours on screen, and GDI+ anti-aliases its edges into whatever is behind them --
# so a ring can manufacture a colour that lands inside ANOTHER species' 34 RGB ball, and the
# scorer then counts those edge pixels as that species' atoms. It is not hypothetical: magenta
# rings on Z0's blue fill produced rgb(221,121,173), 14 RGB from X0's pink, ~33 px per marker,
# which was enough to invent three whole X0 rows at f196-200 and f272-280 and took the c300 score
# from 0.0534 to 0.0653.
#
# GDI+ does NOT blend linearly, so the blend colours cannot be predicted by arithmetic -- they have
# to be drawn and read back. Two findings from doing that:
#
#   1. $GAP below is what makes this safe. With the ring's inner edge touching the fill, the
#      ring-over-fill blend sweeps a long path through colour space and most colours cross some
#      fill's ball. Hold the ring 1 px clear and it only ever blends with the white panel: every
#      colour here then bottoms out at 58.9 RGB, which is the floor the render already has without
#      any rings at all (the teal fill's own anti-aliased edge, rgb(64,177,177), 58.9 from blue).
#   2. A gap is necessary but not sufficient -- a colour whose blend-to-white line passes through a
#      fill still fails. Measured rejects, all far under the 34 bar even with the gap:
#      red(214,0,0) 29.6, navy(0,0,150) 29.9, indigo(60,0,200) 37.9, violet(100,0,170) 7.1.
#
# So: to change an entry, re-run the measurement, and require the margin to stay at the 58.9 floor.
$AOMPAL = @(
  [System.Drawing.Color]::FromArgb(0,0,0),      [System.Drawing.Color]::FromArgb(255,0,220),
  [System.Drawing.Color]::FromArgb(120,230,0),  [System.Drawing.Color]::FromArgb(0,225,235),
  [System.Drawing.Color]::FromArgb(255,90,0),   [System.Drawing.Color]::FromArgb(0,90,255),
  [System.Drawing.Color]::FromArgb(120,62,0),   [System.Drawing.Color]::FromArgb(255,120,255)
)

$ML = 44; $MT = 58; $MR = 12; $MB = 12
$PitchX = [double]$Pitch; $PitchY = [double]$Pitch
$NVC = $VCMAX - $VCMIN + 1; $NVR = $VRMAX - $VRMIN + 1
$OX = $ML + $PitchX/2.0; $OY = $MT + $PitchY/2.0
$W = [int]($ML + $NVC*$PitchX + $MR); $H = [int]($MT + $NVR*$PitchY + $MB)
$MarkR = $PitchX * 0.29                       # marker half-size, in pixels

# -MatchCalib: adopt a movie's own geometry so the two can be laid side by side and compared frame
# for frame. Only the drawing changes; the schedule is untouched.
if ($MatchCalib) {
  $M = @{}
  foreach ($ln in [System.IO.File]::ReadAllLines((Resolve-Path $MatchCalib).Path)) {
    if ($ln -match '^\s*([A-Za-z0-9_]+)\s*=\s*(.+?)\s*$') { $M[$matches[1]] = $matches[2] }
  }
  foreach ($need in 'image_w','image_h','panel_x0','panel_x1','panel_y0','panel_y1','origin_x','pitch_x','origin_y','pitch_y') {
    if (-not $M.ContainsKey($need)) { throw "-MatchCalib file is missing $need" }
  }
  $W = [int]$M['image_w']; $H = [int]$M['image_h']
  $ML = [int]$M['panel_x0']; $MR = $W - [int]$M['panel_x1']
  $MT = [int]$M['panel_y0']; $MB = $H - [int]$M['panel_y1']
  # The calibration's pitch is one of ITS tones. If this workbook counts in coarser tones -- an
  # older workbook written before the tone grid was measured has no tone_divisor at all, so it
  # counts data sites -- one of its steps spans several of the calibration's. Getting this wrong
  # draws every atom at a fraction of its true position and the comparison is meaningless.
  $mdiv = 1
  if ($M.ContainsKey('tone_divisor')) { $mdiv = [int]$M['tone_divisor'] }
  if ($mdiv -lt 1) { $mdiv = 1 }
  $scale = $mdiv / [double]$TDIV
  if ($scale -ne 1.0) { "workbook counts in 1/$TDIV of a data pitch, the calibration in 1/${mdiv}: scaling by $scale" }
  $PitchX = [double]$M['pitch_x'] * $scale; $PitchY = [double]$M['pitch_y'] * $scale
  $OX = [double]$M['origin_x'];    $OY = [double]$M['origin_y']
  $MarkR = [Math]::Min($PitchX,$PitchY) * 0.29
  if ($M.ContainsKey('visible_col_min')) {
    $VCMIN = [int][Math]::Floor(([int]$M['visible_col_min'] - 1) / $scale) + 1
    $VCMAX = [int][Math]::Ceiling(([int]$M['visible_col_max'] - 1) / $scale) + 1
  }
  if ($M.ContainsKey('visible_row_min')) {
    $VRMIN = [int][Math]::Floor(([int]$M['visible_row_min'] - 1) / $scale) + 1
    $VRMAX = [int][Math]::Ceiling(([int]$M['visible_row_max'] - 1) / $scale) + 1
  }
  "matching geometry from $MatchCalib"
}
function Get-PxX([double]$c) { return $OX + ($c - 1.0) * $PitchX }
function Get-PxY([double]$r) { return $OY + ($r - 1.0) * $PitchY }
if (-not $MatchCalib) {
  # place tone 1 so that the visible window starts at the left margin
  $OX = $ML + $PitchX/2.0 - ($VCMIN - 1) * $PitchX
  $OY = $MT + $PitchY/2.0 - ($VRMIN - 1) * $PitchY
}

if (-not $Title) { $Title = [System.IO.Path]::GetFileNameWithoutExtension($Xlsx) }
$fontTitle = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
$fontInfo  = New-Object System.Drawing.Font('Consolas', 12)
$penSite   = New-Object System.Drawing.Pen($SITECOL, 1.4)
$brInk     = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(60,60,60))

# The ring grows the marker rather than eating into it: the fill's pixel area, and so every profile
# the score reads, is untouched. $GAP holds it clear of the fill by a pixel as well, which is what
# keeps its anti-aliased edge out of every other species' colour ball -- see the $AOMPAL note; that
# is load-bearing, not a nicety. One pen per pair, made once: a pen per atom per frame is ~10^5
# allocations.
$OutW = [Math]::Max(2.0, $MarkR * 0.22)
$GAP  = [Math]::Max(1.0, $MarkR * 0.08)
$AOMPEN = @{}; $AOMPENF = @{}
foreach ($s in $aomUsed) {
  $c = $AOMPAL[($s - 1) % $AOMPAL.Count]
  $AOMPEN[$s]  = New-Object System.Drawing.Pen($c, [single]$OutW)
  $AOMPENF[$s] = New-Object System.Drawing.Pen(
    [System.Drawing.Color]::FromArgb([int]($c.R + (255-$c.R)*0.55), [int]($c.G + (255-$c.G)*0.55),
                                     [int]($c.B + (255-$c.B)*0.55)), [single]$OutW)
}
$RO = $MarkR + $GAP + $OutW / 2.0               # square ring: half-size of the stroke's centreline
$DO = $MarkR * 1.26 + ($GAP + $OutW / 2.0) * 1.41421   # diamond: pushing an edge out by e moves
                                                       # the vertex out by e * sqrt(2)

New-Item -ItemType Directory -Force $OutDir | Out-Null

for ($f = 0; $f -lt $NFR; $f++) {
  $t = $f * $DT
  $pos = New-Object 'double[][]' $atoms.Count
  for ($k = 0; $k -lt $atoms.Count; $k++) {
    $x = $seedPos[$k][0]; $y = $seedPos[$k][1]
    if ($byAtom.ContainsKey($k)) {
      foreach ($m in $byAtom[$k]) {
        if ($t -ge $m.t1) { $x = $m.x1; $y = $m.y1 }
        elseif ($t -ge $m.t0) {
          if ($m.t1 -le $m.t0) { $x = $m.x1; $y = $m.y1 }
          else {
            $u = ($t - $m.t0) / ($m.t1 - $m.t0)
            $s = 10*[Math]::Pow($u,3) - 15*[Math]::Pow($u,4) + 6*[Math]::Pow($u,5)
            $x = $m.x0 + ($m.x1 - $m.x0) * $s
            $y = $m.y0 + ($m.y1 - $m.y0) * $s
          }
          break
        }
      }
    }
    $pos[$k] = @($x, $y)
  }

  $isGate = $false
  foreach ($g in $gates) { if ($t -ge $g[0] -and $t -le $g[1]) { $isGate = $true } }

  $bmp = New-Object System.Drawing.Bitmap($W, $H)
  $gfx = [System.Drawing.Graphics]::FromImage($bmp)
  $gfx.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $gfx.Clear([System.Drawing.Color]::White)
  $bg = $(if ($isGate) { $GATECOL } else { [System.Drawing.Color]::White })
  $brBg = New-Object System.Drawing.SolidBrush($bg)
  $gfx.FillRectangle($brBg, $ML, $MT, $W-$ML-$MR, $H-$MT-$MB); $brBg.Dispose()
  $gfx.DrawRectangle((New-Object System.Drawing.Pen([System.Drawing.Color]::Black, 2)), $ML, $MT, $W-$ML-$MR, $H-$MT-$MB)

  for ($c = 1; $c -le $NCOL; $c++) {
    for ($r = 1; $r -le $NROW; $r++) {
      if (-not (Test-HasSite $c $r)) { continue }
      if ($c -lt $VCMIN -or $c -gt $VCMAX -or $r -lt $VRMIN -or $r -gt $VRMAX) { continue }
      $sr = $MarkR * 0.47
      $gfx.DrawEllipse($penSite, [single]((Get-PxX $c)-$sr), [single]((Get-PxY $r)-$sr), [single](2*$sr), [single](2*$sr))
    }
  }

  # TWO PASSES, and the order is load-bearing. Mid-crossing the markers overlap, so a ring drawn
  # after a neighbour's fill paints over part of it -- which deletes fill pixels the score's 1-D
  # profile is measuring and shifts that marker's peak, exactly at the crossings where the score
  # is most sensitive. Rings underneath, fills on top: no fill pixel is ever overwritten, and the
  # ring of the marker in front correctly reads as being in front.
  $vis = New-Object System.Collections.ArrayList
  for ($k = 0; $k -lt $atoms.Count; $k++) {
    if ($t -lt $bornAt[$k] -or $t -ge $diesAt[$k]) { continue }
    $x = $pos[$k][0]; $y = $pos[$k][1]
    if ($x -lt ($VCMIN-0.4) -or $x -gt ($VCMAX+0.4)) { continue }
    if ($y -lt ($VRMIN-0.4) -or $y -gt ($VRMAX+0.4)) { continue }
    # which crossed AOD pair has hold of this atom right now (none for an atom no pair is moving at
    # this instant -- one never taken, or one sitting parked between moves)
    $oa = 0
    if ($hold.ContainsKey($k)) {
      foreach ($iv in $hold[$k]) { if ($t -ge $iv.t0 -and $t -lt $iv.t1) { $oa = $iv.aom; break } }
    }
    [void]$vis.Add([pscustomobject]@{ k=$k; cx=(Get-PxX $x); cy=(Get-PxY $y); aom=$oa })
  }

  foreach ($v in $vis) {                                   # pass 1: the AOM rings
    if ($v.aom -le 0) { continue }
    $opn = $(if ($t -ge $fadeAt[$v.k]) { $AOMPENF[$v.aom] } else { $AOMPEN[$v.aom] })
    $cx = $v.cx; $cy = $v.cy
    if ($SHAPE[$spOf[$v.k]] -eq 'square') {
      $gfx.DrawRectangle($opn, [single]($cx-$RO), [single]($cy-$RO), [single](2*$RO), [single](2*$RO))
    } else {
      $gfx.DrawPolygon($opn, @(
        (New-Object System.Drawing.PointF([single]$cx,[single]($cy-$DO))),
        (New-Object System.Drawing.PointF([single]($cx+$DO),[single]$cy)),
        (New-Object System.Drawing.PointF([single]$cx,[single]($cy+$DO))),
        (New-Object System.Drawing.PointF([single]($cx-$DO),[single]$cy))))
    }
  }

  foreach ($v in $vis) {                                   # pass 2: the fills, unchanged
    $k = $v.k; $cx = $v.cx; $cy = $v.cy
    $c = $COL[$spOf[$k]]
    if ($t -ge $fadeAt[$k]) {
      $c = [System.Drawing.Color]::FromArgb([int]($c.R + (255-$c.R)*0.55), [int]($c.G + (255-$c.G)*0.55), [int]($c.B + (255-$c.B)*0.55))
    }
    $br = New-Object System.Drawing.SolidBrush($c)
    if ($SHAPE[$spOf[$k]] -eq 'square') {
      $gfx.FillRectangle($br, [single]($cx-$MarkR), [single]($cy-$MarkR), [single](2*$MarkR), [single](2*$MarkR))
    } else {
      $d = $MarkR * 1.26
      $pts = @(
        (New-Object System.Drawing.PointF([single]$cx,[single]($cy-$d))),
        (New-Object System.Drawing.PointF([single]($cx+$d),[single]$cy)),
        (New-Object System.Drawing.PointF([single]$cx,[single]($cy+$d))),
        (New-Object System.Drawing.PointF([single]($cx-$d),[single]$cy)))
      $gfx.FillPolygon($br, $pts)
    }
    $br.Dispose()
  }

  $gfx.DrawString($Title, $fontTitle, $brInk, 14, 4)
  $gt = $(if ($isGate) { '   RYDBERG' } else { '' })
  $gfx.DrawString(('frame {0,3}/{1}    t = {2,6:F3} ms{3}' -f $f, $NFR, $t, $gt), $fontInfo, $brInk, 14, 33)

  $gfx.Dispose()
  $bmp.Save((Join-Path $OutDir ('p_{0:d3}.png' -f $f)), [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  if ($f % 64 -eq 0) { Write-Progress -Activity 'rendering' -PercentComplete (100*$f/$NFR) }
}
Write-Progress -Activity 'rendering' -Completed
$penSite.Dispose(); $brInk.Dispose(); $fontTitle.Dispose(); $fontInfo.Dispose()
foreach ($s in $aomUsed) { $AOMPEN[$s].Dispose(); $AOMPENF[$s].Dispose() }

# ---------------------------------------------------------------- calibration for these frames
# Written so inv_extract.ps1 can read this render with exactly the sampling rule it uses on the
# real movie. Scoring the two sides with different rules is how you get a meaningless diff.
if (-not $CalibTxt) { $CalibTxt = Join-Path $OutDir 'calib.txt' }
# The calibration written here always describes the grid THIS workbook counts in, whatever
# geometry the frames were drawn with. compare.ps1 reads both sides' calibrations and converts to
# a common grid, so the two need not agree -- and must not be fudged into agreeing here.
$SPX = $PitchX; $SPY = $PitchY; $SDIV = $TDIV
$SVCMIN = $VCMIN; $SVCMAX = $VCMAX; $SVRMIN = $VRMIN; $SVRMAX = $VRMAX
$SNCOL = $NCOL; $SNROW = $NROW
$gsz = [int][Math]::Max(6, [Math]::Floor($SPX * 0.5))
$lines = @(
  "image_w=$W", "image_h=$H"
  "panel_x0=$ML", "panel_x1=$($W-$MR)", "panel_y0=$MT", "panel_y1=$($H-$MB)"
  ("origin_x=" + ((Get-PxX 1).ToString('F3'))), ("pitch_x=" + $SPX.ToString('F4'))
  ("origin_y=" + ((Get-PxY 1).ToString('F3'))), ("pitch_y=" + $SPY.ToString('F4'))
  "tone_divisor=$SDIV", "data_cols=$DCOLS", "data_rows=$DROWS"
  "lattice_cols=$SNCOL", "lattice_rows=$SNROW"
  "visible_col_min=$SVCMIN", "visible_col_max=$SVCMAX"
  "visible_row_min=$SVRMIN", "visible_row_max=$SVRMAX"
  "bg_r=255", "bg_g=255", "bg_b=255"
  "gate_x0=$($ML+2)", "gate_x1=$($ML+2+$gsz)", "gate_y0=$($MT+2)", "gate_y1=$($MT+2+$gsz)"
)
[System.IO.File]::WriteAllLines($(if ([System.IO.Path]::IsPathRooted($CalibTxt)) { $CalibTxt } else { Join-Path (Get-Location).Path $CalibTxt }),
                                $lines, (New-Object System.Text.UTF8Encoding($false)))

if ($LogCsv) { $logRows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $LogCsv }
"rendered $NFR frames ($W x $H) to $OutDir"
"wrote $CalibTxt"
"validation log entries: $($logRows.Count)"
$logRows | Group-Object kind | ForEach-Object { "  {0,-10} {1}" -f $_.Name, $_.Count }
if ($logRows.Count -eq 0) { "the workbook is self-consistent" }
