﻿<#
deliver_s28.ps1 -- render, score and side-by-side video for the session-28 c540 book (s27 + 2 hand corrections).

Run from run_c540_s28 (or with -WorkDir).  Same chain as run_c540_s25\deliver_s25.ps1; uses the
se-cycle-blocks tools (the s25 fork was promoted to production on 2026-09-16).

    .\deliver_s28.ps1
#>
param([switch]$SkipVideo, [string]$Xlsx = "c540_s28_blocks.xlsx")

$ErrorActionPreference = "Continue"
$ROOT = Split-Path $PSScriptRoot
$SB   = Join-Path $ROOT ".claude\skills\se-cycle-blocks\tools"
$SE   = Join-Path $ROOT ".claude\skills\se-cycle-movies\tools"
$env:Path += ";C:\Users\HP\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.1-full_build\bin"
$env:PYTHONIOENCODING = "utf-8"
Set-Location $PSScriptRoot

function Step($name, $block) {
  Write-Output ""
  Write-Output ("=" * 78)
  Write-Output "== $name   $(Get-Date -Format HH:mm:ss)"
  Write-Output ("=" * 78)
  & $block
}

Step "1. se_calibtxt -- the render calibration that matches the movie" {
  python "$SE\se_calibtxt.py" --calib calib.json --out-txt movie_calib.txt `
         --out-json render_calib.json --render-frames "$PSScriptRoot\rframes" --tone-divisor 1
}

Step "2. render.ps1 -- workbook back to 384 frames" {
  & "$SE\render.ps1" -Xlsx $Xlsx -OutDir "$PSScriptRoot\rframes" `
    -LogCsv "$PSScriptRoot\render_log.csv" -MatchCalib "$PSScriptRoot\movie_calib.txt"
  $n = (Get-ChildItem "$PSScriptRoot\rframes" -Filter "p_*.png" -ErrorAction SilentlyContinue).Count
  $v = (Get-Content "$PSScriptRoot\render_log.csv" -ErrorAction SilentlyContinue | Measure-Object -Line).Lines
  Write-Output "rendered $n frames; validation log lines (incl. header): $v"
}

Step "3. sb_score -- the profile score against the movie" {
  python "$SB\sb_score.py" --movie-calib calib.json --render-calib render_calib.json `
         --out score_s28.txt | Select-Object -Last 20
}

if ($SkipVideo) { Write-Output "`n-SkipVideo: stopping before the mp4s"; exit 0 }

Step "4. sb_video -- the side-by-side comparison videos" {
  & "$SB\sb_video.ps1" -MovieFrames "$ROOT\run_c540\frames" -RenderFrames "$PSScriptRoot\rframes" `
    -Calib "$PSScriptRoot\calib.json" `
    -OutPanels "$PSScriptRoot\c540_s28_original_vs_rebuild_panels.mp4" `
    -OutFull   "$PSScriptRoot\c540_s28_original_vs_rebuild_full.mp4"
}
Write-Output "DONE $(Get-Date -Format HH:mm:ss)"


