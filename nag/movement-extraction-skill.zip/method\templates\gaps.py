"""gaps.py -- for one species/axis over a frame range: which of the block's tones have NO peak on them
(the markers in flight), and where the off-tone peaks are.  A column that leaves tone a and arrives at tone b
shows a as empty from the first moving frame until b fills; the set of empty tones over the run IS the set of
sources, and the set of tones that are empty at the start but full at the end is the destination set.

    python gaps.py SP AXIS F0 F1 T0 T1 C0 C1 R0 R1
"""
import os, sys
sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
from sb_read import Movie

sp, axis, f0, f1 = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
t0, t1 = int(sys.argv[5]), int(sys.argv[6])
win = tuple(float(v) for v in sys.argv[7:11])
M = Movie("calib.json")
tones = list(range(t0, t1 + 1))
for f in range(f0, f1 + 1):
    pk = M.peaks(M.fill[sp], win, f, axis)
    empty = [t for t in tones if not any(abs(p - t) <= 0.15 for p in pk)]
    off = [p for p in pk if min(abs(p - t) for t in tones) > 0.15]
    print("f%03d%s  %2d peaks | EMPTY tones %-22s | off-tone peaks %s"
          % (f, " [p]" if f in M.gate else "    ", len(pk),
             ",".join(str(t) for t in empty) or "-", " ".join("%.2f" % v for v in off) or "-"))
