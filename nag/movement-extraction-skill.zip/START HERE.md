# START HERE

**Read this first. It is short on purpose.** Everything else in this folder is detail you will only
need once you are already working.

---

## 1. What this thing does

You have videos of a quantum computer moving atoms around a grid.

This turns one of those videos back into the **instruction list that produced it** — a spreadsheet
saying which atoms were picked up, when, and where they were put down.

Then it does the reverse: it takes that spreadsheet, renders it back into a video, and puts the two
side by side. So you can *see* whether the answer is right, rather than take anyone's word for it.

```
   the movie   ──►   a spreadsheet of instructions   ──►   a rebuilt movie
                                                             ↓
                                              you watch the two side by side
```

---

## 2. The one thing you must understand

The computer moves atoms with **rectangles**, not one atom at a time.

A laser trap grabs everything sitting on a chosen set of columns crossed with a chosen set of rows,
and carries that whole rectangle somewhere. So if a block of atoms shuffles itself around
internally, that is **not one instruction** — it is several rectangles moving at the same time, and
working out how many, and which atoms are in each, is the entire difficulty of the job.

That is all the physics you need to start.

---

## 3. How you actually use it

You do not run commands. You talk to Claude Code, which reads the instructions in this folder and
runs them.

**Install it once:** copy the two folders inside `skills\` into `.claude\skills\` in whatever
directory you want to work in. Then open Claude Code there.

**Then say things like this:**

| you want | say |
|---|---|
| to start a movie | *"Transcribe `<path to the .mp4>` into a schedule workbook using the se-cycle-blocks skill."* |
| Claude to check its own work | *"Now apply the handmade correction method: find your own mistakes, fix them, and give me a new video."* |
| to report something you saw | *"Wrong movement between frames 176 and 184."* |
| to finish | *"That video is correct. Consider it closed."* |

That's the whole interface.

---

## 4. What happens, start to finish

**① Claude transcribes the movie.** A few hours, mostly unattended. You get a spreadsheet, a
side-by-side video, and a list of anything it could not work out.

**② Claude checks its own work.** It goes back over the whole rebuild against the movie's pixels,
finds its own mistakes, proposes a fix for each, **applies them all without asking**, and gives you
a second video plus a report of everything it changed and why.

**③ You watch that video.** ← *this step is yours, and it cannot be skipped. See §5.*

**④ You report what's still wrong**, by frame number. Claude looks at those frames, tells you what
it thinks the correct movement is and why, and waits for you to approve. Then it applies your
corrections and renders once more.

**⑤ You watch again.** Repeat ④ until it looks right.

**⑥ You say it's closed.** Claude writes up what was corrected, files the final spreadsheet and
videos, and stops.

---

## 5. Why *you* have to watch the video

This is the most important thing in this file.

There is a kind of error the software **cannot detect, by construction**: a block of atoms
rearranging itself *within the same rectangle*. Before and after, everything sits in exactly the
same places — so every automatic check sees a perfect match. Only the frames *in between* differ.

This was tested by taking a finished, correct spreadsheet and deliberately breaking one movement in
it. Then every automatic check was run on it:

| check | what it said about the broken file |
|---|---|
| structural audit | **clean** |
| atom count | **clean** |
| render validation | **0 problems, "self-consistent"** |
| accuracy score | **0.044 — a good score** |

All four passed. Anyone who trusted them would have shipped the wrong answer.

**So: play the side-by-side video and look for a small group of markers that swaps places in the
real movie but stays still in the rebuild — or the reverse, markers dancing in the rebuild that
don't move in the real one.** Note the frame number and say *"wrong movement between frames A and B"*.

Don't check still frames instead. At rest the two always agree — that's the whole problem.

---

## 6. What "good" looks like

| | |
|---|---|
| accuracy score | **0.03 – 0.06** (a first draft is usually 0.3 – 0.8) |
| "couldn't determine" | **0** |
| audit / atom count / render | all clean |
| and | **you have watched it and said so** |

The last row is the one that counts.

---

## 7. Three things that will surprise you

**Claude will sometimes say "I don't know."** Some things genuinely cannot be seen in the video — for
example, where a block goes after it is carried off the edge of the screen. Saying so is correct
behaviour. An answer that fills those gaps with plausible-looking numbers is worse than one that
flags them.

**Nothing transfers between movies.** Colours, block sizes, grid size, timings, which edge the spare
atoms wait on — all of it is measured fresh every time. Don't reuse a number from a previous movie,
ever.

**Never edit the spreadsheet by hand.** Several of its sheets are generated from the others. Change
the underlying movement list and regenerate — Claude knows how. A hand-edited cell silently puts the
file out of step with itself.

---

## 8. Where to go next

| when you want | read |
|---|---|
| to actually start | `README.md` §3 (install) and §6 (the steps) |
| the commands on one page | `RUN_BOOK.md` |
| to understand the corrections loop | `method\handmade correction method.md` |
| to see it done for real | `worked sessions\4aod_c780_s31\` — one complete correction session |
| to see what a finished result looks like | `..\closed videos\c150_full_original_vs_rebuild_panels.mp4` |
| the deep reference | `skills\se-cycle-blocks\SKILL.md` — long, and the real authority |

**One warning about the videos in `..\closed videos\`:** those eleven are finished and verified. Use
them to learn what "right" looks like. Don't re-run them.
