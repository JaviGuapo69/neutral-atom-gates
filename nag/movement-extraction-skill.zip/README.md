# SE-cycle movies → schedule workbooks

> **New here? Read `START HERE.md` first** — two pages, plain language, no jargon. Then
> `what a session looks like.md` for a worked example conversation. **This** file is the full
> reference: read it once end to end before you run anything, and come back to it for detail.

You have been given a method for taking an animated movie of a syndrome-extraction (SE) cycle on a
neutral-atom quantum computer and recovering the **machine schedule** that produced it: a spreadsheet
that says which atoms were picked up by which trap rectangle, when, and where they were put down. The
schedule can be rendered back into frames, so the work is checkable: you put the original movie and
your rebuild side by side and look at them.

Nothing here requires you to know anything about the project in advance. It does assume you are
comfortable on a Windows command line and can read Python when you need to.

---

## Contents

1. [What the job actually is](#1-what-the-job-actually-is)
2. [What one finished movie looks like](#2-what-one-finished-movie-looks-like)
3. [Install and prerequisites](#3-install-and-prerequisites)
4. [The vocabulary](#4-the-vocabulary)
5. [The two phases](#5-the-two-phases)
6. [Phase A — the automatic solve](#6-phase-a--the-automatic-solve)
7. [Phase B — the handmade correction method](#7-phase-b--the-handmade-correction-method)
8. [The checks, and what "closed" means](#8-the-checks-and-what-closed-means)
9. [The 2-AOD family — what changes](#9-the-2-aod-family--what-changes)
10. [Driving this with Claude Code](#10-driving-this-with-claude-code)
11. [What is in this folder](#11-what-is-in-this-folder)
12. [Coverage of the shipped examples](#12-coverage-of-the-shipped-examples)
13. [The traps, collected](#13-the-traps-collected)

---

## 1. What the job actually is

An SE-cycle movie is an `.mp4` animation. Each frame draws a lattice of sites. Coloured markers on
those sites are atoms. There are four **species** — `Z0`, `Z1`, `X0`, `X1` — each a rectangular
**block** of ancilla atoms, plus the data qubits drawn as rings. Over the movie the blocks are
shuttled around the lattice by crossed acousto-optic deflectors (AODs), pausing on **gate frames**
where a global Rydberg pulse fires and every ancilla sitting on a data qubit gets a CZ.

The physical constraint that makes the problem tractable, and that you must keep in your head at all
times:

> **An AOD pair traps a *rectangle*, not a set of atoms.** A move picks up every atom sitting on the
> product of a set of column tones with a set of row tones, and translates that whole grid. A move
> that rearranges a block's atoms among themselves is therefore not one move — it is several
> rectangles, one per *rigid group*, run at once.

The movie shows you positions. It does not show you rectangles, timings, or which atoms belonged to
which rectangle. Recovering those is the job. It is a **fit**, not a measurement, and some of it is
genuinely unrecoverable from the pixels — the tools are written to say so rather than guess, and a
transcript that flags what it could not see is *correct*, while one that fills the gap with
plausible numbers is not.

### The one non-obvious hard part

A move that permutes a block **onto its own sites** (same rectangle before and after, atoms
rearranged inside it) is invisible to every occupancy-based check, to the census, to the render
validation, and to the score. It is visible only by watching the frames *between* two rests. This is
why the procedure ends in a human watching a side-by-side video, and why that step is not optional.

---

## 2. What one finished movie looks like

For each movie you deliver:

| artefact | what it is |
|---|---|
| `cNNN_<tag>_blocks.xlsx` | **the deliverable.** Six sheets: `Constants`, `Seed`, `Gates`, `Schedule`, `Combined`, `Notes` |
| `cNNN_<tag>_original_vs_rebuild_panels.mp4` | movie panel and rebuilt panel side by side — the thing a human reviews |
| `cNNN_<tag>_original_vs_rebuild_full.mp4` | the same, full frame including the movie's own tables |
| `score_<tag>.txt` | mean positional error of the rebuild against the movie, in lattice sites |
| a correction/evidence report (`.md` or `.txt`) | one entry per move: the rigid groups, the measured residual, and what is measurement vs convention |

The workbook sheets, in the renderer's terms:

* **`Constants`** — lattice size, block regions, cycle length, frame count, `dt_ms`, easing, visible
  window. *Read geometry from here, never assume it.*
* **`Seed`** — one row per species: `x_tones`, `y_tones` at t = 0. Expand as a product.
* **`Schedule`** — one row per motion: `move`, `slot`, `event`, `species`, `t_start`, `t_finish`,
  `x_start`, `y_start`, `x_finish`, `y_finish`, `note`. The semantics are *"the atoms resting on
  rectangle (`x_start` × `y_start`) at `t_start` travel to rectangle (`x_finish` × `y_finish`) by
  `t_finish`"*. `event` is `move` (blank), `unload` (atoms retired at `t_finish`) or `load` (fresh
  atoms of `species` appear). **`move` and `slot` are provenance only — no semantics, never group by
  them.**
* **`Gates`** — the global pulses. Nothing moves during one.
* **`Combined`** — the same schedule in the AOM-column layout the lab uses.
* **`Notes`** — the evidence and the list of anything left undetermined.

A good final result is a score around **0.03–0.06 sites**, `AUDIT CLEAN`, `se_sim` validation clean,
**0 render validation entries**, **0 undetermined**, and an AOM peak equal to the AOD count the
movie's title claims.

---

## 3. Install and prerequisites

### You need

| thing | notes |
|---|---|
| Windows + PowerShell 5.1 | the render and video scripts are PowerShell. **PS 5.1 has no `&&`, no ternary, and `$s` and `$S` are the same variable** |
| Python 3.12 | `pip install numpy scipy pillow openpyxl` |
| ffmpeg | `winget install Gyan.FFmpeg`. Not on PATH in a fresh shell — the deliver scripts add it |
| Claude Code | how the analysis is actually driven. See §10 |
| ~20 GB free disk per movie in progress | a 384-frame movie expands to `frames\` + `rframes\` PNGs; 2-AOD movies are ~570 frames |
| RAM | `sb_full.py` holds ~1.2 GB per solver process. Run at most two at once |

### Install the skills

Copy both skill folders into the `.claude\skills\` directory of the project you will work in (or into
your user-level `%USERPROFILE%\.claude\skills\`):

```powershell
# from inside this handover folder, with <project> = wherever you will work
New-Item -ItemType Directory -Force -Path "<project>\.claude\skills" | Out-Null
Copy-Item -Recurse skills\se-cycle-blocks "<project>\.claude\skills\"
Copy-Item -Recurse skills\se-cycle-movies "<project>\.claude\skills\"
```

`se-cycle-blocks` is the one that does the work. `se-cycle-movies` is the older, lower-level skill it
depends on: `se_calib.py` (calibration), `se_sim.py` (census), `se_calibtxt.py` + `render.ps1`
(rendering), `se_aom.py`. **Both are required.** Ignore `se_moves.py` / `se_waypoints.py` in
`se-cycle-movies` — they are superseded by the blocks skill for anything with sub-block moves, which
is every movie here.

### Check the install

```powershell
skills\se-cycle-movies\tools\render.ps1 -Xlsx skills\se-cycle-movies\examples\m540SEmovesV4.xlsx -OutDir t -LogCsv t.csv
```

Expect `seeded 432 atoms`, `221 rows`, `11556 motions`, `864 atoms ever alive`,
`validation log entries: 0`. Anything else means the install is wrong, not the workbook. That
workbook is a verified transcription of the c540 4-AOD movie, so it is a real end-to-end test of the
renderer.

> ⚠ **`skills\se-cycle-movies\tools\preflight.ps1` reports `preflight FAILED` on a correct install.
> Ignore that one line.** Its environment checks (PowerShell, System.Drawing, ffmpeg, ffprobe,
> execution policy, locale) are all still useful and worth reading, but its `tools` check looks for
> `inv_calib.ps1`, `inv_extract.ps1`, `inv_moves.ps1`, `inv_emit.ps1` and `compare.ps1` — files from
> an older version of the skill that no longer exist and are not used by anything in this procedure.
> The `render.ps1` test above is the real check.
>
> If you are on a non-English Windows, note preflight's other warning: a locale such as `es-ES` uses
> `,` as the decimal separator. The shipped scripts pin `InvariantCulture`; **anything you write
> yourself must too.**

### The rule that overrides everything else

> **Never modify anything inside `skills\se-cycle-blocks\tools\`.**
>
> The skill was frozen deliberately (2026-09-16). Its automatic analysis is as good as it is going to
> get; its remaining mistakes are found by a human watching the movie and are fixed **by hand, in the
> move list, outside the skill**. A session that "improves" a tool invalidates every closed movie and
> every regression baseline. If a tool is genuinely wrong, write a new script in your run folder.

---

## 4. The vocabulary

Read this once. The documents assume all of it.

| term | meaning |
|---|---|
| **species** | `Z0`, `Z1`, `X0`, `X1` — the four ancilla blocks, each with its own fill colour |
| **block** | one species' rectangle of atoms, e.g. 6×5 on c150, 4×10 on c200, 10×6 on c300 |
| **site / tone** | a lattice position. Columns and rows are numbered in *sites*; an AOD "tone" is one column or one row of the trap comb |
| **comb** | the set of tones an AOD is driving — i.e. the rectangle's columns (axis 0) or rows (axis 1) |
| **rectangle / slot** | one `(x_tones × y_tones)` trap. One schedule row = one rectangle moving |
| **AOM / AOD group** | how many rectangles can run simultaneously. A "4-AOD movie" drives 4; a 2-AOD movie drives 2. Exceeding it is a defect |
| **pulse / gate frame** | a frame where the header says `global pulse`. Nothing moves during a gate; a gate run is 2 frames on 4-AOD movies, 4 on 2-AOD |
| **pulse-free interval / segment** | the frames between two gate runs. `sb_full` solves one at a time |
| **rest frame** | a frame where a species' occupancy is stable — the anchor points a move is fitted between |
| **transition** | the change in occupancy between two consecutive rests. What must be explained by a move |
| **move** | a fitted record: species, axis, frame window, `src`/`dst` tone lists, `parts` (one per rigid group), timing, and a `how` string of evidence |
| **rigid group / `parts`** | a subset of the block that moves together as one rectangle. A move with `k` rigid groups needs `k` rectangles |
| **outline colour** | the marker's outline. **Each outline colour names one rigid group** — this is the single most useful signal in the movie for reading a permutation |
| **faded** | a desaturated block. On 4-AOD movies it means *being carried away for readout*. On 2-AOD movies it may just mean *idle in place* — see §9 |
| **readout / `unload`** | a block is measured and carried bodily off the array. It is **not** deleted where it stands |
| **load** | a fresh batch of the same species appears and takes over |
| **reservoir** | where fresh stock waits, usually half a pitch off the lattice, off one edge. Which edge differs per movie and sometimes per species |
| **undetermined** | a transition the solver saw but refused to describe. Better than a guess; must reach 0 before closing |
| **same-site permutation** | a move that rearranges a block within its own rectangle. Invisible to every automatic check (see §1) |
| **`mean` (smoothstep)** | the fitted-easing residual of a move. Over-reads on fast wraps |
| **free per-frame progress / error** | the residual against a per-frame free fit. **This is what you judge a hand-written map on**, not `mean` |
| **census** | `se_sim`'s count of live atoms per frame. A *deficit* against the seed is a defect; a *surplus* during a readout is fine |

---

## 5. The two phases

```
   movie.mp4
      │
      │  PHASE A — the skill, automatic.  Hours of compute, little judgement.
      ▼
   automatic book + moves_full.json + rests_full.json + a rebuild video
      │
      │  PHASE B — the handmade correction method.  Judgement, measurement, iteration.
      ▼
   corrected book + a new rebuild video     ──►  human watches it  ──►  names what is still wrong
      │                                                                        │
      └────────────────────────────  loop until the human says CLOSED  ◄───────┘
```

Phase A is described by `skills\se-cycle-blocks\SKILL.md`, section **"Procedure — A NEW MOVIE, END TO
END"**. Phase B is described by `method\handmade correction method.md`.

**Expect Phase A to be 70–90 % right and Phase B to take longer.** On the eight 4-AOD movies the
automatic pass typically produced 80–95 correct moves with 5–15 undetermined and a score around
0.3–0.8; the hand pass took that to 0 undetermined and 0.03–0.06. On c975 the hand pass applied 79
corrections. That is normal.

---

## 6. Phase A — the automatic solve

Work in a fresh folder per movie, e.g. `run_c150\`. Set these once per shell:

```powershell
$SB = "<project>\.claude\skills\se-cycle-blocks\tools"
$SE = "<project>\.claude\skills\se-cycle-movies\tools"
$env:PYTHONIOENCODING = "utf-8"          # or the logs die on the first non-ASCII character
```

**Every step has a check. Do not go past a step whose check fails** — every downstream number will
then be wrong in a way that still looks plausible.

### 1. Frames and calibration

```powershell
New-Item -ItemType Directory -Force -Path frames | Out-Null
ffmpeg -y -v error -i <movie>.mp4 -fps_mode passthrough -start_number 0 frames\p_%03d.png
python $SE\se_calib.py --frames frames --out calib.json --cycle-ms <N>
```

`<N>` comes from the **movie's own header text**, never from a fit. Read it off `frames\p_000.png`:
the header line is `t 0.00/7.22 ms · phase 1 Z:D5 || X:D1-4 · global pulse` and the title line names
the AOD count, whether the movie is pipelined, and the cycle length again.

*Check:* `n_frames` matches the PNG count, and `calib.json`'s `gate_frames` is **exactly** the set of
frames whose header says `global pulse`. `se_calib` derives the gate frames from the gate *tint*, so
this is a genuine independent check. Verify it with `method\templates\hdr.py`, which montages the
header strip of a frame range so you can read it:

```powershell
python <pkg>\method\templates\hdr.py 325 332        # -> hdr.png, one header line per frame
```

Two things to watch for. **1-frame gate runs**: most runs are 2 frames (4 on a 2-AOD movie), but
c300 has single-frame runs at f328 and f383, and those are exactly what pin the "no move crosses a
pulse" bound. **The `reset` token**: a header may end `· reset` instead of, or as well as,
`· global pulse` (c300 f329 is `reset` alone, f383 is `global pulse · reset`). It marks the phase
flip and says nothing about whether a pulse fired — the gate-frame test is `global pulse`, and
nothing else.

Keep `frames\` and `calib.json` — this is slow to redo.

### 2. The palette, including outline colours

```powershell
python $SB\sb_read.py --calib calib.json --palette
```

*Check:* at least one outline colour, ideally two. If none is found, sub-block moves cannot be read
by appearance on that movie — the displacement reader still works, but you have lost the independent
evidence and must say so in the deliverable.

### 3. Block sizes

```powershell
python $SB\sb_blocks.py --calib calib.json --out blocks.json
```

*Check:* one size per species. **Skipping this does not error — it silently loses every move of a
block that spends a whole interval off panel.**

### 3a. Find the readouts and loads — BEFORE solving

```powershell
python $SB\sb_events.py --calib calib.json
python $SB\sb_probe.py --calib calib.json --peaks --sp Z1 --axis 1 --f0 145 --f1 160   # confirm each
```

Write what you confirm into `events.json`, one entry per species per readout/load pair, with a frame
window *containing* the transition the occupancy test will enumerate across it:

```json
[{"sp": "Z1", "f0": 147, "f1": 189, "why": "Z readout at the f147-148 pulse, Z load at f149"}]
```

> **This ordering is not negotiable.** `sb_full` takes the event list as an **input**. An unnamed
> readout becomes a false relocation and the solver fills it with a neighbouring block's move —
> quietly. `sb_full` without `--events` is simply wrong.

> ⚠ **`sb_events` will flag only ONE species of a readout pair. Do not stop there.** A readout
> happens per *phase*, so **both** Z blocks are read out at the same pulse and **both** X blocks at
> theirs — but only the species whose solid→faded transfer is most visible gets a `READOUT?` line.
> On c300, `sb_events` reports `Z1 f149` and `X1 f329` and says nothing about Z0 or X0; the delivered
> event list has **four** entries, not two.
>
> The reliable detector is in the same output, under **"parked stock"**: *every species whose parked-stock
> run ENDS mid-movie is loaded at that frame, and therefore its old batch was read out there.* On c300
> that fires for all four species (`Z0 f002-f155`, `Z1 f002-f146`, `X0 f173-f330`, `X1 f224-f327`).
> Go through the stock list species by species and write an entry for each; then confirm each one on
> the faded track with `sb_probe --peaks`.
>
> **Not every vanish is a readout.** A readout transfers solid area into faded (c300 X1 f329: solid
> 8741→2552, faded 1560→**11874**). An *occlusion* does not — c300's Z0 solid drops 6156→0 at f055 and
> returns at f056 while its faded track stays flat at ~1650 all through, because Z0 and Z1 cross
> *through each other* and the movie draws only the front one. That gets **no** `events.json` entry;
> it is one of the four legitimate `sb_watch` runs instead.

### 4. Transcribe, interval by interval

```powershell
python $SB\sb_full.py --calib calib.json --blocks blocks.json --events events.json *> logs\full.log
```

`--only N` (or `--only 0,1,2,...`) restricts it to segments. **`sb_full` writes only at the END of a
run**, so a killed session loses the whole solve — on long movies run it in parts of about six
segments, at most two processes at once, then merge:

```powershell
New-Item -ItemType Directory -Force -Path half_a, half_b | Out-Null     # ← DO NOT SKIP THIS
python $SB\sb_full.py ... --work half_a --only 0,1,...,11  *> logs\half_a.log
python $SB\sb_full.py ... --work half_b --only 12,...,22   *> logs\half_b.log
python $SB\merge_halves.py --calib calib.json --blocks blocks.json --out . --xlsx <book>.xlsx half_a half_b
```

> ⚠ **`--work <dir>` does not create the directory, and `sb_full` only writes at the very end.** If
> the directory is missing, the solve runs to completion, prints its whole summary, and *then* dies
> with `FileNotFoundError: <dir>\moves_full.json` — and everything is lost. On a half of a real movie
> that is hours of compute. Create the work directories before you launch, every time.

### 4a. Prove the transcription is complete

```powershell
python $SB\sb_audit.py    --moves moves_full.json --rests rests_full.json    # must print AUDIT CLEAN
python $SB\sb_mapcheck.py --moves moves_full.json ...
```

`sb_audit` checks that every transition has a move whose midpoint lies inside it, that the
transitions-minus-moves gap equals the cross-species joins exactly, and that no two species claim the
same site at rest. `sb_mapcheck` verifies each move's **map** independently of its **timing** — it is
the only check that separates a wrong partition from a right one timed a frame out.

### 5. Probe anything odd

```powershell
python $SB\sb_probe.py --calib calib.json --peaks --sp X0 --axis 0 --f0 447 --f1 466 "--win=0.4,20.6,25.4,27.6"
python $SB\sb_probe.py --calib calib.json --classes ...     # replays the partition read and says why it was rejected
```

`sb_probe` is the tool that does the real work. Its docstring maps each symptom to the rule being
broken. **Without `--win` it profiles the whole panel**, so the outline classes it prints are every
species' at once.

### 6. Readouts and loads, by hand

```powershell
python $SB\sb_extra.py --jobs jobs.json ...     # → extra.json
```

Nothing automatic can see a readout's destination. `sb_extra.py`'s docstring carries the whole recipe
and every trap. **A readout/load row must name the block's position AT the readout** — naming its old
columns leaves half its atoms alive and poisons every later move on that site.

### 7–9. Census, render, score, watch

```powershell
python $SE\se_sim.py <book>.xlsx
python $SE\se_calibtxt.py --calib calib.json --out-txt movie_calib.txt --out-json render_calib.json --render-frames $PWD\rframes --tone-divisor 1
& $SE\render.ps1 -Xlsx <book>.xlsx -OutDir $PWD\rframes -LogCsv $PWD\log.csv -MatchCalib $PWD\movie_calib.txt
python $SB\sb_score.py --movie-calib calib.json --render-calib render_calib.json --out score.txt
python $SB\sb_watch.py --movie-calib calib.json --render-calib render_calib.json --thresh 0.35 --min-run 3
& $SB\sb_video.ps1 -MovieFrames frames -RenderFrames rframes -Calib calib.json -OutPanels panels.mp4 -OutFull full.mp4
```

`sb_watch` scores every `(frame, species, axis)` cell separately, so a short, local disagreement — the
signature of a missing or phantom same-site permutation — is readable instead of hunted for by eye.
**Account for every run of ≥3 frames.** There are exactly four legitimate causes:

1. integer-staging cost on parked reservoir stock (a long flat run at ~0.5 site);
2. a block leaving or entering the panel, where only an edge column is measurable;
3. an occlusion — two blocks on the same sites, the rear one simply not drawn;
4. a crossing, where the profile peaks genuinely merge for a few frames.

Anything else is a defect.

### 10. Deliver

```powershell
python $SB\sb_report.py ...
```

Then **append by hand a section saying which choices were conventions** (readout destinations,
reservoir staging) — the tool cannot know. Say what the audit found, not just that it passed.

---

## 7. Phase B — the handmade correction method

Full text: **`method\handmade correction method.md`**. Read it in full before your first correction
session; what follows is the shape of it.

### The division of labour

| who | does |
|---|---|
| **you, first pass** | read the WHOLE rebuild against the movie's pixels, find every mistake you can, propose the correct move for each with its measured residual, **apply them all without asking**, re-emit, check, render once, deliver a report + a new video |
| **the reviewer** | watches the movie against the NEW video, names the movements still wrong *by frame*, approves or overrides each proposal, declares the movie closed |
| **you, second pass** | for each movement named: check the pixels, propose in a fixed format, **apply only on approval** |

Two rules survive from earlier practice: never silently "improve" a movement the reviewer has
described differently (the pixels decide, and the disagreement goes in the Notes), and never touch
`tools\`.

### The mechanics

1. **Set up a session folder** `run_<movie>_sNN\`. Copy `calib.json`, `blocks.json`, `events.json`,
   `extra.json`, `moves_full.json`, `rests_full.json` from the previous run, **and copy the move and
   rest lists again as `moves_full_<PREV>_original.json` / `rests_full_<PREV>_original.json`.** The
   apply script reads *those*, untouched, so re-running it re-applies the whole correction set from
   scratch. This is what makes the work reproducible in one command.
2. **Find the mistakes, in FRAMES** (frame = `t_ms / dt_ms`; reviewers check frames, not
   milliseconds). Work in this order: anything a previous report left open → `undetermined`
   transitions → moves over the 0.10 guideline → `REPLACES`/`TIE` judgement calls → the hand-measured
   readout/load rows, which are conventions, not defects.
3. **Decide each map by MEASUREMENT**, using `sb_compose.verify` and the free per-frame error, and by
   reading the **outline colour classes** on the first moving frame (each colour is one rigid group;
   its tones there are `src`, at the last frame `dst`). Compare alternatives side by side.
   `method\templates\crop.py` montages a block's region frame by frame when the profile is unclear.
4. **Write each correction into `apply_sNN.py`** — **edit the move list, never the xlsx cells.**
   `Combined`, the AOM colouring and `Notes` are all derived by `sb_emit.emit` from the move list; a
   hand-edited cell makes them drift. Template: `method\templates\apply_s28.py`.
5. **Re-emit, then run the skill's own checks unchanged** (§8).
6. **Render once, at the end** — not once per correction. Launch it detached so a tool timeout cannot
   kill it. Template: `method\templates\deliver_s28.ps1`.
7. **Close** only when the reviewer says so.

### The fixed reply format for a movement the reviewer names

> **Wrong movement between frames A and B** (species, axis, block position)
>
> one paragraph: what the movie shows, what the rebuild shows, the peak evidence
>
> table: the `Schedule` rows the workbook currently has for that window
>
> table: the suggested correct rows — one row per rigid group

Then stop and wait. The reviewer answers "apply your correction" or supplies the map to use.

### Writing a move record by hand — the three things that bite

* **List EVERY tone of the block on the moving axis, static ones as identity** (`src 1:5`,
  `dst 1,4,5,2,3`). With only the moving tones, `verify` charges each static row a full site and your
  correct map reads 0.27–0.43 instead of 0.03–0.15.
* **A move you ADD must also be enumerated in `rests_full.json`**, or `sb_audit` reports it as IDLE.
  Split the transition it hides inside, append a transition and a rest at the frame between, and
  repoint the previous move's `for_tr`.
* **Two motions on the same atoms must not overlap in time.** Clip the corrected move to its
  neighbours; a free fit's easing tails will otherwise run into the next move, and the renderer picks
  atoms up by rounding their position at batch time. The two halves of an exchange must share one
  `t_start`.

---

## 7a. Hunting for a wrong map — the search procedure

§7 tells you to "account for every `sb_watch` run". That is what to look at, not how to search. This
is the search, and it was validated by deliberately corrupting one move in a finished book and
finding it again.

**Why it is needed.** On that test, `sb_audit` said CLEAN, `se_sim` said clean, the render reported
**0 validation entries and "self-consistent"**, and `sb_score` read **0.0440 site** — a good score.
All four passed on a knowingly-broken workbook. `sb_watch` did surface it, but as the 12th of 20 runs,
buried among legitimate crossings and readouts.

```powershell
# 1. shortlist: which same-site permutations have an sb_watch run inside their own window?
python <pkg>\method\templates\find_wrong_maps.py watch.txt moves_full.json
#    on the test: 20 runs, 51 same-site permutations, 9 overlapping -> 9 candidates

# 2. decide: score every rotation of each candidate against the movie's pixels
#    edit CAND with the shortlist, then
python <pkg>\method\templates\score_maps.py > score_maps.txt
#    on the test: 4 flagged, 3 of them the direction degeneracy below, 1 real -> the injected fault
```

For a candidate that is **not** a plain rotation, use `alt_s30.py`, which scores arbitrary maps.

**Three things that will mislead you here.**

* **The direction degeneracy.** A rotation by `k` and a rotation by `n−k` are the same motion run
  backwards, and the free per-frame fit **cannot separate them** — they score identically. The older
  notes mention this only for the involution `k = n/2`; it is true for every `k`. Three of the four
  flags in the test were this. Break the tie on `mean` and `worst`, which do see it, or on the outline
  classes. A real fault loses on everything: the true map read mean 0.0209 / worst 0.099 against the
  book's 0.1190 / 0.845.
* **A mis-encoded log gives a false ALL-CLEAR.** PowerShell's `>` redirect writes UTF-16LE. Read as
  UTF-8 it yields silent garbage, so a parser reports *zero suspicious moves* with no error. That is
  exactly how a broken book gets signed off. `find_wrong_maps.py` sniffs the BOM and refuses to run on
  a file it parsed 0 runs from — keep that behaviour in anything you write.
* **The emitter does not re-verify a hand-edited map.** `mean`/`worst` are copied from the move record
  into the workbook `note`. The corrupted book in the test carried
  *"verified 0.0981 site against every profile peak"* — inherited from the correct map it replaced.
  If you change a map and do not re-measure, the delivered book states a verification that never
  happened. Measure, then write the number you measured.

---

## 8. The checks, and what "closed" means

Run all of these after every apply:

```powershell
python $SB\sb_audit.py --moves moves_full.json --rests rests_full.json      # AUDIT CLEAN, 0 IDLE, 0 SILENT
python $SE\se_sim.py <book>.xlsx                                            # validation clean, census conserved
python $SB\cmp_tol.py ..\run_<movie>_<PREV>\moves_full.json moves_full.json # EXACTLY the intended diffs
```

`cmp_tol` is the important one: replaced maps must show as `MAP DIFFERS`, added moves as "in the NEW
run with no counterpart", and **every other move `matched exactly`**. Anything else means your edit
touched a move it should not have.

After the render: `rframes\` has one PNG per frame, `render_log.csv` has only its header (**0
validation entries**), the score is printed raw, and both mp4s exist.

**None of these can see a same-site permutation.** `validation log entries: 0` means *self-consistent*,
not *complete* — it cannot know about a move you never wrote. That is why a movie is closed by a
human watching the video and saying so, and by nothing else.

A movie is closed when: the reviewer declares it correct; `SESSION_NN_*.md` records what was corrected
with its evidence; the book and both videos are copied to a `closed videos\` folder and added to its
manifest; and the report states plainly **what was measured and what is a convention**.

---

## 9. The 2-AOD family — what changes

Full text: **`method\2AOD_SETUP.md`**. Helper scripts: **`method\2aod_helpers\`**.

The same eight codes exist as 2-AOD movies (`movies\movies_2aod\mitten_codes\`). The machine
**serialises** the cycle — the Z phase runs first, then the X phase — so only one or two blocks are on
screen at a time. **The skill itself is unchanged and must stay unchanged.** Every adaptation lives in
the per-movie input files (`calib.json`, `blocks.json`, `events.json`, `extra.json`).

| | 4-AOD | 2-AOD |
|---|---|---|
| frames | 384 | 559–574 |
| gate runs | 2 frames | 4 frames |
| AOD groups | 4 | **2** |
| species on screen | all four at once | serialised: Z first, then X |
| faded stock | blended 55 % into white | **71 %** (α = 0.288) |
| idle blocks | always solid | **drawn faded in place** — the trap |
| footer | none | `CZ firing: Z0→D1: R(x·s) \| …` — the circuit, gate by gate |

**Do these in order on a new 2-AOD movie:**

1. **Crop the footer on all 24 gate frames first.** It prints the whole circuit in 24 lines and tells
   you which blocks are *supposed* to be idle, so the fades in step 3 are explained before you probe a
   single pixel. `method\2aod_helpers\sheet.py` does the cropping.
2. **If the legend is drawn INSIDE the panel** (it is on c300), every species' mask carries a phantom
   marker at a fixed non-integer row on every frame. Run
   `depaint_legend.py <run> --band 55,88 --ref 10 --x 312,1374` **before `se_calib`**; originals go to
   `frames_raw\`. Re-running `se_calib` on cleaned frames can fail panel detection — keep the original
   `calib.json` and re-run only `fix_lattice_2aod.py` and `fix_calib_2aod.py`.
3. **Always run `fix_calib_2aod.py`.** At a 71 % blend `se_calib`'s fold rule misses, so every faded
   form comes back as an extra *species* — six, not four — and the naming heuristic then mislabels all
   of them. Nothing downstream recovers. Check the legend crop before trusting the result.
4. **Watch for a submultiple pitch.** `se_calib.comb_fit` scores every submultiple of the true pitch
   identically, so on a fine lattice it can settle on p/2 or p/3 on noise alone. It announces itself
   with `!! ring centres do not sit on one comb`. **Do not go past that line** — run
   `fix_lattice_2aod.py <run> --floor 30` and check the printed residual (the bar is 0.18) and the
   data extent against the movie.
5. **A faded block here is usually IDLE, not read out.** The atoms never leave and the rectangle is
   identical before and after. The occupancy test bridges the dark run and enumerates a same-site
   permutation *that does not exist*. Prove each case by probing the faded track on both axes over the
   dark run (the peaks will be frozen to the pixel), name it in `events.json`, and the solver skips it.
   Use `transitions.py <run>` first, every time: it prints every rest and transition **without
   solving**, so you can write `events.json` windows that contain exactly what the solver will see.
6. **Two faded tracks are polluted** — pale pink (X0) sits 22 RGB from the gate tint, pale green (Z1)
   34 RGB from the data-ring grey, both inside the mask tolerance. Use the SOLID track, and read the
   faded track only through a tight `--win`.
7. `skeleton.py <run> --faded` prints where every block sits, interval by interval. Start there.

The recurring 2-AOD faults, in the order they bite: X blocks seeded on screen from t = 0, sometimes on
top of a live Z block; the in-place idle fades; **a departure or arrival the solver never enumerates**
because there is no rest on the far side, so it is in no list at all, not even the undetermined one;
duplicated batches. And the one that has cost the most time: a `load` row must go a tenth of a frame
before the **own fitted start** of the move that first drives the block — never clip the move to the
frame the movie turns it solid.

---

## 10. Driving this with Claude Code

The skill is written to be read by an agent. With `skills\se-cycle-blocks` installed, open Claude Code
in the project and say what you want; it will load `SKILL.md` and follow the procedure. It is also a
perfectly readable human runbook, so nothing here *requires* an agent — but Phase B effectively does,
because it is hours of comparing pixel profiles against workbook rows.

Prompts that work:

* **Starting a movie** — *"Transcribe `SE_cycle_movies\movies_4aod\mitten_codes\se_cycle_c630_d20_C7C18_4aod.mp4`
  into a schedule workbook using the se-cycle-blocks skill. Work in `run_c630\`. Follow the SKILL.md
  procedure end to end, and stop at any step whose check fails."*
* **First hand pass** — *"Apply the handmade correction method (`handmade correction method.md`) to
  `run_c630\`. Do the §2 first pass: find every mistake yourself against the pixels, propose and apply
  them all, re-emit, run the checks, render once, and give me the report and a new video."*
* **A correction the reviewer found** — *"Wrong movement between frames 176 and 184."* The session
  then owes you the §3 fixed-format reply and must wait for approval.
* **Closing** — *"Consider c630 closed and correct."*

Things to tell any agent up front, because they are the mistakes agents make here:

* never modify `tools\`;
* never edit xlsx cells — edit the move list and re-emit;
* always pass `--events` to `sb_full`, and **create the `--work` directory before launching it**;
* `events.json` needs one entry per species of a readout PAIR, not just the one `sb_events` flagged;
* write `.json` inputs with the file-write tool, never `Out-File -Encoding utf8` (BOM);
* redirect long tool output to a log file, never `| Select-Object -First N` (it kills the process);
* `python -u` for anything logged to a file, and set `$env:PYTHONIOENCODING = "utf-8"`;
* an `.xlsx` open in Excel causes `PermissionError` on write;
* render once, at the end, detached.

---

## 11. What is in this folder

```
final tools\
├── movement extraction skill\    ← YOU ARE HERE. Everything needed to do the work.
└── closed videos\                ← the 11 finished movies: workbook + both videos each,
                                    with MANIFEST.md. Worked examples and ground truth.

final tools\movement extraction skill\
├── START HERE.md                 ← READ THIS FIRST. Two pages, plain language.
├── what a session looks like.md  ← a worked-through example conversation, start to finish
├── README.md                     ← this file. The full explainer.
├── RUN_BOOK.md                   ← the one-page command checklist, both families
│
├── skills\
│   ├── se-cycle-blocks\          ← THE skill. SKILL.md + tools\ (22 Python + sb_video.ps1)
│   └── se-cycle-movies\          ← its dependency: calibration, census, renderer
│
├── method\
│   ├── handmade correction method.md   ← Phase B, the standard procedure
│   ├── 2AOD_SETUP.md                   ← the 2-AOD variant
│   ├── 2aod_helpers\                   ← fix_calib_2aod, fix_lattice_2aod, depaint_legend,
│   │                                      skeleton, transitions, sheet, darkruns,
│   │                                      census_2aod, deliver_2aod.ps1
│   └── templates\                      ← copy these into a new session folder:
│       ├── apply_s28.py                   the apply-corrections template (start here)
│       ├── apply_c150_2aod.py             the same, for a 2-AOD movie
│       ├── deliver_s28.ps1                render + score + video, detached
│       ├── dump_sched.py                  print the workbook rows in a time window
│       ├── list_moves.py                  print every move with its frames and mean
│       ├── make_list_s31.py               generate the per-move correction list
│       ├── emit_s31.py                    re-emit the workbook from the move list
│       ├── cmp_full.py                    compare a book against a hand-written one
│       ├── hdr.py                         montage the HEADER strip — step 1's gate-frame check
│       ├── crop.py                        frame-by-frame montage of one block's region
│       ├── find_wrong_maps.py             HUNT STEP 1 — shortlist the moves that could hide
│       │                                    a wrong map (§7a)
│       ├── score_maps.py                  HUNT STEP 2 — decide one against the pixels (§7a)
│       ├── alt_s30.py                     score two arbitrary candidate maps side by side
│       ├── aom_where.py                   find what is driving the AOM peak
│       ├── gaps.py                        per frame, the block's tones with NO marker
│       ├── permscan.py / rotscan.py       rank candidate permutations / rotations
│       ├── lineprof.py                    1-D profile of one line
│       ├── sched_win.py                   schedule rows inside a frame window
│       └── jobs_4aod_example.json         a real sb_extra job spec (4-AOD), for step 6
│
├── worked sessions\              ← the correction method as it was actually run
│   ├── 4aod_c780_s31\            a complete hand-correction session: apply_s31.py, the move
│   │                             lists before and after, the 161 KB per-move correction list,
│   │                             every check output, the solver logs. THE reference.
│   ├── 2aod_c150\                the same for a 2-AOD movie, including the automatic book and
│   │                             the corrected one side by side, and calib.json.se_calib vs
│   │                             calib.json — the clearest illustration of the palette fix
│   └── c540_v3_shayne_handwritten.xlsx
│                                 a HUMAN-written book for c540, made independently of these
│                                 tools. The only external ground truth that exists.
│
└── reference\                    ← how the solver got the way it is, and worked accounts
    ├── SESSION_23_PATCH_ROUTE.md, SESSION_25_C540_ROOT_CAUSE.md,
    │   SESSION_26_PATCH_DETECTOR.md, SESSION_27_LAST_RESORT.md      ← why the solver works as it does
    ├── SESSION_28..32, SESSION_34_*.md                              ← worked hand-correction accounts
    ├── SESSION_32_USER_ITEMS_TO_APPLY.md                            ← a real §3 dialogue, as an example
    └── c540_faults_vs_shayne.md                                     ← automatic book vs the human book
```

**The movies themselves are not in here.** Point the tools at wherever your copy of
`SE_cycle_movies\` lives; nothing depends on its location.

**Reading order for your first day:** this file → watch
`..\closed videos\c150_full_original_vs_rebuild_panels.mp4` (the simplest movie, finished — this is
what a correct rebuild looks like) → `skills\se-cycle-blocks\SKILL.md` §"The rules" and
§"Procedure — A NEW MOVIE, END TO END" → `method\handmade correction method.md` →
`reference\SESSION_31_C780_HAND_CORRECTIONS.md` as a worked example of a full hand pass.

---

## 12. Coverage of the shipped examples

| family | movies | worked through? |
|---|---|---|
| `movies_4aod\mitten_codes` | 8 (c150, c200, c300, c500, c540, c630, c780, c975) | **all 8 finished**, in `..\closed videos\` |
| `movies_2aod\mitten_codes` | 8 (same codes) | **3 finished** (c150, c200, c300), in `..\closed videos\` |
| `movies_4aod\structured_mitten_codes` | 4 (c330, c600, c600_d14, d300) | **none — see the warning below** |
| `movies_2aod\structured_mitten_codes` | 5 | **none — see the warning below** |

> ⚠ **The `structured_mitten_codes` movies are not directly supported.** The whole method was written
> against the `mitten_codes` layout: a particular header line, palette and page position for the
> array. The `structured_mitten_codes` movies print a different header and put the array somewhere
> else, so the **frame-parsing** steps (`se_calib`, the panel detection, the header read for
> `--cycle-ms` and the gate frames) need adapting before anything downstream will work. The data model
> and everything from `sb_blocks` onward applies unchanged. Budget real time for that adaptation, and
> do it the way the 2-AOD family was done: in new per-movie input files and new helper scripts, **not**
> by editing the skill.

Two more things worth knowing about the shipped books:

* **`worked sessions\c540_v3_shayne_handwritten.xlsx` is a human transcription** of the c540 4-AOD movie,
  made independently. It is the only external ground truth here. `reference\c540_faults_vs_shayne.md`
  and `method\templates\cmp_full.py` show how an automatic book was compared against it. Note the trap
  recorded there: **`cmp_full.py` compares displacement *sets* at a time boundary, not maps** — two
  blocks doing different movements with the same set of displacements both read MATCH.
* `skills\se-cycle-movies\examples\m540SEmovesV4.xlsx` is a verified renderable workbook, used above as
  the install test.

---

## 13. The traps, collected

Every one of these cost at least one working session. They are repeated here because they are the
difference between a week and a month.

**Procedure**

* `sb_full` without `--events` is wrong, quietly: an unnamed readout becomes a false relocation and
  the solver fills it with a neighbouring block's move.
* Skipping `sb_blocks.py` silently loses every move of a block that spends an interval off panel.
* `sb_full` writes only at the END of a run. Run long movies in parts.
* A never-enumerated movement is **in no list at all** — not the move list, not the undetermined list.
  There is no rest on the far side, so nothing ever proposed it. Only human eyes or a hand book find
  one, and you should expect at least one per pipelined movie.

**Measurement**

* Judge a hand-written map on the **free per-frame fit and the outline classes**, not on the smoothstep
  `mean`, which over-reads on fast wraps (0.15 where the free error is 0.03).
* On an involution (a rotation by n/2) the free progress `p` is arbitrary between `p` and `1−p`. Not a
  fault.
* A hand-written move must list **every** tone of the block on the moving axis, static ones as
  identity, or `verify` charges each static row a full site.
* `sb_probe --peaks` without `--win` profiles the whole panel.
* **Do not "fix" the other over-0.10 moves** because the count looks bad. On c540, 29 of the 31
  over-guideline moves matched the human book; the two real faults were one at 0.161 and one that had
  no number at all.
* The fill colour **on a pulse frame** is not the palette colour — the gate tint moved c300's Z0 by 77
  RGB, far past the 34 RGB mask tolerance.
* When a frame reading and the pixels disagree, **the pixels decide**, and the disagreement goes into
  the Notes.

**Timing and structure**

* No move crosses a pulse. A move starts on the **FIRST** frame of a pulse run, not the last.
* Two motions on the same atoms must not overlap in time. Clip to the neighbours.
* **Both halves of an exchange must share one `t_start`** — the renderer picks atoms up by position at
  batch time, and a 0.6-frame offset makes every later move on those rows pick up twice its atoms.
* A `load` must precede the rectangle that carries the fresh block off, and a move must not start
  before the movement that delivers its atoms has finished.
* When two blocks of the same species pair move at the same time, check their **maps** match, not just
  their displacement sets — and if they do match, join them on one rectangle (fewer AOMs).
* 0.1–0.6-frame overlaps between a block's consecutive moves inflate the AOM count above the movie's
  AOD number. That is a real fault kind, not noise.

**Re-measure per movie — none of this transfers**

Palette and outline colours, the number of species, the species names, the lattice size, block sizes,
pulse frames, cycle length, whether the movie is pipelined, whether shape discriminates classes, the
reservoir's position **and which side it is on** (it can differ per species within one movie), the
readout's destination **and direction**, the registration bias, `tone_divisor`, and how many rigid
sub-blocks a move has.

**Environment**

* PowerShell 5.1: no `&&`, no ternary; `$s` and `$S` are one variable — that once faked a clean file
  diff on a target 700 files short.
* **Never write a `.json` input with `Out-File -Encoding utf8`.** PowerShell 5.1 writes UTF-8 **with a
  BOM**, and Python then fails with the thoroughly misleading
  `json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)`. Write `events.json`,
  `jobs.json` and `blocks.json` with an editor, with an agent's file-write tool, or with
  `[System.IO.File]::WriteAllText($p, $s)`.
* **Do not pipe a tool into `Select-Object -First N`** to shorten its output — closing the pipe kills
  the Python process (exit 255) and you lose the rest of the run. Redirect to a file
  (`*> logs\x.log`) and read the file.
* `python -u` for anything logged to a file; `$env:PYTHONIOENCODING = "utf-8"`.
* An `.xlsx` open in Excel → `PermissionError` on write.
* ffmpeg 9 wants `-fps_mode passthrough`, not `-vsync`.
* ffmpeg is not on PATH in a fresh shell; the deliver scripts add it.
* Launch the render detached (`Start-Process … -WindowStyle Hidden`) so a tool timeout cannot kill it,
  and poll the log.
