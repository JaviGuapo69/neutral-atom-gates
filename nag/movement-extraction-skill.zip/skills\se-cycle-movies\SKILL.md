---
name: se-cycle-movies
description: Translate between an SE-cycle movie (.mp4 of a syndrome-extraction cycle on a neutral-atom quantum computer, atoms shuttled by crossed AODs) and its schedule workbook (.xlsx with Constants/Seed/Schedule/Gates). Use for transcribing such a movie into a schedule, rendering a schedule back into frames, or checking that one matches the other.
---

# SE-cycle movies ⇄ schedule workbooks

```
   movie.mp4      ──► frames ──► workbook.xlsx     "transcribe"   Python
   workbook.xlsx  ──► frames ──► movie.mp4         "render"       PowerShell
```

> **New here? Read `OPERATOR.md` first.** It is the two-page path from "I have been handed an mp4"
> or "I have been handed an xlsx" to a finished, checked answer, with the environment checks and
> the four traps that actually catch people. Come back here for the detail.

`reference/SE_CYCLE_REBUILD_GUIDE.md` is the normative document — the physics, the data model, the
tone-list grammar, the easing profile and the validation checks. **Read part I before making any
judgement call**, and in particular before deciding that something the tools flagged is fine. This
file is the operating procedure.

**Requirements.** PowerShell 5.1, `ffmpeg`, and Python 3.12 with `numpy scipy pillow openpyxl`.
Note that `python` on a stock Windows box is the Microsoft Store stub and silently does nothing —
`tools\se_pipeline.ps1` finds a real interpreter through the `py` launcher, and so should you.

---

## The one thing to understand before running anything

A schedule row means: **the atoms resting on rectangle `x_start × y_start` at `t_start` travel to
rectangle `x_finish × y_finish`, arriving at `t_finish`.** A rectangle is the full Cartesian
product of two frequency combs — `x = 13:24, y = 19:27` is 12 × 9 = 108 traps, never an arbitrary
set of sites. **Species belongs to the atom, not to the row**: a `move` row picks atoms up by
POSITION only and does not consult the `species` column. Rows may overlap in time, are grouped into
batches by identical `t_start`, and are **not** in time order in the sheet.

Two consequences that cost earlier sessions a great deal of time:

* **Every row of a batch sees the state BEFORE the batch.** The renderer collects all the pick-ups
  first and only then writes the new positions, so two rows in one batch cannot chain.
* **A `load` takes effect after its batch's moves**, so a load must sit in a strictly earlier batch
  than the move that carries the batch in.

---

## Quickest path: the driver

```powershell
# movie -> workbook, and score the round trip
tools\se_pipeline.ps1 -Movie <in.mp4> -Work run1 -Xlsx out.xlsx -CycleMs 11.74 -RoundTrip

# workbook -> movie only
tools\se_pipeline.ps1 -Xlsx in.xlsx -Work run2 -OutMovie out.mp4 -MatchMovie <reference.mp4>
```

`-CycleMs` is **printed in the movie's own header** (`t 0.00/11.74 ms` on frame 0) — read it off the
frame, do not fit it. Without it everything still works but times come out in frame units.

The stages below are what the driver runs; run them by hand when something needs inspecting.

---

## Task A — transcribe: movie → workbook

### A1. Frames

```powershell
ffmpeg -y -v error -i <movie>.mp4 -fps_mode passthrough -start_number 0 frames\p_%03d.png
```

Uncropped — `se_calib.py` finds the array panel itself.

### A2. Calibrate, and READ THE REPORT

```powershell
python tools\se_calib.py --frames frames --out calib.json --cycle-ms 11.74
```

It measures the panel, the lattice (from the empty-site **rings** only — they exist at data sites
and nowhere else, which is what makes them immune to staging columns half a pitch off the lattice),
the palette, the species names, the marker offset and the gate frames.

**Check three lines before going on. An error here is silent and everything downstream inherits it.**

| line | what it must say |
|---|---|
| `worst ring residual` | under about 0.02 site. Higher means the lattice fit is wrong. |
| `data extent` | the array size you can count on screen. |
| `species colours : N` | the number of species the movie actually draws. |

A species count that is too high usually means a faded variant was taken for a species of its own;
the tool now merges those and says so (`... is the faded form of ... -- merged`). Too low means the
palette sampling missed one — inspect a frame.

### A3. Extract markers

```powershell
python tools\se_extract.py --calib calib.json --out marks.csv
```

One row per marker per frame, in **continuous** sub-site units, with `solid`/`faded` state.
Continuous is the point: an atom between sites reads 7.43, and that fractional part is the evidence
every later stage runs on.

**Check the last line**: `solid markers per frame: min .. median .. max`. The **max** should equal
the number of atoms the array holds. If the max exceeds it, something is being double-counted; if
the median is far below it, detection is failing. Dips mid-move are expected and harmless —
adjacent markers merge while a block translates (guide §4.2).

### A4. Decompose

```powershell
python tools\se_moves.py --calib calib.json --marks marks.csv --out-prefix sheet
```

Segments the cycle into batches, fits each batch's timing and displacements, and composes rows a
renderer can execute from the seed forward. It prints a **self-check** run through `se_sim.py`,
which is a line-by-line transcription of `render.ps1`:

```
self-check : 323 rows -> 723 atoms ever alive, 9944 motions, validation CLEAN
```

`CLEAN` means the sheet is self-consistent — no `check1`/`check3`/`check4`. Anything else is a
defect in the output, not in the renderer, and is listed immediately below that line.

**Then read `sheet_notes.txt`.** It records everything the tool could not decide, and it prints
rather than guesses. The important categories:

| it says | what it means |
|---|---|
| *split at frame N* | a window held more than one batch. |
| *the fit did not name a motion for N atoms; paired by distance* | the fit was incomplete there; the atoms are conserved but the pairing is a guess. |
| *left where they are and nothing is written* | the movie lost sight of some atoms and there was not enough evidence to call it a transport. **Nothing was invented.** |
| *carried out of the array for measurement* | a readout. Note its warning that the displacement itself is **not determined** — the block leaves the panel, so several (displacement, duration) pairs describe the visible motion equally well. |
| *arrive from the ... reservoir* | a fresh batch. Its rectangle is mostly off-screen and is a **documented convention**, not a measurement — see below. |

### A5. Emit

```powershell
python tools\se_emit.py --out wb.xlsx --constants sheet_constants.csv --seed sheet_seed.csv `
    --schedule sheet_schedule.csv --gates sheet_gates.csv
```

---

## Task B — render: workbook → movie

```powershell
tools\render.ps1 -Xlsx wb.xlsx -OutDir out -LogCsv log.csv [-MatchCalib match.txt]
ffmpeg -y -v error -framerate 8 -i out\p_%03d.png -vf "pad=ceil(iw/2)*2:ceil(ih/2)*2" -pix_fmt yuv420p out.mp4
```

`validation log entries: 0` means the workbook is self-consistent. Non-zero is a real defect:

* `check1` — a row's start and finish tone counts differ.
* `check3` — a row picked up a different number of atoms than its rectangle has sites. Fewer means
  a motion the schedule is missing; **more means two atoms are stacked on one trap**, which is
  always a bookkeeping error upstream.
* `check4` — two rows in one batch claim the same atom.

To draw on a movie's own geometry so the two line up frame for frame:

```powershell
python tools\se_calibtxt.py --calib calib.json --out-txt match.txt `
    --out-json render_calib.json --render-frames out --tone-divisor 1
```

`render.ps1` chooses its own palette and marker shapes (guide II.3 — style is free and carries no
meaning). Do not read anything into a colour or a shape differing from the movie's.

---

## Task C — score it

Two tests. Run both; they fail differently.

**Against the movie** — the real acceptance test, and the one to lead with:

```powershell
python tools\se_score.py --xlsx wb.xlsx --calib calib.json --marks marks.csv
```

It compares the workbook's *simulated* atom positions with the movie's *detected* markers at every
frame, matched species by species and state by state. Read `PAIRED-ATOM RMS` and
`solid markers unexplained` first. This needs no rendering and looks at all 384 frames, not just
the couple of dozen where the array happens to be at rest.

**Against another workbook** — for asking whether two sheets are the same schedule:

```powershell
python tools\se_equiv.py --a reference.xlsx --b wb.xlsx
```

It simulates both and compares them as pictures, on screen only, converting tone grids so a sheet
counting data sites and one counting half-pitch tones are still comparable. **Never diff two
workbooks row by row** — the division of a batch into rows is not unique, `move` and `slot` are
provenance with no semantics, and two workbooks that move the same atoms are the same workbook.

There is also `se_compare.py`, which extracts the render's own frames and compares at held frames.
It is the strictest end-to-end check but it is slow and it only ever looks at the frames where the
whole array is at rest — 22 of c540's 384.

---

---

## Task C2 — the four checks, and why no three of them are enough

Run **all** of these on any transcription before you believe it. Each one catches a failure the
others cannot see, and every one of them has, at some point in this project, passed on a workbook
that was badly wrong.

```powershell
python tools\se_sim.py wb.xlsx                                   # validation + census
python tools\se_divergence.py --xlsx wb.xlsx --calib calib.json --marks marks.csv
python tools\se_repack.py --in-xlsx wb.xlsx --out-xlsx packed.xlsx
python tools\se_aom.py --xlsx packed.xlsx --max-aom 8
python tools\se_score.py --xlsx wb.xlsx --calib calib.json --marks marks.csv
```

| check | must read | what ONLY it catches |
|---|---|---|
| `se_sim.py` validation | `clean` | a row picking up the wrong number of atoms, two rows claiming one atom |
| `se_sim.py` census | `never short` | a readout retiring fewer atoms than its block holds, off screen |
| **`se_divergence.py`** | **`0 mislabelled site-frames`** | **the sheet has the right atoms in the right places wearing the WRONG SPECIES** |
| `se_aom.py` on a **repacked** sheet | `VIOLATIONS: none` | a schedule no machine can execute |
| `se_score.py` | RMS, unexplained | positions and timing |
| **a render, watched** | — | **two atoms stacked on one trap** (see way 7 below) |

**`se_score.py`'s headline numbers are the least trustworthy of these.** Twice now they have
preferred the worse sheet: c150's divisor-2 run scored RMS 0.92 against 1.98 while missing 58
atoms, and c150 v6 scored 66 % of atom-frames within 0.15 site against v9's 48 % while carrying
1374 mislabelled site-frames and needing 33 AOM groups. Read `solid markers unexplained` and
`frames fully explained` before RMS, and read census and divergence before either.

The sheet that passed all of the above — c150 v9 — renders **32 of 32 held frames exactly**, while
v6, which scored better on RMS-within-0.15, managed 25/32 with 5.5 phantom and 5.5 mislabelled per
held frame. The checks in this table are ordered by how much they told us, and RMS is last.

---

## Task D — classify by AOM, and check the hardware can run it

A schedule says which atoms move where. It does not say **which device carries them**, and that is
what an engineer programming the machine needs. `se_aom.py` assigns every row to an AOM trap group
— one crossed pair of deflectors, an x comb and a y comb — checks the assignment is physically
possible, and writes it out in the column layout the hand-written reference sheet uses.

```powershell
python tools\se_aom.py --xlsx wb.xlsx --max-aom 8 --emit aom_layout.xlsx --report feas.txt
```

Four checks, in the order they matter:

| check | rule |
|---|---|
| tone counts | a row's start and finish lists are the same length (guide I.6) |
| non-crossing | a row's own tone map is strictly increasing (guide I.2) |
| comb merge | two rows on ONE group agree wherever their combs overlap, and the merged map is still increasing |
| **atom capture** | merging rows onto one group makes its comb the full product of the unions, creating traps **outside** the rectangles those rows named. An atom belonging to another group standing on one of those traps would be held by two combs at once. |

Atom capture is the one that needs the simulator: it has to know where every atom actually is at
the instant the batch begins, so the state comes from `se_sim`.

**Repack `slot` first, or the peak is meaningless.** Which rows share a crossed pair is decided by
the sheet's `slot` column, and `se_moves.py` writes `slot` as a **running counter** — one value per
row. Read literally that is one AOM group per row, so `peak concurrent AOM groups` comes out as
nothing but the largest batch's *row count*. c150's automatic sheet reported **39**; packed it
needs 33; the correct schedule needs **4**. c540's v11 reported 31 the same way. Shayne's V3
escaped it only because its `slot` genuinely *is* the AOM index. `se_aom.py` now warns when it sees
a counter — do what it says:

```powershell
python tools\se_repack.py --in-xlsx auto.xlsx --out-xlsx packed.xlsx   # also clamps negative times
python tools\se_aom.py --xlsx packed.xlsx --max-aom 8
```

**Then read `peak concurrent AOM groups` against your budget.** A batch needing more groups than
the machine has is almost always a failure upstream, not a hardware limit: either a run of short
batches collapsed into one window so sequential motions read as simultaneous, or the fit gave up
and emitted **one row per site**. Dump the offending batch before you believe the hardware is the
problem — if its rows carry many different displacements, that is the signature. c150's worst batch
held 39 rows with 38 different displacements, of which exactly one was a real rectangle; c540's
v11 needed 31 groups where the correct schedule needs 2.

A useful sanity bound: on these movies **every species at rest is exactly one rectangle**, so a
correct batch never needs more groups than there are species. Four species means four groups.

## Eight ways to be confidently wrong

1. **A faded block is nearly invisible to these checks.** A block taken for measurement is drawn
   desaturated. `se_score.py` matches faded to faded so it does see them, but the readout's
   destination is off the panel and unobservable — do not treat a difference there as an error.
2. **Occupancy mid-move is not evidence.** Counts like `108, 94, 0, 0, 0, 108` during a translation
   are the sampling artefact of markers merging, not missing atoms.
3. **A batch boundary usually falls BETWEEN frames.** c540's move 14 begins at frame 66.9. So there
   is often no frame at which every atom reads as on-grid, and a run of short permutation batches
   can hide inside one window whose end-to-end fit still looks good. That is why `se_moves.py`
   splits any window longer than a measured limit whether or not the fit complains.
4. **The reservoirs are half a pitch off the lattice.** A fresh batch is generated on the AOD's own
   comb: c540's side stock sits at x = 24.50 and 25.46, its top stock at y = −0.47 and +0.51. Only
   one or two rows or columns are ever on screen. The convention here — the only invented geometry
   in the output, and flagged in every `note` — is to round such a block onto the integer grid
   **away from the array** and extend it off-screen to the width the carrying move needs. On c540
   that gives columns 25:36 and rows −8:0, which is what the hand-written reference workbook says.
5. **A block that is mostly off screen gets sized from the part you can see — and nothing tells
   you.** This is rule 4's failure mode and it cost a whole session. c540's automatic v11 sized the
   fresh Z batch as `25:35` because the panel shows only two of its twelve columns, sized the fresh
   X batch as `-6:0` for the same reason, and retired a parked block with `25 x 19:27` when the
   block is `25:36 x 19:27` — retiring 9 atoms of 108 and leaving 99 alive to be dragged back in
   later as though they were the fresh batch. That workbook still rendered with
   `validation log entries: 0`, still passed every `check1`/`check3`/`check4`, and still scored
   84.9 % of atom-frames within 0.15 site — because **every atom involved is off screen at the
   moment it goes missing**, so neither the renderer nor a score against the movie can see it. It
   ran the last third of the cycle with holes in every block, and needed 31 AOM groups in one batch
   to paper over the result.

   **The guard is `se_sim.census()`**, printed by `python tools\se_sim.py <wb>`:

   ```
   census: never short of 432 atoms -- conserved across every readout
   ```

   A species is measured and replaced, so the live population returns to the seed count after every
   readout. A **deficit** is the defect. A **surplus** is not — a block being read out is still
   descending, drawn faded, and legitimately coexists with its replacement for the length of that
   descent. Run this before trusting any transcription. Never conclude a workbook is sound from a
   clean render and a good score alone: those two agreed with each other and were both wrong.

6. **A BLOCK CROSSING THE EDGE OF THE PANEL CORRUPTS SPECIES IDENTITY, NOT JUST POSITION.** This is
   the big one found on c150, and it is worse than a lost block. Only on-screen atoms take part in
   the fit. When a block is carried off the left edge the extractor keeps 5 of its 30 atoms, and
   the fit would have to send 25 atoms to nowhere to explain it — so it takes the cheaper reading
   and re-pairs the arrivals onto whatever sources are nearest, which are **another species' atoms
   standing where the departing block used to be**. Because `move` rows pick up by POSITION, those
   mislabelled atoms are then swept along by every later row and the error compounds forward.

   c150's automatic sheet diverged from the movie at **frame 54** and carried **1374 mislabelled
   site-frames**, two of four readouts never written, 38 per-site fragment rows in one batch, and a
   demand for 33 AOM groups where 4 suffice — all from this one cause. `validation` was clean and
   `census` said *never short*, because the atom count was conserved the whole time; only the
   labels were swapped.

   **The guard is `se_divergence.py`.** It is the cheapest check in the kit. If it reports anything
   but zero, do not tune thresholds — `MIN_BLOCK = 8` in `se_moves.py` makes a block with fewer
   than 8 atoms visible structurally invisible as a readout, at any setting, and there is no flag
   for it. Rebuild with **`se_waypoints.py`**, which reads each species' resting rectangle from the
   pixels at every step and never inherits identity. Read its header before using it.

7. **TWO ATOMS ON ONE TRAP PASS EVERY CHECK AND ONLY SHOW UP AS A SHORT RENDER.** A set of rows can
   be individually legal — matching tone counts, non-crossing, no two rows claiming one atom — and
   still stack atoms, because **a site no row mentions stays put while another row moves onto it**.
   c150's lifted move 2 mapped rows 11→13, 12→14, 14→15, 15→12 and never moved 13, so row 13 ended
   up holding two atoms. `check1`, `check3`, `check4` and `census` all passed. The only symptom:
   two atoms draw as one marker, so `se_compare.py` reported **11 missing, 0 phantom, 0
   mislabelled** per held frame — everything the sheet drew was right, it just drew too few.

   So `0 phantom / 0 mislabelled / N missing` at held frames is the fingerprint of stacking, not of
   a lost block. Whenever you compose a permutation of a block onto its own site set, check the row
   set is a **bijection** on that block's sites; `se_waypoints.py` does this and rejected 9 of 11
   candidate row sets on c150.

8. **A permutation onto a block's own site set needs TWO rows, and the at-rest frames cannot say
   which two.** One rectangle can never reorder itself — guide I.2 fixes the tone order for the
   whole motion, so its map is strictly increasing — so these are two sub-rectangles swapping
   (`1:3 → 4:6` together with `4:6 → 1:3`). They are the CZ gate pairings and there are many: 40
   windows on c150, against 29 net moves. The block leaves the tone grid and returns to the same
   sites, so only a mid-window pixel fit can recover the split. `se_waypoints.py` reports every
   such window by frame range and writes nothing for it unless `--lift` can supply a fitted, and
   bijective, row set. **A schedule that is silent about these is still correct about every
   position it asserts** — but it is not the whole cycle, and it will score worse on close
   positional agreement than a sheet that guesses, because the blocks sit parked while the movie
   shuffles them.

## What a correct answer is allowed to look like

A transcription that says "a block moves here, and its off-screen destination is not recoverable"
is correct. One that fabricates a plausible destination is not. The tools print what they could not
decide; pass that on rather than deleting it.

---

## Files

| | |
|---|---|
| `OPERATOR.md` | **start here** — the short path for someone handed one artefact and asked for the other |
| `reference/SE_CYCLE_REBUILD_GUIDE.md` | the normative rules, both directions |
| `tools/se_pipeline.ps1` | runs either direction end to end |
| `tools/se_calib.py` | panel, lattice, palette, species, gate frames → `calib.json` |
| `tools/se_extract.py` | matched-filter marker detection → continuous positions |
| `tools/se_moves.py` | segmentation, per-batch fit, and composition into rows |
| **`tools/se_waypoints.py`** | **the other transcriber.** Reads each species' resting rectangles from the pixels instead of propagating identity forward. Use it when `se_divergence.py` is non-zero — see way 6 |
| **`tools/se_divergence.py`** | **run this early.** Does the sheet agree with the movie about which species is where? The only check that sees a labelling cascade |
| **`tools/se_repack.py`** | clamps negative times and turns `slot` into a real AOM index. **Run before `se_aom.py`** on any auto-transcribed sheet |
| `tools/se_emit.py` | the four CSVs → `.xlsx` |
| `tools/se_sim.py` | an exact Python replica of `render.ps1`'s semantics; the composer's conscience |
| `tools/se_score.py` | workbook vs movie, every frame. **Not the last word** — see Task C2 |
| `tools/se_aom.py` | classify a schedule by AOM trap group, check it is executable, emit the AOM-column layout |
| `tools/se_equiv.py` | are two workbooks the same schedule? |
| `tools/se_compare.py` | render vs movie at held frames |
| `tools/se_calibtxt.py` | `calib.json` → `render.ps1 -MatchCalib`, and a calibration for the render |
| `tools/render.ps1` | **the proven renderer.** Workbook → frames. Do not modify it. |
| `tools/writexlsx.ps1` | minimal .xlsx writer |
| `examples/m540SEmovesV4.xlsx` | a known-good workbook |

Install check:

```powershell
tools\render.ps1 -Xlsx examples\m540SEmovesV4.xlsx -OutDir t -LogCsv t.csv
# expect: seeded 432 atoms ... 11556 motions ... validation log entries: 0
python tools\se_sim.py examples\m540SEmovesV4.xlsx
# expect: 864 atoms ever alive, 221 rows, 11556 motions, validation: clean
#         census: never short of 432 atoms -- conserved across every readout
python tools\se_aom.py --xlsx examples\m540SEmovesV4.xlsx --max-aom 8
# expect: peak concurrent AOM groups 6, VIOLATIONS: none  (V4's `slot` IS an AOM index, so no
#         repack warning here -- an auto-transcribed sheet will warn, and should be repacked)
```

**Finding a working Python.** `python` on a stock Windows box is the Microsoft Store stub, and even
a real 3.12 may be missing a dependency — on this machine the one on PATH lacks `pillow` while
`%LOCALAPPDATA%\Programs\Python\Python312\python.exe` has everything. `se_pipeline.ps1` probes the
`py` launcher for an interpreter that can `import numpy,scipy,PIL,openpyxl`; do the same rather than
trusting `python --version`. `ffmpeg` likewise is usually installed but not on PATH:

```powershell
$env:Path += ";$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.1-full_build\bin"
```

**Do not pipe these scripts through `Select-Object -First n`.** It terminates the upstream pipeline,
and the script is killed before it writes its output files — it will look like it ran. Redirect to
a file with `> out.txt 2>&1` and read that.

Always pass an **absolute** `-OutDir`: `Bitmap.Save` resolves a relative path against .NET's working
directory, not PowerShell's, and silently writes nothing.
