# Operator guide — read this first, then SKILL.md

You have been handed one of two things. Find yours and follow that column. Nothing else in this
folder is required reading before you start.

| you were given | you must produce | go to |
|---|---|---|
| a `.mp4` of an SE cycle | a `.xlsx` schedule workbook | **Part A** |
| a `.xlsx` schedule workbook | a `.mp4` | **Part B** |

`SKILL.md` is the detailed runbook and `reference/SE_CYCLE_REBUILD_GUIDE.md` is the normative
description of the physics and the file format. This page is the short path plus the traps that
have actually caught people.

---

## 0. Check the machine first (2 minutes, saves hours)

```powershell
python --version                      # need 3.12 with numpy scipy pillow openpyxl
python -c "import numpy,scipy,PIL,openpyxl; print('deps ok')"
ffmpeg -version                       # need ffmpeg on PATH
```

Two things that go wrong here and produce baffling symptoms later:

* **`python` on a stock Windows box is the Microsoft Store stub.** It exits silently having done
  nothing. If `python --version` prints nothing, find the real one with `py -0p` and use its full
  path everywhere.
* **ffmpeg may not be on PATH** even when installed. If `ffmpeg -version` fails, look under
  `%LOCALAPPDATA%\Microsoft\WinGet\Packages` for `ffmpeg.exe` and add its folder to `$env:Path`.

Then confirm the tools themselves work, using the known-good example that ships with the skill:

```powershell
python tools\se_sim.py examples\m540SEmovesV4.xlsx
```

Expect **exactly** this: `864 atoms ever alive, 221 rows, 11556 motions`, `validation: clean`,
and `census: never short of 432 atoms`. Anything else means the install is wrong, not the workbook.

---

## Part A — movie → workbook

One command does the whole thing:

```powershell
tools\se_pipeline.ps1 -Movie <in.mp4> -Work run1 -Xlsx out.xlsx -CycleMs <N>
```

`-CycleMs` is **printed in the movie's own header** — frame 0 says something like `t 0.00/11.74 ms`.
Read it off the frame. Do not fit it, do not guess it. Without it everything still runs but your
times come out in frame units instead of milliseconds.

The pipeline caches: frame extraction and marker detection are slow, and re-running the composer
over one extraction is the normal working loop. Add `-Force` to redo a cached stage.

### The four things you must read before believing the output

**1. The calibration report.** An error here is silent and everything downstream inherits it.

| line | must say |
|---|---|
| `worst ring residual` | under ~0.02 site |
| `data extent` | the array size you can count on screen |
| `species colours` | the number of distinct atom colours the movie draws |

**2. The tone-divisor block.** If you see

```
*** WARNING: this movie parks blocks off the data lattice and tone_divisor 1
*** cannot express where they are.
```

then **stop and act on it**. These movies park blocks in staging areas offset by half a data pitch,
just outside the array. A workbook counting whole data sites cannot say where those blocks are, so
every move that starts or ends in one is silently lost — and the workbook still renders clean while
doing it. Re-run with the divisor it recommends and keep whichever scores better:

```powershell
tools\se_pipeline.ps1 -Movie <in.mp4> -Work run2 -Xlsx out_d2.xlsx -CycleMs <N> -ToneDivisor 2
```

**3. The self-check line** from the composer: `validation CLEAN`. Anything else is a defect in the
output, and the offending rows are listed right below it.

**4. `<prefix>_notes.txt`.** This is the honest part of the output — everything the tool could not
decide, written out instead of guessed. Read it before trusting any row. In particular
*"left where they are and nothing is written"* means the movie lost sight of some atoms and no
transport was invented; that is a correct answer, not a bug.

### Then run all five checks. No four of them are enough.

```powershell
python tools\se_sim.py out.xlsx                                          # validation + census
python tools\se_divergence.py --xlsx out.xlsx --calib run1\calib.json --marks run1\marks.csv
python tools\se_repack.py --in-xlsx out.xlsx --out-xlsx packed.xlsx      # BEFORE se_aom
python tools\se_aom.py --xlsx packed.xlsx --max-aom 8
python tools\se_score.py --xlsx out.xlsx --calib run1\calib.json --marks run1\marks.csv
```

**`se_divergence.py` must read `0 mislabelled site-frames`.** This is the check to run first and
the one most likely to fail. It asks whether the sheet agrees with the movie about *which species
is where* — and a sheet can have every atom in the right place wearing the wrong label. Nothing
else sees it: validation is clean, census says *never short* (the count is conserved, only the
labels swapped), and the score just looks mediocre for no stated reason.

The cause is always the same: **a block crossing the edge of the panel.** The extractor keeps 5 of
its 30 atoms, and rather than send 25 atoms off-screen the fit re-pairs the arrivals onto another
species' atoms standing where the departing block used to be. On c150 that produced 1374
mislabelled site-frames from frame 54, lost two of four readouts, and demanded 33 AOM groups where
4 suffice.

**If it is non-zero, do not tune thresholds.** `MIN_BLOCK = 8` in `se_moves.py` makes a block with
fewer than 8 atoms visible structurally invisible as a readout, at any setting, and there is no
flag. Transcribe again with the other tool, which reads resting rectangles from the pixels and
never inherits identity:

```powershell
python tools\se_waypoints.py --calib run1\calib.json --marks run1\marks.csv `
    --out-prefix wp --lift run1\sheet_schedule.csv
```

Read its header first — it is a page, and it explains what it will and will not recover.

**`se_repack.py` before `se_aom.py`, always.** `se_aom.py` groups rows by the sheet's `slot`, and
`se_moves.py` writes `slot` as a running counter, so the reported peak AOM groups is just the
largest batch's row count. c150's automatic sheet reported 39 where the correct schedule needs 4.

* **`PAIRED-ATOM RMS`** — under ~0.3 site is good, under 0.1 is excellent.
* **`census`** — must say *never short*. A **deficit** means a readout retired fewer atoms than its
  block holds, or a fresh batch was created too small. Both happen off screen, so **neither the
  renderer nor the score can see them.** This is the single most expensive mistake in this project's
  history: a workbook once passed every check and scored well while quietly running the last third
  of its cycle with 51 atoms missing. A **surplus** is fine — a block being read out is still
  descending while its replacement exists.

### Optionally, classify it by AOM

If someone has to program the hardware from your workbook:

```powershell
python tools\se_aom.py --xlsx out.xlsx --max-aom 8 --emit aom_layout.xlsx --report feas.txt
```

`VIOLATIONS: none` means every batch is executable. A batch demanding more AOM groups than the
machine has is almost always a **segmentation error upstream** — a run of short moves collapsed
into one window so that sequential motions read as simultaneous — not a hardware limit.

---

## Part B — workbook → movie

```powershell
tools\se_pipeline.ps1 -Xlsx <in.xlsx> -Work run3 -OutMovie out.mp4
```

That is the whole job. Check the renderer's last line says **`validation log entries: 0`**.

If you were also given the original movie and want a side-by-side that lines up frame for frame,
add `-MatchMovie <ref.mp4>`; the pipeline will then also extract the render, compare at held frames
and build the comparison. **This needs the movie→workbook direction to have been run into the same
`-Work` directory first**, because the comparison needs the movie's calibration.

Three things not to be alarmed by:

* **The colours, marker shapes and canvas size will not match the original.** Style is free and
  carries no meaning (guide II.3). The workbook stores the *schedule*, not the drawing.
* **The original may carry annotation tables, headers and watermarks** that the render has no way
  to know about. Compare the array panel, not the whole frame.
* **The original draws reservoir stock faded from frame 0**; a workbook only creates that stock when
  it loads it. Roughly 9 unexplainable faded markers per frame on c540 is expected and harmless.

`validation log entries` is the only number that must be zero:

* `check1` — a row's start and finish tone counts differ.
* `check3` — a row picked up a different number of atoms than its rectangle has sites. Fewer means
  a missing motion; **more means two atoms stacked on one trap**, always a bookkeeping error.
* `check4` — two rows in one batch claim the same atom.

---

## The model, in the five sentences you cannot work without

1. A schedule row says: **the atoms resting on rectangle `x_start × y_start` at `t_start` travel to
   `x_finish × y_finish`, arriving at `t_finish`.** That is the entire semantics.
2. A rectangle is the **full Cartesian product** of two tone lists — `x = 13:24, y = 19:27` is
   12 × 9 = 108 traps, never an arbitrary set of sites, never an L-shape or a hole.
3. **Species belongs to the atom, not to the row.** A `move` row picks up by POSITION only and does
   not consult the `species` column.
4. Rows are grouped into **batches by identical `t_start`**, batches run in time order, and **every
   row of a batch sees the state BEFORE the batch** — two rows in one batch cannot chain. Rows are
   *not* in time order in the sheet.
5. **Atoms are not conserved**: a species is measured (`unload`) and replaced (`load`). A `load`
   must sit in a strictly earlier batch than the move that carries it in.

## Six ways to be confidently wrong

1. **A faded block is nearly invisible to every check.** A block taken for measurement is drawn
   desaturated and travels off the panel. Its destination is unobservable; do not treat a difference
   there as an error, and do not invent a plausible one.
2. **Occupancy mid-move is not evidence.** Counts like `108, 94, 0, 0, 0, 108` during a translation
   are markers merging, not missing atoms. Compare at rest, or compare continuous positions.
3. **A batch boundary usually falls BETWEEN frames** (c540's move 14 starts at frame 66.9), so there
   is often no frame where the whole array reads as on-grid. A detector that waits for a clean frame
   never fires.
4. **A block that is mostly off screen gets sized from the part you can see.** See the census
   warning in Part A. This is the one that hides. The fix is to size it by its **known population**
   instead: measure each species' block once from a frame where it is wholly visible, and thereafter
   extend a short rectangle *away from the edge that cuts it* — then verify by checking that the
   number of the full rectangle's sites inside the window equals the markers actually seen.

5. **A block crossing the panel edge scrambles species labels, not just positions**, and only
   `se_divergence.py` sees it. See Part A above. This is the most expensive failure in the project
   after the census one, and it is *silent* in every other check.

6. **Two atoms on one trap pass every check and only show up as a short render.** A row set can be
   individually legal and still stack atoms, because a site no row mentions stays put while another
   row moves onto it. Two atoms then draw as one marker, so `se_compare.py` reports
   `N missing, 0 phantom, 0 mislabelled` — everything drawn is right, there is just too little of
   it. **That exact fingerprint means stacking, not a lost block.** Any permutation of a block onto
   its own site set must be checked as a bijection on that block's sites.

## What a correct answer is allowed to look like

A transcription that says *"a block moves here, and its off-screen destination is not recoverable"*
is **correct**. One that fabricates a plausible destination is not. The tools print what they could
not decide — pass that on rather than deleting it.
