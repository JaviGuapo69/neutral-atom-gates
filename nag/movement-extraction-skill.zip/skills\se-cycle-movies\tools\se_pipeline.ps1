<#
  se_pipeline.ps1 -- run one whole direction end to end.

  MOVIE -> WORKBOOK          .\se_pipeline.ps1 -Movie <in.mp4> -Work <dir> -Xlsx <out.xlsx> -CycleMs 11.74
  WORKBOOK -> MOVIE          .\se_pipeline.ps1 -Xlsx <in.xlsx> -Work <dir> -OutMovie <out.mp4> [-MatchMovie <ref.mp4>]
  BOTH, and score the round trip:
                             .\se_pipeline.ps1 -Movie <in.mp4> -Work <dir> -Xlsx <out.xlsx> -CycleMs 11.74 -RoundTrip

  Everything is written under -Work.  Stages already done are skipped unless -Force, because frame
  extraction and marker detection are the slow parts and you will want to re-run the composer many
  times over one extraction.

  -CycleMs is the total cycle time printed in the movie's own header ("t 0.00/11.74 ms").  Read it
  off frame 0; it is printed, not something to fit.  Without it, times come out in frame units and
  the workbook still renders correctly, but its numbers will not be in milliseconds.
#>
param(
  [string]$Movie,
  [string]$Xlsx,
  [Parameter(Mandatory=$true)][string]$Work,
  [double]$CycleMs = 0,
  [string]$OutMovie,
  [string]$MatchMovie,
  [string]$CompareTo,                  # a reference workbook to score against with se_equiv.py
  [switch]$RoundTrip,
  [switch]$Force,
  [int]$ToneDivisor = 0,
  [string]$Python,
  [string]$FFmpeg
)
$ErrorActionPreference = 'Stop'
[System.Threading.Thread]::CurrentThread.CurrentCulture = [System.Globalization.CultureInfo]::InvariantCulture

# ---------------------------------------------------------------- locate the tools
$T = $PSScriptRoot
if (-not $Python) {
  # `python` on a stock Windows box is the Microsoft Store stub, which exits without running
  # anything.  Ask the py launcher for a real interpreter instead.
  $cands = @()
  try { $cands += (& py -0p) -replace '^\s*-V:[^\s]+\s*\*?\s*','' } catch {}
  $cands += "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"
  $cands += "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe"
  foreach ($c in $cands) {
    $c = "$c".Trim()
    if ($c -and (Test-Path $c)) {
      try { & $c -c "import numpy,scipy,PIL,openpyxl" 2>$null; if ($LASTEXITCODE -eq 0) { $Python = $c; break } } catch {}
    }
  }
  if (-not $Python) { throw "no Python with numpy/scipy/pillow/openpyxl found. Pass -Python <path\to\python.exe>." }
}
if (-not $FFmpeg) {
  $g = Get-Command ffmpeg -ErrorAction SilentlyContinue
  if ($g) { $FFmpeg = $g.Source }
  else {
    $w = "$env:LOCALAPPDATA\Microsoft\WinGet\Packages"
    if (Test-Path $w) {
      $hit = Get-ChildItem $w -Filter ffmpeg.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($hit) { $FFmpeg = $hit.FullName }
    }
  }
  if (-not $FFmpeg) { throw "ffmpeg not found. Pass -FFmpeg <path\to\ffmpeg.exe>." }
}
$FFprobe = Join-Path (Split-Path $FFmpeg) 'ffprobe.exe'
"python : $Python"
"ffmpeg : $FFmpeg"

$Work = (New-Item -ItemType Directory -Force $Work).FullName
function Step($name) { "" ; "=== $name" }
function Need($path) { return ($Force -or -not (Test-Path $path)) }

# ================================================================ movie -> workbook
if ($Movie) {
  $Movie = (Resolve-Path $Movie).Path
  $frames = Join-Path $Work 'frames'
  $calib  = Join-Path $Work 'calib.json'
  $marks  = Join-Path $Work 'marks.csv'
  $pfx    = Join-Path $Work 'sheet'

  Step "frames"
  if (Need (Join-Path $frames 'p_000.png')) {
    New-Item -ItemType Directory -Force $frames | Out-Null
    & $FFmpeg -y -v error -i $Movie -fps_mode passthrough -start_number 0 (Join-Path $frames 'p_%03d.png')
  }
  $n = (Get-ChildItem $frames -Filter *.png).Count
  "frames on disk: $n"

  Step "calibrate"
  if (Need $calib) {
    $a = @('--frames', $frames, '--out', $calib)
    if ($CycleMs -gt 0) { $a += @('--cycle-ms', "$CycleMs") }
    & $Python (Join-Path $T 'se_calib.py') @a
  } else { "cached: $calib" }

  Step "extract markers"
  if (Need $marks) { & $Python (Join-Path $T 'se_extract.py') --calib $calib --out $marks }
  else { "cached: $marks" }

  Step "decompose into a schedule"
  $a = @('--calib', $calib, '--marks', $marks, '--out-prefix', $pfx)
  if ($ToneDivisor -gt 0) { $a += @('--tone-divisor', "$ToneDivisor") }
  & $Python (Join-Path $T 'se_moves.py') @a

  Step "emit workbook"
  if (-not $Xlsx) { $Xlsx = Join-Path $Work 'workbook.xlsx' }
  & $Python (Join-Path $T 'se_emit.py') --out $Xlsx --constants "${pfx}_constants.csv" `
      --seed "${pfx}_seed.csv" --schedule "${pfx}_schedule.csv" --gates "${pfx}_gates.csv"
  "workbook: $Xlsx"

  if ($CompareTo) {
    Step "score against $CompareTo"
    & $Python (Join-Path $T 'se_equiv.py') --a $CompareTo --b $Xlsx --label-a reference --label-b transcribed
  }
  if ($RoundTrip -and -not $OutMovie) { $OutMovie = Join-Path $Work 'roundtrip.mp4' }
  if ($RoundTrip -and -not $MatchMovie) { $MatchMovie = $Movie }
}

# ================================================================ workbook -> movie
if ($OutMovie) {
  if (-not $Xlsx) { throw "-OutMovie needs -Xlsx" }
  $Xlsx = (Resolve-Path $Xlsx).Path
  $rdir = Join-Path $Work 'render'
  New-Item -ItemType Directory -Force $rdir | Out-Null

  $matchTxt = $null
  if ($MatchMovie) {
    # Draw on the reference movie's own geometry, so the two line up frame for frame and the same
    # extractor can read both.
    $mcal = Join-Path $Work 'calib.json'
    if (-not (Test-Path $mcal)) { throw "-MatchMovie needs a calibration; run the movie -> workbook direction first" }
    $matchTxt = Join-Path $Work 'match.txt'
    $tdiv = 1
    $cfile = Join-Path $Work 'sheet_constants.csv'
    if (Test-Path $cfile) {
      $row = Import-Csv $cfile | Where-Object { $_.key -eq 'tone_divisor' }
      if ($row) { $tdiv = [int]$row.value }
    }
    & $Python (Join-Path $T 'se_calibtxt.py') --calib $mcal --out-txt $matchTxt `
        --out-json (Join-Path $Work 'render_calib.json') --render-frames $rdir --tone-divisor $tdiv
  }

  Step "render"
  # Splat a HASHTABLE, not an array.  PowerShell binds an array splat POSITIONALLY, so
  # @('-Xlsx', $x, '-OutDir', $d, '-LogCsv', $l) put the literal string '-LogCsv' into render.ps1's
  # [int]$Pitch and the whole direction failed at the first call.  Named binding needs a hashtable.
  $ra = @{ Xlsx = $Xlsx; OutDir = $rdir; LogCsv = (Join-Path $Work 'render_log.csv') }
  if ($matchTxt) { $ra['MatchCalib'] = $matchTxt }
  & (Join-Path $T 'render.ps1') @ra

  Step "assemble"
  # libx264 rejects odd frame heights, hence the pad.
  & $FFmpeg -y -v error -framerate 8 -i (Join-Path $rdir 'p_%03d.png') `
      -vf "pad=ceil(iw/2)*2:ceil(ih/2)*2" -pix_fmt yuv420p $OutMovie
  "movie: $OutMovie"

  if ($MatchMovie) {
    Step "score the render against the movie, at held frames"
    $rcal = Join-Path $Work 'render_calib.json'
    $rmarks = Join-Path $Work 'render_marks.csv'
    & $Python (Join-Path $T 'se_extract.py') --calib $rcal --frames $rdir --out $rmarks
    & $Python (Join-Path $T 'se_compare.py') --reference (Join-Path $Work 'marks.csv') `
        --candidate $rmarks --out (Join-Path $Work 'compare.csv')

    Step "side by side"
    $sbs = [System.IO.Path]::ChangeExtension($OutMovie, $null) + 'side_by_side.mp4'
    & $FFmpeg -y -v error -framerate 8 -i (Join-Path $Work 'frames\p_%03d.png') `
        -framerate 8 -i (Join-Path $rdir 'p_%03d.png') `
        -filter_complex "[0:v]pad=ceil(iw/2)*2:ceil(ih/2)*2[a];[1:v]pad=ceil(iw/2)*2:ceil(ih/2)*2[b];[a][b]hstack=inputs=2,pad=ceil(iw/2)*2:ceil(ih/2)*2" `
        -pix_fmt yuv420p $sbs
    "side by side: $sbs"
  }
}
"" ; "done."
