"""sb_gaps.py -- the PATCH DETECTOR feeding the PRODUCTION solver (session 26, 2026-09-15).

WHAT THIS IS.  Rest-frame occupancy (`sb_build.settled`) is the default enumerator and stays so.
It structurally cannot see a movement that drives a proper SUB-COMB of a block -- two of twelve
columns moving leave the block's profile "at rest" -- and on c540 that is ten hand-book movements
that appear in no list at all (`c540_faults_vs_shayne.md` 2.2).  `sb_patch.patch_movements`
(session 23, the user's patch model) CAN see them, because the marker OUTLINE colour names the
comb the batch drives (rule 44).  But the patch route's own maps, windows and scores were not good
enough to ship: its window is the AOM ring's visibility, not the motion; it reads each species'
band separately; its tunables were calibrated on one segment.

So the division of labour here is:

    the PATCH ROUTE answers  WHERE occupancy missed a movement, and on WHICH LINES;
    the PRODUCTION machinery answers  WHAT map and WHEN -- peaks restricted to the detected comb
    (`sb_build.SubPeaks`), the transition read rest-to-rest ON THE SUB-COMB, the same candidate
    routes (`partition`, `measured_partition`, `rotation_candidates`, the S2.1 rotations of the
    measured moving run), the same `fit_timing` and the same `verify`.

THE GATES, each of which is what keeps c150/c200/c300 unchanged (they contain no sub-comb move):

    1. the detected comb must be a STRICT subset of the block's extent on the static axis;
    2. during the motion window NOTHING OUTSIDE that comb may leave its tones (rule 40, measured
       with `sb_build.sub_comb`) -- a whole-block move seen through a partial colour is not a gap;
    3. no existing move may already explain it: a move of the same species and axis whose
       sub-comb contains this comb and overlaps it in frames, or a whole-block move whose window
       contains the detection's midpoint (rule 29's midpoint test);
    4. the winning candidate must score <= ACCEPT (0.10) on the MOVING frames.  The best of a bad
       set is not an answer (session 25, c540 f093-095).

Every move written here carries `from_patch_detector=True`, `sub_comb_lines`, and a synthetic
transition is appended to the rest record so `sb_audit` can account for it.
"""
import numpy as np

import sb_read, sb_compose, sb_build, sb_rigid, sb_patch
from sb_read import comb

PAD = 3            # frames of slack around the detected patch window for the sub-comb read
MIN_MOVING = 1     # moving frames the sub-comb must show inside the window


# ===================================================================== 1. detect
def detections(M, wins, outlines, frames, blocks):
    """sub-comb patch groups: [(sp, axis, comb, f0, f1, n_patches)] from the patch route's detector.

    Only the DETECTOR is used (which species, which axis, which lines, roughly when).  Patches of one
    batch -- the two rigid groups of a rotation carry two colours -- are grouped on (species, axis,
    comb) with overlapping frames, exactly as `sb_patch.batches` groups them.
    """
    pmv, dropped, _tr = sb_patch.patch_movements(M, wins, outlines, frames)
    groups = {}
    for p in pmv:
        sp = p["sp"]
        if sp not in blocks:
            continue
        ax = 0 if p["axis"] == "cols" else 1
        w, h = blocks[sp]
        full = h if ax == 0 else w                 # the block's extent on the STATIC axis
        cb = tuple(sorted(p["comb"]))
        if len(cb) >= full:
            continue                               # gate 1: a whole-block move is occupancy's job
        groups.setdefault((sp, p["axis"], cb), []).append(p)
    out = []
    for (sp, axis, cb), ps in sorted(groups.items()):
        ps.sort(key=lambda p: p["f0"])
        clusters = []
        for p in ps:
            for c in clusters:
                if min(c[-1]["f1"], p["f1"]) - max(c[-1]["f0"], p["f0"]) >= -1:
                    c.append(p)
                    break
            else:
                clusters.append([p])
        for c in clusters:
            out.append(dict(sp=sp, axis=axis, comb=list(cb), f0=min(p["f0"] for p in c),
                            f1=max(p["f1"] for p in c), n=len(c),
                            colours=sorted({tuple(p["colour"]) for p in c})))
    return out, pmv


def explained(g, moves):
    """gate 3: does an existing move already account for this detection?"""
    mid = (g["f0"] + g["f1"]) / 2.0
    for m in moves:
        if g["sp"] not in (m.get("joins") or [m["sp"]]) or m["axis"] != g["axis"]:
            continue
        lines = m.get("sub_comb_lines")
        if lines:
            if set(g["comb"]) <= set(lines) and min(m["f1"], g["f1"]) - max(m["f0"], g["f0"]) >= 0:
                return m
        elif m["f0"] <= mid <= m["f1"]:
            return m
    return None


# ===================================================================== 2. solve on the sub-comb
def _tones_from_rests(rests, sp, axis, f):
    """the species' tone set on `axis` from the LAST rest ending at or before f (else the first)."""
    rr = (rests.get(sp) or {}).get("rests") or []
    idx = 2 if axis == 0 else 3
    before = [r for r in rr if r[1] <= f]
    if before:
        return sorted(before[-1][idx]), before[-1]
    return (sorted(rr[0][idx]), rr[0]) if rr else (None, None)


def solve_gap(M, wins, blocks, rests, runs, ivs, f0, f1, outlines, g, notes, moves=(), ex=None):
    """one detection -> a verified move on its sub-comb, or None (with the reason in `notes`)."""
    sp, axis = g["sp"], 0 if g["axis"] == "cols" else 1
    win = wins[sp]
    keep = (1 - axis, tuple(g["comb"]))
    tag = "%s %s f%03d-%03d on %s" % (sp, g["axis"], g["f0"], g["f1"], comb(g["comb"]))

    iv = sb_rigid.interval_of(ivs, g["f0"], g["f1"])
    if iv is None:
        iv = next((v for v in ivs if v[0] <= g["f0"] <= v[1] or v[0] <= g["f1"] <= v[1]), None)
    if iv is None:
        notes.append("[gap] %s: not inside one pulse-free interval -- skipped" % tag)
        return None
    plo, phi = sb_rigid.pulse_bounds(runs, *iv)
    a, b = max(iv[0], g["f0"] - PAD), min(iv[1], g["f1"] + PAD)
    # CLAMP TO THE NEIGHBOURING MOVES OF THE SAME SPECIES AND AXIS (production's `sub_window`
    # bounds).  A pipelined movie chains batches back to back, so the slack either side of a
    # detection reaches into the previous or next movement; read there and the "outside" lines
    # appear to move (they do -- in the OTHER batch) and gate 2 refuses a real gap.  c540's Z1 on
    # {14,20} at f207-214 follows the whole-block rotation f200-208 by one frame.
    mid = (g["f0"] + g["f1"]) / 2.0
    # A MOVE ON THE SAME COMB IS A COMPETITOR, NOT A NEIGHBOUR.  Production can fit one batch
    # twice (c540_faults_vs_shayne.md 2.4: X1's {17,23} rotation for X1's transition and again for
    # Z0's); clamping to the duplicate cut the read window to four frames and the detector's
    # candidate scored 0.20 where the same read over the batch's own window scores 0.03.
    nb = [m for m in moves if m is not ex and sp in (m.get("joins") or [m["sp"]])
          and m["axis"] == g["axis"]
          and set(m.get("sub_comb_lines") or ()) != set(g["comb"])]
    blo = max([int(round(m["fb"])) for m in nb if m["fb"] <= mid] or [a])
    bhi = min([int(m["fa"]) for m in nb if m["fa"] >= mid] or [b])
    a, b = max(a, blo), min(b, bhi)
    ff = [f for f in range(a, b + 1) if f not in M.gate and f0 <= f <= f1]
    if len(ff) < 3:
        return None
    Psub = sb_build.SubPeaks(M, wins, keep, ff)

    S_rest, rest_rec = _tones_from_rests(rests, sp, axis, g["f0"])
    if not S_rest:
        notes.append("[gap] %s: no rest record for the species -- skipped" % tag)
        return None
    n = len(S_rest)

    def off(f):
        pk = Psub(sp, f, axis)
        return bool(pk) and max(abs(v - round(v)) for v in pk) > sb_compose.TOL_ONGRID

    def on_full(f):
        pk = Psub(sp, f, axis)
        return len(pk) == n and max(abs(v - round(v)) for v in pk) <= sb_compose.TOL_ONGRID

    moving = [f for f in ff if off(f)]
    if len(moving) < MIN_MOVING:
        notes.append("[gap] %s: the sub-comb never leaves its tones in f%03d-f%03d -- skipped"
                     % (tag, ff[0], ff[-1]))
        return None
    m0, m1 = moving[0], moving[-1]

    # gate 2 (rule 40): the lines OUTSIDE the detected comb must stay on their tones meanwhile
    other_all = sorted(rest_rec[3] if axis == 0 else rest_rec[2])
    outside = [t for t in other_all if t not in g["comb"]]
    if outside:
        moving_lines = sb_build.sub_comb(M, sp, win, axis, outside,
                                         [f for f in ff if m0 <= f <= m1])
        if moving_lines:
            notes.append("[gap] %s: lines %s OUTSIDE the detected comb also leave their tones in "
                         "f%03d-f%03d -- not a sub-comb gap, left to occupancy" % (tag, comb(moving_lines), m0, m1))
            return None

    # the transition on the sub-comb: one settled frame each side of the motion (rule 16)
    before = [f for f in ff if f < m0 and on_full(f)]
    after = [f for f in ff if f > m1 and on_full(f)]
    S = sorted({int(round(v)) for v in Psub(sp, before[-1], axis)}) if before else S_rest
    S2 = sorted({int(round(v)) for v in Psub(sp, after[0], axis)}) if after else S
    if len(S) != n or len(S2) != n:
        S, S2 = S_rest, S_rest
    t0 = before[-1] if before else max(ff[0], m0 - 1)
    t1 = after[0] if after else min(ff[-1], m1 + 1)
    rd = [f for f in ff if t0 <= f <= t1]
    fit_ff = [f for f in ff if t0 - 1 <= f <= t1 + 1]
    if len(rd) < 3:
        rd = [f for f in ff if m0 - 1 <= f <= m1 + 1]
        fit_ff = rd
    if len(rd) < 3:
        notes.append("[gap] %s: only %d frames to read -- skipped" % (tag, len(rd)))
        return None
    lo, hi = max(plo, t0 - 1.0), min(phi, t1 + 1.0)
    if hi - lo < 3.0:
        lo, hi = plo, phi

    # ---------------- candidates, the production routes on the sub-comb
    tries = []
    part, sub = sb_build.partition(M, sp, win, axis, rd, outlines, [], S2, keep, len(other_all))
    if part and not (len(part) == 1 and set(part[0][0]) >= set(S)):
        part2, ok = sb_build.complete_partition(part, S, S2)
        if ok:
            tries.append((part2, "appearance triple on the detected sub-comb"))
    for r in (sb_build.measured_partition(Psub, M, sp, axis, S, S2, rd) or [])[:6]:
        tries.append((r["parts"], "measured displacements on the detected sub-comb"))
    ra = sb_build.rotation_amount(Psub, sp, axis, S, rd)
    if ra:
        for rot in sb_build.rotation_candidates(S, S2, [ra[2], -ra[1]]):
            tries.append((rot, "counted rotation on the detected sub-comb"))
    mt = sb_build.moving_tones(Psub, M, sp, axis, S, rd) if S == S2 else None
    if mt and mt[0]:
        for run in sb_build.candidate_runs(mt[0], S):
            for rot in sb_build.rotations_of(run, S):
                tries.append((rot, "rotation of the measured moving run %s on the detected "
                                   "sub-comb" % comb(run)))
    if not tries:
        notes.append("[gap] %s: motion f%03d-f%03d on the sub-comb, but no candidate route produced "
                     "a map -- left UNDETERMINED" % (tag, m0, m1))
        return dict(undetermined=dict(sp=sp, f0=t0, f1=t1, kind="permutation" if S == S2
                                      else "relocation", comb=g["comb"], axis=g["axis"]))

    best = None
    for parts, how in tries:
        src = [v for p in parts for v in p[0]]
        dst = [v for p in parts for v in p[1]]
        if len(src) != len(dst) or src == dst:
            continue
        if sorted(src) != S or sorted(dst) != S2:
            continue
        if len(set(src)) != len(src) or len(set(dst)) != len(dst):
            continue
        order = np.argsort(src)
        src = [src[i] for i in order]; dst = [dst[i] for i in order]
        ft = sb_build.fit_timing(Psub, M, sp, axis, src, dst, fit_ff, lo, hi)
        if ft is None:
            continue
        m, fa, fb = ft
        prog = [float(sb_read.smoothstep((f - fa) / (fb - fa))) for f in fit_ff]
        if max(prog) - min(prog) < sb_build.MIN_SPAN:
            continue
        mvf = [f for f in fit_ff if off(f)]
        mm = sb_compose.verify(Psub, sp, axis, src, dst, fa, fb, mvf, M)[0] if mvf else m
        if mm != mm:
            mm = m
        _, w, _ = sb_compose.verify(Psub, sp, axis, src, dst, fa, fb, fit_ff, M)
        cand = (mm, m, w, fa, fb, src, dst, parts, how)
        if best is None or mm < best[0]:
            best = cand
    if best is None:
        notes.append("[gap] %s: %d candidate(s), none fitted -- left UNDETERMINED" % (tag, len(tries)))
        return dict(undetermined=dict(sp=sp, f0=t0, f1=t1, kind="permutation" if S == S2
                                      else "relocation", comb=g["comb"], axis=g["axis"]))
    mm, m, w, fa, fb, src, dst, parts, how = best
    rows = []
    for a2, b2 in ((list(p[0]), list(p[1])) for p in parts):
        for gg in sb_build.split_by_displacement(a2, b2):
            if gg[1][0] - gg[0][0] != 0:
                rows.append((list(gg[0]), list(gg[1])))
    if not rows:
        return None
    text = " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in rows)
    if mm > sb_compose.ACCEPT:
        notes.append("[gap] %s: best candidate %s scores %.4f on the moving frames, over the %.2f "
                     "guideline -- NOT written, left UNDETERMINED (gate 4)"
                     % (tag, text, mm, sb_compose.ACCEPT))
        return dict(undetermined=dict(sp=sp, f0=t0, f1=t1, kind="permutation" if S == S2
                                      else "relocation", comb=g["comb"], axis=g["axis"]))
    kind = "permutation" if S == S2 else "relocation"
    notes.append("[gap] %s: occupancy saw no transition here; the patch detector named the comb, "
                 "the sub-comb read gives %s f%03d-%03d (%s), mean %.4f, moving-frame mean %.4f, "
                 "%d candidates" % (tag, text, t0, t1, how, m, mm, len(tries)))
    mv = dict(for_tr=[sp, t0, t1], sp=sp, axis=g["axis"], kind=kind,
              f0=fit_ff[0], f1=fit_ff[-1], iv=list(iv), parts=rows, src=src, dst=dst,
              A=rows[0][0], A2=rows[0][1],
              B=[v for gg in rows[1:] for v in gg[0]], B2=[v for gg in rows[1:] for v in gg[1]],
              fa=round(fa, 3), fb=round(fb, 3), lo=lo, hi=hi,
              t0=round(fa * M.dt, 4), t1=round(fb * M.dt, 4),
              mean=round(m, 4), mean_moving=round(mm, 4), n_moving=len([f for f in fit_ff if off(f)]),
              worst=round(w, 3), mono=0.0, span=1.0, joins=[sp], detail={}, comb=list(g["comb"]),
              how="PATCH DETECTOR + production solver: the outline colour named the sub-comb %s "
                  "(rule 44); the map and timing were read on peaks restricted to it -- %s"
                  % (comb(g["comb"]), how),
              sub_comb_lines=list(g["comb"]), from_patch_detector=True,
              ok=bool(m <= sb_compose.ACCEPT))
    # the synthetic transition, so the rest record and sb_audit account for this move
    xs, ys = sorted(rest_rec[2]), sorted(rest_rec[3])
    tr = dict(sp=sp, f0=t0, f1=t1, kind=kind, source="patch-detector",
              x0=S if axis == 0 else xs, x1=S2 if axis == 0 else xs,
              y0=S if axis == 1 else ys, y1=S2 if axis == 1 else ys)
    return dict(move=mv, transition=tr, Psub=Psub, ff=fit_ff, off=off)


# ===================================================================== 3. fill the gaps
def fill(M, wins, blocks, rests, runs, ivs, f0, f1, outlines, moves, undet, verbose=True):
    """detect sub-comb batches occupancy missed and solve each with the production routes.

    Returns (new_moves, still_undetermined, notes, n_detections).  `moves` and `rests` are updated
    in place (moves appended, synthetic transitions appended to the rest record).
    """
    notes = []
    frames = [f for f in range(f0, f1 + 1) if f not in M.gate]
    dets, pmv = detections(M, wins, outlines, frames, blocks)
    if verbose:
        print("   patch detector: %d patch movement(s), %d sub-comb group(s)" % (len(pmv), len(dets)))
    new = []
    for g in dets:
        ex = explained(g, moves)
        if ex is not None and not ex.get("sub_comb_lines"):
            # a WHOLE-BLOCK move of this species contains the detection's midpoint: occupancy saw
            # the movement and read it on the full block.  Not a gap.
            notes.append("[gap] %s %s f%03d-%03d on %s: already explained by the whole-block move "
                         "%s %s f%03d-%03d"
                         % (g["sp"], g["axis"], g["f0"], g["f1"], comb(g["comb"]),
                            "+".join(ex.get("joins") or [ex["sp"]]), ex["axis"], ex["f0"], ex["f1"]))
            continue
        got = solve_gap(M, wins, blocks, rests, runs, ivs, f0, f1, outlines, g, notes, moves, ex)
        if not got or "move" not in got:
            continue
        mv, tr = got["move"], got["transition"]
        if ex is not None:
            # A SUB-COMB MOVE ALREADY EXISTS HERE (production's rule-40 path found it).  Compete on
            # the SAME peak source over the SAME frames (rule 42): the detection's read replaces it
            # only if it is under the guideline and strictly better.  c540's {17,23} batch is the
            # case -- production wrote X1 `19:22->24:27 | 23:27->19:23` at 0.2276 where the hand
            # book (and the pixels, session 23) have `19:23->23:27 | 24:27->19:22`.
            Psub, ff, off = got["Psub"], got["ff"], got["off"]
            ax = 0 if mv["axis"] == "cols" else 1
            union = sorted(set(ff) | {f for f in range(ex["f0"], ex["f1"] + 1)
                                      if f not in M.gate and f0 <= f <= f1})
            mvf = [f for f in union if off(f)]
            try:
                s_ex = sb_compose.verify(Psub, mv["sp"], ax, ex["src"], ex["dst"], ex["fa"],
                                         ex["fb"], mvf or union, M)[0]
                s_new = sb_compose.verify(Psub, mv["sp"], ax, mv["src"], mv["dst"], mv["fa"],
                                          mv["fb"], mvf or union, M)[0]
            except Exception:
                continue
            same = (ex["src"], ex["dst"]) == (mv["src"], mv["dst"])
            if same or not (s_new == s_new) or s_new > sb_compose.ACCEPT \
                    or not (s_ex != s_ex or s_new < s_ex - 0.01):
                notes.append("[gap] %s %s f%03d-%03d on %s: %s existing sub-comb move %s f%03d-%03d "
                             "(%s, %.4f on the moving frames) is KEPT against the detector's %s "
                             "(%.4f)" % (mv["sp"], mv["axis"], g["f0"], g["f1"], comb(g["comb"]),
                                         "the same map;" if same else "",
                                         ex["sp"], ex["f0"], ex["f1"],
                                         " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in ex["parts"]),
                                         s_ex, " | ".join("%s->%s" % (comb(s), comb(d))
                                                          for s, d in mv["parts"]), s_new))
                continue
            notes.append("[gap] %s %s f%03d-%03d on %s: existing sub-comb move %s f%03d-%03d %s "
                         "scores %.4f on the moving frames; the detector's read %s scores %.4f on "
                         "the same peaks and frames -- REPLACED"
                         % (mv["sp"], mv["axis"], g["f0"], g["f1"], comb(g["comb"]), ex["sp"],
                            ex["f0"], ex["f1"],
                            " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in ex["parts"]), s_ex,
                            " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in mv["parts"]), s_new))
            mv["replaces"] = [ex["sp"], ex["f0"], ex["f1"]]
            moves[moves.index(ex)] = mv
            new.append(mv)
            # BOOKKEEPING FOR sb_audit: the production transition `ex` was fitted for is now
            # described by the detector's move over the sub-comb's own window, so swap the
            # transition too -- drop the one `ex` carried (its `for_tr`) and append the synthetic
            # one.  Left as it was, the audit reports the old transition as a SILENT HOLE and the
            # new move as IDLE, which is the same batch counted twice as a fault.
            ft = ex.get("for_tr")
            tl = rests.setdefault(mv["sp"], dict(rests=[], transitions=[]))["transitions"]
            if ft:
                tl[:] = [t for t in tl if not (t["sp"] == ft[0] and t["f0"] == ft[1]
                                               and t["f1"] == ft[2])]
            tl.append(tr)
            if verbose:
                print("     [gap] %-3s %-4s f%03d-%03d  %-30s comb %-10s mean %.4f (moving %.4f) %s"
                      " REPLACES %s f%03d-%03d"
                      % (mv["sp"], mv["axis"], mv["f0"], mv["f1"],
                         " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in mv["parts"]),
                         comb(mv["comb"]), mv["mean"], mv["mean_moving"],
                         "OK" if mv["ok"] else "OVER 0.10", ex["sp"], ex["f0"], ex["f1"]))
            continue
        # the same batch may be detected through two colours with slightly different windows
        if any(q["sp"] == mv["sp"] and q["axis"] == mv["axis"] and q["src"] == mv["src"]
               and q["dst"] == mv["dst"] and min(q["f1"], mv["f1"]) - max(q["f0"], mv["f0"]) >= 0
               for q in new + moves):
            continue
        moves.append(mv); new.append(mv)
        rests.setdefault(mv["sp"], dict(rests=[], transitions=[]))["transitions"].append(tr)
        if verbose:
            print("     [gap] %-3s %-4s f%03d-%03d  %-30s comb %-10s mean %.4f (moving %.4f) %s"
                  % (mv["sp"], mv["axis"], mv["f0"], mv["f1"],
                     " | ".join("%s->%s" % (comb(s), comb(d)) for s, d in mv["parts"]),
                     comb(mv["comb"]), mv["mean"], mv["mean_moving"],
                     "OK" if mv["ok"] else "OVER 0.10"))
    # ONE BATCH, ONE MOVE: two sub-comb moves of one species on the same comb with overlapping
    # windows are one movement fitted twice (c540_faults_vs_shayne.md 2.4 -- production wrote X1's
    # {17,23} rotation for X1's transition AND again for Z0's).  Keep the better-scoring one.  Only
    # sub-comb moves take part, so a movie with none (c150/c200/c300) is untouched.
    drop = set()
    subs = [m for m in moves if m.get("sub_comb_lines")]
    for i in range(len(subs)):
        for j in range(i + 1, len(subs)):
            p, q = subs[i], subs[j]
            if p["sp"] != q["sp"] or p["axis"] != q["axis"] or \
                    set(p["sub_comb_lines"]) != set(q["sub_comb_lines"]):
                continue
            if min(p["fb"], q["fb"]) - max(p["fa"], q["fa"]) < 1.0:
                continue
            loser = q if p["mean_moving"] <= q["mean_moving"] else p
            winner = p if loser is q else q
            drop.add(id(loser))
            notes.append("[gap] %s %s: %s f%03d-%03d (%.4f) and f%03d-%03d (%.4f) on comb %s are one "
                         "batch fitted twice -- the lower-scoring %s f%03d-%03d is dropped"
                         % (p["sp"], p["axis"], p["sp"], p["f0"], p["f1"], p["mean_moving"],
                            q["f0"], q["f1"], q["mean_moving"], comb(p["sub_comb_lines"]),
                            loser["sp"], loser["f0"], loser["f1"]))
    if drop:
        # the dropped duplicate's own transition goes with it -- the batch is described by the
        # winner -- or sb_audit reports it as a SILENT HOLE (session 26, X1 f236-238)
        for m in moves:
            if id(m) in drop and m.get("for_tr"):
                ft = m["for_tr"]
                tl = rests.get(m["sp"], {}).get("transitions", [])
                tl[:] = [t for t in tl if not (t["sp"] == ft[0] and t["f0"] == ft[1]
                                               and t["f1"] == ft[2])]
        moves[:] = [m for m in moves if id(m) not in drop]
        new = [m for m in new if id(m) not in drop]
    # an undetermined occupancy transition that a new move now covers (midpoint test) is resolved
    still = []
    for t in undet:
        if any(t["sp"] == mv["sp"] and t["f0"] <= (mv["f0"] + mv["f1"]) / 2.0 <= t["f1"]
               for mv in new):
            notes.append("%s %s f%03d-%03d: was UNDETERMINED; now described by a patch-detector "
                         "sub-comb move" % (t["sp"], t["kind"], t["f0"], t["f1"]))
            continue
        still.append(t)
    moves.sort(key=lambda m: (m["fa"], m["fb"]))
    return new, still, notes, len(dets)
