"""sb_rigid.py -- APPEARANCE-DRIVEN movement recognition.  Session 11 final method.

THE RULE (normative, from the user):

    Atoms sharing the triple (SHAPE, FILL COLOUR, OUTLINE COLOUR) and moving at a given frame
    move AS ONE RIGID BODY.  In general only the triple moves rigidly.

    Two such groups may happen to perform the SAME motion, in which case one AOM can drive both --
    and when that is possible IT MUST BE DONE, to keep the structure as simple as possible.

So there is nothing to search for.  A move is read in three steps:

    1. CLASSIFY   partition the moving markers by the appearance triple
    2. MEASURE    each class is rigid, so it has ONE displacement -- read it
    3. MERGE      fuse classes with identical motion onto one AOM.  Mandatory, not optional.

This replaces the candidate-partition search in sb_compose.py, which solved a harder problem than
the physics poses and got it wrong (see SB_COMPOSE_OPEN_BUG.md).  It also dissolves the "crossing"
difficulty entirely: two sub-blocks merge into one profile peak only when they share the colour
being profiled -- i.e. only when you profile the shared FILL.  Profile the classes and they stay
separated on every frame, including where the fill profile collapses.

Measured on c150 Z0 f029-036, where the fill profile drops from 6 peaks to 3:

    mauve rgb(152,123,184)   f030 [1.031 3.011 5.016] -> f035 [1.971 3.955 5.973]   cols 1,3,5  D=+1
    gold  rgb(246,187,70)    f030 [1.959 3.983 5.971] -> f035 [1.011 3.036 5.019]   cols 2,4,6  D=-1

Three clean peaks per class on every frame.  No search, no clustering, no crossing analysis.
"""
import argparse, json, os, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sb_read
from sb_read import Movie, comb, discover_outlines, smoothstep

MIN_CLASS_AREA = 150       # px: below this an outline colour is noise, not a class
RIGID_TOL = 0.15           # site: max spread of member displacements within one class
SHAPE_SPLIT = 0.35         # relative area gap that would indicate two SHAPES in one colour class
MOVE_MIN = 0.45            # site: below this a class did not move


# ===================================================================== the appearance triple
def marker_areas(M, colour, win, f, xs, ys):
    """per-marker pixel area, for the SHAPE component of the triple.

    Shape is the third component and it is the one this project ignored until the end of session
    11.  On c150 it turned out not to discriminate within a species (Z0 126.9 +/- 5.5, Z1 129.4
    +/- 3.5, and the two rigid groups of Z0's f029-036 move indistinguishable at 127.4 vs 126.4) --
    so here it is measured and CHECKED rather than used to split, and any real bimodality is
    reported loudly instead of being silently merged.  Pixel area is a weak descriptor at this
    resolution (one X0 column reads 119 against 144 for its neighbours, a sub-pixel sampling
    artefact), so do not split on small differences.
    """
    m, X0, Y0 = M.mask(colour, win, f)
    out = []
    for xv in xs:
        for yv in ys:
            cx = M.ox + (xv - 1 + M.moff[0]) * M.px - X0
            cy = M.oy + (yv - 1 + M.moff[1]) * M.py - Y0
            x0, x1 = int(cx - 0.45 * M.px), int(cx + 0.45 * M.px)
            y0, y1 = int(cy - 0.45 * M.py), int(cy + 0.45 * M.py)
            if x0 < 0 or y0 < 0 or x1 > m.shape[1] or y1 > m.shape[0]:
                continue
            a = int(m[y0:y1, x0:x1].sum())
            if a >= 20:
                out.append(a)
    return out


def shape_is_bimodal(areas):
    """does this colour class hold two distinct shapes?  Reported, never used to split silently."""
    if len(areas) < 4:
        return False, 0.0
    v = sorted(areas)
    best = 0.0
    for i in range(1, len(v)):
        lo, hi = np.mean(v[:i]), np.mean(v[i:])
        gap = (hi - lo) / max(hi, 1.0)
        best = max(best, gap)
    return best > SHAPE_SPLIT, best


def classes_in_window(M, sp, win, frames, colours):
    """the appearance classes of species `sp` that are visible in this window.

    A class is (fill = sp, outline = one discovered colour, shape = checked).  Its per-frame
    positions are that colour's profile peaks INSIDE THIS SPECIES' WINDOW -- the window is what
    supplies the FILL component of the triple, so masking an outline colour panel-wide would merge
    two species that merely share a marking.
    """
    out = []
    for col in colours:
        per = {}
        ok = True
        for f in frames:
            if f in M.gate:
                continue
            if M.area(col, win, f) < MIN_CLASS_AREA:
                ok = False
                break
            per[f] = (M.peaks(col, win, f, 0), M.peaks(col, win, f, 1))
        if ok and len(per) >= 2:
            out.append(dict(sp=sp, colour=tuple(round(float(c), 1) for c in col), per=per))
    return out


# ===================================================================== step 2: measure
def rigid_displacement(cls, axis, frames):
    """the class's single displacement on `axis`, plus the residual that proves it is rigid.

    A class is rigid by the rule, so every member shares one displacement.  That is a testable
    claim, not an assumption: compute each member's offset from its source tone on every frame and
    take the spread.  A spread above RIGID_TOL means the class is not one rigid body -- either the
    triple was read wrong, or two classes share a colour, and it must be reported.
    """
    fs = [f for f in frames if f in cls["per"]]
    if len(fs) < 2:
        return None
    # A CLASS HAS A FIXED NUMBER OF MEMBERS, so read it only on the frames that show them all.
    # Taking src and dst from the first and last frame regardless lets a frame where the mask
    # dropped a marker define the class: on c150's f050-055 the noise colour rgb(184,133,90) shows
    # 2, 3, 3, 3, 3, 2 peaks, so its src and dst came from the two-peak frames and it claimed
    # cols 7,11 -> 8,12 -- a SUBSET of the real mauve class 7,9,11 -> 8,10,12.  The two then shared
    # tones, the union stopped being a bijection, and X1's cleanly measured pairwise swap was
    # reported UNDETERMINED.  Keep the modal count and drop the frames that disagree.
    from collections import Counter
    counts = Counter(len(cls["per"][f][axis]) for f in fs)
    n_mode = counts.most_common(1)[0][0]
    fs = [f for f in fs if len(cls["per"][f][axis]) == n_mode]
    if len(fs) < 2:
        return None
    first, last = fs[0], fs[-1]
    p0 = cls["per"][first][axis]
    p1 = cls["per"][last][axis]
    if not p0 or len(p0) != len(p1):
        return None
    src = [int(round(v)) for v in p0]
    dst = [int(round(v)) for v in p1]
    if len(set(src)) != len(src):
        return None
    D = [d - s for s, d in zip(src, dst)]
    if len(set(D)) != 1:                       # not one uniform displacement -> not one class
        return dict(bad="displacements differ within the class: %s" % D, src=src, dst=dst)
    # ONE DEGRADED FRAME MUST NOT VETO A RIGID CLASS.  The residual used to be the max over frames,
    # so a single frame whose mask partly drops out decides the whole class: on c150's f168-178 X0
    # mauve reads cols 3:6 -> 1:4 with a spread of 0.01-0.03 on every frame except f170, where the
    # fill area falls from 4355 to 3601 px and one peak lands 0.16 off.  That took the residual to
    # 0.159 against a 0.15 tolerance, the class was rejected as NOT RIGID, the partition collapsed
    # to a single class, and a real move was reported UNDETERMINED.  This is the same failure the
    # tool already guards against by area ("skip the frame, not the class") -- the area test just
    # does not catch a frame that is present but degraded.
    #
    # So drop the single worst frame when there are enough to spare.  A genuinely non-rigid class
    # has a large spread on MANY frames, so dropping one does not rescue it; the discrimination is
    # unaffected.  The raw max is still reported, as is the frame that produced it.
    spreads = []
    for f in fs:
        pk = cls["per"][f][axis]
        if len(pk) != len(src):
            continue                           # a member left the window; skip this frame
        offs = [pk[i] - src[i] for i in range(len(src))]
        spreads.append((max(offs) - min(offs), f))
    if not spreads:
        return None
    spreads.sort()
    worst, worst_f = spreads[-1]
    # The frames that inflate the spread are the ones where this class's markers pass CLOSE TO
    # ANOTHER class's.  Two markers within ~0.3 site blend at their anti-aliased boundary, so each
    # colour's profile peak is pulled toward the other and that member's offset is biased -- on
    # c150's f192-203 X0 mauve sits at 0.02-0.07 site on nine frames and 0.16 / 0.18 on the two
    # where gold is crossing through it (gold at 2.67, mauve's first marker at 2.83).  SKILL.md 4
    # already says this: "expect the achievable error to rise at a crossing, where peaks are
    # genuinely unresolvable for a few frames; a residual concentrated there ... is a resolution
    # limit and not a wrong map."  So judge rigidity on a ROBUST quantile and report the max.
    # A class that is genuinely two sub-blocks is wide on MOST frames -- its spread grows with
    # progress -- so this does not weaken the test, and the uniform-displacement check on the
    # first and last frames (both settled, both clean) still has to pass first.
    spread = spreads[int(0.75 * (len(spreads) - 1))][0] if len(spreads) >= 4 else worst
    return dict(src=src, dst=dst, D=D[0], rigid_residual=round(spread, 4),
                rigid_residual_worst=round(worst, 4), worst_frame=worst_f,
                n_frames=len(spreads),
                rigid=bool(spread <= RIGID_TOL), first=first, last=last)


def fit_progress(cls, axis, frames, src, D):
    """(frame, progress) per frame from this class alone -- it is one rigid body, so one number"""
    seq = []
    for f in frames:
        if f not in cls["per"]:
            continue
        pk = cls["per"][f][axis]
        if len(pk) != len(src):
            continue
        p = float(np.mean([(pk[i] - src[i]) / D for i in range(len(src))]))
        seq.append((f, p))
    return seq


def fit_easing(seq, lo, hi, step=0.02):
    fs = np.array([s[0] for s in seq], float)
    ps = np.array([s[1] for s in seq], float)
    best = None
    for a in np.arange(lo, hi - 1.0 + 1e-9, step * 5):
        for b in np.arange(a + 1.5, hi + 1e-9, step * 5):
            e = float(np.sqrt(((smoothstep((fs - a) / (b - a)) - ps) ** 2).mean()))
            if best is None or e < best[0]:
                best = (e, float(a), float(b))
    if best is None:
        return None
    _, a0, b0 = best
    for a in np.arange(max(lo, a0 - 0.3), min(hi - 1.0, a0 + 0.3) + 1e-9, step):
        for b in np.arange(max(a + 1.5, b0 - 0.3), min(hi, b0 + 0.3) + 1e-9, step):
            e = float(np.sqrt(((smoothstep((fs - a) / (b - a)) - ps) ** 2).mean()))
            if e < best[0]:
                best = (e, float(a), float(b))
    return best


# ===================================================================== step 3: merge (MANDATORY)
def occupied_at(rests, f):
    """every (x, y) held by any species at frame f, from the settled rectangles.

    Needed for the atom-capture check: merging two classes with different combs on the other axis
    creates traps at the full product of the unions, and an atom belonging to neither class
    standing on one of those would be held by two combs at once.
    """
    occ = {}
    for sp, rec in rests.items():
        cur = None
        for a, b, xs, ys in rec["rests"]:
            if a <= f:
                cur = (xs, ys)
        if cur:
            for x in cur[0]:
                for y in cur[1]:
                    occ[(x, y)] = sp
    return occ


def merge_classes(groups, rests, axis, f_ref):
    """Fuse classes with IDENTICAL motion onto one AOM.  Mandatory: the simplest structure wins.

    Two classes may share one crossed pair when they have the same displacement on the moving axis
    (so the merged tone map is that same translation of the union, and therefore still strictly
    increasing).  The only thing to check is the OTHER axis: the merged rectangle is
    (union of moving tones) x (union of other combs), and if that product contains a site held by
    an atom in neither class, the merge would capture it and is refused.

    On c150 this is what turns X0's row move and X1's row move -- same displacement, combs 1:6 and
    7:12 -- into the single rectangle x 1:12, and what the user's correction to the 0.30 ms sheet
    was about.
    """
    occ = occupied_at(rests, f_ref)
    merged, used = [], [False] * len(groups)
    for i, g in enumerate(groups):
        if used[i]:
            continue
        cur = dict(D=g["D"], src=list(g["src"]), other=list(g["other"]),
                   members=[g], sps={g["sp"]}, colours={g["colour"]})
        used[i] = True
        changed = True
        while changed:
            changed = False
            # NOTE: do NOT prefer a class sharing the outline colour.  It looks like the natural
            # tie-breaker and it is wrong -- measured on c150's f019-028 window, the gold outline
            # rgb(247,187,70) marks D=+3 for X0 and X1 but D=-3 for Z0, so the marking does not
            # determine direction across fill colours.  Only the triple is guaranteed rigid (that
            # is the rule); merging across fill colours is justified by EQUAL DISPLACEMENT and
            # legality alone.  Where that leaves more than one minimal grouping, the pixels do not
            # decide and the tie is reported instead of being broken silently.
            for j in range(len(groups)):
                h = groups[j]
                if used[j] or h["D"] != cur["D"]:
                    continue
                new_src = sorted(set(cur["src"]) | set(h["src"]))
                new_other = sorted(set(cur["other"]) | set(h["other"]))
                if len(new_src) != len(set(new_src)):
                    continue
                # atom capture: any site in the merged product held by a non-member?
                own = {m["sp"] for m in cur["members"]} | {h["sp"]}
                captured = []
                for x in (new_src if axis == 0 else new_other):
                    for y in (new_other if axis == 0 else new_src):
                        s = occ.get((x, y))
                        if s is not None and s not in own:
                            captured.append((x, y, s))
                if captured:
                    continue
                cur["src"] = new_src
                cur["other"] = new_other
                cur["members"].append(h)
                cur["sps"] |= {h["sp"]}
                cur["colours"] |= {h["colour"]}
                used[j] = True
                changed = True
                break
        cur["dst"] = [s + cur["D"] for s in cur["src"]]
        merged.append(cur)
    return merged


# ===================================================================== driver
def interval_of(ivs, f0, f1):
    best = None
    for a, b in ivs:
        lo, hi = max(a, f0), min(b, f1)
        if hi >= lo and (best is None or (hi - lo) > (best[1] - best[0])):
            best = (a, b)
    return best


# WHICH FRAME OF A PULSE RUN IS THE BOUND?  THE FIRST (p0).  Sessions 9-14 used the LAST (p1), on
# rule 9's wording "a move may begin the moment the last pulse frame is displayed" and c540_v4's
# `Gates` row 1.  That is wrong for a run longer than one frame, and the USER settled it (session
# 15): A RYDBERG PULSE IS FAR FASTER THAN THE ATOMS MOVE, so it is effectively INSTANTANEOUS on this
# time base.  A pulse RUN of two frames is therefore not a two-frame gate -- it is one instantaneous
# gate whose DISPLAY the animation holds for two frames, over-representing its duration.  The gate's
# instant is p0, so p0 is when the atoms are free to move.  Rule 9 itself is untouched and remains
# exactly true: nothing moves during the pulse.
#
# The pixels agree, and sharply:
#   c300: for all 29 moves that start on the first free frame after a run, fa = p0 is a sharp
#         minimum -- Z0+Z1 cols f190-209 scores 0.0510 at p0=188 against 0.1594 at p1=189, X0 cols
#         f246-261 0.0959 against 0.2432, Z0 cols f048-064 0.0810 against 0.1866.  The movie's
#         SINGLE-frame runs settle it independently: at f328, where p0 == p1, the optimum is exactly
#         the gate frame (0.0308, against 0.1146 one frame later and 0.1157 one frame earlier).
#         Whole-movie score 0.0522 -> 0.0369 site.
#   c150: p0 wins on 17 of 24 post-pulse moves and p1 on 7, and where p1 wins the margin is small
#         (0.0447 vs 0.0516, 0.0202 vs 0.0328) while where p0 wins it is often large (0.0432 vs
#         0.1431, 0.0459 vs 0.1598).  The residual 7 are within a frame either way and are noise
#         against this, not evidence for p1.
#
# Note that under p0 the block has moved only ~0.02 site by p1 anyway -- the quintic easing is flat
# at the start -- so nothing measurably moves on any gate frame under either convention.  The
# difference is entirely in where the easing's flat tail is anchored, which is why it shows up as a
# mid-move lag rather than as motion during a gate.
#
# c150's and c200's DELIVERED sheets were built with p1 and are still self-consistent and correct in
# every map; they would simply score better rebuilt with p0.  See the handover.
PULSE_BOUND_FIRST = True


def pulse_bounds(runs, a_iv, b_iv):
    # `lo` must come from the preceding run itself, NOT from a_iv - 1: a pulse-free interval starts
    # one frame after its run ends, so a_iv - 1 IS that run's last frame and, used as a floor, it
    # silently reimposes the p1 convention and makes PULSE_BOUND_FIRST inert.
    lo, hi = None, float(b_iv + 1)
    for p0, p1 in runs:
        if p1 < a_iv:
            cand = float(p0 if PULSE_BOUND_FIRST else p1)
            lo = cand if lo is None else max(lo, cand)
        if p0 > b_iv:
            hi = min(hi, float(p0))
    return (float(a_iv - 1) if lo is None else lo), hi


def solve_per_transition(M, rests, runs, ivs, f0, f1, wins, verbose=True):
    """Solve each TRANSITION separately, then merge co-timed classes across species.

    A pulse-free interval is NOT one move: c150's f019-047 holds four sequential moves, so reading
    a class's source on the interval's first frame and its destination on the last straddles
    unrelated motions and finds nothing.  The transition list from sb_compose --transitions is the
    correct segmentation and is already trusted, so drive off that; the interval only supplies the
    pulse bounds for the easing fit.
    """
    full = (M.K["visible_col"][0] - 0.4, M.K["visible_col"][1] + 0.4,
            M.K["visible_row"][0] - 0.4, M.K["visible_row"][1] + 0.4)
    colours = discover_outlines(
        M, [f for f in range(f0, f1 + 1, max(1, (f1 - f0) // 8)) if f not in M.gate], full)
    if verbose:
        print("discovered outline colours (candidate appearance classes):")
        for c in colours:
            print("   rgb(%3d,%3d,%3d)" % tuple(int(v) for v in c))

    trs = []
    for sp in sorted(rests):
        for t in rests[sp]["transitions"]:
            if t["f1"] >= f0 and t["f0"] <= f1:
                trs.append(t)
    trs.sort(key=lambda t: (t["f0"], t["sp"]))

    findings, notes = [], []
    for t in trs:
        sp = t["sp"]
        if sp not in wins:
            continue
        iv = interval_of(ivs, t["f0"], t["f1"])
        if iv is None:
            notes.append("%s %s f%03d-%03d spans a pulse with no usable interval"
                         % (sp, t["kind"], t["f0"], t["f1"]))
            continue
        lo, hi = pulse_bounds(runs, *iv)
        frames = [f for f in range(max(t["f0"], iv[0]), min(t["f1"], iv[1]) + 1)
                  if f not in M.gate]
        if len(frames) < 3:
            continue
        if verbose:
            print("\n" + "-" * 100)
            print("%s %-11s transition f%03d-%03d  solving frames %d..%d  bounds f%.1f..f%.1f"
                  % (sp, t["kind"], t["f0"], t["f1"], frames[0], frames[-1], lo, hi))
        got = 0
        for cls in classes_in_window(M, sp, wins[sp], frames, colours):
            for axis in (0, 1):
                r = rigid_displacement(cls, axis, frames)
                if r is None:
                    continue
                if r.get("bad"):
                    continue
                if abs(r["D"]) < MOVE_MIN:
                    continue
                if not r["rigid"]:
                    notes.append("%s rgb%s %s f%03d-%03d: NOT RIGID, member spread %.3f site"
                                 % (sp, cls["colour"], "cols" if axis == 0 else "rows",
                                    frames[0], frames[-1], r["rigid_residual"]))
                    continue
                other = [int(round(v)) for v in cls["per"][r["first"]][1 - axis]]
                if not other:
                    continue
                areas = marker_areas(M, M.fill[sp], wins[sp], r["first"],
                                     cls["per"][r["first"]][0], cls["per"][r["first"]][1])
                bim, gap = shape_is_bimodal(areas)
                if bim:
                    notes.append("%s rgb%s f%03d: SHAPE looks bimodal (relative gap %.2f) -- the "
                                 "triple may hold two classes here" % (sp, cls["colour"],
                                                                       r["first"], gap))
                seq = fit_progress(cls, axis, frames, r["src"], r["D"])
                fe = fit_easing(seq, lo, hi) if len(seq) >= 3 else None
                findings.append(dict(sp=sp, colour=cls["colour"], axis=axis, kind=t["kind"],
                                     src=r["src"], dst=r["dst"], D=r["D"], other=other,
                                     rigid_residual=r["rigid_residual"],
                                     fa=round(fe[1], 3) if fe else None,
                                     fb=round(fe[2], 3) if fe else None,
                                     prog_rms=round(fe[0], 4) if fe else None,
                                     frames=[frames[0], frames[-1]], iv=list(iv)))
                got += 1
                if verbose:
                    print("   CLASS rgb%-22s %-4s  %-16s -> %-16s  D=%+d  rigid %.3f  t %s..%s"
                          % (str(cls["colour"]), "cols" if axis == 0 else "rows",
                             comb(r["src"]), comb(r["dst"]), r["D"], r["rigid_residual"],
                             "%.4f" % (fe[1] * M.dt) if fe else "?",
                             "%.4f" % (fe[2] * M.dt) if fe else "?"))
        if got == 0:
            notes.append("%s %s f%03d-%03d: no appearance class resolved a rigid move here"
                         % (sp, t["kind"], t["f0"], t["f1"]))
            if verbose:
                print("   (nothing resolved)")

    # ---- MANDATORY merge: bucket co-timed findings with equal displacement, then fuse
    if verbose:
        print("\n" + "=" * 100)
        print("MERGING classes with identical motion (mandatory -- simplest structure)")
    moves = []
    used = [False] * len(findings)
    for i, g in enumerate(findings):
        if used[i]:
            continue
        bucket = [g]
        used[i] = True
        for j, h in enumerate(findings):
            if used[j] or h["axis"] != g["axis"] or h["D"] != g["D"]:
                continue
            if g["fa"] is None or h["fa"] is None:
                continue
            if abs(h["fa"] - g["fa"]) <= 1.5 and abs(h["fb"] - g["fb"]) <= 1.5:
                bucket.append(h)
                used[j] = True
        mg = merge_classes(bucket, rests, g["axis"], g["frames"][0])
        # Report a TIE: if the bucket held classes from 3+ fill colours and the merge left some
        # unmerged, another equally-minimal grouping exists and the pixels do not choose between
        # them.  c150 f019-028 is the case: X0, X1 and Z0 all move +3 cols, any two may share one
        # crossed pair, all three may not (the merged rectangle would capture Z1), so X0+X1 and
        # X0+Z0 are both minimal at 4 groups.  Say so rather than presenting one as measured.
        if len({x["sp"] for x in bucket}) >= 3 and len(mg) > 1:
            notes.append("TIE at t=%.4f on %s D=%+d: classes from %s all share this displacement "
                         "and any two may ride one crossed pair, but not all three. Chose %s; "
                         "other groupings of the same atom motion are equally minimal and the "
                         "pixels do not decide between them."
                         % (g["fa"] * M.dt if g["fa"] else 0.0,
                            "cols" if g["axis"] == 0 else "rows", g["D"],
                            "+".join(sorted({x["sp"] for x in bucket})),
                            " | ".join("+".join(sorted(m["sps"])) for m in mg)))
        for m in mg:
            fas = [x["fa"] for x in m["members"] if x["fa"] is not None]
            fbs = [x["fb"] for x in m["members"] if x["fb"] is not None]
            mv = dict(axis="cols" if g["axis"] == 0 else "rows",
                      sps=sorted(m["sps"]), colours=sorted({str(x["colour"])
                                                            for x in m["members"]}),
                      kind=g["kind"], src=m["src"], dst=m["dst"], D=m["D"], other=m["other"],
                      fa=round(float(np.mean(fas)), 3) if fas else None,
                      fb=round(float(np.mean(fbs)), 3) if fbs else None,
                      t0=round(float(np.mean(fas)) * M.dt, 4) if fas else None,
                      t1=round(float(np.mean(fbs)) * M.dt, 4) if fbs else None,
                      frames=g["frames"], interval=g["iv"], n_classes=len(m["members"]),
                      rigid_residual=max(x["rigid_residual"] for x in m["members"]))
            moves.append(mv)
            if verbose:
                print("   AOM  %-10s %-4s  %-16s -> %-16s  other %-14s  t %s..%s  (%d class%s)"
                      % ("+".join(mv["sps"]), mv["axis"], comb(mv["src"]), comb(mv["dst"]),
                         comb(mv["other"]),
                         "%.4f" % mv["t0"] if mv["t0"] is not None else "?",
                         "%.4f" % mv["t1"] if mv["t1"] is not None else "?",
                         mv["n_classes"], "es" if mv["n_classes"] > 1 else ""))
    moves.sort(key=lambda m: (m["fa"] if m["fa"] is not None else 0, m["axis"]))
    return moves, notes


def solve(M, rests, runs, ivs, f0, f1, wins, verbose=True):
    colours = discover_outlines(M, [f for f in range(f0, f1 + 1, max(1, (f1 - f0) // 8))
                                    if f not in M.gate],
                                (M.K["visible_col"][0] - 0.4, M.K["visible_col"][1] + 0.4,
                                 M.K["visible_row"][0] - 0.4, M.K["visible_row"][1] + 0.4))
    if verbose:
        print("discovered outline colours (each is a candidate appearance class):")
        for c in colours:
            print("   rgb(%3d,%3d,%3d)" % tuple(int(v) for v in c))

    moves, notes = [], []
    for a_iv, b_iv in ivs:
        if b_iv < f0 or a_iv > f1:
            continue
        lo_f, hi_f = max(a_iv, f0), min(b_iv, f1)
        frames = [f for f in range(lo_f, hi_f + 1) if f not in M.gate]
        if len(frames) < 3:
            continue
        # pulse constraint: a move may begin at the last pulse frame's time and must finish by the
        # next pulse's first frame
        lo, hi = float(a_iv - 1), float(b_iv + 1)
        for p0, p1 in runs:
            if p1 < a_iv:
                lo = max(lo, p1)
            if p0 > b_iv:
                hi = min(hi, p0)
        if verbose:
            print("\n" + "=" * 100)
            print("pulse-free interval f%03d-%03d   easing bounds f%.1f..f%.1f" % (a_iv, b_iv, lo, hi))

        found = []
        for sp in M.species:
            if sp not in wins:
                continue
            for cls in classes_in_window(M, sp, wins[sp], frames, colours):
                for axis in (0, 1):
                    r = rigid_displacement(cls, axis, frames)
                    if r is None or r.get("bad"):
                        if r and verbose:
                            print("   %-3s rgb%s %s: %s" % (sp, cls["colour"],
                                                            "cols" if axis == 0 else "rows",
                                                            r["bad"]))
                        continue
                    if abs(r["D"]) < MOVE_MIN:
                        continue
                    if not r["rigid"]:
                        notes.append("%s rgb%s %s f%03d-%03d: NOT RIGID, member spread %.3f site"
                                     % (sp, cls["colour"], "cols" if axis == 0 else "rows",
                                        frames[0], frames[-1], r["rigid_residual"]))
                        continue
                    other_axis_pk = cls["per"][r["first"]][1 - axis]
                    other = [int(round(v)) for v in other_axis_pk] or None
                    if not other:
                        continue
                    areas = marker_areas(M, M.fill[sp], wins[sp], r["first"],
                                         cls["per"][r["first"]][0], cls["per"][r["first"]][1])
                    bim, gap = shape_is_bimodal(areas)
                    if bim:
                        notes.append("%s rgb%s f%03d: SHAPE looks bimodal (relative gap %.2f) -- "
                                     "the triple may hold two classes here, check by eye"
                                     % (sp, cls["colour"], r["first"], gap))
                    seq = fit_progress(cls, axis, frames, r["src"], r["D"])
                    fe = fit_easing(seq, lo, hi) if len(seq) >= 3 else None
                    found.append(dict(sp=sp, colour=cls["colour"], axis=axis,
                                      src=r["src"], dst=r["dst"], D=r["D"], other=other,
                                      rigid_residual=r["rigid_residual"],
                                      fa=round(fe[1], 3) if fe else None,
                                      fb=round(fe[2], 3) if fe else None,
                                      prog_rms=round(fe[0], 4) if fe else None,
                                      frames=[frames[0], frames[-1]]))
                    if verbose:
                        print("   CLASS %-3s rgb%-22s %-4s  %-16s -> %-16s  D=%+d  rigid %.3f  "
                              "t %s..%s"
                              % (sp, str(cls["colour"]), "cols" if axis == 0 else "rows",
                                 comb(r["src"]), comb(r["dst"]), r["D"], r["rigid_residual"],
                                 "%.4f" % (fe[1] * M.dt) if fe else "?",
                                 "%.4f" % (fe[2] * M.dt) if fe else "?"))

        for axis in (0, 1):
            gs = [g for g in found if g["axis"] == axis]
            if not gs:
                continue
            mg = merge_classes(gs, rests, axis, frames[0])
            if verbose and len(mg) < len(gs):
                print("   -> MERGED %d classes into %d AOM group(s) on %s (mandatory: simplest "
                      "structure)" % (len(gs), len(mg), "cols" if axis == 0 else "rows"))
            for m in mg:
                fas = [x["fa"] for x in m["members"] if x["fa"] is not None]
                fbs = [x["fb"] for x in m["members"] if x["fb"] is not None]
                moves.append(dict(
                    axis="cols" if axis == 0 else "rows",
                    sps=sorted(m["sps"]), colours=[x["colour"] for x in m["members"]],
                    src=m["src"], dst=m["dst"], D=m["D"], other=m["other"],
                    fa=round(float(np.mean(fas)), 3) if fas else None,
                    fb=round(float(np.mean(fbs)), 3) if fbs else None,
                    t0=round(float(np.mean(fas)) * M.dt, 4) if fas else None,
                    t1=round(float(np.mean(fbs)) * M.dt, 4) if fbs else None,
                    interval=[a_iv, b_iv],
                    frames=[frames[0], frames[-1]],
                    rigid_residual=max(x["rigid_residual"] for x in m["members"]),
                    n_classes=len(m["members"])))
                if verbose:
                    print("      AOM  %-10s %-4s  x/y %-16s -> %-16s  other %-14s  spans %s"
                          % ("+".join(sorted(m["sps"])), "cols" if axis == 0 else "rows",
                             comb(m["src"]), comb(m["dst"]), comb(m["other"]),
                             ",".join(sorted(m["sps"]))))
    return moves, notes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--f0", type=int, default=0)
    ap.add_argument("--f1", type=int, default=None)
    ap.add_argument("--work", default=".")
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    import sb_compose as C
    M = Movie(a.calib, a.frames)
    f1 = a.f1 if a.f1 is not None else M.nf - 1
    runs = C.pulse_runs(M)
    ivs = C.free_intervals(runs, M.nf)
    wins = C.species_windows(M, a.f0, f1)
    trj = os.path.join(a.work, "transitions.json")
    if not os.path.exists(trj):
        print("run sb_compose.py --transitions first (it writes %s)" % trj)
        return
    rests = json.load(open(trj))

    print("movie: %d frames, dt %.9f ms" % (M.nf, M.dt))
    print("pulse runs: %s" % runs)
    moves, notes = solve_per_transition(M, rests, runs, ivs, a.f0, f1, wins)

    print("\n" + "=" * 100)
    print("%d AOM-level moves" % len(moves))
    if notes:
        print("\n%d note(s) -- reported, not swept under the rug:" % len(notes))
        for n in notes:
            print("   %s" % n)
    out = a.out or os.path.join(a.work, "rigid_moves.json")
    json.dump(dict(moves=moves, notes=notes), open(out, "w"), indent=1, default=str)
    print("\nwrote %s" % out)


if __name__ == "__main__":
    main()
