# probes batch C -- segments 6-8 (f214-299)
$env:PYTHONIOENCODING = "utf-8"
$SB = "..\.claude\skills\se-cycle-blocks\tools"
function P($name, $sp, $ax, $f0, $f1, $win) {
  cmd /c "python $SB\sb_probe.py --calib calib.json --peaks --sp $sp --axis $ax --f0 $f0 --f1 $f1 --win=$win > logs\probe_$name.txt 2>&1"
  Write-Output "done $name $(Get-Date -Format HH:mm:ss)"
}
P "X0_cols_214_226"  X0 0 214 226 "0.4,13.6,24.4,36.6"
P "X0_rows_221_248"  X0 1 221 248 "0.4,13.6,24.4,36.6"
P "X0_cols_246_258"  X0 0 246 258 "0.4,13.6,24.4,36.6"
P "Z0_rows_252_264"  Z0 1 252 264 "0.4,13.6,0.4,12.6"
P "Z1_rows_252_264"  Z1 1 252 264 "0.4,13.6,12.4,24.6"
P "X0_rows_252_278"  X0 1 252 278 "-0.6,0.6,24.4,36.6"
P "Z1_rows_279_298"  Z1 1 279 298 "0.4,26.6,12.4,24.6"
P "Z0_rows_279_298"  Z0 1 279 298 "0.4,26.6,0.4,12.6"
P "X1_cols_279_298"  X1 0 279 298 "0.4,26.6,24.4,36.6"
