"""sb_extra.py -- fit the timing of READOUTS and LOADS, the part nothing automatic can see.

SKILL.md 7.  A readout has no outline and no solid fill: the block desaturates and descends off
panel.  A load's stock is FADED until the instant it joins the cycle (rule 3).  Neither is visible
to the outline reader or to the occupancy test, so `sb_full` never emits them -- and without them
the census loses atoms at every readout and the fresh blocks never arrive.

Give it a JSON list of jobs; it prints the fitted (t_start, t_finish) and the verified error for
each, plus a D-scan for the unloads so you can see how little the destination is constrained.

    python sb_extra.py --calib calib.json --jobs jobs.json

A job:
    {"name":  "Z readout",
     "sp":    "Z1",              species to MEASURE on (the one with most markers visible)
     "mask":  "faded",           "faded" for a readout, "solid" for a load's stock
     "axis":  1,                 0 = cols, 1 = rows
     "src":   [11,12,13,14,15],  where the block starts, on that axis
     "D":     9,                 candidate displacement
     "frames":[123,132],         inclusive range over which the block is actually VISIBLE
     "lo":    122, "hi": 166,    rule 9's bounds: last pulse frame before, first pulse frame after
     "scan":  [5,6,8,9,10,12,20,30]}    optional: report the residual against each D

SCORING, and both halves were learned by getting them wrong:

  * EVERY MEASURED PEAK MUST BE EXPLAINED, against unclipped predictions.  Dropping a frame because
    the model has already flown off panel REWARDS a model that leaves as fast as possible: the
    first version of this put c150's Z readout at f123.7-f125.8, a two-frame descent, because the
    seven frames where the block is still plainly on screen contributed nothing at all.
  * A PREDICTION IS ONLY REQUIRED TO BE SEEN IF IT IS WELL INSIDE THE PANEL.  A marker straddling
    the border is half clipped and the profile does not resolve it -- measured on c150, an x peak
    at -0.29 is detected and one at -0.50 is not -- so scoring against edge predictions penalises a
    correct model for the crop.

WHAT YOU THEN WRITE INTO THE SHEET (sb_emit's `extra` rows), and what is convention not measurement:

  * a readout is one `unload` row.  Its rectangle spans the species that descend TOGETHER -- on
    c150 both Z blocks ride one rectangle x -5:6 -- because species belongs to the atom, not the
    row.  Its DESTINATION is unobservable: only a few rows of the travel are on screen.  c540's
    convention is +9 rows, columns unchanged; say that it is a convention.
  * a load is an INSTANTANEOUS `load` row at the reservoir (t_start == t_finish), at the frame the
    stock turns vivid (rule 3), plus a LATER `move` row that carries it in.  `render.ps1` applies a
    batch's moves and only then creates that batch's loaded atoms, so the load must be in a
    strictly EARLIER batch than the move that carries it.
  * the load instant must be at or just BELOW its frame's timestamp.  Rounding 330*dt = 4.7179688
    up to 4.7180 put the birth after the frame, and the render drew nothing there while the movie
    showed the whole block.
  * the RESERVOIR sits at half-integer tones (see the memory note), but `render.ps1` picks atoms up
    by [int][Math]::Round(x), so the row must use integer staging -- and the OUTSIDE-the-array
    choice, even though the other scores better, or the stock lands on a data site where another
    block is standing and gets dragged off by its rectangle.
  * track a load's TRAILING edge.  Its leading edge is pinned at the panel border while the block
    is still a sliver, and those frames carry no information.
"""
import argparse, json, os, sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sb_read import Movie, smoothstep

MERGE = 0.30            # site: predictions closer than this merge, because that is what a profile does
INTERIOR = 0.45         # site: how far inside the panel a prediction must be to be required visible


def score(meas, src, D, fa, fb, interior):
    tot = n = 0.0
    worst = 0.0
    for f, ms in meas.items():
        p = float(smoothstep((f - fa) / (fb - fa)))
        pred = sorted(s + D * p for s in src)
        mg = [pred[0]]
        for v in pred[1:]:
            if v - mg[-1] < MERGE:
                mg[-1] = (mg[-1] + v) / 2.0
            else:
                mg.append(v)
        e = [min(abs(v - q) for q in mg) for v in ms]
        e += [min(abs(q - v) for v in ms) for q in mg if interior[0] <= q <= interior[1]]
        if not e:
            continue
        tot += sum(e)
        n += len(e)
        worst = max(worst, max(e))
    return (tot / n if n else float("nan")), worst, int(n)


def fit(meas, src, D, lo, hi, interior, coarse=0.25, fine=0.01):
    best = None
    for a in np.arange(lo, hi - 1.5 + 1e-9, coarse):
        for b in np.arange(a + 1.5, hi + 1e-9, coarse):
            m, w, n = score(meas, src, D, float(a), float(b), interior)
            if m == m and (best is None or m < best[0]):
                best = (m, float(a), float(b), w, n)
    if best is None:
        return None
    _, a0, b0, _, _ = best
    for a in np.arange(max(lo, a0 - 0.35), min(hi - 1.5, a0 + 0.35) + 1e-9, fine):
        for b in np.arange(max(a + 1.5, b0 - 0.35), min(hi, b0 + 0.35) + 1e-9, fine):
            m, w, n = score(meas, src, D, float(a), float(b), interior)
            if m == m and m < best[0]:
                best = (m, float(a), float(b), w, n)
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--jobs", required=True)
    a = ap.parse_args()

    M = Movie(a.calib, a.frames)
    vc, vr = M.K["visible_col"], M.K["visible_row"]
    win = (vc[0] - 0.45, vc[1] + 0.45, vr[0] - 0.45, vr[1] + 0.45)
    for j in json.load(open(a.jobs)):
        axis = int(j["axis"])
        interior = ((vc[0] + INTERIOR, vc[1] - INTERIOR) if axis == 0
                    else (vr[0] + INTERIOR, vr[1] - INTERIOR))
        colour = M.fill[j["sp"]] if j["mask"] == "solid" else M.faded[j["sp"]]
        f0, f1 = j["frames"]
        meas = {f: sorted(M.peaks(colour, win, f, axis)) for f in range(f0, f1 + 1)}
        meas = {f: v for f, v in meas.items() if v}
        print("\n=== %s" % j.get("name", "(unnamed)"))
        print("    %s %s mask, %s, frames %d-%d (%d with a signal), src %s"
              % (j["sp"], j["mask"], "cols" if axis == 0 else "rows", f0, f1, len(meas), j["src"]))
        if not meas:
            print("    NO SIGNAL -- wrong mask, wrong frames, or the block is already off panel")
            continue
        r = fit(meas, j["src"], j["D"], j["lo"], j["hi"], interior)
        if r is None:
            print("    no fit inside the pulse bounds [%s, %s]" % (j["lo"], j["hi"]))
            continue
        m, fa, fb, w, n = r
        print("    D=%+5g  t_start f%.2f = %.6f ms   t_finish f%.2f = %.6f ms"
              % (j["D"], fa, fa * M.dt, fb, fb * M.dt))
        print("              mean %.4f site (worst %.3f, %d comparisons)" % (m, w, n))
        if abs(fa - j["lo"]) < 0.02:
            print("              NOTE t_start is pinned at rule 9's lower bound. The free fit wants"
                  " to start earlier;")
            print("              refit under the constraint rather than clamping, and say so.")
        for D in j.get("scan", []):
            rr = fit(meas, j["src"], D, j["lo"], j["hi"], interior)
            if rr:
                print("      scan D=%+4g  mean %.4f   t %.6f..%.6f ms"
                      % (D, rr[0], rr[1] * M.dt, rr[2] * M.dt))
        if j.get("scan"):
            print("      a FLAT scan means the destination is not observable -- adopt the +9 row")
            print("      convention and label it a convention. A scan with a clear minimum at the")
            print("      convention corroborates it.")


if __name__ == "__main__":
    main()
