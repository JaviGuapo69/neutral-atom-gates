﻿# Session 23â€“24 â€” the PATCH ROUTE and the HYBRID driver

**2026-09-14 / 15. THIS IS THE CURRENT STATE DOCUMENT.** Read before `SKILL_RESET_2026-09-14.md`
(why v2 was archived) and `HANDOVER.md` (stale at session 17).

---

## 0. Where everything is

| | |
|---|---|
| **production skill** | `.claude/skills/se-cycle-blocks/` â€” the reset target. **UNTOUCHED this session.** Use it for anything delivered. |
| **testing fork** | `.claude/skills/se-cycle-blocks-test/` â€” everything below lives here |
| **render skill** | `.claude/skills/se-cycle-movies/` â€” **MODIFIED**: `render.ps1` outline fix. Backup at `render.ps1.bak_before_outline_fix` |
| **archive** | `.claude/skill_archive/se-cycle-blocks-v2-c540-failed-version/` â€” v2, source of the Â§2.1 port |
| **working dir** | `run_c540_v3/` |

### New / changed files in the test fork

| file | status |
|---|---|
| `tools/sb_hybrid.py` | **THE DRIVER. Use this one.** Rest detection default + patch route for gaps |
| `tools/sb_patch.py` | the patch route (measurement) |
| `tools/sb_build.py` | modified: `FIT_PAD` bound narrowing; the S2.1 port + competition in `build()`, **switched OFF via `S21_COMPETITION = False`, but see section 5: the regression it was blamed for was NOT its fault, so it is UNTESTED rather than convicted** |
| `tools/sb_video.ps1` | modified: `-F0` / `-F1` to cut a video to a frame range |
| `tools/sb_patch_build.py` | **SUPERSEDED** â€” single-range, patch-FIRST. Wrong architecture, kept only for the segment-6 result |
| `tools/sb_patch_full.py` | **SUPERSEDED** â€” whole-movie patch-FIRST. Wrong architecture |

---

## 1. THE CAUSE â€” "the skill arbitrarily stops working on some movements"

The user named it from the video: the *same* movement comes out right in one zone and wrong in
another. Traced end to end on c540 f023â€“f027, where D3 (X0, cols 1:12) and D4 (X1, cols 13:24) do
the same double swap (rows 12â†”13, 15â†”16) and their row profiles agree to 0.05 site:

```
f025  X0 worst marker 0.130 off its tone  ->  AT REST       (TOL_ONGRID = 0.14)
f025  X1 worst marker 0.160 off its tone  ->  NOT at rest
```

â†’ X0's transition window is f023..f025, X1's runs on to f026 â€” which belongs to the NEXT movement
â†’ no appearance class is rigid across X1's window, so `partition` returns nothing (X0 fails
  identically on that window: it is the window, not the species)
â†’ the fallback family (`rotations_of`) can express only **two rigid groups on a contiguous run**,
  and a product of two disjoint transpositions is not a rotation of anything
â†’ a 5-cycle is written, and **the correct map beats it on every ranking number the code uses**
  (mean 0.0682 vs 0.0792) â€” it was simply never generated.

**THE TRANSFERABLE STATEMENT: the candidate routes have different EXPRESSIVE POWER, and which one
fires is gated on measurement luck. When the appearance read goes silent the hypothesis space
silently collapses to "rotations of one contiguous run", and nothing reports the collapse.**
Rule 19 says k is not 2 â€” but only the appearance route can produce k > 2. Measured on the v3
book: 68% of its 93 moves came from those restricted routes, and 51% of moves were over the 0.10
guideline, 79% of those from those routes.

---

## 2. THE PATCH ROUTE â€” rules 41â€“44, in the fork's SKILL.md

* **41.** A patch is the unit of rigid motion: same FILL + OUTLINE + SHAPE. A patch is **not** an
  AOM â€” two patches may share one crossed pair. Merge into AOM groups afterwards, never before.
* **42.** The first/last frames a patch is visible need not be rest frames. Round to the nearest
  slot; on a tie, **backwards at the source**, **forwards at the destination**. **Round per patch,
  never per marker** â€” rigidity is mandatory.
* **43.** Where no rest frame exists, a boundary is where the rigid-body rule breaks. In practice
  the stronger tell is **the comb on the static axis, because it IS the AOM's frequency comb.**
* **44.** **The outline colour NAMES the sub-comb.** On segment 6 `rgb(152,124,185)` on X1 reads
  cols {13,19}, then {14,20}, {15,21}, {16,22}, {17,23}, {18,24} â€” the six column-pair batches of
  the hand book, with no search. Rule 40's whole difficulty dissolves. Filter DECORATION colours
  (peaks never move) and non-rigid colours (they cover both groups of a rotation).

---

## 3. THE ARCHITECTURE â€” and the first version was WRONG

The user specified it in answer 6 and it was built backwards first. **Rest detection is the
DEFAULT. The patch route fills its gaps.** Measured both ways:

```
c150   rest route (accepted)   55 moves,  0 undetermined
       patch route             42 moves, 27 undetermined   <- ALL 27 solved by the rest route
c540   rest route (v3 book)    93 moves,  0 undetermined
       patch route             51 moves, 68 undetermined   <- 24 of the hand book's 53 EVENTS
                                                              missing entirely
```

The patch route has **high precision, low recall**: what it writes is right (47/55 matched the hand
book; segment 6 is 19/19), but it is blind wherever the movie draws no outline for a group â€” c150
has 6 discovered outline colours against c540 segment 6's 10. **The two routes fail in opposite
places.**

`sb_hybrid.py` consults the patch route in exactly four places:

* **(a)** transitions the default reported UNDETERMINED
* **(b)** movements with **no transition at all** â€” occupancy never saw them (10 of 19 on segment 6)
* **(c)** **borderline rests** â€” bracketing rest decided within `BORDERLINE = 0.03` site of
  `TOL_ONGRID` AND the patch route disagrees. This is the D3/D4 case, caught by construction.
* **(d)** **the default's own score says it failed** â€” its move is over the 0.10 guideline and the
  patch route measures something different. Both maps are then re-scored **through the same peak
  source and the same frames** before comparing (their native `mean`s are not comparable).

---

## 4. WHAT WAS FIXED, with the evidence

1. **`fit_timing` searched the whole pulse-free interval.** 0.25-frame grid over a 57-frame span =
   **24,976 points per candidate**, and 260 of segment 6's 574 fits had a **five-frame** window.
   Now bounded by the transition Â± `FIT_PAD`, pulse bound kept as outer clamp.
   **Segment 6: 3 h 15 min â†’ 94 s.**
2. **`_complete` forced destination âŠ† source**, so a batch could only be a same-site permutation
   and **every whole-block RELOCATION was structurally inexpressible**. That is why transport
   vanished from the patch-only book while gate permutations came through. Now takes a separate
   destination set `T`.
3. **The block's tone set must come from the REST RECORD, not a fill profile.** c540's Z0 stands on
   cols 13:24 **only on the gate frames f314/f315**; the pulse tint breaks the fill mask, so every
   fill-based read was short a column and `Z0/Z1 cols 13:24 -> 1:12` at f315â€“328 came out as an
   eleven-tone map or not at all. `tone_lookup_from_rests` hands `sb_patch.batches` what
   `sb_build.settled` already knows (rule 9's deduction + `rect_on_pulse`). Now reads
   `13:22->3:12 | 23:24->1:2` â€” the hand book exactly.
4. **THE SKILL RESET REMOVED THE Â§2.1 REPAIR, and c540 regressed because of it.** The v3 book was
   built by **v2**, which had it. Verified by running the **untouched parent** on segment 0: it
   produces byte-identical short maps (`X0 cols f002-010` = `2:8->6:12 | 9:12->2:5`, where the
   movie and hand book do `1:7->6:12 | 8:12->1:5`). **Do not treat the v3 book as a baseline
   without remembering which skill made it.** `moving_tones` / `contradicted` / `candidate_runs` /
   `rotations_of` + the competition in `build()` were ported from the archive.
   **`subcomb_transitions` and its rule-43 propagation were deliberately NOT ported** â€” the likely
   source of the three spurious transitions in v2's c300 failure.
   **-> CORRECTED IN SECTION 5: the c150/c300 regression this was later blamed for was NOT caused
   by this port. The port is currently OFF and UNTESTED. c540 segment 0 went 2/9 -> 6/9 -> 8/9
   matching the v3 book as gap rule 2d and then this port were added, so it did help c540 --
   its effect on the closed movies is simply unknown.**
5. **The render's outline bug** (agent B, in `se-cycle-movies/tools/render.ps1`): the renderer
   ended an AOM's hold at that pair's **next assignment**; the movie ends it at the row's own
   **`t_finish`**. It failed both ways â€” rings never released (cols 13,19 outlined 37 frames after
   the movie goes bare) and rings cancelled mid-flight (three sub-moves packed on slot 1 a
   thirtieth of a frame apart, each killing the previous one's). Proof nothing moved: across all
   384 frames, **0 differing pixels are marker pixels** on c540 seg6 and on c150/c200/c300; all
   validation logs still clean.

### Segment 0 recovery, measured against the v3 book

| | identical maps |
|---|---|
| hybrid as first built | 2 of 9 |
| + gap rule 2d | 6 of 9 |
| + Â§2.1 port | **8 of 9** |

### Segment 6 (the test case the user watched and confirmed)

19 movements, **19/19 matching Shayne**, 0.0308 site, ~94 s through the hybrid. Includes the three
cols {15,21} movements the old peak-count tell never fired on once.

---

## 5. THE REGRESSION â€” c150 IDENTICAL, c300 63/64 WITH 0 WRONG MAPS

**Final state of this session. Two real bugs in `sb_hybrid` were found and fixed getting here, and
an earlier attribution in this document was WRONG â€” see the correction below.**

```
c150   IDENTICAL.  55 of 55 moves match on (species set, axis, f0, f1), 0 different maps,
                   0 lost, 0 extra.  The patch route stayed SILENT on all 12 segments, which
                   is the right behaviour on a movie where rest detection is complete.

c300   65 moves vs 64 accepted.  63 match, 0 DIFFERENT MAPS.
       absent from the new run:  X1 rows f307-315  13:18 -> 13,14,17,18,15,16
       new in the new run:       X1 rows f293-308  13:18 -> 13,15,14,17,16,18
                                 X1 rows f314-318  13:18 -> 14,13,16,15,18,17
```

### The c300 difference, CHECKED AGAINST THE PIXELS â€” and BOTH books are wrong

Do not adopt the accepted book as ground truth here. X1's row peaks over the window:

```
f293-f307   13.06 13.96 15.02 15.96 17.02 18.00   worst 0.058-0.083   PROVABLY STILL
f308-f312   worst 0.224, 0.489, 0.090, 0.494, 0.170            moving   <- movement 1
f313-f314   worst 0.045, 0.068                                 settled
f315-f317   worst 0.268, 0.478, 0.202                          moving   <- movement 2
f318-f319   worst 0.054, 0.062                                 settled
```

**The movie contains TWO movements** separated by a settled pair at f313-314.

* the **accepted book** writes ONE move `f307-315`, spanning both movements *and* the still frames
  between them â€” it merges two batches;
* the **hybrid** correctly splits them in two, but its first window is `f293-308`, which begins
  **fifteen frames before anything moves**.

So the hybrid's STRUCTURE is right and its WINDOWING is worse on the first one. This is the same
class of defect the user originally complained about â€” a window that does not correspond to when
the block actually moves. **Fixing this properly is the best-defined open task in the project**:
the correct answer is two movements at roughly f307-313 and f314-318, and neither book has it.

### âš  CORRECTION: the Â§2.1 port was NOT the cause of the c150 failure

An earlier version of this section blamed the Â§2.1 port. **That was wrong**, and the way it was
wrong is worth keeping:

* the c150 failure **persisted with `S21_COMPETITION = False`**;
* the **fork's own `sb_full`** â€” same `sb_build.py`, same `FIT_PAD`, Â§2.1 off â€” produced the
  correct `X0 cols f224-239 1:6 -> -5:0` at mean 0.0451 with 0 undetermined;
* so `sb_build` was always clean and **the bug was in `sb_hybrid`**, the driver written this
  session. `FIT_PAD` is also cleared by the same test.

**`S21_COMPETITION` is still `False`, but it is now UNTESTED rather than convicted.** Its regression
needs redoing from scratch. The rule-21 concern in the comment beside the flag (that `moving_tones`
cannot see off-panel tones and so reports a false static set on a block entering or leaving the
array) is a real hypothesis that was never confirmed â€” treat it as a lead, not a finding.

### The two bugs that were fixed, and they are the same mistake

Both are rule 42 â€” *a route that commits without competing is not a measurement* â€” committed by the
gap rules themselves, in a driver written by the person who put that sentence in this document.

1. **The gap rules committed a patch map without ever looking at its score.** On c150 segment 8
   that wrote `X0 cols f239-252` at **mean 2.1234 site** against a 0.10 guideline, displacing the
   correct map at 0.0451. Filling a declared hole with a map twenty times the bar is strictly worse
   than leaving the hole: an undetermined transition is visible in every report and audit, a
   committed wrong move is not. **The bar now lives inside `emit_from_batch`** (`PATCH_MAX = 4 Ã—
   ACCEPT`) â€” one gate, because four call sites is four chances to forget. The first attempt put it
   in rules (a) and (b) only and the bad move walked straight past it through (c).
2. **Gap rule (c) preferred the patch map unconditionally** whenever the rest was borderline and
   the two maps differed â€” no comparison at all. It now re-scores both through the same peak source
   over the same frames and keeps the better, exactly as rule (d) does. **A borderline rest is a
   reason to ASK the second opinion, never a reason to believe it.**

### Re-running the regressions

**The working directories were in the session scratchpad and are GONE.** `regh_c150/` and
`regh_c300/` in the project hold inputs plus **STALE** checkpoints written by the pre-fix code â€”
**delete their `ck/` before using them**, or a run will silently mix two builds (rule 49: staleness
is judged on segment bounds only).

```powershell
cd regh_c150; rmdir /s /q ck
python ..\.claude\skills\se-cycle-blocks-test\tools\sb_hybrid.py `
       --calib calib.json --blocks blocks.json --events events.json --work . --ckpt ck
cd ..\regh_c300; rmdir /s /q ck
python ..\.claude\skills\se-cycle-blocks-test\tools\sb_hybrid.py `
       --calib calib.json --blocks blocks.json --events events.json --work . --ckpt ck
cd ..
python reg_c300\cmp_moves.py reg_c150\moves_full.json regh_c150\hybrid_moves.json
python reg_c300\cmp_moves.py run_c300\moves_full.json regh_c300\hybrid_moves.json
```

Expected: c150 IDENTICAL, c300 63/64 with 0 different maps. Each takes 5-10 minutes.

---

## 6. c540 DELIVERABLES -- all SUPERSEDED, rebuild them

Everything in `run_c540_v3/`. **The workbook and videos below predate fixes 3, 4 and gap rule 2d,
so they are out of date. Rebuild once the regression is green.**

| file | what |
|---|---|
| `c540_hybrid.xlsx` | 88 moves, 5 undetermined â€” **stale** |
| `c540_hybrid_panels.mp4` / `_full.mp4` | **stale**; the user watched this and it is wrong from the first movement (that is fix 4) |
| `hybrid_vs_shayne.txt` | 71/92 matched, 38 events fully / 13 partly / 2 not at all |
| `v3_vs_shayne.txt` | the v3 baseline: 84/97, 45 fully / 2 partly / 6 not at all |
| `c540_seg6_patch.xlsx`, `c540_seg6_patch_*.mp4`, `SEG6_PATCH_REPORT.md` | the segment-6 result â€” **still valid**, the user confirmed it |
| `PATCH_FULL_REPORT.md`, `OUTLINE_FIX_REPORT.md` | the two agents' reports |
| `ckpt/` | the **v3** book's checkpoints (93 moves) â€” made by v2, see Â§4.4 |
| `hyb_ck/` | the hybrid's checkpoints. **Delete after any change to decision logic** (rule 49) |

Rebuild:

```powershell
cd run_c540_v3
rmdir /s /q hyb_ck
python ..\.claude\skills\se-cycle-blocks-test\tools\sb_hybrid.py --calib calib.json `
       --blocks blocks.json --events events.json --work . --extra extra.json --xlsx c540_hybrid.xlsx
python ..\.claude\skills\se-cycle-movies\tools\se_calibtxt.py --calib calib.json `
       --out-txt hybrid_calib.txt --out-json hybrid_render_calib.json `
       --render-frames "$PWD\rframes_hybrid" --tone-divisor 1
..\.claude\skills\se-cycle-movies\tools\render.ps1 -Xlsx c540_hybrid.xlsx `
       -OutDir "$PWD\rframes_hybrid" -LogCsv "$PWD\render_hybrid.csv" -MatchCalib "$PWD\hybrid_calib.txt"
python ..\.claude\skills\se-cycle-blocks-test\tools\sb_score.py --movie-calib calib.json `
       --render-calib hybrid_render_calib.json --out score_hybrid.txt
python ..\.claude\skills\se-cycle-movies\tools\se_sim.py c540_hybrid.xlsx
python ..\.claude\skills\se-cycle-blocks-test\tools\sb_audit.py --moves hybrid_moves.json --rests hybrid_rests.json
python cmp_full.py --moves hybrid_moves.json --out hybrid_vs_shayne.txt
# ffmpeg is NOT on PATH in a fresh shell:
$env:Path += ";C:\Users\HP\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.1-full_build\bin"
..\.claude\skills\se-cycle-blocks-test\tools\sb_video.ps1 -MovieFrames "..\run_c540\frames" `
       -RenderFrames "$PWD\rframes_hybrid" -Calib "$PWD\calib.json" `
       -OutPanels "$PWD\c540_hybrid_panels.mp4" -OutFull "$PWD\c540_hybrid_full.mp4"
```

---

## 7. OTHER OPEN ITEMS

1. **AOM time-splitting** â€” the user's own next topic, deliberately deferred. One physical batch is
   reported as 2â€“3 movements because each species band is fitted separately. **Z0 and Z1 agree to
   0.0000â€“0.0088 ms (under a third of a frame) â€” those are one AOM.** But **X1 is consistently
   0.6â€“1.9 frames later and that is probably REAL pipelining** (`c540_v3_diagnosis.md` Â§2 measured
   it). **Do not merge on time alone.** The strongest handle is probably not timing: all three
   bands on comb {14,20} are provably on the same column pair, and merging on shared comb + a
   compatible strictly-increasing map is rule 8's actual criterion. Full table in
   `memory/se-cycle-aom-time-splitting.md`.
2. **"Partly accounted" jumped from 2 (v3) to 13 (hybrid)** against the hand book. Unexplained.
   Could be the AOM splitting above, or a real defect. Not distinguished.
3. **Transition counts differ** from the v3 book (108 vs 130) with identical rest-detection
   settings. Unexplained; agent A did not chase it.
4. **`sb_patch.py` tunables** were calibrated on c540 segment 6 alone.
5. **Render outlines**: Â±1 frame of slack at ring on/off edges (the render samples the workbook's
   fitted `t_finish` at `t = fÂ·dt`); and a pre-existing draw-order issue where a close neighbour's
   ring paints over an earlier one. Neither affects marker motion.
6. Four forward disagreements with Shayne unadjudicated against the pixels: `X1 rows t 0.94`,
   `Z1 rows t 3.27`, `Z1 rows t 4.07`, `X0 cols t 9.88`.

---

## 8. TRAPS THIS SESSION COST TIME ON

* **A per-step bound applied to a whole run.** `MAX_MEMBER_JUMP` rejected every one-site move as
  `member MISMATCH 8 -> 8`. A jump bound is per-frame; over a run a marker is *supposed* to travel.
* **Rigidity judged on the max deviation** rejects real patches. Use rule 26's robust quantile:
  `[0.68 0.46 0.65 0.63 0.66 0.68 0.71 0.87]` has max spread 0.41, robust spread 0.04, and is
  plainly one rigid body.
* **Timing must be fitted through a peak source restricted to the patch's comb.** Against the whole
  block the ten static columns pull the easing to a short sharp one mid-window: X1 f200â€“207 fitted
  to f203.1â€“f204.8 for a movement gradual across the whole window.
* **A size check is not a set check.** At f316 Z0's twelve-column profile has twelve peaks â€” the
  count is right â€” but rounds to `{13..22, 22, 23}`: column 22 twice, column 24 missing.
* **`se_sim`'s census was CLEAN on a book missing 21 relocations.** The census conserves atoms; it
  cannot see a block that never moved. Rule 27 again.
* PowerShell 5.1: no `&&`, no ternary; `$s` and `$S` are one variable; `Select-Object -First n`
  kills the upstream pipeline; `.xlsx` in this OneDrive folder throws `PermissionError` if open in
  Excel; ffmpeg not on PATH in a fresh shell.




