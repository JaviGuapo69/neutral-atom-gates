# What a session looks like

A worked-through example conversation, so you know what to expect before you start.

> **Everything below is illustrative.** The movie, the numbers, the frame references and the
> filenames are invented for the purpose of showing the shape of the exchange. Real numbers will
> differ; the *structure* is accurate.

Read `START HERE.md` first if you haven't.

---

## ① First contact

**YOU:** *hi, I've been given this folder and told you'd explain it.*

**CLAUDE:** Welcome. Here's what this is.

You have a set of movies of a quantum computer running a syndrome-extraction cycle. Atoms get
shuttled around a grid by steerable laser traps. My job is to watch one of those movies and work out
the **schedule** that produced it — which atoms were picked up, when, and where they were put down —
and write it into a spreadsheet.

Then I render your spreadsheet back into a video and put it side by side with the original, so you
can *see* whether it's right.

How it goes:

1. You name a movie. I transcribe it. Takes a few hours, mostly unattended.
2. I hand you a workbook and a comparison video, plus a list of anything I wasn't sure about.
3. I go back over my own work against the movie, find my mistakes, fix them, and give you a
   **second** video.
4. **You watch that video.** This part can't be automated — the most common error is invisible to
   every check I have.
5. You tell me what's still wrong, by frame number. I propose a fix for each, you approve, I apply
   it and re-render.
6. When a video looks right to you, you declare it closed.

Two things worth knowing up front. I will sometimes say "I don't know" rather than guess — that's
correct behaviour, not a failure. And my checks passing does **not** mean the workbook is right;
only your eyes settle that.

Which movie?

---

## ② The job

**YOU:** *the c630 one, the 4-AOD version.*

**CLAUDE:** `se_cycle_c630_d20_C7C18_4aod.mp4`. Starting.

Setup done, and I'll flag what I read off the movie itself so you can sanity-check me:

- 384 frames, cycle 8.11 ms, **4-AOD**, pipelined
- lattice 18 × 35, four blocks of 18 × 7
- 13 gate pulses; two of them are single-frame
- four species found and named correctly against the legend

Now the long part — I solve the movie in twelve chunks. About three hours. I'll report when it's
done; you don't need to sit here.

> **What to check here:** those five lines are read off the movie's own header and legend. If any of
> them looks wrong to you, stop — everything downstream will be wrong in a way that still looks
> plausible.

---

## ③ First delivery

**CLAUDE:** Done. First draft is ready.

**`c630_blocks.xlsx`** and **`c630_original_vs_rebuild_panels.mp4`**.

| | |
|---|---|
| movements transcribed | 87 |
| **couldn't determine** | **6** |
| audit | clean |
| atom count | clean |
| rebuild score | 0.31 site *(good is under 0.06)* |

Don't read too much into the clean checks — they're structural. The score of 0.31 is the honest
signal: something is off.

The six I couldn't determine are listed in the workbook's `Notes` sheet. Next I go back over my own
work against the movie frame by frame and fix what I can. Another hour or so. Go ahead?

**YOU:** *yes go.*

---

## ④ Claude corrects itself

**CLAUDE:** Second draft ready: **`c630_s2_blocks.xlsx`**, **`c630_s2_..._panels.mp4`**.

I found and applied **19** corrections. Full detail in `c630_s2_corrections.md`; the headline ones:

| # | frames | block | what was wrong | changed to | evidence |
|---|---|---|---|---|---|
| 1 | 118–131 | Z1 cols | rotation read one tone short | rotation by 7, not 8 | 0.021 vs 0.119 |
| 2 | 203–210 | X0 rows | two blocks doing this, only one written | joined on one rectangle | 0.034 |
| 3 | 247–249 | Z0 cols | **a movement I never wrote at all** | new 3-cycle | 0.028 |
| 4 | 288–289 | Z1 rows | false one-frame rest inside a move | merged into one move | 0.019 |
| … | | | | | |

Number 3 is the kind that matters: there was no rest frame on the far side, so nothing ever proposed
it. It was in no list — not even the "couldn't determine" one.

| | first draft | now |
|---|---|---|
| undetermined | 6 | **0** |
| score | 0.31 | **0.058** |
| audit | clean | clean |

**Now it's your turn, and this is the part I can't do for you.** My checks are blind to a whole class
of error: a block shuffling its atoms *within the same rectangle*. The atom count can't see it, the
render can't see it, the score can't see it. Only watching can.

Play `c630_s2_..._panels.mp4`. Movie on the left, my rebuild on the right. You're looking for a clump
of markers that swaps in the movie but sits still in mine — or the reverse, markers dancing in mine
that don't move in the movie. Note the frame number and tell me.

---

## ⑤ You watch

**YOU:** *mostly looks right. but around frame 176 the green block does something in the real one and
nothing in yours. wrong movement between frames 176 and 184.*

**CLAUDE:** Looking.

> **Wrong movement between frames 176 and 184** — Z1, columns, block parked at rows 13:18.
>
> The movie shows Z1's markers bunching from f177 and settling by f183; my rebuild holds them still.
> My book has no move there at all — the occupancy test bridged it, because Z1 rests on the same
> columns before and afterwards. The outline colours on f177 split the block into two groups, and
> their positions at mid-progress say it's an exchange of the two halves, not a rotation. Measured:
> **0.024 site**, against 0.31 for the best rotation.
>
> **What the workbook has now for that window:**
>
> | move | event | t_start | t_finish | x_start | y_start | x_finish | y_finish |
> |---|---|---|---|---|---|---|---|
> | — | *(nothing)* | | | | | | |
>
> **What I suggest:**
>
> | event | t_start | t_finish | x_start | y_start | x_finish | y_finish | displacement |
> |---|---|---|---|---|---|---|---|
> | move | 3.712 | 3.861 | 1:5 | 13:18 | 6:10 | 13:18 | +5 |
> | move | 3.712 | 3.861 | 6:10 | 13:18 | 1:5 | 13:18 | −5 |
>
> Both halves share one start time — they have to, or the renderer picks the same atoms up twice.

Apply it?

**YOU:** *yes. also frame 301, the orange block moves the wrong way I think.*

**CLAUDE:** Checking f301 before I agree with you — the pixels decide, and sometimes they disagree
with the frame you noticed.

> **Wrong movement between frames 298 and 306** — X1, columns.
>
> You're right that it's wrong, but not in the direction you described. My book has it rotating left
> by 2; the movie rotates it **right by 2**. The two look similar because the block is nearly
> symmetric. Measured: 0.026 for right, 0.18 for left.
>
> *[table of current rows]*
> *[table of proposed rows]*

Apply?

**YOU:** *yes, apply both.*

> **What to notice here:** Claude checked your report against the pixels instead of just doing as it
> was told, and said so when the pixels disagreed with your description. That is the intended
> behaviour. The pixels decide, and any disagreement goes into the workbook's notes.

---

## ⑥ Second pass

**CLAUDE:** Both applied, re-checked, re-rendered once.

**`c630_s3_blocks.xlsx`**, **`c630_s3_..._panels.mp4`**.

| | before | after |
|---|---|---|
| movements | 106 | 108 |
| audit | clean | clean |
| atom count | clean | clean |
| render validation | 0 | 0 |
| score | 0.058 | **0.041** |

I also confirmed the change list contains *exactly* your two items and nothing else — no move I
wasn't asked to touch has moved.

One thing to be straight about: the destination of the read-out blocks is a **convention**, not a
measurement. The movie carries them off the edge and I can't see where they land, so I've given them
a plausible destination and said so in the report. Same for where the fresh atoms wait. If the lab
has the real numbers, those two should be replaced.

Have a look at the new video.

---

## ⑦ Closing

**YOU:** *that's it, the c630 video is correct. consider it closed.*

**CLAUDE:** Closing c630.

- **`c630_s3_blocks.xlsx`** + both videos are the final set, copied to `closed videos\` and added to
  the manifest
- **`SESSION_c630.md`** records all 21 corrections with their evidence, and separates what was
  measured from what is convention
- the working folders stay as provenance; nothing gets re-run

For the record: 108 movements, none undetermined, every structural check clean, final score 0.041
site, and you have watched and accepted the rebuild.

Next movie whenever you want one.

---

## The four moments that matter

1. **After setup** — sanity-check the five lines Claude read off the movie.
2. **After the first draft** — look at the score and the "couldn't determine" count, not the clean checks.
3. **Watching the second video** — the only step that can catch the invisible class of error. Yours alone.
4. **Before closing** — make sure the report says which parts are measured and which are convention.
