"""fix_lattice_2aod.py -- re-fit a calib.json's lattice when se_calib locked onto a SUBMULTIPLE.

WHY (2026-09-18, c300_2aod).  `se_calib.comb_fit` maximises |sum exp(2*pi*i*v/p)| over p from
6.0 px upward and keeps the best.  Every submultiple of the true pitch scores the SAME magnitude,
because points on a comb of pitch p are also on a comb of pitch p/k, so on a fine lattice the scan
can settle on p/2 or p/3 on noise alone.  On c300_2aod it returned 16.038 x 24.056 px where the
rings are 47.8 apart -- a third and a half of the truth -- and reported its own failure
("!! ring centres do not sit on one comb", worst residual 0.208 site, data extent 58 x 38 where
the movie has 22 x 19).

This re-runs se_calib's OWN lattice derivation, unchanged, with the comb search floor raised, and
rewrites only the fields that depend on it: origin, pitch, data extent, visible window, ring sites,
ring area.  The palette, the gate frames, the panel and the timing are left exactly as se_calib
measured them.  Run it BEFORE fix_calib_2aod.py, which re-measures the marker offset.

    python fix_lattice_2aod.py <run dir> [--floor 30]     # --floor: px, the smallest credible pitch

Check the printed residual (se_calib's own bar is 0.18 site) and the data extent against the movie.
"""
import argparse, json, os, sys

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SE = os.path.abspath(os.path.join(HERE, "..", ".claude", "skills", "se-cycle-movies", "tools"))
sys.path.insert(0, SE)
import se_calib  # noqa: E402  -- se_calib's own comb_fit and components, unchanged


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--floor", type=float, default=30.0)
    ap.add_argument("--samples", type=int, default=40)
    ap.add_argument("--ymin", type=float, default=None,
                    help="px: ignore blobs above this y. c300_2aod draws its LEGEND inside the "
                         "panel box, so the legend's 'data' ring and its species swatches are "
                         "detected as lattice rings and wreck the fit")
    a = ap.parse_args()

    cpath = os.path.join(a.run, "calib.json")
    K = json.load(open(cpath))
    x0, x1, y0, y1 = K["panel"]
    fd = K["frames_dir"]
    nfr = K["n_frames"]
    bgs = np.asarray(K["background_per_frame"], float)

    paths = [os.path.join(fd, "p_%03d.png" % f) for f in range(nfr)]

    def load(p):
        return np.asarray(Image.open(p).convert("RGB"), dtype=float)

    pick = np.unique(np.linspace(0, nfr - 1, min(a.samples, nfr)).astype(int))
    rings = []
    for f in pick:
        for c in se_calib.components(load(paths[f]), bgs[f], x0, x1, y0, y1):
            if c["holeness"] > 1.22 and (a.ymin is None or c["y"] >= a.ymin):
                rings.append(c)
    print("sampled %d frames : %d ring blobs%s"
          % (len(pick), len(rings), "" if a.ymin is None else " (y >= %.0f)" % a.ymin))
    if len(rings) < 20:
        sys.exit("too few empty-site rings found")

    ring_area = float(np.median([r["area"] for r in rings]))
    rings = [r for r in rings if 0.78 * ring_area < r["area"] < 1.30 * ring_area
             and r["holeness"] > 1.5]
    rx = np.array([r["x"] for r in rings])
    ry = np.array([r["y"] for r in rings])
    span = min(x1 - x0, y1 - y0)
    px, phx = se_calib.comb_fit(rx, a.floor, span / 3.0)
    py, phy = se_calib.comb_fit(ry, a.floor, span / 3.0)
    ox = phx + np.floor((rx.min() - phx) / px + 0.5) * px
    oy = phy + np.floor((ry.min() - phy) / py + 0.5) * py
    ci = np.round((rx - ox) / px).astype(int) + 1
    ri = np.round((ry - oy) / py).astype(int) + 1
    ex = np.abs((rx - ox) / px - (ci - 1))
    ey = np.abs((ry - oy) / py - (ri - 1))
    resid = max(ex.max(), ey.max())
    print("lattice           : origin (%.2f, %.2f)  pitch %.3f x %.3f  worst ring residual %.3f site"
          % (ox, oy, px, py, resid))
    print("   residual spread: 50%% %.3f  90%% %.3f  99%% %.3f  (a few stragglers do not matter; "
          "a wrong pitch shows in the MEDIAN)"
          % (np.percentile(np.r_[ex, ey], 50), np.percentile(np.r_[ex, ey], 90),
             np.percentile(np.r_[ex, ey], 99)))
    print("   was            : origin (%.2f, %.2f)  pitch %.3f x %.3f"
          % (K["origin_x"], K["origin_y"], K["pitch_x"], K["pitch_y"]))
    print("data extent       : cols %d..%d   rows %d..%d   (was cols %d..%d rows %d..%d)"
          % (ci.min(), ci.max(), ri.min(), ri.max(), K["data_col_min"], K["data_cols"],
             K["data_row_min"], K["data_rows"]))
    if resid > 0.18:
        print("!! STILL not one comb -- do not go on; check --floor and the panel")

    def rng(o, p, lo, hi):
        i = np.arange(-40, 200)
        c = o + (i - 1) * p
        ok = (c >= lo) & (c <= hi)
        return int(i[ok].min()), int(i[ok].max())

    vc = rng(ox, px, x0, x1)
    vr = rng(oy, py, y0, y1)
    print("visible window    : cols %d..%d   rows %d..%d" % (vc[0], vc[1], vr[0], vr[1]))

    if not os.path.exists(cpath + ".se_calib"):
        json.dump(K, open(cpath + ".se_calib", "w"), indent=1)
        print("kept se_calib's original as calib.json.se_calib")
    K.update(origin_x=float(ox), origin_y=float(oy), pitch_x=float(px), pitch_y=float(py),
             data_cols=int(ci.max()), data_rows=int(ri.max()),
             data_col_min=int(ci.min()), data_row_min=int(ri.min()),
             visible_col=[vc[0], vc[1]], visible_row=[vr[0], vr[1]],
             ring_area=ring_area,
             ring_sites=sorted(set("%d,%d" % (c, r) for c, r in zip(ci.tolist(), ri.tolist()))))
    json.dump(K, open(cpath, "w"), indent=1)
    print("wrote", cpath, "-- now re-run fix_calib_2aod.py for the palette and the marker offset")


if __name__ == "__main__":
    main()
