"""emit_s31.py -- re-emit the workbook from the saved moves_full.json / rests_full.json without re-applying anything
(the same sb_emit.emit call apply_s31.py ends with).  Use after fix_extra.py, or when the xlsx was locked.

    python emit_s31.py [out.xlsx]      # default c780_s31_blocks.xlsx
"""
import json, os, sys
sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_compose, sb_emit
from sb_read import Movie

out = sys.argv[1] if len(sys.argv) > 1 else "c780_s31_blocks.xlsx"
M = Movie("calib.json")
mv = json.load(open("moves_full.json", encoding="utf-8"))
rests = json.load(open("rests_full.json", encoding="utf-8"))
runs = sb_compose.pulse_runs(M)
wins = sb_compose.species_windows(M, 0, M.nf - 1)
P = sb_compose.Peaks(M, wins, 0, M.nf - 1)
sb_emit.emit(out, M, mv, rests, runs, P, 0, M.nf - 1, extra="extra.json",
             scope_note="the WHOLE movie: frames 0-%d, t = 0 .. %.4f ms, all %d pulse runs; the automatic "
                        "se-cycle-blocks book (run_c780, session 28) + the session-31 hand corrections listed in "
                        "Notes (read from the pixels and applied 2026-09-17 on the user's one-time instruction); the two "
                        "readout rows of extra.json corrected to cols -12:0,1:13" % (M.nf - 1, (M.nf - 1) * M.dt, len(runs)))
print("wrote", out)
