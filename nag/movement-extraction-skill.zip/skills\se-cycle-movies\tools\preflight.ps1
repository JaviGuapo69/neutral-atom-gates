<#
  preflight.ps1 -- check this machine can run the pipeline, before you spend an hour finding out
  it cannot. Run it first, from anywhere.

  Prints a line per requirement and exits non-zero if anything essential is missing.
#>
param([switch]$Quiet)
$ok = $true
function Say($state, $what, $detail) {
  if ($state -eq 'ok' -and $Quiet) { return }
  $mark = switch ($state) { 'ok' { '  ok  ' } 'warn' { ' warn ' } default { ' FAIL ' } }
  "[$mark] {0,-22} {1}" -f $what, $detail
}

# ---- PowerShell
$v = $PSVersionTable.PSVersion
if ($v.Major -ge 5) { Say ok 'PowerShell' "$v" }
else { Say fail 'PowerShell' "$v -- need 5.1 or later"; $ok = $false }

# ---- System.Drawing: every image tool here depends on it
try {
  Add-Type -AssemblyName System.Drawing -ErrorAction Stop
  $b = New-Object System.Drawing.Bitmap(4,4); $b.Dispose()
  Say ok 'System.Drawing' 'available'
} catch {
  Say fail 'System.Drawing' "unavailable: $($_.Exception.Message)"
  $ok = $false
}

# ---- ffmpeg / ffprobe, needed only to turn a movie into frames
$ff = (Get-Command ffmpeg -ErrorAction SilentlyContinue)
if ($ff) {
  Say ok 'ffmpeg' $ff.Source
} else {
  $guess = Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter ffmpeg.exe -Recurse -ErrorAction SilentlyContinue |
           Select-Object -First 1
  if ($guess) {
    Say warn 'ffmpeg' "installed but not on PATH. Run:`n           `$env:Path += `";$($guess.Directory.FullName)`""
  } else {
    Say warn 'ffmpeg' 'not found. Needed only for movie -> frames. Install: winget install Gyan.FFmpeg'
  }
}
if (Get-Command ffprobe -ErrorAction SilentlyContinue) { Say ok 'ffprobe' 'on PATH' }

# ---- the tools themselves
$here = $PSScriptRoot
$need = 'inv_calib.ps1','inv_extract.ps1','inv_moves.ps1','inv_emit.ps1','render.ps1','compare.ps1','writexlsx.ps1'
$missing = @($need | Where-Object { -not (Test-Path (Join-Path $here $_)) })
if ($missing.Count -eq 0) { Say ok 'tools' "$($need.Count) scripts present in $here" }
else { Say fail 'tools' "missing: $($missing -join ', ')"; $ok = $false }

# ---- execution policy: scripts must be runnable
$pol = Get-ExecutionPolicy
if ($pol -in 'Restricted','AllSigned') {
  Say warn 'execution policy' "$pol -- run scripts with: powershell -ExecutionPolicy Bypass -File <script>"
} else { Say ok 'execution policy' $pol }

# ---- locale: decimal parsing is pinned in every script, but flag a comma locale anyway
$cul = [System.Globalization.CultureInfo]::CurrentCulture
if ($cul.NumberFormat.NumberDecimalSeparator -ne '.') {
  Say warn 'locale' "$($cul.Name) uses '$($cul.NumberFormat.NumberDecimalSeparator)' as the decimal separator. The scripts pin InvariantCulture; anything you write yourself must too."
} else { Say ok 'locale' $cul.Name }

# ---- OneDrive: known to lock .xlsx mid-write
if ($here -like '*\OneDrive\*') {
  Say warn 'location' 'this package is inside OneDrive, which locks .xlsx files. Write workbooks to a local path, or expect intermittent File.Open failures.'
}

""
if ($ok) { 'preflight passed.'; exit 0 } else { 'preflight FAILED -- fix the lines marked FAIL.'; exit 1 }
