"""darkruns.py -- every stretch where a species has no SOLID marker, and what it looks like either side.

This is the first pass of the hand correction on a 2-AOD movie, done in one command.  For each run
of frames where a species' solid area is below the floor it prints:

  * the last settled rectangle BEFORE the run and the first one AFTER it, on both axes, so an
    IN-PLACE readout/load pair (identical rectangles, nothing travels) is separated at a glance
    from a real departure (no rectangle after) and a real arrival (no rectangle before);
  * whether the FADED image is frozen through the run -- the peaks and the mask area on the first,
    middle and last frame of it.  Frozen to a pixel means the block did not move while dark, which
    is what an `unload` + `load` pair in extra.json has to assert.

Usage:  python darkruns.py <run dir> [--floor 300]
"""
import argparse, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SB = os.path.abspath(os.path.join(HERE, "..", ".claude", "skills", "se-cycle-blocks", "tools"))
sys.path.insert(0, SB)
import sb_read  # noqa: E402


def fmt(v):
    if not len(v):
        return "-"
    ints = [int(round(x)) for x in v]
    if all(abs(a - b) < 0.12 for a, b in zip(v, ints)):
        if len(ints) > 1 and ints == list(range(ints[0], ints[0] + len(ints))):
            return "%d:%d" % (ints[0], ints[-1])
        return ",".join(str(i) for i in ints)
    return " ".join("%.2f" % x for x in v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--floor", type=float, default=300.0)
    a = ap.parse_args()

    cal = os.path.join(a.run, "calib.json")
    M = sb_read.Movie(cal)
    K = json.load(open(cal))
    vc, vr = K["visible_col"], K["visible_row"]
    win = (vc[0] - 0.6, vc[1] + 0.6, vr[0] - 0.6, vr[1] + 0.6)
    names = [s["name"] for s in K["species"]]
    frames = [f for f in range(M.nf) if f not in M.gate]

    def rect(sp, f, faded=False):
        c = M.faded[sp] if faded else M.fill[sp]
        return fmt(M.peaks(c, win, f, 0)), fmt(M.peaks(c, win, f, 1)), M.area(c, win, f)

    for sp in names:
        print("\n=== %s" % sp)
        area = {f: M.area(M.fill[sp], win, f) for f in frames}
        runs, cur = [], None
        for f in frames:
            if area[f] <= a.floor:
                cur = [f, f] if cur is None else [cur[0], f]
            elif cur is not None:
                runs.append(cur); cur = None
        if cur is not None:
            runs.append(cur)
        if not runs:
            print("   solid on every non-gate frame")
            continue
        for f0, f1 in runs:
            before = [f for f in frames if f < f0 and area[f] > a.floor]
            after = [f for f in frames if f > f1 and area[f] > a.floor]
            print("   DARK f%03d..f%03d  (%d frames)" % (f0, f1, f1 - f0 + 1))
            if before:
                c, r, ar = rect(sp, before[-1])
                print("      last solid  f%03d  cols %-22s rows %-22s  a%6d" % (before[-1], c, r, ar))
            else:
                print("      last solid  --  the block is not on screen before this run")
            if after:
                c, r, ar = rect(sp, after[0])
                print("      next solid  f%03d  cols %-22s rows %-22s  a%6d" % (after[0], c, r, ar))
            else:
                print("      next solid  --  the block never comes back")
            mid = (f0 + f1) // 2
            for f in sorted({f0, mid, f1}):
                c, r, ar = rect(sp, f, faded=True)
                print("      faded       f%03d  cols %-22s rows %-22s  a%6d" % (f, c, r, ar))


if __name__ == "__main__":
    main()
