"""se_extract.py -- stage 2 of movie -> workbook.  One marker list per frame.

For every frame this writes, for every atom marker on screen:

    frame, species, state (solid|faded), x, y      -- x, y in CONTINUOUS data-site units

Continuous is the whole point.  The old pipeline sampled the colour at each data-site centre and
asked "occupied?", which made a block in flight invisible (it registers only on the frames where
its displacement happens to land near a whole site) and made a block parked half a pitch off the
lattice invisible always.  A centroid has neither problem: an atom between sites reads as 7.43,
and that fractional part is the evidence every later stage runs on.

Detection is a matched filter, not a colour mask with the blobs counted:

  * a score image per species, 1 at the fill colour and falling to 0 at the colour tolerance,
    taking each pixel's better match of the solid and the faded fill;
  * box-filtered to the size of a marker's flat interior, so the peak of the filter sits on the
    marker's centre and a 1-px anti-aliased halo or a thin outline ring contributes almost nothing;
  * peaks picked with non-maximum suppression at 0.62 of a pitch, which is what makes this robust
    where colour masks are not -- two markers that merge mid-flight give two peaks, and a marker
    ringed by an outline of a *different* species' colour still gives exactly one.

The colour tolerance has to be wide (h.264 chroma subsampling moves a saturated fill by up to 50
RGB between frames), so solid and faded are told apart afterwards, from the median colour in a
small window on the peak itself -- never from which mask claimed the pixel.
"""
import argparse, glob, json, os, sys
import numpy as np
from PIL import Image
from scipy import ndimage


def odd(n):
    n = int(round(n))
    return n if n % 2 else n + 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--out", required=True, help="markers .csv to write")
    ap.add_argument("--tol", type=float, default=70.0, help="colour match radius")
    ap.add_argument("--peak", type=float, default=0.55,
                    help="minimum filtered score for a marker: the fraction of the box that must "
                         "carry the species' colour.  An unobstructed marker's interior gives 1.0, "
                         "but these movies draw faint block labels (D1..D5) as a watermark ACROSS "
                         "the array, and a marker under one scores about 0.7 -- at the old default "
                         "of 0.75 exactly those markers went missing, three of them in c540's "
                         "seed.  The threshold is low because outlines are now rejected on the "
                         "colour at the detection's own centre (see --peak-centre) rather than by "
                         "being too weak to pass.")
    ap.add_argument("--no-centre-test", action="store_true",
                    help="disable the centre-colour test (diagnostics only)")
    ap.add_argument("--frames", default=None, help="override the frame directory in the calibration")
    args = ap.parse_args()

    K = json.load(open(args.calib, encoding="utf-8"))
    d = args.frames or K["frames_dir"]
    paths = sorted(glob.glob(os.path.join(d, "*.png")))
    if len(paths) != K["n_frames"]:
        print("!! %d frames on disk, calibration says %d" % (len(paths), K["n_frames"]))
    x0, x1, y0, y1 = K["panel"]
    ox, px, oy, py = K["origin_x"], K["pitch_x"], K["origin_y"], K["pitch_y"]
    moff = K.get("marker_offset", [0.0, 0.0])
    sp = K["species"]
    names = [s["name"] for s in sp]

    # The box filter must be sized from THE MARKER, not from the pitch.  A marker is about the same
    # number of pixels in every one of these movies (c540 and c150 both draw ~144 px ones) while the
    # pitch is whatever the array size makes it -- 34 px on c540, 57 px on c150.  Sizing the box at
    # 0.27 of the pitch therefore fits c540 by luck and is nearly twice the marker on c150, where the
    # filtered density of a real marker fell to ~0.6 and two thirds of the atoms went undetected:
    # 45 markers a frame against the 120 that are on screen.  se_calib measures `marker_area`, so
    # use it; the suppression radius stays a fraction of the pitch, because "two markers closer than
    # this are one atom" really is a statement about the lattice.
    marea = np.median([s.get("marker_area", 0) or 0 for s in sp]) or (min(px, py) * 0.27) ** 2
    box = max(3, odd(np.sqrt(marea) * 0.75))
    box = min(box, max(3, odd(min(px, py) * 0.45)))
    nms = max(3, odd(min(px, py) * 0.62))       # two atoms nearer than this are one detection
    win = int(round(min(px, py) * 0.30))
    print("marker area %.0f px -> box filter %d px, non-max suppression %d px" % (marea, box, nms))

    # Every colour a pixel can be, so a pixel is only scored for a species when that species is its
    # NEAREST match.  The frame's own background must be in here: on a gate frame the panel tint is
    # a pale pink 38 RGB from faded X0, so without it the whole background scores as faded atoms.
    bgpf = K.get("background_per_frame")
    other = [[255., 255., 255.], list(map(float, K["background"])), [178., 178., 178.],
             [128., 128., 128.], [60., 60., 60.]]

    def watermark_colours(bg):
        """The block labels (D1..D5) drawn faintly across the array are the frame's own background
        blended towards a grey ink, so they are not a fixed colour -- they follow the background,
        gate tint included.  Measured on c540: rgb(234,209,194) on a gate frame whose background is
        rgb(254,231,218), and rgb(229,230,229) on a plain white frame.  Both are NEARER to faded X0
        rgb(244,195,214) than to their own background, so without these blends in the competing
        palette every label glyph is reported as a faded atom -- 22 of them on c540's frame 0, which
        is enough to make the faded-marker evidence for a readout meaningless.  Blending the
        background towards grey by 10-45% covers the anti-aliased range of the glyph.
        """
        bg = np.asarray(bg, float)
        return [list(bg + (128.0 - bg) * al) for al in (0.10, 0.18, 0.26, 0.34, 0.45)]

    rows = []
    nsupp = 0
    for f, p in enumerate(paths):
        cand = []
        a = np.asarray(Image.open(p).convert("RGB")).astype(np.float32)[y0 + 3:y1 - 2, x0 + 3:x1 - 2]
        H, W = a.shape[:2]
        pal = []
        for s in sp:
            pal.append(s["solid"]); pal.append(s["faded"])
        fbg = list(map(float, bgpf[f])) if bgpf and f < len(bgpf) else list(map(float, K["background"]))
        comp = list(other) + [fbg] + watermark_colours(fbg)
        allc = np.asarray(pal + comp, np.float32)
        nsp2 = 2 * len(sp)                      # index of the first non-species colour
        dall = np.empty((len(allc), H, W), np.float32)
        for k, c in enumerate(allc):
            dall[k] = ((a - c) ** 2).sum(axis=2)
        who = dall.argmin(axis=0)
        np.sqrt(dall, out=dall)
        for si, s in enumerate(sp):
            ds, df = dall[2 * si], dall[2 * si + 1]
            # Binary, not a distance ramp.  The fill colour drifts by up to 50 RGB between frames,
            # so a ramp scores a perfectly good marker at 0.3 on one frame and 1.0 on the next; a
            # membership mask makes the filtered value mean "what fraction of this box is this
            # species", which does not move with the drift.
            mine = ((who == 2 * si) | (who == 2 * si + 1)) & (np.minimum(ds, df) < args.tol)
            score = mine.astype(np.float32)
            if score.max() <= 0:
                continue
            dens = ndimage.uniform_filter(score, size=box, mode="constant")
            mx = ndimage.maximum_filter(dens, size=nms, mode="constant")
            hit = (dens >= mx - 1e-9) & (dens > args.peak)
            if not hit.any():
                continue
            lab, n = ndimage.label(hit)
            for cy, cx in ndimage.center_of_mass(hit, lab, range(1, n + 1)):
                iy, ix = int(round(cy)), int(round(cx))
                ya, yb = max(0, iy - win), min(H, iy + win + 1)
                xa, xb = max(0, ix - win), min(W, ix + win + 1)
                w = score[ya:yb, xa:xb]
                tot = w.sum()
                if tot <= 0:
                    continue
                gy, gx = np.mgrid[ya:yb, xa:xb]
                fy = float((w * gy).sum() / tot)
                fx = float((w * gx).sum() / tot)
                # state from the colour on the peak, not from which mask found it
                sm = int(round(fy)), int(round(fx))
                patch = a[max(0, sm[0] - 2):sm[0] + 3, max(0, sm[1] - 2):sm[1] + 3].reshape(-1, 3)
                if not len(patch):
                    continue
                med = np.median(patch, axis=0)
                dsol = np.sqrt(((med - np.asarray(s["solid"])) ** 2).sum())
                dfad = np.sqrt(((med - np.asarray(s["faded"])) ** 2).sum())
                if min(dsol, dfad) > args.tol:
                    continue
                # The colour at the detection's OWN CENTRE must belong to this species and to
                # nothing else in the palette.  This is what makes the low --peak threshold safe:
                # a marker is a filled shape inside an outline, the outline is drawn in a colour
                # that is another species' fill (c540 outlines everything in X1's gold), and a
                # detection that latched onto a corner of such a ring has that ring's colour at its
                # centre.  Testing "is this nearer to my species than to ANY other palette entry"
                # rejects it on identity rather than on strength, so genuine markers dimmed by a
                # watermark stay in while rings stay out.
                if not args.no_centre_test:
                    dc = np.sqrt(((allc - med[None, :]) ** 2).sum(axis=1))
                    if int(dc.argmin()) not in (2 * si, 2 * si + 1):
                        continue
                cand.append((float(dens[iy, ix]), si, "solid" if dsol <= dfad else "faded",
                             (fx + x0 + 3 - ox) / px + 1.0 - moff[0],
                             (fy + y0 + 3 - oy) / py + 1.0 - moff[1]))

        # ONE TRAP HOLDS AT MOST ONE ATOM.  Two detections on top of each other are always one
        # atom, whatever species they claim: of a different species it is the marker plus its
        # outline read as somebody else, and of the SAME species it is one marker that gave two
        # peaks because a watermark split its interior.  Suppressing only the cross-species case --
        # which is what this did until now -- let a single c540 marker at (11,22) be counted twice
        # on every frame from 2 onwards, so the array read 109 Z1 against the 108 that exist, and
        # the composer then invented a `load` row to explain the extra atom.  Keep the stronger.
        cand.sort(key=lambda t: -t[0])
        kept = []
        for dv, si, st, cx, cy in cand:
            if any(abs(cx - x2) < 0.45 and abs(cy - y2) < 0.45 for s2, x2, y2 in kept):
                nsupp += 1
                continue
            kept.append((si, cx, cy))
            rows.append((f, si, st, cx, cy))
        if f % 32 == 0:
            print("  frame %3d/%d  markers so far %d" % (f, len(paths), len(rows)))

    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write("frame,species,state,x,y\n")
        for f, si, state, x, y in rows:
            fh.write("%d,%s,%s,%.4f,%.4f\n" % (f, names[si], state, x, y))
    per = np.zeros(len(paths), int)
    for f, si, state, x, y in rows:
        if state == "solid":
            per[f] += 1
    print("wrote %s: %d markers over %d frames (%d cross-species duplicates suppressed)"
          % (args.out, len(rows), len(paths), nsupp))
    print("solid markers per frame: min %d  median %d  max %d  (a constant count is what you want)"
          % (per.min(), int(np.median(per)), per.max()))


if __name__ == "__main__":
    main()
