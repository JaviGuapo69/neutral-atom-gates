# SE-cycle movies ⇄ schedule workbooks

Everything needed to translate a syndrome-extraction cycle movie into a schedule workbook, and a
schedule workbook back into a movie. Self-contained: copy this folder anywhere.

```
   workbook.xlsx  ──►  frames  ──►  movie
   movie.mp4      ──►  frames  ──►  workbook
```

## Requirements

Windows, PowerShell 5.1 or later, and `ffmpeg` (only to turn a movie into frames). No Python, no
Node, no Excel — the workbook is read and written directly.

```powershell
tools\preflight.ps1        # says what is missing, if anything
```

If `ffmpeg` is missing: `winget install Gyan.FFmpeg`. If it installs but is not on PATH, preflight
prints the line to add.

## Two ways to use this

**With Claude Code.** Drop this folder into `.claude/skills/` of any project (or your user-level
`~/.claude/skills/`) and ask for what you want — "transcribe this movie into a schedule",
"render this workbook". `SKILL.md` is the procedure it follows.

**By hand.** `SKILL.md` is also a readable runbook: every command is spelled out, in order, with
what to check after each. Nothing requires an AI.

## Check the install works

```powershell
tools\render.ps1 -Xlsx examples\m540SEmovesV4.xlsx -OutDir t -LogCsv t.csv
```

Expect: `seeded 432 atoms`, `221 rows`, `11556 motions`, `864 atoms ever alive`,
`validation log entries: 0`. That workbook is a verified transcription of the c540 4-AOD movie, so
if this reports anything else, the install is wrong, not the workbook.

## Where to start reading

1. `SKILL.md` — the procedure. Start here.
2. `reference/SE_CYCLE_REBUILD_GUIDE.md` — the rules. Part I is the data model and is worth reading
   once in full; it is short, and every surprising behaviour downstream follows from it.

## What this will and will not give you

**Rendering a workbook is solved.** A renderer reading only the workbook reproduces the reference
movie at every frame where the movie holds a configuration.

**Transcribing a movie is a fit, not a measurement, and it is not fully automatic.** Run end to end
on the c540 movie with no human input, the pipeline recovers the seed and all 13 gates exactly,
writes 34 correct schedule rows, reproduces **20 of the 46 held frames**, and prints 19 things it
declined to decide. Every held frame up to the first readout is exact; everything after it needs
the `unload`/`load` pair written by hand first.

Three things are not recoverable from the video at all, and the tools report them rather than
guessing:

* a move that **permutes a block onto its own sites** is invisible to occupancy — you can see that
  something happened, but not what or exactly when;
* a block carried **off-screen** for measurement has a destination you can only extrapolate;
* a fresh batch waiting in a reservoir is mostly off-screen, so its rectangle is too.

A transcript that flags these is correct. One that fills them in with plausible-looking numbers is
not, and nothing in the validation suite will catch it. All three gaps close immediately if the
source schedule that generated the movie can be obtained — worth asking before doing the work.

**A `PASS` from `tools\compare.ps1` is necessary, not sufficient.** A block being carried away is
drawn faded and is missing from both extracts, so errors about it are invisible to every automated
check. Watch the render and the movie side by side before believing a result.

## Scope

Written against the `mitten_codes` family (2-AOD and 4-AOD), which share a header line, palette and
page layout. The data model in part I of the guide applies to any of these movies; the
frame-parsing steps assume that layout and need adapting for the `structured_mitten_codes` family,
which prints a different header and puts the array in a different place.
