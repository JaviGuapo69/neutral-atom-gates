# Session 29 (2026-09-16) — c500 closed by the hand-correction method

> **CLOSED AND CORRECT** — the user, after watching `c500_s29_original_vs_rebuild_panels.mp4`: "look like
> all the faults are corrected. Consider the video and the workbook closed and correct." (2026-09-16)

**Written for: the next Claude session and Javier.** Second movie finished by `handmade correction
method.md` (after c540, session 28). The automatic book came from the "delivering the rest of videos"
session (`run_c500\`, session 28, same day); this session corrected it in `run_c500_s29\` with the
user's own list of faults merged in. The skill (`.claude/skills/se-cycle-blocks/`) was NOT changed.

## Deliverables

| file | what |
|---|---|
| `c500_s29_blocks.xlsx` (root and `run_c500_s29\`) | THE BOOK: automatic run + 12 hand-corrected windows (Notes sheet lists them) |
| `c500_s29_original_vs_rebuild_panels.mp4` / `_full.mp4` | the side-by-side videos of that book |
| `run_c500_s29\s29_correction_list.md` | every corrected window in FRAMES: the book's old rows, the evidence, the new rows, the residuals |
| `run_c500_s29\apply_s29.py` + `apply_s29.log` | the corrections as code (re-runnable from `moves_full_c500_original.json`), with every measurement |
| `run_c500_s29\audit_s29.txt`, `sim_s29.txt`, `s29_vs_c500.txt`, `score_s29.txt`, `watch_s29.txt` | the checks |
| `run_c500_s29\logs\probe_*.txt` | the pixel probes behind every correction |
| `run_c500_s29\make_list.py`, `dump_sched.py`, `list_moves.py`, `deliver_s29.ps1` | the helpers; copy for the next movie |

## Result

| | automatic book (`run_c500`) | s29 book |
|---|---|---|
| moves / undetermined | 84 / 7 (+1 silent hole) | 91 / 0 |
| sb_audit | FAILED (2) | CLEAN |
| se_sim | check4 400, check3 26 | validation clean, census conserved (400) |
| AOM groups / peak (measured rows) | 4 / 4 | 4 / 4 |
| render validation entries | 426 | 0 |
| sb_score mean (site) | 0.1009 (X0 0.16, X1 0.15) | **0.0514** (X0 0.084, X1 0.037, Z0 0.048, Z1 0.037); 0.0447 without the 10 occlusion/noise cells |
| frames with every peak within 0.25 | 66 / 360 | 91 / 360 |
| sb_watch runs >= 3 frames | 37 | 25, all four-causes-accounted (below) |

`cmp_tol` against the automatic book: 75 moves matched exactly, 5 maps changed, 3 combs changed, 4 rows
removed, 11 added — exactly the intended list, nothing else.

## The 12 corrected windows (frames; full evidence in `run_c500_s29\s29_correction_list.md`)

| # | frames | block | fault in the automatic book | correction | found by |
|---|---|---|---|---|---|
| 1 | f029-032 | X1 rows 16:20 | undetermined | ADD `17,19->18,20 \| 18,20->17,19` | both |
| 1b | f029-031 | X0 rows 11:15 | 3-part read `13,15->12,14 \| 14->13 \| 12->15` | REPLACE by `12,14->13,15 \| 13,15->12,14` | both |
| 2 | f055-068 | X0+X1 cols | rotation written twice (smeared the X blocks to the end) | DELETE the X1-derived copy | session |
| 3 | f077-080 | X0 rows 1:5, X1 rows 6:10 | X0 silent hole; X1 `7:8->9:10\|9:10->7:8` written twice | ADD X0 `2,4->3,5 \| 3,5->2,4`; REPLACE X1's early copy by `7,9->8,10 \| 8,10->7,9` | both |
| 4 | f105-109 | X0 rows 1:5 | undetermined | ADD `1:2->2:3 \| 3->1` (user read row 1 +2 / rows 2,3 −1; pixels and X1's twin say +1/+1/−2) | both, pixels decided |
| 5 | f139-142 | X1 rows 16:20 | undetermined | ADD `17,19->18,20 \| 18,20->17,19` | both |
| 6 | f193-198 | Z0 rows 1:5, Z1 rows 11:15 | undetermined (last resort refused the right maps at 0.21) | ADD `1:2->4:5 \| 3:5->1:3`, `11:12->14:15 \| 13:15->11:13`; clip the f200-205 pair to start at f198 | both |
| 7 | f233-245 | X0 parked row 26 | X0+Z1+Z0 row double-claimed the Z rows and gave row 26 the Z map | REPLACE by X0-only `1:8->13:20 \| 9:20->1:12` on rows 26:30 (the inverse rotation) | both |
| 8 | f244-251 | X0/X1 exchange | X1's half `21:25->26:30` missing; `X1 cols` on rows 22:24 a phantom | ADD X1's half with X0's timing (one batch); DELETE the phantom | session |
| 9 | f251-263 | X0 rows 21:25 | two undetermined | ADD `21:23->23:25 \| 24:25->21:22` (whole) and `21->25 \| 22:25->21:24` on cols 2,6,10,14,18 | session |
| 10 | f142-146 | X0 rows 11:15, X1 rows 16:20 | 4-part reads `12->15\|13->14\|14->13\|15->12` etc. | REPLACE by `12:13->14:15 \| 14:15->12:13`, `17:18->19:20 \| 19:20->17:18` | user |
| 11 | f297-310 | X0 rows 21:25 | right maps on the WHOLE block, fits collapsed to 1.5 frames | combs → 2,6,10,14,18 and 3,7,11,15,19; refit | user |
| 12 | f335-353 | X0 rows 21:25 | three sub-comb moves written on the whole block, two with wrong maps | `21->25\|22:25->21:24` on 2,6,..; `21:24->22:25\|25->21` on 3,7,..; f348-353 map kept, comb → 4,8,12,16,20 | user (frames), session (maps), user confirmed |

Residuals of the corrected moves: smoothstep mean 0.02–0.15 site, free per-frame error 0.016–0.135; the
high smoothstep means are the two-frame windows (items 3, 5) and the exchange half whose timing was forced
onto X0's batch (item 8, free 0.042).

## Lessons (new, not in the method file yet)

1. **A hand-written move record must list EVERY tone of the block on the moving axis**, static ones as
   identity (`src 1:5, dst 1,4,5,2,3`), exactly as the solver's records do. With only the moving tones the
   symmetric `verify` charges each static row a full site (0.27–0.43 on maps that were right; 0.03–0.15
   once fixed). `apply_s29.set_map(m, parts, block)` does it.
2. **The two halves of an exchange must share one `t_start`.** X1's own fit began 0.6 frame before X0's;
   se_sim then moved X1 onto X0's sites first and every later X0 row move "picked up twice its atoms"
   (check3). Mirror the partner's timing and state the own fit in `how`.
3. **A run of three consecutive sub-comb row permutations on cols {2,6,10,14,18} → {3,7,11,15,19} →
   {4,8,12,16,20} is c500's signature** (f200-216 Z, f254-275, f297-315, f335-353). The skill wrote several
   on the whole block with the right map and a fit collapsed to 1.5 frames. Probe the outline colours with
   `--axis 0` to read the comb; the fill keeps peaks ON tones mid-move when a sub-comb moves.
4. **The report's "duplicate" at f233-245 was not a duplicate**: the parked X0 row rotates the opposite way
   to the Z blocks (+12/−8 against +8/−12). Check a shared-map double claim on the pixels before deleting.
5. **Exclude the occluded frame from the measurement window** (f246: X0 behind X1, fill 1 px → 3.9 site of
   noise in the mean) and say so.
6. When the user's frame reading and the pixels disagree (item 4: direction; item 11: comb one column
   over), the pixels decide, and the disagreement is written into the Notes.

## sb_watch runs in the s29 rebuild (25, all legitimate)

crossings: X1 cols f007-013 and X0 cols f009-013 (the 19-tone wrap), X0 cols f037-040, X0/X1 cols f056-064
(the f055-068 rotation), X0 cols f091-095, X1 cols f224-230, X0 cols f280-285, f322-325, Z0 cols f069-071,
f117-126, f188-190, f236-238, f281-285, f318-322, Z0 rows f138-140, f256-258, X0 rows f273-275, f349-352;
integer staging on parked stock: Z1 rows f148-169, X1 rows f354-377; occlusion: X0 rows f246-248 (behind
X1 during the exchange); movie-side mask noise after the X readout: X0 f367-370 (the 8 MISSING-BLOCK cells).

## Conventions inherited unchanged from the automatic run

Readout destinations +9 rows; stock staging −4:0 (Z1, X1), −14:−10 (Z0), −9:−5 (X0), integer, outside the
array; the Z carry-in ends at f178.0, one frame into the f177-178 pulse run, because the movie's own move
does (hence `allocate_aom` slot 5 on that hand row at t 4.8977 — bookkeeping, no AOM tone columns).
