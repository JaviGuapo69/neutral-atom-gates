---
name: se-cycle-blocks
description: THE OFFICIAL AND FINAL MEASUREMENT SKILL (promoted 2026-09-16 on the user's instruction; the user corrects its remaining mistakes BY HAND against the movie and does not expect the automatic analysis to improve further). Production of sessions 9-22 plus, in tools/sb_build.py, the S2.1 'one tone short' competition (session 25), the patch DETECTOR tools/sb_gaps.py for sub-comb batches (session 26) and the LAST-RESORT families for transitions no route describes and no rectangle carries, ranked on the free per-frame progress (session 27). Regresses c150 55/55, c300 64/64, c200 69/69 IDENTICAL to the pre-promotion production; c540 92 of 98 movements match Shayne's hand book, 0 undetermined, AUDIT CLEAN (SESSION_27_LAST_RESORT.md). Transcribe a WHOLE SE-cycle movie into a renderable schedule workbook, then render it back and score it. Reads blocks and their movements by rest-frame occupancy, 1-D colour profiles and marker OUTLINE colour, and reduces them to the simplest AOM configuration. Run tools/sb_blocks.py, then tools/sb_events.py to name the readouts and loads, then tools/sb_full.py --events (which solves one pulse-free interval at a time and is WRONG WITHOUT IT — an unnamed readout becomes a false relocation and the solver fills it with a neighbouring block's move); tools/sb_probe.py is the diagnostic for anything it cannot describe and tools/sb_report.py writes the evidence report. Use instead of se-cycle-movies' se_moves.py/se_waypoints.py whenever a movie contains sub-block moves — two halves of one block travelling to different places in the same batch, or a block permuting onto its own sites — which those tools cannot see. Proven end to end on c150 (0 undetermined, 0.047 site), c200 (0.053) and c300 (0.053). READ THE SESSION 15 BOX AND RULE 27 FIRST. A same-site permutation is invisible to the census, the score and render validation alike, and a move that was never even enumerated appears in no list at all — not even the undetermined one — so completeness must be PROVED with tools/sb_audit.py, tools/sb_mapcheck.py and tools/sb_watch.py before any sheet is delivered.
---

# Reading blocks and movements from an SE-cycle movie

> **STATUS: THE OFFICIAL, FINAL VERSION — promoted from the `se-cycle-blocks-s25` fork on
> 2026-09-16 on the user's instruction.** Session 9 (2026-09-07), extended sessions 10–12
> (2026-09-08), 13 and 14 (2026-09-09), 15 and 16 (2026-09-10), 22 (2026-09-14), 25–27
> (2026-09-15). DO NOT DELETE, DO NOT ARCHIVE.
>
> **The user's decision (2026-09-16):** the automatic analysis of movements will not get better than
> this; this skill is used as is from now on and its remaining mistakes are corrected BY HAND
> against the movie. So the job of a session is now to RUN it (RUN_TEST.md, the run book in
> HANDOVER.md), deliver the book and the side-by-side video, and list for the user the movements
> it reports as undetermined, over the guideline, or in doubt — not to change candidate generation
> or ranking. If a change to `tools/` is ever made anyway, regress c150, c200 AND c300 with
> `tools/cmp_tol.py` against `reg_c150\fix`, `reg_c200`, `reg_c300_fix` first ("newer isn't better").
> The pre-promotion production is archived at
> `.claude/skill_archive/se-cycle-blocks-PRODUCTION-pre-promotion-2026-09-16/` (identical to the
> 2026-09-15 backup beside it); restore by copying it back.
>
> Known faults on c540 (`SESSION_27_LAST_RESORT.md` §3, §5) — the six-frame rotation at f348-355
> never enumerated, and `X0+X1 rows f152-154` disagreeing with the hand book — plus `X0 rows
> f140-144` (D3 does the same movement as D4; the S2.1 read gave it a different one) **were
> corrected BY HAND in session 28 (2026-09-16) and c540 is CLOSED**: `run_c540_s28\c540_s28_blocks.xlsx`,
> `SESSION_28_HAND_CORRECTIONS.md`. The procedure for doing the same on the next movie is
> `handmade correction method.md` at the project root. c150, c200, c300 and c540 are correct.

> ## ⚠ SESSION 27 (2026-09-15, evening) — the LAST RESORT in `sb_build.build()`, and `MAX_SPAN` 16 → 27
>
> For a transition EVERY route has failed on (no outline read, no displacement fit, no uniform
> translation, no sub-comb), and which no other species' rectangle carries (rule 29's midpoint
> test — the same one the UNDETERMINED filter uses, so the candidate is computed inside the loop
> but committed only after that test; committed inside the loop it misfired on c540's X1 f023-026,
> `run_c540_s25\logs\seg0_last_resort_TEST.log`), three one-integer families are scored:
> `rotations_of` the run `moving_tones` measured (and its hull); `periodic_rotations` — rotation by
> k within each consecutive group of m tones (c540's Z0 f380-383: each row triple rotates within
> itself, the hand book's +2 on rows 19, 22, 25); and, for a relocation, `relocation_rotations` —
> the translation composed with each rotation, k = 0 the plain translation (c540's f315-328
> `13:22->3:12 | 23:24->1:2`). The v2 fork had the last family and it BROKE c300 by competing against
> a translation an earlier route had read correctly; here it can only ever answer a transition whose
> alternative is UNDETERMINED, which is why c150/c200/c300 cannot change (they have none).
>
> **Ranked and gated on the FREE per-frame progress** (`sb_compose.progress_per_frame`: mean error
> + monotone penalty, ≤ 0.10), not on the smoothstep fit. A fast wrap (22 sites in 13 frames, 7 in
> 6) turns a 1 % easing error into 0.2 site and the comb's unit pitch saturates it, so the joint fit
> scored the hand book's maps 0.22-0.23 and preferred wrong members at 0.19-0.21; the free fit gives
> them 0.03-0.05, monotone. The monotone penalty breaks time reversal (the mirror rotation scores the
> same with p running 1 → 0) and is SKIPPED for an involution (rotation by n/2, Z0 f001-007: p and
> 1 − p are the same picture, so the penalty was 0.22 of noise on the right answer). The smoothstep
> fit still supplies the timing and the quoted `mean`, which reads OVER 0.10 on these moves,
> honestly. `MAX_SPAN` 16 → 27 was the handover's suggestion for f315-328; on its own it recovers
> nothing (the wrap markers scramble the correspondence from the second moving frame), and it is
> kept because the cap never guarded anything — every scale is pinned by the destination set.
>
> Per-segment tests on c540 (final code): seg 0 Z0 f001-007 `13:18<->19:24` 0.048; seg 9 Z0+Z1
> `13:22->3:12 | 23:24->1:2` 0.046; seg 10 X0 `13:17->20:24 | 18:24->13:19` 0.032 and Z0+Z1
> `1:7->6:12 | 8:12->1:5` 0.028 — all the hand book's maps. Whole-movie result and regressions:
> `SESSION_27_LAST_RESORT.md`.
>
> ## ⚠ SESSION 26 (2026-09-15, afternoon) — `tools/sb_gaps.py`: the PATCH DETECTOR feeding the production solver
>
> `sb_full.py` now runs `sb_gaps.fill` after the production chain on every segment (`--gaps off`
> reproduces the session-25 behaviour). `sb_patch.patch_movements` (session 23) is used ONLY as a
> detector: the outline colour names the sub-comb a batch drives (rule 44), the species band and a
> rough frame range. The map and timing come from the PRODUCTION routes run on peaks restricted to
> that comb (`SubPeaks`, `partition`, `measured_partition`, `rotation_candidates`, the S2.1
> rotations, `fit_timing`, `verify`). Four gates keep it silent on a movie without sub-comb moves:
> the comb must be a strict subset of the block; nothing outside the comb may move meanwhile
> (rule 40, window clamped to the neighbouring moves); a whole-block move containing the midpoint
> explains it, and an existing sub-comb move is only REPLACED if the detector's read wins on the
> same peaks under 0.10; the winner must be under 0.10 on the moving frames. c540 segment 6 went
> from 10 to 19 moves, 17 of 19 matching the hand book. Full account: `SESSION_26_PATCH_DETECTOR.md`.
>
> ## ⚠ SESSION 25 (2026-09-15) — THIS FORK: production + the S2.1 COMPETITION
>
> `tools/sb_build.py` differs from production in exactly one place inside `build()`. After the
> appearance read is completed by the complement rule, `moving_tones` measures which tones of the
> block provably LEAVE their site on the moving frames (no peak within 0.30 of the tone; off-panel
> tones skipped, rule 21). **If the appearance read holds none of those static, the production code
> runs unchanged.** If it does — a contiguous run read ONE TONE SHORT, the fault the c540 hand-book
> comparison found thirteen times — the appearance map competes against the rotations of the
> measured run (and its convex hull) and the measured-displacement candidates, ranked by
> `mean_moving`, the statistic the measured route already uses.
>
> | regression (production `sb_full.py --events`) | result |
> |---|---|
> | c150 vs `reg_c150\fix\moves_full.json` | **55/55 identical maps AND windows**; competition fired 0 times |
> | c300 vs `reg_c300_fix\moves_full.json` | **64/64 identical maps AND windows**; competition fired 0 times |
> | c540 segments 0-1 vs the hand book | all six short maps corrected (`X0 cols 1:7->6:12|8:12->1:5`, `X1 cols 13:19->18:24|20:24->13:17`, rows `13:15<->16:18` x2, `10->17|11:17->10:16`, `12:14<->15:17`); the phantom `X1+Z0` join gone |
>
> NOT in this fork, on purpose: no `FIT_PAD`, no relocation+rotation family (broke c300 in v2), no
> sub-comb propagation (spurious transitions in v2), no patch route. What it does NOT fix on c540:
> the sub-comb batches whole-block occupancy never enumerates, the f315-328 relocation+rotation
> (|D| = 22 > `MAX_SPAN`), and Z0's f001-007 rotation, now honestly UNDETERMINED instead of hidden
> inside a phantom join. Cost: c540 runs ~3x slower (each contradicted read fits 6-12 extra
> candidates over the pulse-free interval); run it as halves with `--only` and merge with
> `tools/merge_halves.py`. `tools/cmp_tol.py` is the comparator for the user's pass criterion
> (maps identical, ~1 frame of window shift tolerated). Full account: `SESSION_25_C540_ROOT_CAUSE.md`.
>
> ## ⚠ SESSION 22 — ALL THREE CLOSED MOVIES REGRESS GREEN AGAIN. `--events` IS MANDATORY.
>
> | | moves | against the delivered book | undetermined | `sb_audit` |
> |---|---|---|---|---|
> | **c150** | 55 | **IDENTICAL, 55/55** | 0 | CLEAN |
> | **c200** | 69 | 68/69 identical; one move's END frame reads f288 where session 14 wrote f287 — same map, same comb, same start — and it **returns to f287 under session 14's own `--pulse-bound last --stationary-rest off`**, so it is the documented convention change, not a regression | 0 | CLEAN |
> | **c300** | 64 | **IDENTICAL, 64/64** | 0 | CLEAN |
>
> Counts: c150 102 rows / 4 AOM; c200 131 rows; c300 118 rows / 4 AOM peak 4 / 9 over-guideline.
> The frames 0–49 acceptance test is **bit-for-bit identical** to session 16's stored log.
> Transition counts read 4 (or 3) higher than the delivered books — 73, 90, 78 — because the
> readout/load bridges are now enumerated and **named** rather than absorbed.
>
> Sessions 17–21 (the archived `v2` fork) were reset after failing a c300 regression. The reset
> target — this skill — was then reported as ALSO finding one move c300's accepted book lacks, plus
> 2 undetermined. **Both were adjudicated against the pixels and both were the same defect, and it
> was not in the code: `sb_full` was invoked without `--events`.**
>
> **THE ORDERING WAS THE BUG.** Finding the readouts and loads was **step 6** of the Procedure, and
> `sb_full` — **step 4** — takes them as an INPUT. So a first pass through the Procedure as written
> could not be right. It is now **Procedure step 3a**, before the solve. (Not to be confused with
> §3a of "What this changes about measurement", which is the displacement fallback.)
>
> **A readout bridged to its load is not a rigid motion, and left unnamed it fails in two ways,
> both quiet.** On c300 it produced one of each:
>
> | | what the solver did | what it looked like |
> |---|---|---|
> | Z readout, f147–148 pulse | enumerated `Z1 rows 13:18 → 7:12`, found no rigid motion, and **re-emitted a neighbouring block's column rotation** to fill it — `X0 cols f149-187`, a duplicate of a real move over a wider window | written to the sheet at **3.0993 site against the 0.10 bar**, `ok=false`, and it rotates X0 by four columns instead of two |
> | X readout, f328 pulse | nothing | **2 undetermined** at f328–383 |
>
> The pixels settle it: the faded Z1 block descends rows 13.32 → 19.12 over f149–155 with its
> columns pinned at 1..10 and is off panel by f156, while a **fresh** block — faded stock at the
> half-pitch reservoir column 0.49 since f002 — turns solid at f149. Different atoms. And X0's
> columns sit on their tones to better than 0.05 site from f161 to f187, so there is no second
> rotation to find. Full write-up: `SKILL_RESET_2026-09-14.md`.
>
> **Two things now catch this, and neither existed when the ordering was written:**
>
> * `sb_full` lists every transition with a **readout signature** (solid collapses as faded jumps,
>   read across the pulse) that is **not named in `--events`**, at the end of its run. It reports;
>   it does not skip — which transitions are readouts is a measurement you confirm with
>   `sb_probe --peaks` on the FADED track.
> * `sb_audit`'s **check 1b** already failed on it (`Z1 relocation f148..f188 rows ... has no rows
>   move`, exit 1, 5 problems). **It was never run on that regression.** Run step 4a.
>
> **AND THE REAL LESSON, which is about evidence rather than code.** `cmp_moves.py` keys on
> (species set, axis, f0, f1), so a duplicate under a *different* frame window reports as
> "64/64 reproduced, 0 maps wrong, 1 extra" — which reads like success. **A move that appears only
> in the "extra" list is compared against nothing. Adjudicate it against the pixels, and look at
> its residual first.** That one was printed as `OVER 0.10` in the log the whole time.
>
> `events.json` now sits beside `calib.json` for c150, c200 and c300. **Without it a closed movie
> cannot be re-solved** — which is exactly how c300 became irreproducible between sessions 15 and 21.
>
> ## ⚠ SESSION 16 — c540 IS TRANSCRIBED BUT **NOT CLOSED**, AND RULE 40 IS NEW
>
> **`se_cycle_c540_d18_C9C3C4_4aod.mp4`: 108 transitions, 78 moves, 158 + 8 rows, 6 AOM groups,
> `sb_audit` checks 1/2/3 clean — but 7 transitions UNDETERMINED and one structural hole.**
> Deliverables `c540_full_blocks.xlsx`, `c540_full_blocks_report.txt` (its appendix is the honest
> account), `c540_vs_shayne.md`. Working files in `run_c540/`. **This movie is the first with a
> hand transcription to check against — `c540_v3_shayne_handwritten.xlsx` — and that comparison
> found real errors in the tool's output. Read `c540_vs_shayne.md` before trusting the sheet.**
>
> **RULE 40 IS THE FINDING: THE RECTANGLE'S COMB ON THE NON-MOVING AXIS IS A MEASUREMENT.** c150,
> c200 and c300 never exercised it — every one of their moves happens to use the block's full
> extent — so `extend_comb` read the comb off the joining species' rest configuration and was
> never wrong. c540 does gate moves on a proper SUB-COMB constantly (eleven of them: cols
> `{13,19}`, `{14,20}`, `{16,22}`, `{17,23}`, `{18,24}`, `{14,16,18,20,22,24}`,
> `{2,4,6,8,10,12}` — arithmetic progressions, i.e. exactly what an AOD comb is). Assuming the
> full extent predicts every marker moving, so the static majority is scored against a moving
> prediction and the move is not written wrong, it is **rejected outright as undetermined.**
>
> **THE OTHER LESSON: THE ONLY THING THAT CAUGHT THE REMAINING ERRORS WAS THE HAND BOOK.** With
> `sb_audit` clean and the census clean, Shayne's book still shows my X column permutations are
> systematically wrong in the same way — where the movie rotates a whole 12-column block, my
> partition read leaves ONE column static and shifts the rest by one less. Two cases scored
> against the pixels and Shayne wins both (0.2126 vs 0.2432, 0.1942 vs 0.2352); on the first, my
> map needs a marker sitting at 1.00 on f002 and the movie's lowest peak is 1.66. **This is rule
> 27's warning again in a new place: the automatic checks all passed.**
>
> **AND THE AOM ANSWER, WHICH IS WORTH CARRYING TO EVERY MOVIE.** Shayne's book writes up to 6
> crossed pairs; applying rule 8's merge criterion to his own batches drops the peak to **4**,
> matching the movie's "4-AOD" title, with 38 of his 55 non-gate batches needing fewer than he
> wrote. `run_c540/aom_min.py` does this for any `Combined` sheet — run it on a hand book before
> believing its AOM count.
>
> Ten defects were fixed this session, all in `se-cycle-blocks`; the c150 regression held
> throughout (frames 0–49 bit-for-bit; the whole movie reproduces all 55 delivered moves exactly,
> 0 undetermined, AUDIT CLEAN, 4 AOM groups). `sb_full` gained `--events` (name the readout/load
> transitions so the solver cannot invent moves for them) and `--stationary-rest`.
>
> ## ⚠ SESSION 15 — READ THIS FIRST. RULE 9's BOUND WAS OFF BY ONE FRAME ON EVERY MOVIE.
>
> **c300 (`se_cycle_c300_d14_C10xS3_4aod.mp4`) is closed: 75 transitions, 64 moves, 126 rows,
> 4 AOM groups, 0 undetermined, audit clean, 0.0534 site.** Rules 36–39 are new, and rule 9 has
> been **corrected**. c150, c200 and c300 are all done; **c400 is next.**
>
> **THE CORRECTION, and it is not specific to c300.** Sessions 9–14 read
> rule 9 as "a move may start on the **last** frame of a pulse run". **A Rydberg pulse is far
> faster than the atoms move** — effectively instantaneous on this time base — so a two-frame pulse
> **run** is one instantaneous gate whose *display* the animation holds for two frames. The
> original animation over-represents the pulse's duration. **The gate's instant is the run's FIRST
> frame, and that is when the atoms are free to move.** Correcting it took c300 from 0.0618 to
> **0.0534** site end to end, and its over-guideline moves from 17 to 9. It is not a c300
> peculiarity — c150 improves too (over-guideline **10 → 6**, mean of per-move errors
> 0.0620 → 0.0558) — but **on c150 the gain is NET rather than uniform: 22 moves improve and 28
> get slightly worse**, and c150 has not been re-scored end to end. Read rule 9 before acting on
> this. `sb_rigid.PULSE_BOUND_FIRST` is now `True`.
>
> **The second lesson is about checking, and it is why c300 did not repeat c200's failure.**
> c300's Z0 and Z1 **exchange places**, and Z0's half of the exchange was not merely undetermined —
> it was **never enumerated**, so it appeared in *no* list at all, not even the undetermined one.
> Rule 27's warning that "0 undetermined is not evidence of completeness" is therefore too weak:
> **the undetermined list is not a list of what is missing, it is a list of what was noticed and
> not solved.** The three checks that do prove completeness are new tools — `sb_audit.py`,
> `sb_mapcheck.py`, `sb_watch.py` — and step 4a of the Procedure. Run them.
>
> ## ⚠ SESSION 14 — STILL LOAD-BEARING
>
> **c200 (`se_cycle_c200_d12_C4xD10_4aod.mp4`) is closed: 86 transitions, 69 moves, 140 rows,
> 4 AOM groups, 0 undetermined, census clean, 0.0526 site.** Rules 27–35 are new. Nine defects
> were found; **five of them were found by the USER WATCHING THE COMPARISON VIDEO, after every
> automatic check in this project was clean and the sheet reported "0 undetermined".**
>
> **THE ONE THING TO INTERNALISE (rule 27): a SAME-SITE PERMUTATION is invisible to every
> automatic check here.** It conserves atoms, so the census cannot see it; it ends on the
> rectangle it began on, so the score cannot see it; it is self-consistent, so `render.ps1`
> validation cannot see it. **The only signals are the UNDETERMINED list and WATCHING THE WHOLE
> VIDEO** — and on c200 a buggy guard was silently emptying the undetermined list, so "0
> undetermined" was reading empty for the wrong reason. Budget time to watch all 384 frames.
> Spot-checking a few stills is NOT enough: three of the four misses were in windows that had
> been spot-checked.
>
> **The frames 0–49 acceptance test cannot see a cross-segment defect** — it is a single
> `sb_build` call over one range. **Also re-run c150's WHOLE movie** through `sb_full`
> (69 transitions / 55 moves / 0 undetermined / 102 rows before the extras); it takes ~10 minutes
> and runs in parallel with the new movie. Four of session 14's nine defects were invisible to
> the frames 0–49 test and it stayed bit-for-bit identical through all of them.
>
> **Session 13: THE WHOLE OF c150 IS TRANSCRIBED, RENDERED AND SCORED.** 69 transitions, all
> accounted for, 0 undetermined; 110 schedule rows; **4 crossed pairs** (`allocate_aom`'s peak over
> all rows reads 5 — see the c150 section); `se_sim` clean; **0.0472 site**
> against the movie over all 360 non-pulse frames. See "The whole c150 movie" below for the numbers
> and for the one procedural point that matters — **run it interval by interval, never in one
> pass.** Rules 18–26 are new; nine of the twelve defects behind them were code that violated a
> rule already written here.
>
> **The transcription is AUTOMATIC. Run `tools/sb_build.py` — see Procedure.** It reproduces the
> verified c150 frames 0–49 answer with no hand steps (8 moves, 16 rows, 4 AOM groups, 0
> undetermined, 0.046 site) and that remained bit-for-bit unchanged through all nine of session
> 13's fixes — **re-run it after every change.**
> This directory — `.claude/skills/se-cycle-blocks/` — is the **only** copy. There is no copy under
> `rebuild guide/skill/` and there should not be one. It does **not** supersede
> `.claude/skills/se-cycle-movies/`; the two are used together, and both must be kept. See
> `HANDOVER.md` sessions 9–11.

This skill replaces the *measurement* half of `se-cycle-movies`. The data model, the workbook
format and the renderer are unchanged — read `se-cycle-movies/reference/SE_CYCLE_REBUILD_GUIDE.md`
for those. What changes is **what counts as a block, what counts as a movement, and when it is
allowed to happen**.

> **Why it exists.** The matched-filter extractor in `se-cycle-movies` suppresses any two markers
> closer than 0.62 of a lattice pitch, on the rule that one trap holds one atom. But bringing two
> atoms within a fraction of a pitch of each other **is what a two-qubit gate move does**. So the
> extractor is structurally blind to exactly the moves that carry the circuit, and the composer
> downstream then reports the block as "at rest, unchanged". On c150 that turned three moves into
> one and silently reversed the row order of both X blocks. See §7.

---

## The rules

These are normative. Rules 1–8 are session 9; 9–14 are sessions 10–11; 15–17 are session 12; 18–26
are session 13, which transcribed the **whole** of c150; 27–35 are session 14, which transcribed
c200; 36–39 are session 15, which transcribed c300 — and session 15 also CORRECTED rule 9;
**40 is session 16, which transcribed c540 and could compare it against a HAND BOOK.**
Each was found by reading the tool's own rejected output — or, for five of session 14's, by a
human watching the comparison video. Each cost real time and each one silently corrupts a
transcription if ignored.

> **The one-line lesson, twice over: the rules were already right, and the defects were in code
> that violated them.** Nine of session 13's twelve, and all nine of session 14's. Every fix is a
> rule in this file being enforced where it was not, or a statistic being made to agree with a rule
> it contradicted. **Before adding a new rule, check whether an existing one is simply not being
> applied.**
>
> **Session 14's addition: the rules were right AND the tests were blind.** Rule 27 explains why —
> the whole automatic check suite cannot see a same-site permutation. Read rules 27–32 before
> touching a new movie; they are the ones that produce a sheet which passes every check and is
> still wrong.
>
> **Session 15's addition, and it breaks the pattern: A RULE ITSELF WAS WRONG.** Rule 9's timing
> bound was off by one frame on every movie for six sessions, and nothing in the pipeline could
> have found it, because the error is invisible in *structure* — every map, every count and every
> census stays correct — and shows up only as a mid-move lag that looks like ordinary crossing
> error. **It took the user telling me a physical fact about the hardware: a Rydberg pulse is far
> faster than the atoms move.** So: when a systematic residual will not go away and every map is
> confirmed, suspect a CONVENTION rather than a measurement, and check the conventions against the
> physics rather than against the animation. The animation is a drawing of the schedule and can
> misrepresent it — here it over-represented the pulse duration.

1. **A block is rigid.** Throughout a movement the spacing between its markers and its shape are
   constant. Anything that changes shape is not one block — it is two or more blocks with
   different displacements, and must be split until each part is rigid.

2. **A zone is 100 % full or 0 % full at rest.** At the beginning and end of every movement each
   zone's occupancy is total or nothing. A frame showing a zone half occupied is a **transition
   frame**: those atoms are in flight, not parked. Never read a configuration off a partly filled
   zone.

3. **Faded means not in use.** Atoms parked at the side of the zones, outside the array, are drawn
   in a paler shade. They are stock. They join the cycle later and turn vivid at the instant they
   do. A faded block is not part of any configuration until its colour changes.

4. **Atom number is not conserved.** Atoms leave the grid past the edge of the screen and arrive
   from off screen. Do not force conservation; account for departures and arrivals as events.

5. **Identify blocks at a rest frame, then walk forward.** Find a rest frame by rule 2. Step
   forward a few frames until motion starts, and read off the blocks and their velocity there,
   while they are still near their starting sites and unambiguous.

6. **Do not track a block the whole way — meet it from the other end.** Go to the *next* rest
   frame, step back a few frames, and read the blocks and velocities there. Extrapolate backwards
   to where each must have come from, and match against the blocks found in rule 5. Two
   independent readings that agree are a measurement; one tracked trajectory is a guess.

7. **Shape + fill colour + outline colour is the block's identity, and all three are constant
   through a movement.** The outline is not decoration. In these movies it changes when a block's
   role changes, and within one move it marks *which sub-block is moving* — see §3.

8. **Then find the simplest AOM configuration that realises the movements.** Not the rows: the
   hardware. Merge rows onto one crossed pair wherever the merged tone map is still strictly
   increasing, and report the peak number of concurrent groups.

9. **NOTHING MOVES DURING A GLOBAL PULSE.** Every move lies entirely inside one pulse-free
   interval; no move may start before a pulse and finish after it, and the configurations either
   side of a pulse are therefore different.

   **A RYDBERG PULSE IS FAR FASTER THAN THE ATOMS MOVE — it is effectively INSTANTANEOUS on this
   time base — so a pulse RUN of several frames is ONE instantaneous gate whose DISPLAY the
   animation holds for those frames. The animation over-represents the pulse's duration; that is a
   fault of the original animation, not physics.** The gate's instant is the run's **first** frame,
   and that is when the atoms are free to move:

   ```
   t_start  >=  (FIRST frame of the pulse run before the interval) * dt
   t_finish <=  (FIRST frame of the next pulse run)                * dt
   ```

   **Sessions 9–14 used the run's LAST frame for the lower bound and that is wrong**, by one frame
   on every two-frame run, on every movie. It is not a small effect, because the error is not
   motion during the gate — the quintic easing is flat at its start, so a block has moved only
   ~0.02 site by the run's second frame either way — it is that the whole easing is anchored a
   frame late and the move then lags through its entire middle, where the movie is most legible.

   The pixels say so sharply. Scanning `t_start` over the frames of the preceding run, for all 29
   c300 moves that begin on the first free frame after one, the run's first frame is a clear
   minimum: `Z0+Z1 cols f190-209` scores **0.0510 there against 0.1594** one frame later, `X0 cols
   f246-261` **0.0959 against 0.2432**, `Z0 cols f048-064` **0.0810 against 0.1866**. And c300's
   **single-frame** runs settle it independently, since there first == last: at f328 the optimum is
   exactly the gate frame, **0.0308**, against 0.1146 one frame later and 0.1157 one frame earlier.

   | | last frame (old) | first frame (correct) |
   |---|---|---|
   | c300 score, end to end | 0.0618 | **0.0534** |
   | c300 frames all within 0.25 site | 126/360 | **133/360** |
   | c300 moves over the 0.10 guideline | 17 of 64 | **9 of 64** |
   | **c150** moves over the guideline | 10 of 55 | **6 of 55** |
   | **c150** mean of per-move errors | 0.0620 | **0.0558** |

   **BUT THE IMPROVEMENT IS NET, NOT UNIFORM, AND YOU WILL SEE INDIVIDUAL MOVES GET WORSE.** On
   c150's whole movie 22 of 50 comparable moves improve and **28 worsen**; the aggregate improves
   because the winners are large and the losers small (`X0 cols f224-239` 0.1599 → 0.0451 against
   the worst regression, `X1+X0 rows f030-046`, 0.0764 → 0.1312). On the **frames 0–49 window
   alone the balance is unfavourable** — 3 better, 4 worse, over-guideline 2 → 5 — because that
   window is short and its moves are mostly chained to each other rather than to a pulse. Judge
   this on a whole movie and on an end-to-end score, never on one window.
   **Only c300 has been scored end to end under the new bound**; c150's `extra.json` was not kept,
   so its readout/load rows would have to be reconstructed from the delivered workbook first.

   **c150's and c200's delivered sheets were built with the old bound** and have not been
   regenerated. No map in either is wrong and both remain self-consistent; only their timings are
   a frame late. c540_v4's `Gates` row 1 (`t 0 → 0.03`, frames 0..1, first move at 0.03) is what
   suggested the old reading — but that is the gate's *display* span, and it is the sheet's own
   convention rather than a measurement.

   `sb_rigid.PULSE_BOUND_FIRST` is `True`; `sb_full --pulse-bound last` reproduces sessions 9–14.
   **The trap if you ever touch this:** `pulse_bounds` used to initialise `lo = a_iv - 1`, and for
   an interval that starts one frame after a run that *is* the run's last frame — so the flag was
   silently inert and the first "experiment" reproduced the old answer exactly, to four decimals.
   **Check that a convention switch actually moves a number before believing the comparison.**

10. **A merged profile peak is a CROSSING, not a destination.** Two markers closer than ~0.3 pitch
    produce one peak at their midpoint, and that midpoint is where they *pass each other*. Reading
    it as a destination invents a move that does not exist: on c150 it turned an ordinary pairwise
    column swap (`1↔2, 3↔4, 5↔6`) into a fictitious sub-pitch "gate excursion" and an argument
    about needing a finer `tone_divisor`. **Every move measured on c150 lands on integer tones.**
    Before believing any non-integer destination, check whether an integer-endpoint permutation
    explains the same frames — it did, exactly.

11. **Find the partition and the timing SEPARATELY.** For a candidate partition, fit the progress
    `p` *independently on each frame*. A correct partition explains every frame **and** yields a
    monotone `p`-sequence; a wrong one cannot do both. Fit the easing to that sequence afterwards.
    This makes partition discovery a scored search instead of a judgement call, and it is the only
    reason the c150 moves that carry no outline are recoverable automatically.

12. **Enumerate the transitions from the occupancy record, not from the outline.** The outline
    reader only fires where an outline is drawn, and on c150 it missed three real moves — one of
    them carried by the same rectangle as another species' move. Between two settled
    configurations, if a species goes off-grid then *something moved*: endpoints that differ are a
    **relocation**, endpoints that are identical are a **same-site permutation**. Every one must be
    accounted for or the movie is not reproduced. c150 has **29 relocations and 39 permutation
    windows**.

13. **Never take a species' comb from the seed.** Read it from that species' configuration *at the
    time of the move*. X0 is on rows `6:10` when it swaps columns at f019-029, not on its seed rows
    `1:5`; taking the seed put one rectangle at `y 1:5,11:15` where the movie plainly shows
    `y 6:15`.

14. **Boundaries within ~1.5 frames are one boundary measured twice — but never merge across a
    pulse.** One block cannot do two things at once and the easing is flat at both ends, so each
    endpoint is individually soft. Merge them, or the sub-frame overlap makes the AOM colouring
    believe both moves are live at once and allocate a fresh crossed pair. But a pulse separates
    two batches *by definition*: chaining `f16.74` and `f17.00` (ends, before the pulse) with
    `f18.00` (starts, after it) drags the post-pulse moves 1.75 frames early and triples their
    error. And place the merged boundary **where it costs least**, not at the cluster mean — the
    mean is arbitrary and simply trades one move's accuracy for another's.

15. **A configuration that exists only on a PULSE frame is still a configuration — read it from
    the outline colours.** Rule 2 says never read a configuration on a pulse frame, and that is
    right *about the fill*: the tint moves every fill colour ~40 RGB and c150's Z0 comes back with
    four peaks where there are six. But the outline colours are not shifted the same way and read
    all six cleanly, and a pulse frame is physically the most reliable rest there is, because
    nothing moves during a pulse (rule 9). So try the fill, then every outline, and accept the
    first that gives a **full block on tones**.

    This is load-bearing, not a refinement. Any transition that begins at the seed, or ends *at* a
    pulse, has a settled configuration on one side that lives only on a pulse frame, so occupancy
    alone never sees it and the move is silently missing from the sheet. On c150's frames 0–49 this
    recovers **2 of the 8 moves** and takes the transition count from 9 to 11. **Every
    transition count in this project taken from `sb_compose --transitions` is therefore a floor,
    including the movie-wide 68.**

16. **Read the partition BEFORE arrival; fit the timing AFTER it.** These want opposite windows and
    using one window for both loses a move at each end.
    * The **partition** must be read where the classes are still resolved. Past arrival every
      outline colour covers the whole block again, the classes dissolve into one, and the read
      returns "no move". Shorten the window from the far end until at least two classes resolve,
      and require the last frame used to be a genuine arrival — every peak within 0.25 of a tone —
      or `dst` gets rounded off a marker still in flight.
    * The **timing** wants the opposite: a couple of settled frames *past* arrival are strong
      evidence that the block has stopped, and they pin `t_finish`, which the flat tail of the
      easing otherwise leaves very soft. On c150 widening the timing window by two frames took
      six of eight moves' errors down (Z0's seed swap 0.112 → 0.087) and changed no partition.

17. **Score against a registration bias measured on a STATIC species, not against zero.**
    `render.ps1` places its markers at a constant sub-site offset from the movie's — on c150,
    **−0.084 site in x and +0.081 in y**, on every species and every frame. It is not schedule
    error, and the proof is a species that never moves in the window: Z1 holds one rectangle
    throughout frames 0–49, so its schedule is exactly right by construction, and it *still* shows
    that offset, with a spread of 0.009 site. Uncorrected it nearly **doubles** the reported error
    (0.0946 raw against 0.0459 corrected) and will make a correct workbook look half as good as it
    is. Calibrate on the static species, subtract, and say which number you are quoting.

18. **A move's tone map must COVER the block exactly and be a BIJECTION.** Both halves were
    silently violated and both produced sheets that looked measured.
    * A **partial cover** scores every unmodelled marker against a foreign prediction, so it reads
      as a wrong partition when it is a missing piece: c150's f272-281 X1 read `1:2 -> 3:4 |
      3:4 -> 1:2` for a SIX column block and came back at 0.41 site. Complete a partial read with
      the complement rule of §3 (`B = S \ A`), which is exact.
    * Two sub-blocks claiming **one destination** is two atoms driven into one trap, which no
      crossed pair can do. c150's f192-203 emitted `3:4 -> 1:2 | 5:6 -> 1:2`. Reject it.

19. **k IS NOT 2.** A move is *k* rigid sub-blocks and c150 uses k = 1, 2, 3 **and 4**. Two
    failures follow, one at each end:
    * **k = 1** — a plain translation of the whole block — has ONE appearance class, so a reader
      that requires two classes drops it. Everything structural in c150 after the first 0.7 ms is
      k = 1: both parking slides, both load carries, the closing descents. Recover it from the
      displacements (§3a), and **never from the endpoints**: c150's X1 f001-016 looks like a clean
      uniform `+5` and is really `+7` and `+2` crossing, so require the per-tone displacements to
      *share one value* before writing a translation.
    * **k >= 3** — where a class is NOT rigid, **SPLIT it, do not discard it.** A colour-separated
      profile stays resolved right through a crossing (that is the whole point of §3z, since the
      partners that cross carry different colours), so a class's members' own displacements are
      measurable even where the shared fill has collapsed. c150's f331-350 Z0 has mauve on cols
      7, 10, 11 travelling −3, −5, −5 and gold on 8, 9, 12 travelling −7, −7, −9: both classes are
      "not rigid", and splitting yields four groups that tile the destination set exactly, rigid to
      0.009 and 0.015 site. Discarding them lost the move entirely.

20. **The sorted correspondence is valid only up to the first frame where the PEAK COUNT DROPS.**
    An equal peak count does not prove there has been no crossing — after one, the count is back to
    normal and the *order* is scrambled. On c150's f341 Z0's six columns read
    `3.65 4.63 5.13 6.37 6.88 7.89` while the tones that own them are `8, 9, 7, 12, 10, 11`. But
    two markers cannot swap order without first coming within ~0.3 pitch and merging, so the count
    dropping marks the boundary exactly: use the leading run of frames that still show every peak,
    and nothing after. Then read the ratios by a **joint rank-1 fit** over that run (`d_i(f) =
    D_i · s_f` is exactly rank 1, so its leading singular vector *is* the displacement direction
    with the per-frame noise averaged down) — **never by rounding a single frame.** Rounding one
    frame gives Z0's tone 9 a ratio of 0.71 against a true 0.778, which rounds to −6 where the
    answer is −7, and the whole move is then rejected.

21. **A PREDICTION OFF THE PANEL CANNOT BE SEEN — do not require it to be.** Score every measured
    peak against the model, but only require a prediction to be *visible* if it lies inside the
    panel's visible tone range. Otherwise every move that leaves the panel is scored as though the
    crop were error: c150's two parking slides (`1:6 -> -5:0`, only column 0 still visible) came
    back at **0.62 and 0.64 site for maps that are exactly right**, and the phantom penalty also
    dragged X0's fitted finish seven frames past where the movie stops moving. Corrected: 0.081
    and 0.160.

22. **Block size is a property of the BLOCK, measured over the WHOLE movie.** It is one rigid size
    throughout (rule 1), so a view can only ever show *fewer* markers than it has, never more —
    take the largest count seen on at least two on-grid frames, and take it movie-wide. The mode
    over one window says "1 column" wherever the block spends that window off panel: c150's X0
    reads 1 column on 44 frames against 6 on 25, so `rect_at` had no width to complete the clipped
    rectangle with and **both parking slides were never enumerated as transitions at all** — the
    blocks would have stayed on screen in the rebuild while the movie parked them off it.

23. **A pulse-frame configuration read from the shared OUTLINE mask may belong to ANOTHER SPECIES.**
    Rule 15 is still right, but the mask spans the panel, so a species whose window contains a
    different block reads that block as its own — on c150's f329 X1's window contains Z0 at
    `7:12 x 1:5` while X1's own fill is not in the window at all (area 0). Two guards, both from
    rules already in this file: prefer the **rule-9 deduction** (if the adjacent non-pulse frame is
    settled, the pulse frame holds exactly that configuration), and where two species claim
    **overlapping sites** on one frame, drop the claim its neighbours do not confirm — one trap
    holds one atom. Untreated this invented an X0 jump of six columns in one frame across a pulse.

24. **An appearance class exists THROUGHOUT the move and has a FIXED number of members** — and one
    spurious part poisons a whole partition, so both tests matter.
    * A colour present on a handful of frames is a **blend**, appearing only where two markers
      overlap enough to mix at their anti-aliased boundary. c150's f192-203 read both real classes
      perfectly (0.044 and 0.018 site) and lost the move anyway to `rgb(203,167,90)` on 2 frames
      of 12.
    * A colour whose **peak count wanders** takes its `src` and `dst` from dropout frames: c150's
      `rgb(184,133,90)` shows 2, 3, 3, 3, 3, 2 peaks and so claimed `7,11 -> 8,12`, a SUBSET of
      the real class `7,9,11 -> 8,10,12`. Keep the modal count and drop the frames that disagree.
    * **The same atoms seen through a second colour are not a second sub-block.** An outline is
      drawn with an anti-aliased edge, so c150 carries `rgb(255,250,182)` alongside the gold and
      `rgb(184,133,90)` alongside the mauve (§3z names both). Merge parts that share a tone *and* a
      displacement; exact-key dedup cannot see it, because the keys differ.

25. **A move must complete most of its travel INSIDE the window it claims to explain.** The easing
    is flat at both ends, so a fit will happily push the whole move past the end of the window and
    sit at progress ~0 throughout — which reproduces a block that never moved, and scores
    beautifully for exactly that reason. Read it as a rejection, not a result: on c150's f192-203 a
    blend colour produced a fictitious `rows 12 -> 13 | 13 -> 12` swap fitted to f203.4-f222.0,
    entirely outside its own f192-205 window, for a mean of **0.0199** while X0's rows sat dead
    still on 11:15 the whole time.

26. **Judge rigidity on a ROBUST quantile of the per-frame spread, and report the max separately.**
    The frames that inflate a class's spread are the ones where *another* class crosses through it:
    two markers within ~0.3 site blend at their boundary and each colour's peak is pulled toward
    the other. c150's f168-178 X0 mauve sits at 0.01-0.03 site on eleven frames and 0.16 on the one
    where the mask partly drops out — enough to fail a 0.15 bar on a `max`, and a real move was
    reported undetermined. §4 already says a residual concentrated at a crossing is a resolution
    limit and not a wrong map; the statistic has to agree. A class that is genuinely two sub-blocks
    is wide on *most* frames, so this does not weaken the test — and rule 19's split now catches
    those anyway.

27. **A SAME-SITE PERMUTATION IS INVISIBLE TO EVERY AUTOMATIC CHECK IN THIS PROJECT.** This is the
    most important rule on the page, and it is why session 14 shipped a wrong sheet twice.
    * it conserves atoms, so **`se_sim`'s census cannot see it**;
    * it ends on the rectangle it began on, so the **profile score cannot see it** — every frame
      at rest matches perfectly;
    * it is self-consistent, so **`render.ps1`'s validation cannot see it**.

    The only two signals are the **UNDETERMINED list** and **WATCHING THE VIDEO**. So:
    **never read "0 undetermined" as "nothing is missing"** without satisfying yourself that
    nothing is emptying that list (rule 29 was doing exactly that), and **watch all 384 frames
    before delivering**. On c200 the user found four wrong or missing moves this way — at f093,
    f169, f289 and f330 — while the census was clean, the render validation was 0 and the score
    was 0.057. Three of the four were in windows that had been spot-checked as stills.

28. **TWO IDENTICAL RESTS A FEW FRAMES APART MAY HIDE A PERMUTATION — do not fuse them blindly.**
    `settled()` fuses two rests holding the same rectangle within ~3 frames, on the assumption that
    the frames between are a mask dropout. That is right for a dropout and **wrong for a short
    same-site permutation**, and it swallows the transition before it is ever enumerated, so rule
    12 never gets to demand an explanation. c200's X0/X1 rows 5 and 6 swap over f092–f095 while
    every other row stands still, and the gap is exactly the 3 frames the fuser tolerated.
    The discriminator is what the intervening frames show: such a frame is never a rest, so either
    a peak is **off its tone** (a marker is travelling → do not fuse) or the count is short with
    everything still on tone (**dropout** → fuse). `sb_build.left_its_tones()` implements it.

29. **OVERLAP IS NOT EXPLANATION.** A transition is only "carried by another rectangle" if the move
    was fitted *for* it — not merely because a move of the same species touches its frames. c200's
    X0/X1 `rows f162..f170` double cyclic shift was absorbed by their own `rows f154-163` move,
    which ends one frame *into* it, and Z1's `rows f009..f016` by its own `cols f002-010`, on a
    different axis entirely. Require the carrying move's **midpoint** to lie inside the
    transition's frames. This guard silently empties the undetermined list, which is what made
    rule 27's failure so hard to see.

30. **WHERE TWO PARTS CLAIM THE SAME SOURCE TONE, RANK THEM BY PEAK-COUNT STABILITY, NOT BY FRAME
    COUNT.** One atom cannot travel two distances, so a collision means one part is rule 24's
    anti-aliased twin seen through a partial mask. The merge of rule 24 only fuses twins that
    *agree* on D; a twin whose count wanders reads its `dst` off dropout frames and disagrees, the
    union stops being a bijection and `emit` throws the whole move away. Keep the claim with the
    stronger evidence — and **the evidence is the fraction of frames at the modal count**, because
    a twin is typically present on *every* frame and wrong on most of them. Ranking by raw frame
    count instead is worse than not fixing it at all: on c200 it let a twin with counts [2,3,4] and
    residual 1.015 outrank a clean class with a stable count and residual 0.042, and corrupted a
    move that had been correct.

31. **THE CROSS-SPECIES JOIN TEST IS DILUTED WHEN ONLY A FEW TONES MOVE — require the species to
    actually MOVE.** §5's justification ("a genuinely static block misses by half a tone at half
    progress, so the separation is 20–40×") holds only when the *whole* block moves, which is true
    of every c150 example. `verify` is a mean over **all** of a species' peaks, so on a move
    touching 2 of 10 rows the eight correctly-static rows dominate and a block standing perfectly
    still passes. On c200's `rows 5 -> 6 | 6 -> 5` Z0 joined while its peak list was byte-identical
    and exactly on tones across f091–f095; the rectangle would then have swapped Z0's rows 5 and 6
    as well. A block held by a moving rectangle must travel, so demand that the species leave its
    tones on that axis somewhere in the window (`sb_compose.moves_on_axis`).
    **This defect also produces movements in the rebuild that are not in the movie at all** — c200
    showed phantom X0/X1 row permutations around f289, and made the X0 block parked off-panel at
    cols −3:0 permute around f330 — **and it inflates the AOM peak** (c200: 6 against a true 4).

32. **READ THE PARTITION FROM THE FIRST MOVING FRAME. A SETTLED FRAME WEARS THE PREVIOUS MOVE'S
    ROLES.** A transition's window opens on the settled frame that ends the previous rest, and on
    that frame the block is *between* two moves — the outline still carries the grouping of the
    move that just finished. `rigid_displacement` takes `src` from the first frame of the window,
    so every class comes out mislabelled. §3a already says to take "the first frames **after motion
    starts**"; this is that, enforced.
    c200's X1 f322–f328: on f322, at rest, gold sits on rows 1,3,6,8 and mauve on 2,4,7,9 —
    interleaved, which is the *previous* (f318–321) move's grouping. One frame later gold is on
    rows 3,4,8,9 and mauve on 1,2,6,7 and stays there. Reading f322 produced
    `1->1 | 3->2 | 6->6 | 8->7`, predicting peaks at 1.00, 2.39, 2.61, 4.00 on f325 where the movie
    plainly shows 1.78, 2.25, 2.79, 3.26 — the signature of `1:2 -> 3:4` crossing `3:4 -> 1:2`.

33. **RULE 16'S ARRIVAL TEST NEEDS RULE 18'S ESCAPE HATCH WHEN A MOVE ENDS AT A PULSE.** The
    partition read may not use gate frames, so a move that finishes exactly *at* the pulse ending
    its interval has a last usable frame ~90 % through, with every peak ~0.28 off a tone against a
    0.25 bar — and the whole class is dropped. The transition's destination set is known
    independently from the settled configuration on the far side (rule 15 makes it readable even on
    a pulse frame), and a rounded `dst` that is injective and lands inside that set cannot have
    been rounded off a marker in flight. `emit` still has to make the parts tile it exactly.

34. **ONE CLASS COVERING PART OF THE BLOCK IS ENOUGH — the complement rule finishes it.** Requiring
    two resolved classes throws away a complete measurement, because §3's `B = S \ A` is exact. A
    single class covering the **whole** block is different: that is k = 1 and belongs to the
    measured-displacement route. c200's X1 f275–282 was recovered this way, its second class having
    been rejected only because the two sub-blocks cross through each other on most of the few
    frames it resolves.

35. **THE RULE-9 PULSE-FRAME DEDUCTION MUST BE ALLOWED TO LOOK OUTSIDE ITS SEGMENT.** A segment
    begins and ends on a bounding pulse run, so at its first frame there is no `f-1` in range and
    at its last no `f+1`; the deduction then falls back to the shared outline mask exactly where it
    is most needed, and rule 23 has to drop the result, leaving the species with **no configuration
    at all**. c200's X1 stands on cols −3:0 until the pulse at f253–254 and its rest lives only in
    the *previous* segment, so no segment saw both ends of `X1 -3:0 -> 1:4` — while X0's half of
    the same swap was written, putting two blocks on one another's sites. Reading one frame further
    out costs one peak measurement and cannot create a rest or transition outside the segment.

36. **THE UNDETERMINED LIST IS NOT A LIST OF WHAT IS MISSING. It is a list of what was NOTICED and
    not solved.** Rule 27 says "0 undetermined is not evidence of completeness" because a guard was
    emptying the list; c300 shows the stronger version — **a move can fail to be ENUMERATED at all,
    and then it appears in no list of any kind.** Z0's half of c300's Z0/Z1 exchange
    (`1:10 -> -9:0`) was in no output anywhere: not the moves, not the notes, not the undetermined
    list. Only Z1's half was reported, and a sheet with one half of an exchange puts two blocks on
    one another's sites.
    So **prove completeness, do not infer it.** Three checks, all cheap, none of which existed
    before session 15 (`sb_audit.py`):
    * **every transition has a move that JOINS that species and whose MIDPOINT lies inside it**
      (rule 29's test, not frame overlap);
    * **the transitions-minus-moves gap equals the cross-species joins, exactly** — one rectangle
      may carry two species, so moves < transitions legitimately, but every unit of the difference
      must be a named join. c300: 75 − 64 = 11, and exactly 11 moves carry two transitions. If the
      gap does not close, something is absorbing transitions and that is a bug;
    * **no two species claim the same site AT REST**, checked on the MEASURED rests rather than on
      what was emitted. This is the check c200 lacked, and it is the one that catches a half-written
      exchange. c300: 0 clashes over 39120 species-frame-site claims.

37. **A CONFIGURATION MAY EXIST ONLY ON A PULSE FRAME AND ONLY IN A COLOUR THAT EXISTS ONLY THERE.**
    Rule 15 says read such a configuration from the outline colours. That is not enough: **the fill
    is not gone under the tint, it has MOVED, and by more than the palette tolerance.** c300's Z0
    renders at `rgb(87,120,151)` while a pulse is on, **77 RGB** from its `rgb(41,119,213)`, so a
    34 RGB mask catches 63 px of ~7800 and resolves nine of its ten columns. No outline resolves it
    either — one reads nine, another eleven because it also picks up Z1 standing at col 0.
    **`discover_outlines` cannot supply the colour, because it SKIPS gate frames — which is exactly
    where the colour lives.** So *measure the colours on the frame*: `sb_read.colours_on_frame`
    clusters what is actually there. And **the two axes need not come from the same colour** — a
    rectangle is the product of two independent axis reads and rule 1 fixes its size, so requiring
    one colour to resolve both is an implementation restriction, not a rule. Here the palette fill
    reads all six rows on tones and only nine columns.
    Both extensions run only *after* the existing palette read has failed, so no previous answer can
    change; the guard against rule 23 is that an accepted axis read must **contain every on-tone
    peak the species' own fill still shows**, which another species' block cannot.

38. **RULE 26'S ROBUST QUANTILE APPLIES TO THE k = 1 READ TOO, AND A BLOCK ENTERING THE PANEL
    GUARANTEES ONE BAD FRAME.** `uniform_displacement` returned `None` on the *first* frame whose
    member spread exceeded the bar — a `max`, which rule 26 exists to forbid. On a block sliding
    **onto** the panel that frame always exists: while the block is a sliver at the border its
    leading marker is clipped, its centroid is pulled, and the peak reads *outside* the visible
    range. c300's Z1 `cols -9:0 -> 1:10` is rigid to **0.04 site on four frames and 0.16 on f058
    alone**, where the leading peak reads −0.48 — so a 0.15 bar on the max threw away a perfect
    translation and lost half the Z0/Z1 exchange. §7 already says a sliver at the border carries no
    information. Use the 75th percentile, report the max beside it.
    **The general form: rule 20's "leading run" is written for a block LEAVING the panel, where the
    peak count falls from full. A block ENTERING starts at one peak and rises, so the leading run
    is empty and every count-based guard fails open.** Check which way the block is going.

39. **NOTHING IN THIS SKILL MAY HARDCODE THE LATTICE.** `sb_build`'s direct-run path discovered
    outline colours over a hardcoded `(0.4, 12.6, 0.4, 15.6)` — c150's 12×15 — so on c300's 20×18
    it never looked at cols 13:20 or rows 16:18. Take it from the calibration
    (`data_cols` / `data_rows`), as `sb_full` already did. The same applies to block size, species
    count, pulse frames, the reservoir side and the readout direction: see the re-measure table.

40. **THE RECTANGLE'S COMB ON THE NON-MOVING AXIS IS A MEASUREMENT, NOT THE BLOCK'S EXTENT.** A
    crossed AOD pair holds two independent frequency combs and nothing requires the one on the
    axis that is not moving to span the whole block. Every move in c150, c200 and c300 happens to
    use the full extent, so `extend_comb` reading the comb off the joining species' rest
    configuration was never wrong before — and c540 breaks it eleven times over, because a
    pipelined movie does gate work on a sub-comb. The subsets it uses are arithmetic progressions,
    which is what an AOD produces: cols `{13,19}`, `{14,20}`, `{16,22}`, `{17,23}`, `{18,24}`,
    `{14,16,18,20,22,24}`, `{2,4,6,8,10,12}`.
    The signature is unmistakable and needs no new machinery to spot: **a nine-row block whose row
    profile shows EIGHTEEN peaks.** Nine rows cannot split into eighteen groups, so the split is
    across the other axis; profile one column at a time and it falls out (c540's X1 at f204, cols
    13 and 19 read 19.66 20.60 21.61 22.31 22.71 23.61 24.59 25.51 26.51 while the other ten are
    within 0.10 of their tones). The move is `19:26 -> 20:27 | 27 -> 19` on `{13,19} × 19:27`.
    Assuming the full extent does not write the move wrong — it predicts every marker moving, so
    `verify` scores ten correctly-static columns against a moving prediction and the move is
    **rejected**, appearing as UNDETERMINED. `sb_build.sub_comb` measures which lines take part;
    `SubPeaks` re-reads the partition, the timing and the join test through only those lines.
    Three consequences worth knowing before you meet this again:
    * **whole-block occupancy cannot see a sub-comb move at all**, so the TRANSITION's own frames
      are wrong — the static majority dominates the profile and the block reads "at rest" while
      part of it is plainly moving. `sub_window` re-derives the window from the sub-comb, but a
      pipelined movie chains sub-comb moves back to back and an unclamped extension fuses two of
      them, so clamp it to the neighbouring transitions and score both windows;
    * **a sub-comb rectangle carries only its own block.** Do not let `extend_comb` grow it;
    * **rule 31's dilution appears in the TIME dimension too.** A three-frame transition has two
      rest frames and one moving frame, and the rest frames agree with every candidate map by
      construction: c540's X1 f203-205 scores a wrong map at 0.1128 over the window and 0.2921 on
      f204 alone, against the right map's 0.0513. Rank candidates on the frames that move.

---

## What this changes about measurement

### 1. Measure with 1-D colour profiles, not with a peak detector

For each colour, take the mask of pixels nearest to it, and sum along each axis inside the block's
window. The **x-profile's peaks are the block's columns and the y-profile's peaks are its rows**,
in continuous tone units.

This is the whole trick. A profile is unharmed by two markers approaching each other: the two peaks
stay separate down to about 0.3 of a pitch and, closer than that, the merged peak sits at their
midpoint, which is still the correct centroid of the pair. A matched-filter detector with
non-maximum suppression instead deletes one of them and reports the block as half its size.

`tools/sb_read.py` does this. Profiles also cost nothing: one mask and two sums per frame.

### 1a. Measure ONCE, then fit as pure arithmetic

`Movie.peaks()` opens and masks an image. A 2-D timing search calls it millions of times, so
**never call the measuring code from inside a fit loop.** Precompute every species' x- and
y-profile peaks on every frame up front — c150 is 400 peak lists for 50 frames, done in seconds —
and everything after that is arithmetic on numbers. With the call inside the loop a single move
took ~10 minutes; outside it, all eight took under a minute. Use a coarse sweep and then a local
refinement: the error surface is a polynomial and has no fine structure to miss.

Windows must be **per species** and measured over **every** non-pulse frame of the span. Not a
subsample — `sb_read`'s default takes about seven frames and on a long span that clips the window
and silently loses whatever leaves it. And not the whole panel either: the outline mask is shared
across the panel, so a panel-wide window attributes one species' outline to every species (it
reported X1's move as Z1's).

### 2. Rest is per species, and it is an occupancy test (rule 2)

A species is at rest at frame *f* when

* every x-profile peak and every y-profile peak is within `--tol` (default 0.12) of a whole tone, **and**
* the block is a **full rectangle**: the number of markers equals (number of x peaks) × (number of
  y peaks).

Both halves are required. On-grid alone is satisfied mid-move whenever the displacement happens to
land near an integer; full-rectangle alone is satisfied by a block that has crossed onto the
half-pitch staging grid. Do not wait for the whole array to be still — the AODs are independent and
each species rests on its own schedule.

Two further conditions, both learned the hard way:

* **Never read a configuration on a pulse frame.** The tint moves every fill colour ~40 RGB and the
  mask comes back empty or wrong. This is the single most common way to lose a whole move.
* **A single on-grid frame that is not adjacent to a pulse is discarded.** A translating block
  lands on integer tones by coincidence (guide §4.2) — c150's X0 does it at f075, f115, f117, f141
  and f146. Require two consecutive frames, *or* adjacency to a pulse, which rescues the genuine
  single-frame rests since a block is always at rest while a pulse is on.

**Complete a clipped rectangle by rigidity.** A block is one size throughout, so if only column 0
is visible and it runs off the left edge, its columns are `(0-w+1):0`. This is a deduction from
rule 1, and it is the only way an off-panel rectangle enters the sheet at all.

### 3. The outline colour names the moving sub-block (rule 7)

Discover the palette *including outline colours*: cluster the saturated pixels that are not within
tolerance of any known fill, faded fill, or background. On c150 this finds one extra colour, a
mauve — `rgb(146,127,190)` measured over frames 0–18, `rgb(152,123,184)` averaged over the whole
movie — that the `se-cycle-movies` extractor discards as noise, being 82 RGB from the nearest
palette entry against a tolerance of 70.

Profile that outline colour exactly like a fill. Then, over a move:

* the outline's peak set is a **proper subset** of the block's peak set on one axis;
* it moves from one tone set to another while the fill's peaks split into two groups.

That subset **is** the moving sub-block, and it is what makes the partition recoverable at all. The
at-rest configurations cannot say how a block reorders itself; the outline can.

**The complement rule.** Given the block's tone set `S` before the move and `S'` after it, and the
outline's tones `A → A'`, the other sub-block is

```
B  = S  \ A          B' = S' \ A'          paired in increasing order
```

This is exact, not a heuristic: a rectangle's tone map is strictly increasing (guide I.2), so once
the two source sets and the two destination sets are known the pairing is forced.

**But the outline is often absent.** On c150 it named 6 of the 8 moves in the first 0.7 ms and was
silent for the other two, and its silence is *not* evidence of stillness. Where it is silent, use
the candidate library in §3a.

### 3z. APPEARANCE NAMES THE RIGID GROUP — and appearance is the TRIPLE

**The rule (user, session 11): all atoms sharing SHAPE + FILL COLOUR + OUTLINE COLOUR at a given
frame perform ONE rigid body motion.** Appearance *is* the group label, so a block's partition is a
direct READ rather than an inference.

**IMPLEMENTED in `tools/sb_rigid.py`. See `RUN_TEST.md` for the test run and its expected output.**
Three steps, and there is nothing to search for:

```
1. CLASSIFY   partition the moving markers by the appearance triple
2. MEASURE    each class is rigid, so it has ONE displacement -- read it, and report the
              RIGIDITY RESIDUAL (the spread of member displacements) as proof
3. MERGE      fuse classes with identical displacement onto one AOM.  MANDATORY, not optional:
              the simplest structure that realises the motion is the right answer.
```

Measured on c150 frames 0–49, every accepted class is rigid to **0.00–0.15 site** — the rule
holding, quantitatively. The two sub-blocks of a move carry *different* outline colours, so the
partition is a direct read: `X-rowcross` comes out as gold `rows 1:3 → 8:10` (D=+7) and mauve
`rows 4:5 → 6:7` (D=+2), and the merge across X0 and X1 produces `x 1:12` by derivation.

**Merging is justified by EQUAL DISPLACEMENT, not by shared marking.** Do not use outline colour to
group across fill colours — measured on c150's f019-028 window, gold `rgb(247,187,70)` marks D=+3
for X0 *and* X1 but D=−3 for Z0. The outline labels a sub-block *within its own block* (by role),
so the direction it travels depends on the species. This is precisely why the rule says *only the
triple* is rigid: `X0+gold` and `Z0+gold` are different triples and do move differently.

**Where more than one minimal grouping exists, say so.** In c150's f019-028 window X0, X1 and Z0 all
move +3 columns; any two may ride one crossed pair but not all three (the merged rectangle would
capture Z1's atoms), so **X0+X1 and X0+Z0 are both minimal at 4 groups** and the pixels do not
decide between them. `sb_rigid.py` emits a `TIE` note. Never present the tool's pick as measured.

**The group key is the whole triple, and getting that wrong breaks it in both directions:**

* **Same outline, different fill = different classes.** Masking one outline colour across the whole
  panel merges two species' atoms that merely share a marking. The measurement below works only
  because the window holds the fill constant (one species) *and* the mask selects the outline.
* **Same fill and outline, different shape = different classes.** Every result in this project uses
  fill (via the per-species window) and outline (via the colour mask) — two of the three
  components. **Shape was measured for the first time at the end of session 11
  (`SB_COMPOSE_BUG_shape.py`) and on c150 it is NOT a discriminator within a species:** at rest,
  Z0's marker areas are mean 126.9 ± 5.5 and Z1's 129.4 ± 3.5, aspect ≈ 1.0 ± 0.1, and the two
  rigid groups of Z0's f029-036 move are indistinguishable by shape (area 127.4 vs 126.4) — they
  are separated by outline colour alone. Across species the sizes do differ (X1 154, X0 144,
  Z1 129, Z0 128) but fill colour already separates those.
  **This is a weak null, not a proof:** four rest frames on one movie, and pixel area is a poor
  descriptor at this resolution — X0 at f044 shows one whole column at ~119 against ~144 for the
  rest, almost certainly sub-pixel sampling phase rather than a real difference. **Re-check on any
  new movie**, and if shape ever does matter use second moments or a normalised template rather
  than pixel count.

With the triple as the key, profile **each class separately** — same machinery as profiling a fill.

This is the whole problem, solved, and it dissolves the crossing difficulty completely. On c150's
Z0 over f029–036, where I had claimed "no outline is drawn on Z0 here":

| frame | mauve `rgb(152,123,184)` | gold `rgb(246,187,70)` |
|---|---|---|
| f030 | `1.031 3.011 5.016` → cols **1,3,5** | `1.959 3.983 5.971` → cols **2,4,6** |
| f032 | `1.326 3.329 5.348` | `1.681 3.686 5.698` |
| f033 | `1.624 3.604 5.640` | `1.310 3.321 5.282` |
| f035 | `1.971 3.955 5.973` → cols **2,4,6** | `1.011 3.036 5.019` → cols **1,3,5** |

Three clean peaks in each colour on **every** frame — including f032 and f033, where the *fill*
profile collapses to 4 and 3 peaks. **The two sub-blocks never merge in a colour-separated
profile**, because they carry different outline colours. `1,3,5 → +1` and `2,4,6 → −1` falls
straight out.

**Consequences, and each corrects an error made in session 11:**

* **There is no crossing problem.** Peak merging only happens when two groups share the colour you
  are profiling — i.e. when you use the fill. Profile the outlines and the groups stay resolved
  throughout. Every claim in this project about "unresolvable crossing frames" and about
  crossing-limited verification errors was an artefact of profiling the shared fill.
* **`--palette` finds ALL the outline colours; use them all.** c150 has at least two that carry
  partitions — the mauve *and* `rgb(246,187,70)`. `rgb(254,249,184)` tracks the gold identically
  (same outline, anti-aliased edge). Only `rgb(184,132,90)` looks like genuine noise (area ~40 px).
  `sb_read.py` iterates outline candidates but takes the FIRST that fits and never combines two,
  so it sees one group and calls the rest static.
* **Enumerate the CLASSES PRESENT, do not assume a fixed number.** The classes are whatever triples
  occur on that frame inside that species' window. Two is what c150 shows so far; three or more is
  perfectly possible and a fixed assumption of two would mis-split them.
* **The complement rule of §3 is a fallback, not the method.** `B = S \ A` is only needed when a
  group's outline cannot be isolated. With two outline colours both groups are measured directly,
  which is a stronger measurement and needs no assumption that there are exactly two.
* **More than two outline colours means more than two groups.** Do not assume a move splits in two.

**Then optimise the AOM count** — and note this is a *separate* question from the grouping. Two
groups with **different** appearance may still share one crossed pair if their displacements are
equal and the merged comb is legal (§5, §6). Appearance tells you what moves rigidly together;
it does not tell you the minimum hardware. Read the groups first, merge second.

### 3a. Fallback, and the confirmation: MEASURE THE DISPLACEMENTS

**A move is k rigid sub-blocks, each with ONE uniform integer displacement** — that is the only
thing a crossed AOD pair can do: hold a comb, shift the whole comb by one frequency offset. So
`1,3,5 → +1` with `2,4,6 → −1` is the right description; calling it a "pairwise swap" and
enumerating bijections solves a harder problem than the physics poses.

**All sub-blocks of one move share the same easing**, so at every frame `d_i(t) = D_i · s(u)` and
the **ratios** `d_i / d_j = D_i / D_j` are exact and constant throughout the move, independent of
the timing. One mid-move frame in which all peaks are still resolved therefore gives every relative
displacement at once — n measurements for one unknown scale factor.

```
1. take the first frames after motion starts and BEFORE any crossing
   (detectable: peak count still equals tone count, so peaks are still ordered
    and peak i IS tone i -- the correspondence is free)
2. fit each tone's velocity across those frames (averages the ~0.03 site per-frame noise)
3. snap the velocity vector to INTEGER RATIOS -- over-determined, so a check as well as a fit
4. group tones by equal displacement; each group is one AOM group
5. fit the easing afterwards, under the pulse constraint (rule 9)
6. confirm from the other end (rule 6) on the last pre-arrival frames
```

Verified on all eight moves of c150 frames 0–49 from one or two frames each — e.g. Z0's column swap
reads `+0.204 −0.186 +0.191 −0.184 +0.173 −0.192` at f002 (t = 0.0286 ms), which is `1,3,5: +1` and
`2,4,6: −1` immediately.

**This is rules 5 and 6 done numerically**, and it is what `sb_compose.py` should do. Note the
crossing frames are the *worst* place to look, not the best: peaks merge there and information is
destroyed. Two traps: clustering a single frame's *absolute* displacements over-splits when two
groups have similar speeds (the signs are usually clean when the magnitudes are not), and dividing
by a near-zero reference displacement amplifies noise — hence steps 2 and 3.

The shapes this produces on c150, for reference (all are two rigid translations):

| shape | c150 example |
|---|---|
| move | as two rigid translations |
|---|---|
| X-rowcross | rows `1,2,3: +7` and rows `4,5: +2` |
| X-rowreloc | rows `7,8,9,10: −6` and row `6: −1` |
| X0-colswap | cols `4,5,6: −3` and cols `1,2,3: +3` |
| Z0-colswap, Z0-colpair | cols `1,3,5: +1` and cols `2,4,6: −1` |
| Z0-rowperm | rows `11,12: +3` and rows `13,14,15: −2` |
| Z0-rowcyc | rows `11,12,13,14: +1` and row `15: −4` |

Prefer the outline's own partition when it agrees — it is independent evidence. **Report anything
the displacements do not resolve as undetermined rather than approximating it.**

### 4. Fit the timing, then verify on every fill peak

Where the outline exists, fit `(t_start, t_finish)` against the outline sub-block alone — it is one
rigid set, unobstructed, and its displacement is known from `A → A'`. Otherwise fit the easing to
the per-frame `p`-sequence of rule 11. Either way, **predict every fill peak on every frame of the
window and score it**, and do the fit **under the pulse constraint of rule 9** rather than freely.

Do not *clamp* a free fit to the pulse boundary — clamping keeps the other endpoint where the
unconstrained fit put it, so the easing no longer matches the track. On c150 clamping tripled the
error (X-rowcross 0.044 → 0.203) where a constrained **refit** did not.

Scoring must be **symmetric**: every measured peak near a prediction *and* every prediction near a
measured peak. Scoring predictions alone is satisfied by any timing that keeps the atoms inside the
crowd, and the fit slides to whatever stretches the motion furthest. And **merge predictions closer
than 0.3 pitch before comparing**, because that is what the profile does; comparing against
unmerged predictions penalises a correct model exactly at the crossings.

Accept below about 0.10 site mean error — but read that against a noise floor you measured, not
against zero. **Calibrate on a species that is static in the window**: on c150 frames 0–49, Z1 sits
**0.008 site** from its tones on every single frame. Expect the achievable error to rise at a
crossing, where peaks are genuinely unresolvable for a few frames; a residual concentrated there,
with the per-frame progress agreeing across all peaks, is a resolution limit and not a wrong map.

### 5. A rectangle is not confined to one species — grow the comb across the whole array

**Species belongs to the atom, not the row.** A row picks atoms up by POSITION, so one rectangle
routinely spans two blocks of different colours. Measuring each species inside its own window
therefore cuts such a rectangle in half, and if the outline happens to mark only one half, the
other half is reported as *static*.

So after fitting a move, **take its tone map and test it against every other species over the same
frames**. Where it verifies, that species is on the same rectangle and its tones join the comb on
the other axis. On c150 this turns `x 4:6 ↔ 1:3` over `y 6:10` into the same swap over **`y 6:15`**,
carrying Z0 as well as X0, and merges the two X row-moves into one rectangle `x 1:12`.

A static block fails this test badly — at half progress the prediction is half a tone off every
marker — so there are no cheap false positives. It is also the only way to prove a block is
*genuinely* still rather than merely unmarked by the outline.

> **⚠ THAT LAST PARAGRAPH IS ONLY TRUE WHEN THE WHOLE BLOCK MOVES — see rule 31.** `verify` is a
> mean over **every** peak of the species, so on a move that touches only a few of the block's
> tones the correctly-static majority dominates it and a block standing perfectly still sails
> through. c200's `rows 5 -> 6 | 6 -> 5` moves 2 of 10 rows, and Z0 joined on that map while its
> peak list was byte-identical and exactly on tones across the whole window. **So also require the
> species to actually leave its tones on that axis** (`sb_compose.moves_on_axis`). Getting this
> wrong does not merely add a species to a comb — it puts *that species' atoms* on a rectangle that
> permutes them, which is a movement in the rebuild that is **not in the movie at all**, and it
> inflates the reported AOM peak (c200: 6 against a true 4).

The threshold must be **relative as well as absolute**: `max(0.10, 1.3 × best achieved)`. Where two
sub-blocks cross, the achievable error rises for *every* species on the rectangle, so a flat 0.10
bar rejects a species from its own rectangle — c150's `X-rowcross` scores 0.159 on X0 and 0.166 on
X1 against 5.87 on Z0 and 5.67 on Z1. The separation between sharers and non-sharers is 20–40×, so
the exact factor does not matter.

### 6. Then pack the AOMs (rule 8)

Two rows may share one crossed pair when, on the shared axis, their tone maps merge into a still
strictly increasing map, and the other axis's combs are equal. Two sub-blocks that swap never merge
— `1→2` with `2→1` is not increasing — so **a split or a permutation always needs two groups.**

**A group is reusable the moment it is free.** A crossed AOD pair is reprogrammed between batches,
so packing is an *interval colouring*, not a running counter: a row may join a group whose rows all
either finish before it starts or legitimately share with it. Getting this wrong is invisible in
the geometry and shows up only as an inflated `peak concurrent AOM groups` — the first draft of
this tool put the second half of c150's window on AOM3–AOM6 while AOM1 and AOM2 sat idle.

For rows that genuinely overlap, merge only when they already share an **identical comb on one
axis**. Merging two different combs creates traps at the full product of the unions, and an atom of
another group standing on one of those would be held twice — the guide's atom-capture rule, which
needs the simulator to check properly.

Take the **lowest free index**, so a sheet read as hardware does not climb through crossed pairs it
does not need.

### 7. Readouts and loads are measured differently

A readout has **no outline and no solid fill** — the block desaturates and descends off panel — so
`--solve` cannot see it at all. Measure it on the **faded** track:

* fit the descent over only the frames where the faded block is actually visible;
* the displacement is **not determined** by the visible part. On c150 the residual is flat from +8
  to +16 rows (0.032 → 0.018 site) because only ~4.8 rows of the travel is on screen, so the
  destination is unobservable. Adopt c540's convention — **+9 rows, columns unchanged** — and say
  that it is a convention, not a measurement.
* a `load` is instantaneous (`t_start == t_finish`) at the reservoir rectangle, with a *later*
  `move` row carrying the stock in. `render.ps1` applies a batch's moves and only then creates that
  batch's loaded atoms, so **a load must be in a strictly earlier batch than the move that carries
  it**.
* a load's **leading** edge is pinned at the panel border while the block is still a sliver and
  those frames carry no information — track its **trailing** edge instead. Exclude frames after
  arrival too: on c150 the fresh Z blocks do not stop at `1:6`, they go on to `7:12`, and that
  later move drags the fitted `t_finish` out by 1.3 frames.

---

## Procedure — A NEW MOVIE, END TO END

> **This is the section to work from. It is what session 13 actually did to close c150, written as
> a recipe for the next movie.** Every step has a check; do not go past a step whose check fails,
> because every downstream number will be wrong in a way that still looks plausible.
>
> **c150's numbers appear below only as an EXAMPLE of what the output looks like. Re-measure every
> one of them. Nothing about the palette, the outline colours, the block sizes, the pulse frames,
> the reservoir position or the readout convention transfers between movies.**

```powershell
$SB = "<project>\.claude\skills\se-cycle-blocks\tools"
$SE = "<project>\.claude\skills\se-cycle-movies\tools"
mkdir work; cd work
```

### 1. Frames and a calibration

```powershell
ffmpeg -y -v error -i <movie>.mp4 -fps_mode passthrough -start_number 0 frames\p_%03d.png
python $SE\se_calib.py --frames frames --out calib.json --cycle-ms <N>
```

**Read the movie's own header for `--cycle-ms`** — it prints `t 0.00/5.49 ms` and, on gate frames,
`global pulse`. Take the cycle length and the pulse frames from that text, never from a fit.

**Check:** `calib.json`'s `gate_frames` matches the frames whose header says `global pulse`, and
`n_frames` matches the PNG count. This is slow to redo, so keep `frames/` and `calib.json`.

### 2. The palette, including the outline colours

```powershell
python $SB\sb_read.py --calib calib.json --palette
```

**Check:** at least one discovered outline colour, and ideally two that carry partitions. c150 has
the mauve and the gold, each with an anti-aliased twin, plus genuine blends that get rejected. **If
no outline colour is found, sub-block moves are unrecoverable from that movie by the appearance
read** — the displacement reader (§3a) still works, but you have lost the independent evidence, so
say so in the deliverable.

### 3. Block sizes, movie-wide — `sb_blocks.py`

```powershell
python $SB\sb_blocks.py --calib calib.json --out blocks.json
```

**Check:** one size per species, and it should be the same for every species if the movie is laid
out like c150 (four 6×5 blocks). Look at the printed count histograms: smaller counts are the
frames where a block is clipped or crossing, and that is exactly why the LARGEST is taken (rule 22).
**Skipping this step does not error — it silently loses every move of a block that spends a whole
interval off panel.**

### 3a. FIND THE READOUTS AND LOADS **BEFORE** YOU SOLVE — `sb_events.py`

**This step used to be step 6, and that ordering was a defect that cost a session.** `sb_full`
takes the readout/load list as an **input** (`--events`), so discovering them after it has run
means the first pass is always wrong — and quietly. Fitting them is still step 6; only the
*naming* moves here.

```powershell
python $SB\sb_events.py --calib calib.json          # then confirm each on the FADED track:
python $SB\sb_probe.py  --calib calib.json --peaks --sp Z1 --axis 1 --f0 145 --f1 160
```

Write what you confirm into `events.json`, one entry per species per readout/load pair, with the
frame window **containing** the transition the occupancy test will enumerate across it:

```json
[{"sp": "Z1", "f0": 147, "f1": 189, "why": "Z readout at the f147-148 pulse, Z load at f149"}]
```

**What goes wrong if you skip it (c300, session 22 — measured, not hypothetical).** A readout
bridged to its load is not one rigid motion: the occupancy test sees the DEPARTING block's
rectangle and the ARRIVING one's and enumerates a transition between them. Left unnamed the solver
does one of two things, and neither announces itself:

* **it fits something else to it.** c300's unnamed Z readout became `Z1 rows 13:18 → 7:12`; with no
  rigid motion to find, the solver reached into the overlapping window and re-emitted **a
  neighbouring block's column rotation** — `X0 cols f149-187`, a duplicate of a real move over a
  wider window. It scored **3.0993 site against the 0.10 bar** and was written to the sheet with
  `ok=false`. Applied, it rotates X0 by four columns instead of two;
* **it leaves it undetermined.** c300's unnamed X readout produced the two undetermined
  transitions at f328-383.

`sb_full` now lists every transition with a readout signature that is not named in `--events`, at
the end of its run, and `sb_audit`'s check 1b fails on them (`... has no rows move`). **Neither
existed when this ordering was written, which is why it went unnoticed.**

**Check:** every readout `sb_events` reports is either in `events.json` or explained. c150, c200 and
c300 each have exactly two readout/load pairs — one Z, one X — so **four** entries, two species
each. Keep `events.json` next to `calib.json`: without it the movie cannot be re-solved, which is
how c300 became irreproducible between sessions 15 and 22.

### 4. Transcribe, one pulse-free interval at a time — `sb_full.py`

```powershell
python $SB\sb_full.py --calib calib.json --blocks blocks.json --work . --xlsx out.xlsx `
                      --events events.json
```

**`--events` is not optional** — see step 3a. Its absence is not an error and the run looks normal.

It derives the segments from the movie's own pulse runs, solves each with its own tight windows,
merges, and colours the AOMs once over the merged rows. **Never run `sb_build.py` over the whole
movie** — see the note in `sb_full.py`'s docstring; the windows go panel-wide and the shared outline
mask attributes one species' outline to another.

Use `--only 0,1` to iterate on one segment while you are chasing something.

**Checks, in this order:**

1. **`0 undetermined`.** An undetermined transition means the movie shuffles a block and the sheet
   does not say so. Go to step 5 for each one. Do not proceed with any left.
   **BUT `0 undetermined` IS NOT EVIDENCE OF COMPLETENESS (rules 27 and 36).** The list is silently
   emptied by the "carried by another species' rectangle" guard, which is how c200 shipped twice
   with four real moves missing while reporting zero — **and worse, a move that is never ENUMERATED
   appears in no list at all**, which is how c300's Z0/Z1 exchange lost half of itself. Do not
   sanity-check this by eye: **run step 4a, which proves it.**
2. **The transition count.** It should be comparable to `sb_compose --transitions` but not equal —
   that tool cannot see a configuration living only on a pulse frame, so it under-counts. c150: 69
   against its floor of 68.
   **And a permutation-heavy movie has MANY more transitions than c150's 69** — c200 has 86 in a
   movie of the same frame count, because it is pipelined. A count close to c150's on a pipelined
   movie is a symptom, not a reassurance.
3. **Every note.** `NOT RIGID` on a *blend* colour is correct and expected; on a **pure palette
   colour** it is a real finding. `SPLIT` notes are rule 19 working. `TIE` means more than one
   grouping is equally minimal — **never present the tool's pick as measured**; say which groupings
   tie.
4. **The AOM peak — and treat it as a MEASUREMENT, not a curiosity.** If a batch needs more crossed
   pairs than the machine has, that is a segmentation error upstream, not a hardware limit. The
   movie's own title says how many AODs it uses; c200 is a "4-AOD pipelined SE cycle" and
   transcribes to **exactly 4** once the join test is right. It read **6** while the join test was
   letting motionless species onto moving rectangles (rule 31), so an inflated peak is a *symptom
   to chase*. **c150 also drives exactly 4** — its `Combined` sheet populates AOM1–AOM4 and nothing
   else.
   **Count the right thing.** `allocate_aom`'s peak is over *every* schedule row, including the
   hand-measured `unload`/`load` rows, and a readout's long span can straddle two batches of moves
   and take an extra index — that is what makes c150's `slot` column reach 5 on one row of 110.
   Those rows are never written into the `Combined` AOM tone columns, so they cost no hardware.
   Before reporting a peak that exceeds the title, check whether the excess is a move or an extra
   row: `{AOM_n: rows populated}` over the `Combined` sheet is the hardware answer.
5. **Moves over 0.10 site.** Expected at crossings and where a block leaves the panel. Confirm each
   one is one of those, by eye, with step 5 — do not just accept them.
   **A LOT of them, spread evenly over the movie, is a different symptom: suspect a CONVENTION.**
   c300 first read 17 of 64 over the bar, at every point in the cycle and on every species, which
   is not what crossings look like — and it was rule 9's timing bound being a frame late. Step 4a's
   map check tells you which you have: a wrong map fails it, a wrong convention passes it.

### 4a. PROVE the transcription is complete — `sb_audit.py`, `sb_mapcheck.py`

**NEW IN SESSION 15, AND NOT OPTIONAL.** These are the checks that would have caught c200's four
missing permutations and c300's half-written exchange, and neither the census nor the score nor
render validation can do their job (rules 27 and 36).

```powershell
python $SB\sb_audit.py    --moves moves_full.json --rests rests_full.json
python $SB\sb_mapcheck.py --calib calib.json --moves moves_full.json
```

`sb_audit` must print **AUDIT CLEAN**. It checks three things and each one has caught a real defect:
every transition has a move that *joins* it with its *midpoint* inside; the transitions-minus-moves
gap equals the cross-species joins **exactly**; and **no two species claim the same site at rest**.
Its exit status is 1 on failure, so it can gate a delivery.

`sb_mapcheck` verifies every move's **map** independently of its **timing** — each sub-block's own
measured displacement must imply the same progress on every pre-crossing frame. This is the only
check that separates "wrong partition" from "right partition, timing a frame out", and on c300 it
is what established the elevated means were the latter. Moves reported "too few pre-crossing frames"
are **not verified** by it, only untestable this way; check those against the outline profiles.

### 5. Probe anything the tool could not do, or did oddly — `sb_probe.py`

**This is the step that actually does the work, and it is not optional.** Nine defects were found
this way on c150 and every one produced a plausible-looking sheet.

```powershell
# what is actually on the frames: fill, faded fill, and EVERY outline colour, profiled separately
python $SB\sb_probe.py --calib calib.json --peaks --sp X0 --axis 0 --f0 167 --f1 180 `
       --win=0.45,6.55,10.43,15.60

# replay sb_full's own partition read for one transition, and see why it rejected it
python $SB\sb_probe.py --calib calib.json --classes --sp X0 --axis 0 --seg 190,223 --tr 192,203
```

**The loop, and it is the method of this whole session:**

```
1  read the tool's own rejection note -- it says WHICH class or map it threw away and why
2  probe the pixels and work out the answer BY HAND: src at the first frame, dst at the last,
   displacements from the difference, per outline colour separately
3  compare. If the hand answer is right and the tool's is not, find WHICH RULE IN THIS FILE the
   code is failing to apply -- nine times out of twelve on c150 that is what it was
4  fix that, then RE-RUN THE FRAMES 0-49 ACCEPTANCE TEST (RUN_TEST.md) before believing anything
5  re-run the affected segment only (--only N) and repeat
```

Two axes and two directions: if the fill shows no motion at all over the transition's frames, you
are looking at the wrong axis — a same-site column permutation leaves the rows dead still.

### 6. Readouts and loads, by hand — `sb_extra.py` (you FOUND them in step 3a)

Nothing automatic transcribes these (§7). A readout is where a species' **solid** area collapses
while its **faded** area jumps and then travels off panel; a load is where faded stock turns solid.

**You already found and confirmed them in step 3a** — that is where `sb_events.py` and
`sb_probe.py` belong, because `sb_full` needs their names as an input. What is left here is the
FITTING, which genuinely does come after the solve:

```powershell
python $SB\sb_extra.py  --calib calib.json --jobs jobs.json                  # FIT them
```

`jobs.json` (what to fit) and `events.json` (what the solver must not fit) describe the same
events and are written together in step 3a. **Keep both** — `run_c300/` had `jobs.json` and no
`events.json`, and that alone made the movie irreproducible.

`sb_events.py` is **new in session 15** and does the search that used to be done by eye across 384
frames: it reports the frames where solid collapses as faded jumps, where stock turns solid, and
the long steady runs of small faded area that are parked stock. It is a **finder, not an oracle** —
on c300 it flagged both readouts and every stock run, but not the loads, because there the fresh
stock turns solid on the same frame the old block starts fading, so the species' faded area goes
*up* rather than down. Read the areas it prints, then confirm with `sb_probe --peaks`.

Then hand-write the rows into `extra.json` (`unload` / `load` / `move`) — the format and every trap
are in `sb_extra.py`'s docstring. Re-emit with `--extra extra.json`.

**Do not re-run `sb_full` just to pick up an edited `extra.json`** — that re-solves all twelve
segments for nothing, ~15 minutes per iteration, and you will iterate on these rows several times.
`sb_full` already saved `moves_full.json` and `rests_full.json`; re-emit straight from them.
`run_c300/reemit.py` is a 20-line script that does exactly this (it calls `sb_emit.emit` with the
same arguments `sb_full` uses) — copy it next to your work. It matters that the re-emit goes
through `sb_emit`, because `allocate_aom` must colour the measured rows and the hand-measured
rows **together** or the reported AOM peak is not the sheet's.

**Always run `sb_extra.py`'s D-scan on the carry-in, not just on the readout.** It is what pins the
reservoir's half-pitch offset by a *fit* rather than at rest, and it is the strongest evidence you
will get about the load geometry: c300's Z carry-in reads **0.1202 site at D = +9.5 against 0.2196
at +10**, and its X carry-in **0.1374 at +5.5 against 0.2626 at +6**.

**Check:** the census in step 7. If atoms go missing at a readout, or the fresh blocks never
arrive, these rows are wrong.

### 7. The census — the check that catches a missing move

```powershell
python $SE\se_sim.py out.xlsx
```

**Read the census, not just "validation clean".** A **deficit** against the seed count is the
defect. A **surplus** is a readout still descending while its replacement exists, and is fine.
c150: `validation clean`, never short of 120 atoms, 39 frames with a surplus, max 180.

### 8. Render and score

```powershell
python $SE\se_calibtxt.py --calib calib.json --out-txt movie_calib.txt `
       --out-json render_calib.json --render-frames $PWD\rframes --tone-divisor 1
& $SE\render.ps1 -Xlsx out.xlsx -OutDir $PWD\rframes -LogCsv $PWD\log.csv `
       -MatchCalib $PWD\movie_calib.txt
python $SB\sb_score.py --movie-calib calib.json --render-calib render_calib.json --out score.txt
```

**Use the UNTOUCHED `render.ps1`.** `validation log entries: 0` means self-consistent, **not
complete** — it cannot know about a move you never wrote.

`sb_score.py` finds its own static control for rule 17's registration bias and reports it with its
spread. **Never carry a bias forward from another session as a constant.** It also reports
`MISSING-BLOCK` cases where one side has a block and the other does not — those are mistimed rows,
not positional error, and must be fixed before the mean means anything (on c150 a load's birth time
rounded past its frame and the render drew nothing there).

### 9. Watch the whole movie — `sb_watch.py`, then `sb_video.ps1`

```powershell
python $SB\sb_watch.py --movie-calib calib.json --render-calib render_calib.json `
       --thresh 0.35 --min-run 3
& $SB\sb_video.ps1 -MovieFrames frames -RenderFrames rframes -Calib calib.json `
       -OutPanels panels.mp4 -OutFull full.mp4
```

**A SAME-SITE PERMUTATION IS INVISIBLE TO EVERY OTHER CHECK (rule 27), AND THIS STEP IS NOT
OPTIONAL.** Census, score and render validation are blind to one by construction. On c200 the user
found **four** wrong or missing moves by watching, at f093, f169, f289 and f330, after all three
checks were clean and the sheet said "0 undetermined".

**But it is not invisible frame by frame, and session 15 made that a tool.** While such a move
runs, the movie's sub-blocks are at intermediate positions and the rebuild's are not — the
disagreement is real and positional, merely SHORT and LOCAL, which is exactly why it cannot move a
39000-comparison mean. `sb_watch.py` scores every **(frame, species, axis) cell separately** and
prints the local runs, with the movie's and the rebuild's peak lists side by side, so a missing or
phantom permutation is readable directly instead of hunted for by eye.

**Account for EVERY run of three frames or more.** There are exactly four legitimate causes, and
you must be able to name which one each run is:

* the **integer-staging** cost on parked reservoir stock — a long flat run at ~0.5 site (c300: X
  rows f329–374 and f376–381, Z cols f149–186);
* a block **leaving or entering the panel**, where only an edge column is measurable (rule 21);
* an **occlusion in the movie** — two blocks on the same sites and the rear one simply not drawn
  (c300: Z0 hidden behind Z1 at f055–060 as the two Z blocks cross *through each other*);
* a **crossing**, where the profile peaks genuinely merge for a few frames (§4).

Anything else is a defect. On c300, 20 runs of ≥3 frames were all one of those four.

**Then still watch the video** — `sb_watch` compares what the profiles can measure, and an
occlusion or a mask dropout is precisely where they cannot. Watching is what tells you a run is an
occlusion rather than a wrong move.

**Watch for these two things specifically:**

* **a small group of markers that swaps in the movie and stands still in the rebuild** — that is a
  missing permutation (c200 f093: rows 5 and 6 of an otherwise-static block; f169: a double cyclic
  shift). They are easy to miss because everything around them is correct;
* **markers that move in the REBUILD and not in the movie** — that is rule 31's phantom join, and
  it looks like a block spontaneously shuffling (c200 f289, and the off-panel block at f330).

**Spot-checking stills is NOT a substitute**: three of c200's four misses were inside windows that
had been checked as stills, because at rest both sides agree perfectly and only the frames *between*
two rests differ. If you must sample, sample the frames a few after each settled configuration, not
the settled ones.

`render.ps1` draws bunched atoms mid-crossing as solid bars rather than discrete markers. That is
correct; the movie does the same at the same frames. It also uses its own fixed shapes and colours
per species index, so shapes may differ from the movie — compare **positions**, not appearance.

### 10. Deliver

Workbook, a per-move evidence report, the score, and the two videos. **The report must separate
what was measured from what is a convention** — a readout's destination and the reservoir's integer
staging are conventions on every movie, not measurements. `sb_report.py` writes the per-move half;
**append the convention section by hand, the tool cannot know which choices were yours.** c300's
set is the model, and its appendix is the fullest: `c300_full_blocks.xlsx`,
`c300_full_blocks_report.txt`, `c300_full_rebuild_score.txt`,
`c300_full_original_vs_rebuild_panels.mp4` / `..._full.mp4`.

**Say what the audit found, not just that it passed** — the transition/move/join accounting, the
site-clash count, and which of `sb_watch`'s runs is which of the four legitimate causes. A reader
cannot tell a proved sheet from an unchecked one otherwise.

### What to re-measure rather than assume, on a movie that is not c150

| thing | why it will not transfer |
|---|---|
| fill and faded palette, **outline colours** | per movie; `--palette` finds them |
| **the fill colour ON A PULSE FRAME** | it is not the palette colour: the tint moves it, on c300's Z0 by **77 RGB**, far past the 34 RGB mask tolerance — and `discover_outlines` cannot find it because it skips gate frames. `sb_read.colours_on_frame` measures it. Rule 37 |
| **the NUMBER of species** | `se_calib.py` reported **five** on c200, the fifth being the blend where a mauve outline meets a blue fill — `rgb(80,121,185)`, the midpoint of `(41,119,213)` and `(152,123,185)`, at 0.6 % of site centres. Left in, it is tracked as a phantom fifth block. Check any species with a tiny site-centre share against the outline palette, and drop it from `calib.json` (keep the original as `.orig`) |
| **the species NAMES** | `se_calib` could not find c200's coloured legend labels and fell back to `S0..S4`. Read them off the movie's own `H_X` / `H_Z` tables and pass `--species-names` — or fix the JSON. It worked unaided on c300 |
| **the LATTICE SIZE** | c150 is 12×15, c200 12×20, c300 20×18. Take it from `calib.json`'s `data_cols`/`data_rows` and **never hardcode it** — a stale 12×15 window in `sb_build` meant c300's cols 13:20 and rows 16:18 were never searched for outline colours (rule 39) |
| block sizes | `sb_blocks.py`; do not assume 6×5, and do not assume all species match. c150 is 6×5, c200 4×10, c300 10×6 |
| pulse frames and the cycle length | from the movie's own header text. c150 is 5.49 ms, c200 7.41, c300 7.22. **Verify the runs against the header frame by frame** — c300 has eleven 2-frame runs and two 1-frame ones, and the 1-frame runs are what pin rule 9's bound |
| **whether the movie is PIPELINED** | c200's and c300's headers alternate `phase 1 Z:D5 \|\| X:D1-4` and `phase 2 X:D5 \|\| Z:D1-4`. A pipelined movie does far more same-site permutation work — c200 has 86 transitions against c150's 69 in the same 384 frames, c300 has 75 — which is exactly the material rule 27 says the checks are blind to. Read the header |
| **whether SHAPE discriminates classes** | on c150 it does not, and §3z calls that a weak null on four rest frames. **On c200 and c300 it plainly does — X squares, Z diamonds.** So the null did not hold; re-check every time. (Fill colour already separates the species, so nothing has yet *depended* on it) |
| the reservoir's position **and its side** | half a pitch off the lattice on all three movies, but the side moves: c150 LEFT (`x -5:0`) and ABOVE (`y -4:0`), c200 RIGHT (`x 12.5:15.5`), c300 LEFT for Z (`x -8.5:0.5`) and ABOVE for X (`y -4.5:0.5`) — **two different reservoirs in one movie**. Measure at rest, then confirm with the carry-in D-scan, which pins it hard (c200 0.0082 at D = −3.5 against 0.209 at −4; c300 Z 0.1202 at +9.5 against 0.2196 at +10, X 0.1374 at +5.5 against 0.2626 at +6) |
| the readout's destination **and its direction** | a convention. c150's readouts DESCEND (+9 rows), c200's ASCEND (−20 / −25), c300's DESCEND (+9). Run `sb_extra.py`'s D-scan: a flat scan means unobservable. **Reject a scan minimum that the frames contradict** — c200's X scan preferred D = −10 while the movie shows the block already 10 rows gone and still accelerating, and c300's Z scan preferred +3 while its trailing row already reads +5.07 before it leaves the panel |
| the registration bias | `sb_score.py` measures it on a static control every run |
| `tone_divisor` | 1 on all three movies because every move landed on integer tones. Check that the moves do |
| how many rigid sub-blocks a move has | c150 uses k = 1, 2, 3 and 4; c200 and c300 the same. Assume nothing |
| **the AOM peak against the movie's title** | the title names the AOD count. c150, c200 and c300 all drive exactly 4 for a "4-AOD" movie — treat a mismatch as a defect to chase (rule 31 inflated c200's to 6), but count the crossed pairs the `Combined` sheet actually populates, not `allocate_aom`'s peak, which also colours the hand-measured readout/load rows. c300's peak is 4 over *all* rows, so it has none of c150's fifth-index bookkeeping |
| **whether two blocks pass THROUGH each other** | c300's Z0 and Z1 exchange places on the *same rows*, so for a few frames they occupy the same columns and the movie draws only the front one. Expect the rear species' fill mask to read **zero peaks** there, and expect `sb_score` to report it as MISSING-BLOCK. It is occlusion, not schedule error — confirm by checking the species is measurable and correct on both sides of the crossing |

---

## Procedure — one window, by hand (for inspection, not for building)

### One window, by hand

```powershell
# 1. frames (uncropped) and a calibration -- reuse se-cycle-movies for both
ffmpeg -y -v error -i <movie>.mp4 -fps_mode passthrough -start_number 0 frames\p_%03d.png
python ..\se-cycle-movies\tools\se_calib.py --frames frames --out calib.json --cycle-ms <N>

# 2. read the palette, including outline colours
python tools\sb_read.py --calib calib.json --palette

# 3. rest frames and occupancy, per species
python tools\sb_read.py --calib calib.json --rest --f0 0 --f1 383

# 4. solve one window between two rest points
python tools\sb_read.py --calib calib.json --solve --f0 0 --f1 18 --out-prefix win1
```

`--solve` prints the moves, the fitted times, the per-frame verification, the AOM packing and the
`Combined`-format table. It fits **freely**, so check its timings against rule 9 before using them.

### One segment — `sb_build.py`

`sb_build.py` is the per-window transcriber that `sb_full.py` calls once per pulse-free interval.
Run it directly when you want the **full** detail for one segment — the settled-configuration lists
per species, the pulse-collision drops, every note — which `sb_full` summarises:

```powershell
python tools\sb_build.py --calib calib.json --f0 190 --f1 223 --work . --blocks blocks.json
python tools\sb_build.py --calib calib.json --f0 0 --f1 49 --work . --blocks blocks.json  # the
                                                                    # frames 0-49 acceptance test
```

**Always pass `--blocks`** (rule 22). Without it the block size comes from that window alone, and a
block that spends the window off panel reads as one column wide.

> **Do NOT use `sb_compose.py --solve` / `--run`.** It searches a candidate library where it should
> measure displacements, and on c150's first window it returns 6 moves and 6 AOM groups against a
> verified 8 and 4. Its `--transitions` is still correct as far as it goes, but it cannot see a
> configuration living only on a pulse frame, so it under-counts. `SB_COMPOSE_OPEN_BUG.md` records
> why, and is history rather than a to-do.

**Read its three output lists before believing the sheet.** `UNDETERMINED` is a transition nothing
describes — the movie shuffles a block and the schedule does not say so. `NOT RIGID` is an
appearance class whose members did not share one displacement (on c150 these are all blend colours
at marker boundaries, and the rejection is correct; a *pure* palette colour rejected is a real
finding). `TIE` is where three or more classes share one displacement, so more than one grouping is
equally minimal — **never present the tool's pick as measured.**

#### The four things `sb_build` does that the older path did not

1. **It reads configurations ON pulse frames, from the outline colours.** A pulse frame is the most
   reliable rest there is — nothing moves during a pulse — but the tint moves every fill colour
   ~40 RGB, so the *fill* mask comes back wrong (c150's Z0 reads four peaks where there are six on
   f000–001). The outline colours are not shifted the same way and read all six cleanly. So: try
   the fill, then every outline, accept the first that is a full block on tones.
   **This is not a refinement, it is the difference between finding a move and not finding it.**
   Any transition that begins at the seed, or ends *at* a pulse, has a settled configuration on one
   side that exists only on a pulse frame, and is otherwise invisible to occupancy. On c150's first
   0.7 ms this recovered **2 of the 8 moves** — Z0's opening column swap and its closing cyclic row
   shift — and it raises the transition count for the window from 9 to 11.
   **Consequence: the movie-wide count of 68 in the table below is a FLOOR, not the answer.**
   Re-enumerate with `sb_build` before planning the work.
2. **It reads the partition on the longest prefix of the window that still resolves it.** Past
   arrival every outline colour covers the whole block again and the classes dissolve into one, so
   a read that includes post-arrival frames takes the whole block as a single class and reports no
   move. Shorten from the far end until at least two classes resolve, and require the last frame
   used to be a genuine arrival (every peak within 0.25 of a tone), or `dst` is rounded off a
   marker still in flight.
3. **It fits the timing over a wider window than it reads the partition on.** A couple of settled
   frames past arrival are strong evidence that the block has stopped and they pin `t_finish`,
   which the flat tail of the easing otherwise leaves very soft. Those frames must *not* enter the
   partition read, for the reason in point 2.
4. **Its boundary reconciliation stays inside the pulse-free interval.** `sb_compose.reconcile`
   refuses to merge *across* a pulse but does not stop the merged boundary landing *inside* the
   next pulse run — on c150 it put the f16.73/f17.00 cluster at **f17.18**, after the pulse at f17
   had already fired. Intersect the trial range with each touched move's `[lo, hi]`.

#### Two failure modes it handles that will recur

* **A one-frame mask dropout must not kill a class.** `sb_rigid.classes_in_window` drops a whole
  class the moment its mask falls under `MIN_CLASS_AREA` on *any* frame, and during a crossing a
  one-marker class dips below that for a single frame (c150's Z0 gold at f043). Skip the frame,
  not the class.
* **A transition is not undetermined merely because its own species' outline did not resolve it.**
  A rectangle spans species (§5), so before reporting anything undetermined, check whether some
  emitted move both joins that species and overlaps its frames. On c150 X1's f001–016 relocation is
  carried by X0's rectangle and would otherwise be reported as a hole.

**Read the movie's own header.** It prints `t 0.00/5.49 ms` and, on gate frames, `global pulse`.
Take the cycle length and the pulse frames from the text, not from a fit.

**Score with profiles, not with `se_compare.py`.** That tool works from `se_extract.py`'s marker
lists, whose 0.62-pitch suppression deletes the crossing frames — on *both* sides — and so flatters
the result. Compare each side's own profile peaks per species per axis per frame, masking each with
**its own palette**: `render.ps1` assigns its own fixed colours in species order, and c150's Z0
alone differs by 47 RGB between movie and render, more than the 34 RGB mask tolerance.

---

## c150, measured. The template for the other 24 movies.

| | |
|---|---|
| geometry | 2590×1092, 384 frames, 8 fps, cycle 5.49 ms, dt 0.014296875 ms |
| lattice | 12 × 15 data sites, 150 data qubits, 120 atoms |
| species | X0 pink `(232,122,164)`, X1 gold `(236,159,0)`, Z0 blue `(42,119,213)`, Z1 green `(0,129,0)` |
| outline | mauve `rgb(152,123,184)` |
| blocks | every species is one **6 × 5 block of 30 atoms** |
| seed | X0 `1:6 x 1:5`, X1 `7:12 x 1:5`, Z0 `1:6 x 11:15`, Z1 `7:12 x 11:15` |
| no-data zone | `7:12 x 11:15`, where Z1 sits |
| pulses | 13 runs: f0-1, 17-18, 48-49, 87-88, 106-107, 121-122, 166-167, 190-191, 222-223, 264-265, 297-298, 329, 383 |
| pulse-free intervals | (2,16) (19,47) (50,86) (89,105) (108,120) (123,165) (168,189) (192,221) (224,263) (266,296) (299,328) (330,382) |
| transitions | **69**, all accounted for — 12 per-interval `sb_build` runs, session 13. (`sb_compose --transitions` said "at least 68"; the floor was close but the composition differs, because it cannot see a configuration living only on a pulse frame) |
| registration | `render.ps1` sits **−0.084 site in x, +0.081 in y** from the movie; calibrate on Z1 and subtract before quoting a score (rule 17) |

**The choreography.** To make room, the block at `1:6` slides **−6 columns to `-5:0`** (off panel,
only column 0 visible) while the block at `7:12` slides −6 into `1:6`. Z does this at f050–f073,
X at f224–f238.

| event | frames | what |
|---|---|---|
| Z readout | f123–133 | Z1 `1:6 x 11:15` and Z0 `-5:0 x 11:15` desaturate and descend, columns unchanged |
| Z load | f150–167 | fresh Z0 → `1:6 x 1:5` and Z1 → `1:6 x 6:10`, entering from the left |
| X parking | f224–237 | X1 `7:12 → 1:6`, X0 `1:6 → -5:0`, rows `11:15` |
| X readout | f330–340 | X1 `1:6 x 11:15` and X0 `-5:0 x 11:15` descend |
| X load | f364–383 | fresh X0 → `1:6 x 1:5` and X1 → `7:12 x 1:5`, descending from above |

The cycle **closes on the seed**: by f369–382 Z0 is back on `1:6 x 11:15` and Z1 on `7:12 x 11:15`,
with the fresh X blocks arriving into rows `1:5`.

**Frames 0–49, verified end to end, THREE independent times** — by hand in session 11, by hand
again in session 12, and by `sb_build.py` with no hand steps at all. All three agree on every map
and on 8 moves / 16 rows / 4 AOM groups. **This is the acceptance test for any change to the
tools: reproduce this table.**

| move | spans | map | t (ms) | verified |
|---|---|---|---|---|
| Z0-colswap | Z0 | x `2,4,6↔1,3,5`, y `11:15` | 0.014–0.100 | 0.087 |
| X-rowcross | X0+X1 | y `1:3→8:10` & `4:5→6:7`, x `1:12` | 0.014–0.243 | 0.164 |
| Z0-rowperm | Z0 | y `11:12→14:15` & `13:15→11:13`, x `1:6` | 0.100–0.243 | 0.107 |
| X0-colswap | X0+Z0 | x `4:6↔1:3`, y `6:15` | 0.257–0.416 | 0.057 |
| X1-colswap | X1 | x `10:12↔7:9`, y `6:10` | 0.257–0.416 | 0.053 |
| Z0-colpair | Z0 | x `1,3,5↔2,4,6`, y `11:15` | 0.416–0.516 | 0.026 |
| X-rowreloc | X0+X1 | y `7:10→1:4` & `6→5`, x `1:12` | 0.416–0.656 | 0.076 |
| Z0-rowcyc | Z0 | y `11:14→12:15` & `15→11`, x `1:6` | 0.516–0.686 | 0.063 |

8 moves, 16 schedule rows, **4 AOM groups, peak 4 concurrent**, `validation log entries: 0`,
census never short of 120 atoms, and the render scores **0.046 site mean** peak-matching error
against the movie over ~3800 comparisons (worst 0.556; 14 of 44 non-pulse frames have every peak
within 0.25 site) — **after removing the registration bias of rule 17**; the raw figure is 0.095.

The two moves over 0.10 are the ones whose sub-blocks pass through each other, and the residual is
concentrated on the frames where the fill peaks merge — a resolution limit, per §4, not a wrong
map.

**Session 11's sheet, `c150_first_0p70ms_blocks.xlsx`, differs in one substantive way and is
wrong about it:** it ends X-rowcross and Z0-rowperm at 0.249 ms = f17.42, *after* the pulse at f17
has fired. Rule 9 was tested directly on this — on f017/f018 every block is on its tones (X1 0.036
off, X0 0.047, Z0 0.092) while on f016 they are not (Z0 0.201) — so the moves really do finish at
f17.0, and crossing the pulse buys only 0.012 site. `c150_first_0p70ms_blocks_s12.xlsx` is the
corrected sheet.

---

## Ways to be confidently wrong

These are in addition to the eight in `se-cycle-movies/SKILL.md`, all of which still apply.

1. **A block that ends on the rectangle it started on has still moved.** Same rectangle, different
   atoms in it. Occupancy at rest cannot see it and neither can a positional score — both blocks
   are exactly where the sheet says. Only the outline colour and the mid-move profile can.
   **THIS IS THE SINGLE MOST EXPENSIVE ITEM ON THIS PAGE — see rule 27.** Session 14 shipped a
   c200 sheet twice with four such moves wrong or missing, and every automatic check passed both
   times: census clean, `validation log entries: 0`, score 0.057, "0 undetermined". They were
   found by a human watching the comparison video. If a movie is pipelined, most of its
   transitions are this kind, and **you should expect to find some by eye that the tools did not**.

2. **A block that ends on a *different* rectangle may still not be rigid.** c150's X blocks move
   from rows 1:5 to rows 6:10, which looks like a clean +5 translation and scores well as one. It
   is two sub-blocks, +7 and +2, crossing through each other. The final rectangle is identical
   either way; the atom order inside it is reversed.

3. **Do not trust the marker count mid-move.** It is the merging of rule 1, and it is exactly the
   evidence you are trying to keep. Count peaks in a profile, not detections.

4. **A fitted `t_start` before the preceding pulse ends is a fit artefact, and now also illegal**
   (rule 9). The easing is flat at both ends, so the first and last 10 % of a move is sub-pixel and
   a free fit will happily run past a pulse or into negative time — c150's X-rowcross fitted
   `t_start` = −0.008 ms, before the movie begins. Refit **under the constraint**; do not clamp.

5. **Outline colour marks a role, not an atom.** On c150 the mauve set is 15 atoms during one move
   and 18 during the next. Use it to partition *this* move; never carry it forward as identity.

6. **A merged peak is not a destination** (rule 10). This produced a whole fictitious class of
   "sub-pitch gate excursions" and an argument about needing `tone_divisor` 4. There was no such
   move: the atoms were crossing, and both endpoints were integers. The tell is that an
   integer-endpoint permutation fits the *same* frames at least as well — check that first.

7. **The outline reader's silence is not evidence of stillness.** On c150 it found no move for Z0
   in f019-029, f029-036 or f036-047. All three are real, and the first is carried by the same
   rectangle as X0's column swap. Always cross-check against the transition list (rule 12).

8. **A workbook that renders cleanly and scores well can still be missing moves.** `validation log
   entries: 0` means self-consistent, not complete. Check the transition count: if the movie has 68
   transitions and the sheet describes 40, then 28 blocks sit still in your rebuild while the movie
   shuffles them. This is the same class of error as HANDOVER §13's "38 unwritten permutation
   windows".
   **And a workbook that passes the CENSUS too can still be missing moves** — session 14's
   correction to this entry. The census only counts atoms, so it catches a *relocation* that goes
   astray (it caught c200's f255 swap, where one block's half was written and the other's was not)
   and is blind to a *permutation*. Passing all four checks — validation, census, score,
   undetermined — is the state c200 was in while four moves were wrong.

9. **Do not take a species' comb from the seed** (rule 13).

10. **Do not treat a move as a permutation to be identified.** It is k rigid sub-blocks with
    uniform integer displacements (§3a), and that is both the physical truth and by far the easier
    measurement. Framing it as "which bijection is this?" throws away the peak *ordering* that
    makes the pre-crossing frames informative, and leads to searching a space of candidates when a
    single frame's displacement ratios already answer the question.

11a. **An equal peak count does not prove there was no crossing** (rule 20). After the sub-blocks
    have passed through each other the count is back to normal and the *order* is scrambled, so
    `sorted(peaks)[i]` is no longer tone `i`. I read the ratios off the most-moved frame — which is
    the worst possible frame — and got a four-sub-block move wrong in a way that still verified at
    0.037 site. The count *dropping* is the boundary.

11b. **A tool reporting nothing is not the movie containing nothing.** Every one of session 13's
    nine defects presented as either a transition the tool called UNDETERMINED or a move it scored
    oddly, and in **every** case the movie showed the answer plainly in the outline profiles. Probe
    the pixels (`sb_probe.py`) before concluding anything about the physics.

11c. **A move fitted outside its own window explains nothing, and scores brilliantly for it**
    (rule 25). The easing is flat at both ends, so a fit will push the whole move past the end of
    the frames and sit at progress ~0 — reproducing a block that never moved. On c150 that gave a
    fictitious swap a mean of 0.0199 while the block sat dead still.

11d. **Two blocks cannot occupy one site, and a pulse-frame read can violate that** (rule 23). The
    outline mask spans the panel, so a species whose window contains a *different* block reads that
    block as its own — and on a pulse frame there is no fill to contradict it. The collision is the
    tell; rule 9 breaks the tie.

12. **The crossing frames are the WORST place to look, not the best.** It is tempting to reason
    that the crossing is where candidate models differ most, so that is where the evidence is. In
    fact peaks *merge* at a crossing and information is destroyed; the readable frames are the
    early ones where every peak is still resolved. I got this backwards mid-session 11 and it sent
    the analysis down a blind alley.

13. **A MOVE THAT WAS NEVER ENUMERATED IS IN NO LIST AT ALL — not the moves, not the notes, not
    the undetermined list.** Every previous entry here assumes the tool at least *noticed*
    something. c300's Z0 half-exchange did not reach that stage: its only rest lived on a pulse
    frame in a colour no palette held, so no transition was created and there was nothing to
    report. The output looked perfect. **Do not audit a transcription by reading its own
    complaints** — count what must be there and check it is: `sb_audit.py`, rule 36.

14. **A SYSTEMATIC RESIDUAL WITH EVERY MAP CONFIRMED IS A CONVENTION, NOT A MEASUREMENT.** c300
    read 17 of 64 moves over the guideline, spread evenly across the whole cycle and across every
    species — which is not the signature of crossings, but is easy to accept as "lots of
    crossings" because each individual move has a plausible excuse. It was rule 9's timing bound
    being a frame late, and it had been wrong on every movie for six sessions. Two tells: the
    over-guideline moves do not cluster where the geometry is hard, and `sb_mapcheck` passes
    everything. **And check conventions against the PHYSICS, not against the animation** — the
    animation is a drawing of the schedule and can misrepresent it, which is exactly what it does
    with the pulse duration.

15. **A CONVENTION FLAG THAT CHANGES NOTHING IS NOT EVIDENCE THAT THE CONVENTION DOES NOT MATTER.**
    The first attempt to test the rule-9 bound reproduced the old numbers to four decimals, and
    the natural reading was "so it makes no difference". The flag was inert: `pulse_bounds`
    initialised `lo = a_iv - 1`, which *is* the preceding run's last frame, and that floor
    silently overrode it. **Always verify a switch moves at least one number before drawing any
    conclusion from a null result.**

---

## Files

| file | what |
|---|---|
| **`tools/sb_full.py`** | **START HERE for a new movie.** Whole movie → one workbook, by solving each pulse-free interval with its own tight windows and then merging and colouring the AOMs once. Segment bounds come from the movie's own pulse runs. `--only N` to iterate on one segment |
| **`tools/sb_blocks.py`** | **RUN THIS FIRST.** Each species' block size, measured movie-wide and as the largest count (rule 22). Feed it to the others with `--blocks`. Skipping it silently loses every move of a block that spends an interval off panel |
| **`tools/sb_probe.py`** | **THE DIAGNOSTIC — this is the tool that does the real work.** `--peaks` prints the fill, the faded fill and EVERY outline colour profiled separately, per frame, so you can read a move off the pixels by hand. `--classes` replays the partition read for one transition and says exactly why it was rejected. Its docstring maps each symptom to the rule being broken |
| `tools/sb_extra.py` | fits the timing of readouts and loads from a JSON job spec — the part nothing automatic can see (§7). Its docstring carries the whole recipe for writing the `unload` / `load` / `move` rows, and every trap in doing so |
| `tools/sb_score.py` | scores a rebuild by profile peaks, each side masked with its own palette. Finds its own static control for rule 17's bias, and flags `MISSING-BLOCK` cases, which are mistimed rows rather than positional error |
| `tools/sb_video.ps1` | the two side-by-side comparison videos, with the crop derived from the calibration's panel |
| **`tools/sb_build.py`** | the per-window transcriber `sb_full` calls once per interval: settled configurations (including on pulse frames), transitions, appearance-triple partitions, measured displacements, timing under the pulse constraint, comb growth, AOM colouring, workbook. Run it directly for the **full** detail of one segment, and for the frames 0–49 acceptance test |
| `tools/sb_rigid.py` | the appearance-triple reader `sb_build` is built on: `classify` → `measure` → `merge`, with the rigidity residual as proof. Useful on its own to inspect one window's classes |
| `tools/sb_read.py` | the measurement primitive: `--palette`, `--rest`, `--solve`, `--xlsx`. Outline-driven, one window at a time. Fits **freely** — check its timings against rule 9 |
| `tools/sb_compose.py` | the shared machinery `sb_build` imports: `Peaks`, `rect_at`, `verify`, `extend_comb`, `schedule_rows`, `allocate_aom`. Its `--transitions` is superseded (it cannot see pulse-frame configurations); **its `--solve` / `--run` are dead code — do not use them** |
| `tools/sb_emit.py` | `moves.json` → the six-sheet workbook: `Constants`/`Seed`/`Gates`/`Schedule` in c540_v4's renderable layout with `slot` = AOM index, plus `Combined` in Shayne's AOM-column layout and `Notes` with the evidence and the undetermined list |
| **`tools/sb_report.py`** | **NEW, session 14.** `moves.json` (+ `extra.json`, + `score.txt`) → the per-move evidence report that step 10 asks for, which session 13 wrote by hand for c150. Prints each move's rigid sub-blocks, the appearance classes with their rigidity residuals, the cross-species join scores, the verification error, the hand-measured rows with their notes, and every note the transcriber raised. Append a "what is a CONVENTION" section by hand — the tool cannot know which of your choices were conventions |
| **`tools/sb_audit.py`** | **NEW, session 15. Step 4a — PROVES completeness, and exits 1 if it cannot.** Every transition must have a move that joins it with its midpoint inside; the transitions-minus-moves gap must equal the cross-species joins exactly; no two species may claim the same site at rest. That last check is the one c200 lacked. Rule 36 |
| **`tools/sb_mapcheck.py`** | **NEW, session 15.** Verifies every move's MAP independently of its TIMING: each sub-block's own displacement must imply the same progress on every pre-crossing frame. The only check that separates a wrong partition from a right one timed a frame out — which is how session 15 knew c300's elevated means were rule 9 and not bad maps |
| **`tools/sb_watch.py`** | **NEW, session 15.** The numerical form of "watch the whole video": scores every (frame, species, axis) cell separately and prints the local runs with both sides' peak lists, so a same-site permutation — short, local, invisible to the mean — is readable. Account for every run of ≥3 frames; its docstring lists the only four legitimate causes |
| **`tools/sb_events.py`** | **NEW, session 15.** Finds the readouts and loads (step 6): where solid collapses as faded jumps, where stock turns solid, and the long steady runs of parked stock. A finder, not an oracle — confirm each with `sb_probe --peaks` |

## The whole c300 movie — DONE, session 15 (2026-09-10). READ THIS FIRST.

`se_cycle_c300_d14_C10xS3_4aod.mp4`. **Deliverables in the project root:**
`c300_full_blocks.xlsx`, `c300_full_blocks_report.txt`, `c300_full_rebuild_score.txt`,
`c300_full_original_vs_rebuild_panels.mp4` / `..._full.mp4`. Working files, including the
calibration, the frames and the jobs/extra JSON, are in `run_c300/` **in the project**.

```
75 transitions, ALL accounted for -- 0 undetermined, AND PROVED (sb_audit: every transition has a
   joining move with its midpoint inside; 75 - 64 = 11 = exactly the 11 cross-species joins;
   0 site clashes over 39120 species-frame-site claims)
64 measured moves -> 118 schedule rows, + 8 hand-measured readout / load rows = 126
4 AOM groups, peak 4 -- over ALL rows, so no c150-style fifth-index bookkeeping. Combined
   populates AOM1..AOM4 exactly, matching the movie's own "4-AOD pipelined" title
se_sim: validation clean, census never short of 240 atoms
render.ps1 -MatchCalib: validation log entries 0
score: 0.0534 site mean over 39383 comparisons on 360 non-pulse frames; 133 of 360 frames have
   every peak within 0.25 site. 0.0436 with the six MISSING-BLOCK cells dropped -- those are
   movie-side OCCLUSION, not schedule error
sb_mapcheck: 0 wrong maps.  sb_watch: 20 runs of >=3 frames, all four-causes-accounted
```

| | c150 | c200 | c300 |
|---|---|---|---|
| cycle / dt | 5.49 ms / 0.0142969 | 7.41 / 0.0192969 | **7.22 / 0.0188021** |
| lattice, blocks | 12×15, 4 × (6×5) = 120 | 12×20, 4 × (4×10) = 160 | **20×18, 4 × (10×6) = 240** |
| pipelined? | no | yes | **yes** |
| shape discriminates? | no | yes | **yes** (X squares, Z diamonds) |
| reservoir | left `x -5:0` / above `y -4:0` | right `x 12.5:15.5` | **Z left `x -8.5:0.5`, X above `y -4.5:0.5` — two reservoirs** |
| readouts | descend (+9) | ascend (−20 / −25) | **descend (+9)** |
| transitions / moves | 69 / 55 | 86 / 69 | **75 / 64** |
| score | 0.0472 | 0.0526 | **0.0534** |

**Seed** (and the cycle closes exactly on it at f382–383): X0 `1:10 × 1:6`, X1 `11:20 × 1:6`,
Z0 `1:10 × 13:18`, **Z1 parked off-panel at `-9:0 × 13:18`** — a species can start off screen.

**The choreography, and two parts of it are new to this project:**

| event | frames | what |
|---|---|---|
| **Z0/Z1 EXCHANGE** | f048–064 | Z0 `1:10 → -9:0` while Z1 `-9:0 → 1:10`, **both on rows 13:18, passing THROUGH each other**. The movie draws Z1 over Z0, so Z0's fill reads zero peaks at f055/f059 |
| Z readout | f149–155 | Z0 (`-9:0`) and Z1 (`1:10`), rows 13:18, desaturate across the pulse f147–148 and descend |
| Z load | f149 | fresh Z0 → `-9:0 × 1:6`, Z1 → `-9:0 × 7:12`, staged at x 0.49 |
| Z carry-in | f174–187 | both ride one rectangle `x -9:0 → 1:10`, `y 1:12` |
| X readout | f329–337 | X0 (`-9:0`) and X1 (`1:10`), rows 13:18, desaturate at the pulse f328 and descend |
| X load | f329 | fresh X0 → `1:10 × -5:0`, X1 → `11:20 × -5:0`, staged **above** at y −0.49/0.51 |
| X carry-in | f373–382 | both ride one rectangle `x 1:20`, `y -5:0 → 1:6` — the seed |

**Three tool defects were fixed on this movie — rules 37, 38, 39 — and rule 9 was CORRECTED.**
The full account with the pixel evidence is the appendix of `c300_full_blocks_report.txt`. The one
to internalise: **Z0's half of the exchange was never ENUMERATED**, so it was in no list at all,
not even the undetermined one — which is why `sb_audit.py` now exists.

### How to RE-SOLVE c300 (session 22 — it was irreproducible until this was written)

```powershell
python $SB\sb_full.py --calib calib.json --blocks blocks.json --work . `
                      --xlsx out.xlsx --extra extra.json --events events.json
```

with `run_c300\events.json` — **Z0 and Z1 f147-189, X0 and X1 f327-384**. That reproduces session
15 exactly: **64 moves, every map identical, 0 undetermined, 118 schedule rows, 4 AOM groups peak 4,
9 moves over the 0.10 guideline, AUDIT CLEAN, 0 wrong maps.** The transition count reads **78 = 75
solved + 3 held back as readout/load**, where session 15 reported 75: the three bridges are now
enumerated (rule 36) and named rather than absorbed.

**Session 15 predates `--events`**, so `run_c300/` shipped with `jobs.json` (what to FIT) and no
`events.json` (what the solver must NOT fit). Re-solving without it is what produced session 21's
false regression: the unnamed Z readout became a spurious `X0 cols f149-187` at 3.0993 site and the
unnamed X readout became the two undetermined transitions at f328-383. **Adjudicated against the
pixels in `SKILL_RESET_2026-09-14.md`** — the faded Z1 block descends rows 13.32 → 19.12 over
f149-155 with its columns pinned, and X0's columns are motionless from f161 to f187. Both files now
exist; keep them together.

## The whole c200 movie — DONE, session 14 (2026-09-09)

`se_cycle_c200_d12_C4xD10_4aod.mp4`. **Deliverables in the project root:**
`c200_full_blocks.xlsx`, `c200_full_blocks_report.txt`, `c200_full_rebuild_score.txt`,
`c200_full_original_vs_rebuild_panels.mp4` / `..._full.mp4`.

```
86 transitions, ALL accounted for -- 0 undetermined
69 measured moves -> 131 schedule rows, + 9 hand-measured readout / load rows = 140
4 AOM groups, peak 4 concurrent -- matching the movie's own "4-AOD" title, and the Combined
   sheet populates AOM1..AOM4 exactly, as c150's does
se_sim: validation clean, census never short of 160 atoms
render.ps1 -MatchCalib: validation log entries 0
score: 0.0526 site mean over 36462 comparisons on 359 non-pulse frames; 164 of 359 frames
       have every peak within 0.25 site
```

| | c150 | c200 |
|---|---|---|
| cycle / dt | 5.49 ms / 0.014296875 | 7.41 ms / 0.019296875 |
| lattice, blocks | 12×15, 4 × (6×5) = 120 atoms | 12×20, 4 × (4×10) = 160 atoms |
| seed | X0 `1:6 x 1:5`, X1 `7:12 x 1:5`, Z0 `1:6 x 11:15`, Z1 `7:12 x 11:15` | X0 `5:8 x 11:20`, X1 `9:12 x 11:20`, Z0 `-3:0 x 1:10`, Z1 `1:4 x 1:10` |
| shape discriminates? | **no** | **yes** — X squares, Z diamonds |
| pipelined? | no | **yes** — `phase 1 Z:D5 \|\| X:D1-4` ↔ `phase 2`, switching near f172 and f342 |
| reservoir | left `x -5:0` / above `y -4:0` | **right, `x 12.5:15.5`** |
| readouts | descend (+9 rows) | **ascend (−20 / −25 rows)** |
| pulses | 13 runs | 13 runs: f0-1, 16-17, 57-58, 96-97, 129-130, 170-171, 214-215, 234-235, 253-254, 274-275, 308-309, 340-341, 383 |
| Z readout / load | f123–133 / f150–167 | f172–186 / stock vivid at f172, carried f199–207 |
| X readout / load | f330–340 / f364–383 | f342–352 / stock vivid at f342, carried f366–381 |

**The cycle closes exactly on the seed at f382.**

**Nine tool defects were found and fixed on this movie — rules 27–35.** Five of them were found by
the **user watching the comparison video**, not by any check in this project, and all five were
same-site permutations. See rule 27 and step 9. The full account, including the pixel evidence for
each, is the last third of `c200_full_blocks_report.txt`.

**Both c150 and c200 were transcribed from the `_4aod` variants** (384 frames), in
`SE_cycle_movies/movies_4aod/mitten_codes/`. The `movies_2aod/` versions of the same codes are
longer (c150: 568 frames) and have not been touched.

## The whole c150 movie — DONE, session 13 (2026-09-09)

**Deliverables in the project root:** `c150_full_blocks.xlsx`, `c150_full_blocks_report.txt`,
`c150_full_rebuild_score.txt`, `c150_full_original_vs_rebuild_panels.mp4` / `..._full.mp4`.

```
69 transitions, ALL accounted for -- 0 undetermined
55 measured moves -> 102 schedule rows, + 8 hand-measured readout / load rows = 110
4 crossed pairs -- the Combined sheet populates AOM1..AOM4 and nothing else, matching the
   movie's "4-AOD" title. (`allocate_aom`'s peak over ALL rows reads 5, on one row of 110: the
   X readout unload, whose span straddles two batches of moves. It drives no AOM columns.)
se_sim: validation clean, census never short of 120 atoms
render.ps1 -MatchCalib: validation log entries 0, "the workbook is self-consistent"
score: 0.0472 site mean over 28457 comparisons on all 360 non-pulse frames; 143 of 360 frames
       have every peak within 0.25 site; worst 0.886
```

**RUN IT INTERVAL BY INTERVAL, not in one pass.** `sb_build` sizes each species' window as its
bounding box over the range it is given, and over all 384 frames those go panel-wide and overlap
(Z0 spans cols −0.88..12.60, covering Z1) — so the shared outline mask attributes one species'
outline to another (§1a). Twelve runs bounded by the pulse frames either side, then merge and
colour the AOMs **once** over the merged rows so the peak concurrency is the movie's and not a
segment's. Rule 9 guarantees this loses nothing, and segments 0+1 reproduce the verified frames
0–49 answer exactly. Pass `--blocks` (rule 22).

The registration bias of rule 17 is **~0 when the render is extracted with `se_calibtxt.py
--out-json`**, which zeroes `marker_offset`: measured on the static control, x +0.005, y +0.009
site, and the raw and corrected scores agree to 0.0001. Session 12's −0.084/+0.081 is the movie
calibration's own marker offset, and it appears only if both sides are extracted with the movie's
calibration. Say which you used.

10 of the 55 moves are over the 0.10 site guideline, at 0.10–0.16. Every one is either a crossing
(where the fill peaks genuinely merge for a few frames, §4) or a block sliding off panel with one
column left to measure. None is a wrong map: each was cross-checked by hand against the outline
profiles.

## Still open

* **FINISHING c540 IS THE NEXT JOB, not starting another movie.** c150, c200 and c300 are closed
  end to end; c540 is transcribed, audits clean on completeness, and is **not** closed. Four
  things, in order, all with the evidence already gathered (`c540_vs_shayne.md`, and the appendix
  of `c540_full_blocks_report.txt`):
  1. **`Z0/Z1 cols 13:24 → 1:12` at f316–327 is missing** — the only structural hole and the cause
     of both `se_sim check3` entries. Not a uniform translation, so the k=1 route rightly refused
     it. Shayne reads it `13:22→3:12 | 23:24→1:2`; the pixels support that *shape* (at f316 ten
     columns run at ≈ −0.26 and two at ≈ −0.64, ratio 2.46 against his 2.2) but the fit cannot
     separate rotate-by-2 (0.2654) from rotate-by-3 (0.2458). **Settle it by eye against the
     movie**, then hand-write it or fix the reader.
  2. **The rotation-vs-static-column error, which is systematic.** Where the movie rotates a whole
     12-column block, the partition read leaves ONE column static and shifts the rest by one less.
     Scored against the pixels on two moves and Shayne wins both. On X0 cols f002–008 it is
     decisive by eye: the sheet needs a marker sitting still at 1.00 on f002 and the movie's
     lowest X0 peak is 1.66. This is almost certainly `complete_partition`'s complement being
     handed a class that is itself short by one.
  3. **Six undetermined same-site permutations.** `run_c540/diag_scan.py` classifies them.
  4. **Then render and score** — never done on c540, so `sb_score` and `sb_watch` have never run
     on it, and rule 27's "watch the whole movie" signal has never been available for a movie that
     is pipelined and therefore mostly same-site permutations.
* **The other 21 movies**, after that. The per-interval procedure above is the one to repeat, with
  the rules and the re-measure table applied from the start. Budget most of the time for steps
  4a–6 and 9, not for step 4: the transcription itself is two `sb_full` runs, and everything that
  has ever gone wrong went wrong in the checking, the readouts and the conventions.
* **RUN `aom_min.py` ON ANY HAND BOOK BEFORE BELIEVING ITS AOM COUNT.** Shayne's c540 book writes
  6 crossed pairs and needs 4; 38 of its 55 non-gate batches merge down. A human writing one
  rectangle per block will not see that two blocks moving by the same displacement on the same
  comb are one crossed pair. This does **not** apply to `sb_emit`'s own output, where
  `allocate_aom` has already merged — a high peak there is rule 31's symptom to chase.
* **c540 is the only movie with an independent hand transcription, so it is the only place the
  tool can be scored against something other than itself.** Session 16's most useful finding came
  from that comparison, not from the check suite, which was clean at the time. If another hand
  book ever appears, compare against it.
* **c150 and c200 under the corrected rule-9 bound — MEASURE BEFORE YOU RE-DELIVER.** Neither is
  wrong in any map and both remain self-consistent; their timings are a frame late. Re-running
  c150 gives the identical 55 moves / 102 rows / 4 AOM groups / 0 undetermined with moves over the
  guideline **10 → 6** and the mean of per-move errors **0.0620 → 0.0558** — but 28 of 50 moves
  individually get *worse*, so **this needs an end-to-end score before it counts as an
  improvement, and that has not been done.** The obstacle is small and specific: c150's
  `extra.json` was never kept, so the 8 readout/load rows must be reconstructed from
  `c150_full_blocks.xlsx`'s `Schedule` sheet first (`sb_emit`'s extra format is in
  `sb_extra.py`'s docstring). Do that, re-render, re-score, compare against 0.0472 — then decide.
  **Do not overwrite sheets the user has already accepted without asking.**
* **The three new checks have not been run against c150 or c200.** `sb_audit.py`,
  `sb_mapcheck.py` and `sb_watch.py` were written on c300. Running them on the two closed movies
  is the obvious way to find out whether either still hides something — c200 especially, whose
  four defects were found by eye and whose sheet has never been audited this way.
* **NOT open, and do not "fix" it: c150 uses FOUR crossed pairs, the same as c200.** Checked
  directly in `c150_full_blocks.xlsx`: its `Combined` sheet populates **AOM1–AOM4 only**, AOM5–AOM8
  are empty. Session 13's headline "5 AOM groups, peak 5" comes from the `Schedule` sheet's `slot`
  column, which reaches 5 on **exactly one row of 110** — the X readout `unload`, whose span
  (4.7037–5.0141 ms) straddles two batches of moves, so the interval colouring gives it a fifth
  index. `sb_emit` never writes `unload`/`load` rows into the AOM tone columns, so that fifth index
  is bookkeeping, not hardware. **Both movies agree with their "4-AOD" titles.**
  When quoting an AOM count, say which you mean: `allocate_aom`'s peak over *all* schedule rows
  (c150: 5, c200: 4) or the crossed pairs the `Combined` sheet actually drives (both: 4).
* **Check every delivered movie over its whole length before calling it done.** See rule 27. This
  is a step, not a nicety: it found four real defects on c200 after everything else was green.
  Since session 15 there is a tool for the mechanical half — `sb_watch.py`, which scores every
  (frame, species, axis) cell separately and prints the local runs — so the job is now "account
  for every run of ≥3 frames" rather than "stare at 384 frames". **Still watch the video too:**
  `sb_watch` compares what the profiles can measure, and an occlusion is exactly where they cannot.
* **Readouts and loads are still hand-written, but they are no longer hand-FOUND.**
  `sb_events.py` locates them; §7 and `sb_extra.py`'s docstring remain the recipe for the rows.
* **`SB_COMPOSE_OPEN_BUG.md` is CLOSED and is now history, not a to-do.** Its diagnosis was right
  and `sb_build.py` implements the fix (measure displacements; never search a candidate library).
  Keep the file for the reasoning; do not work from its "acceptance test" as if it were pending.
* **Readouts and loads are not automated.** The method is §7 and the c150 numbers are in the table
  above; `sb_emit.emit(..., extra=<json>)` takes them as a list of `unload`/`load` rows. The
  readout destination is unobservable and its magnitude is a convention.
  **Three c200 traps worth carrying forward:**
  (a) an `unload`'s `t_start` sets `fadeFrom`, so it must be a hair **under** `f*dt` for the frame
  the movie fades on — exactly the rounding trap already documented for a load's birth time;
  (b) `se_sim` runs **one batch per distinct `t_start`** and matches every row in a batch against
  the state *before* it, so an unload must share (or precede) the batch of any move whose
  destination is the sites it is vacating — c200's X readout otherwise picked up Z0's parking
  slide, 120 atoms into an 80-site rectangle, and dragged Z0 off panel;
  (c) two blocks that travel together still need **two rows** if their combs differ on both axes —
  merging them makes a rectangle that traps far more sites than it carries (c200's Z readout:
  160 sites for 80 atoms), which `check3` flags.
* **The fresh stock's staging position is SETTLED: the reservoir really is at half-integer tones,
  and c200 confirms it BY A FIT rather than only at rest** — much stronger evidence. Scanning the
  carry-in displacement pins the half-pitch hard: c200's Z load scores **0.0082 site at D = −3.5**
  against 0.2090 at −4 and 0.2644 at −3, and its X load **0.0371 at −7.5** against 0.1649 and
  0.1747. **But the SIDE does not transfer** — c150's reservoir is left and above, c200's is right
  (`x 12.5:15.5`). The outside-the-array integer-staging rule holds on both and still binds: on
  c200 the choices are 12:15 and 13:16, and 13:16 is required because col 12 is inside the data
  array with X1 standing on cols 9:12 at the load instant.
  Session 13 measured the reservoir directly at rest, not through a fit, on frames where nothing is
  moving: c150's Z stock sits with its trailing column at **x = 0.50** from f123 to f151 (one
  visible column, unclipped — a marker at 0.5 spans px 480..513 inside a panel starting at 433) and
  the X stock with its trailing row at **y = 0.50** from f330 to f370. This is not rule 10's trap,
  because it is read on *settled* frames rather than mid-crossing, and the departing block parks on
  integer `-5:0` on the same rows. So the reservoir is genuinely half a pitch off the lattice,
  which is HANDOVER §11.1/§13.2 confirmed.
  **The sheet still has to use integer staging**, since `render.ps1` picks atoms up by
  `[int][Math]::Round(x)`. Of the two integer choices, the better-*scoring* one puts stock at col 1
  / row 1 — **inside** the data array, where c150 has X and Z blocks standing at that moment, so
  their rectangles would pick the stock up and drag it away. Use the outside-the-array staging
  (`-5:0` in x, `-4:0` in y) and pay ~0.5 site on the reservoir's single visible row or column:
  Z load 0.1395 as written against 0.0843 measured, X load 0.2190 against 0.2399.
* **c150's tone divisor** is settled as "neither" for *extraction* (HANDOVER §13.2: divisor 2 wins
  on RMS but fails census). For *representation* the answer is divisor 1 — every move measured
  lands on integer tones.
