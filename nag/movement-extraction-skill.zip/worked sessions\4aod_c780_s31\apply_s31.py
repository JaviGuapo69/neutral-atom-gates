"""apply_s31.py -- the HAND CORRECTIONS to the automatic c780 book (session 31, 2026-09-17).

Follows `handmade correction method.md` (template run_c630_s30\apply_s30.py). The skill is FINAL and is not
changed; the move list `moves_full.json` (copied from run_c780\, the automatic run of session 28 by the
"delivering the rest of videos" session) is edited here, every corrected or added map is MEASURED with the
skill's own `sb_compose.verify` / `progress_per_frame`, the timing is fitted with the skill's own
`sb_build.fit_timing` CLIPPED to the neighbouring moves of the same block (rule 9 + no atom carries two
motions), and the workbook is re-emitted through `sb_emit.emit` exactly as sb_full.py / merge_halves.py do.

STATUS: the user's instruction of 2026-09-17 for this movie ONLY: "find all the mistakes you can find yourself
and propose solutions ... apply the solutions to the problems that you find right away without consulting me,
but only for this one time ... after that remake the rebuild video".  So every item below was read from the
pixels (logs\probe_*.txt, logs\crop_*.png in this folder) and APPLIED; the s31 video is the starting point for
the ordinary hand-correction dialogue.  Anything the user later overrides is changed by editing this script
and re-running it (it always starts from moves_full_c780_original.json / rests_full_c780_original.json).

Block positions (frames): X0 cols 1:13, rows 1:12 (f0-77) -> 13:24 (f87-178) -> 25:36 (f198-280), parked
cols -12:0 (f288-349); X1 cols 14:26, rows 1:12 (f0-86) -> 13:24 (f96-197) -> 25:36 (f207-), cols 1:13 (f288-349);
Z0 1:13 x 25:36 (f0-70) -> parked -12:0 (f79-172); fresh Z0 -12:0 x 1:12 -> 1:13 (f214) -> 14:26 (f290)
-> 1:13 (f361), rows 25:36 (f373); Z1 14:26 x 25:36 (f0-70) -> 1:13 (f79-172); fresh Z1 -12:0 x 13:24
-> 1:13 (f214) -> 14:26 (f290), rows 25:36 (f373).

    python -u apply_s31.py > apply_s31.log 2>&1      # from run_c780_s31
"""
import json, os, sys
sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_build, sb_compose, sb_emit
from sb_read import Movie

OUT_XLSX = "c780_s31_blocks.xlsx"
TAG = "HAND CORRECTION (session 31, 2026-09-17, read from the pixels; applied on the user's one-time instruction)"
M = Movie("calib.json")
dt = M.dt
mv = json.load(open("moves_full_c780_original.json", encoding="utf-8"))
rests = json.load(open("rests_full_c780_original.json", encoding="utf-8"))
moves = mv["moves"]
print("start: %d moves, %d undetermined" % (len(moves), len(mv["undetermined"])))

print("measuring every species' peaks once (sb_compose.Peaks) ...")
runs = sb_compose.pulse_runs(M)
wins = sb_compose.species_windows(M, 0, M.nf - 1)
P = sb_compose.Peaks(M, wins, 0, M.nf - 1)
AX = {"cols": 0, "rows": 1}
R = lambda a, b: list(range(a, b + 1))
X0C, X1C, XC = R(1, 13), R(14, 26), R(1, 26)


# ====================================================================== helpers (from apply_s30.py)
def find(sp, axis, f0, f1, sel=None):
    ix = [i for i, m in enumerate(moves) if (sp in m["joins"] or m["sp"] == sp) and m["axis"] == axis
          and m["f0"] == f0 and m["f1"] == f1 and (sel is None or sel(m))]
    assert len(ix) == 1, (sp, axis, f0, f1, ix, [label(moves[i]) for i in ix])
    return ix[0]


def rng(t):
    t = list(t)
    if len(t) > 1 and t == list(range(t[0], t[-1] + 1)):
        return "%d:%d" % (t[0], t[-1])
    return ",".join(str(x) for x in t)


def label(m):
    return "%s %s f%03d-%03d %s%s" % ("+".join(m["joins"]), m["axis"], m["f0"], m["f1"],
                                     " | ".join("%s->%s" % (rng(a), rng(b)) for a, b in m["parts"]),
                                     (" on %s" % rng(m["sub_comb_lines"])) if m.get("sub_comb_lines") else "")


def sub_peaks(m, frames):
    if m.get("sub_comb_lines"):
        other = 1 - AX[m["axis"]]
        return sb_build.SubPeaks(M, wins, (other, list(m["sub_comb_lines"])), frames)
    return P


def measure(m, frames, PP=None):
    """fill mean/worst/detail/mean_moving with the skill's own verify + free progress fit"""
    PP = PP or sub_peaks(m, frames)
    axis = AX[m["axis"]]
    detail = {}
    for nm in M.species:
        mean, worst, n = sb_compose.verify(PP, nm, axis, m["src"], m["dst"], m["fa"], m["fb"], frames, M)
        detail[nm] = round(mean, 4) if n else None
    mean, worst, n = sb_compose.verify(PP, m["sp"], axis, m["src"], m["dst"], m["fa"], m["fb"], frames, M)
    seq = sb_compose.progress_per_frame(PP, m["sp"], axis, m["src"], m["dst"], frames, M)
    moving = [s for s in seq if 0.05 < s[1] < 0.95]
    m["mean"] = round(mean, 4)
    m["worst"] = round(worst, 3)
    m["detail"] = detail
    m["mean_moving"] = round(sum(s[2] for s in moving) / len(moving), 4) if moving else m["mean"]
    m["n_moving"] = len(moving)
    m["mono"] = round(sb_compose.monotone_penalty(seq), 4)
    m["ok"] = bool(m["mean"] <= 0.10)
    free = [s[2] for s in seq if 0.02 < s[1] < 0.98]
    m["free_err"] = round(sum(free) / len(free), 4) if free else None
    print("  %s: t %.4f-%.4f (f%.2f-%.2f)  smoothstep mean %.4f worst %.3f over %d peaks; "
          "moving-frame mean %.4f on %d frames; FREE per-frame err %s; monotone %.3f; joins %s"
          % (label(m), m["t0"], m["t1"], m["fa"], m["fb"], mean, worst, n, m["mean_moving"],
             m["n_moving"], m["free_err"], m["mono"], detail))
    for f, p, e, w in seq:
        print("      f%03d  p %.3f  err %.3f  worst %.3f" % (f, p, e, w))
    return seq


def refit(m, frames, lo_fr, hi_fr, why):
    """fit_timing, the skill's own, confined to [lo_fr, hi_fr] frames (rule 9 + neighbours)"""
    PP = sub_peaks(m, frames)
    best = sb_build.fit_timing(PP, M, m["sp"], AX[m["axis"]], m["src"], m["dst"], frames,
                               float(lo_fr), float(hi_fr))
    if best is None:
        print("  !! fit_timing found nothing in [f%.2f, f%.2f] for %s -- window set to the bounds" % (lo_fr, hi_fr, label(m)))
        set_time(m, lo_fr, hi_fr, "fit failed; bounds used")
        return PP
    _, a, b = best
    m["fa"], m["fb"] = round(a, 2), round(b, 2)
    m["t0"], m["t1"] = round(a * dt, 4), round(b * dt, 4)
    print("  timing fitted in [f%.2f, f%.2f] (%s): f%.2f-f%.2f" % (lo_fr, hi_fr, why, a, b))
    return PP


def set_time(m, fa, fb, why):
    m["fa"], m["fb"] = round(fa, 2), round(fb, 2)
    m["t0"], m["t1"] = round(fa * dt, 4), round(fb * dt, 4)
    print("  timing set to f%.2f-f%.2f (%s)" % (fa, fb, why))


def set_map(m, parts, block=None):
    """parts = the rigid groups; `block` = every tone of the block on the moving axis, so the static
    tones enter src/dst as identity (the solver's records do this; verify otherwise charges every
    static row a full site)"""
    m["parts"] = [[list(a), list(b)] for a, b in parts]
    m["A"], m["A2"] = m["parts"][0]
    m["B"], m["B2"] = m["parts"][1] if len(m["parts"]) > 1 else ([], [])
    mp = {}
    for a, b in m["parts"]:
        mp.update(dict(zip(a, b)))
    for t in (block or []):
        mp.setdefault(t, t)
    m["src"] = sorted(mp)
    m["dst"] = [mp[s] for s in m["src"]]
    assert sorted(m["dst"]) == m["src"] or m["kind"] == "relocation", m["parts"]


def interval(f0):
    """the pulse-free interval holding frame f0: (lo, hi) = first frames of the bounding runs, iv"""
    prev = max(r for r in runs if r[0] <= f0)
    nxt = min(r for r in runs if r[0] > f0)
    return float(prev[0]), float(nxt[0]), [prev[1] + 1, nxt[0] - 1]


def new_move(sp, axis, kind, f0, f1, parts, comb, how, sub=None, joins=None, block=None, for_tr=None):
    lo, hi, iv = interval(f0)
    n = dict(for_tr=list(for_tr or [sp, f0, f1]), sp=sp, axis=axis, kind=kind, f0=f0, f1=f1, iv=iv,
             parts=None, src=None, dst=None, A=None, A2=None, B=None, B2=None,
             fa=float(f0), fb=float(f1), lo=lo, hi=hi, t0=f0 * dt, t1=f1 * dt,
             mean=None, mean_moving=None, n_moving=None, worst=None, mono=None, span=1.0,
             joins=list(joins or [sp]), detail={}, comb=list(comb), how=TAG + ": " + how,
             sub_comb_lines=(list(sub) if sub else None), ok=False)
    set_map(n, parts, block)
    return n


def insert(n):
    pos = max([i for i, m in enumerate(moves) if m["f0"] <= n["f0"]] + [-1]) + 1
    moves.insert(pos, n)
    print("\n+ ADDED %s" % label(n))
    return n


def delete(sp, axis, f0, f1, why, sel=None):
    i = find(sp, axis, f0, f1, sel)
    print("\n- DELETED %s  (%s)" % (label(moves[i]), why))
    del moves[i]


def replace(m, parts, block, how, f0=None, f1=None, for_tr=None, comb=None, joins=None, kind=None):
    old = label(m) + " comb %s" % (rng(m["comb"]) if m["comb"] else "(empty)")
    if kind:
        m["kind"] = kind
    if f0 is not None:
        m["f0"] = f0
    if f1 is not None:
        m["f1"] = f1
    if for_tr is not None:
        m["for_tr"] = list(for_tr)
    if comb is not None:
        m["comb"] = list(comb)
    if joins is not None:
        m["joins"] = list(joins)
        m["sp"] = joins[0]
    set_map(m, parts, block)
    m["how"] = TAG + ": " + how
    print("\n~ REPLACED %s  ->  %s" % (old, label(m)))
    return m


def drop_undetermined(sp, f0, f1):
    before = len(mv["undetermined"])
    mv["undetermined"] = [u for u in mv["undetermined"]
                          if not (u["sp"] == sp and u["f0"] == f0 and u["f1"] == f1)]
    if len(mv["undetermined"]) != before - 1:
        print("  (no undetermined entry %s f%03d-%03d to drop)" % (sp, f0, f1))


def retime_transition(sp, f0_old, f1_old, f0_new, f1_new):
    """move a transition's frame bounds and keep the neighbouring rests consistent"""
    z = rests[sp]
    t = [t for t in z["transitions"] if t["f0"] == f0_old and t["f1"] == f1_old]
    assert len(t) == 1, (sp, f0_old, f1_old)
    t = t[0]
    t["f0"], t["f1"] = f0_new, f1_new
    keep = []
    for r in z["rests"]:
        if r[1] == f0_old and r[0] <= f0_new:
            r[1] = f0_new
        if r[0] == f1_old and r[1] >= f1_new:
            r[0] = f1_new
        if r[0] <= r[1]:
            keep.append(r)
    z["rests"] = keep
    print("  rests_full: transition %s f%03d-%03d -> f%03d-%03d" % (sp, f0_old, f1_old, f0_new, f1_new))


def fr(a, b):
    return list(range(max(0, a), min(M.nf - 1, b) + 1))


notes = []


def note(s):
    notes.append("[%s] %s" % (TAG, s))


# ====================================================================== 1. f001-008 X1 cols (undetermined): the same rotation as X0's written move
x0c = moves[find("X0", "cols", 2, 10)]
n = insert(new_move("X1", "cols", "permutation", 1, 8, [[R(14, 15), R(25, 26)], [R(16, 26), R(14, 24)]], R(1, 12),
                    "UNDETERMINED X1 cols f001-008 on rows 1:12: the SAME rotation as X0's written 1:2->12:13 | 3:13->1:11, "
                    "not its inverse. Gold outline cols 14,15 -> 25,26 (15.33 16.29 on f002, 19.47 20.54 on f004, 23.56 24.77 "
                    "on f006, 25.00 26.00 on f008) and mauve cols 16:26 -> 14:24 (15.97..25.77 on f002, 14.01..23.99 on f008).",
                    for_tr=["X1", 1, 8]))
set_time(n, x0c["fa"], x0c["fb"], "the same batch as X0's rotation")
measure(n, fr(0, 10))
drop_undetermined("X1", 1, 8)
note("1: ADDED X1 cols 14:15->25:26 | 16:26->14:24 f001-008 (verified %.4f, free %s)." % (n["mean"], n["free_err"]))

# ====================================================================== 2. f001-008 Z0 cols (undetermined): the INVERSE rotation
n = insert(new_move("Z0", "cols", "permutation", 1, 8, [[R(1, 11), R(3, 13)], [R(12, 13), R(1, 2)]], R(25, 36),
                    "UNDETERMINED Z0 cols f001-008 on rows 25:36: the INVERSE of X0's rotation. Gold outline cols 12,13 -> 1,2 "
                    "(10.66 11.69 on f002, 6.59 7.62 on f004, 2.32 3.37 on f006, 1.01 2.02 on f008) and mauve cols 1:11 -> 3:13 "
                    "(1.21..11.17 on f002, 2.99..12.93 on f008). The user's item 'f1-8 missed transition in D5'.",
                    for_tr=["Z0", 1, 8]))
refit(n, fr(0, 10), 0.0, 8.6, "gate instant f0; block on tones from f008-009")
measure(n, fr(0, 10))
drop_undetermined("Z0", 1, 8)
note("2: ADDED Z0 cols 1:11->3:13 | 12:13->1:2 f001-008 (verified %.4f, free %s)." % (n["mean"], n["free_err"]))

# ====================================================================== 3-6. f008-034 Z0 rows: four consecutive small permutations (crops logs\crop_Z0_rows_*.png)
retime_transition("Z0", 16, 23, 16, 22)
retime_transition("Z0", 23, 29, 22, 30)
m = moves[find("Z0", "rows", 8, 18)]
replace(m, [[[26], [36]], [[28], [26]], [[36], [28]]], R(25, 36),
        "the S2.1 read 26:34->28:36 | 35:36->26:27 (rotation of 26:36 by 2) is wrong: rows 27, 29:35 sit on their tones on "
        "every frame f009-015. Three rows move: gold row 26 -> 36 (26.26 f009, 27.24 f010, 31.13 f012, 33.58 f013, 35.79 f015), "
        "mauve row 36 -> 28 (35.78, 34.97, 33.63, 31.76, 30.03, 28.82, 28.13 on f009-015) and mauve row 28 -> 26 (27.93, 27.81, "
        "27.49, 26.43, 26.19, 26.04). Rest at f016 (all twelve rows on tones). The user's 'f9-15 missed transition in D5'.",
        f1=16, for_tr=["Z0", 8, 16])
refit(m, fr(7, 17), 8.0, 16.2, "block on tones at f008 and f016")
measure(m, fr(7, 17))
z3 = m
m = moves[find("Z0", "rows", 16, 25)]
replace(m, [[[25], [31]], [[31], [33]], [[33], [25]]], R(25, 36),
        "the read 25->32 | 31->33 | 32->31 | 33->25 moves row 32, which the fill holds at 31.99 on every frame f017-022 (the "
        "user: 'row 32 should not move'). Gold row 33 -> 25 (32.43 f017, 31.27 f018, 29.31 f019, 27.21 f020, 25.84 f021, 25.08 "
        "f022), mauve row 25 -> 31 (25.38, 26.27, 27.61, 29.36, 30.50, 30.89) and mauve row 31 -> 33 (31.14, 31.54, 31.9, 32.58, "
        "32.80, 32.96).", f0=16, f1=22, for_tr=["Z0", 16, 22])
refit(m, fr(15, 23), 16.0, 22.8, "rest at f016; the next 3-cycle starts f022.8")
measure(m, fr(15, 23))
z4 = m
m = moves[find("Z0", "rows", 23, 31)]
replace(m, [[[27], [35]], [[29], [27]], [[35], [29]]], R(25, 36),
        "the read 27->35 | 29->27 | 34->29 | 35->34 moves row 34, which the fill holds at 33.99 on every frame f023-029 (the "
        "user: 'row 34 should not move'). Gold row 27 -> 35 (27.06 f023, 27.48 f024, 29.09 f025, 30.91 f026, 32.91 f027, 34.47 "
        "f028, 34.92 f029), mauve row 29 -> 27 (28.94, 28.82, 28.58, ~28, 27.38, 27.16, 27.00) and mauve row 35 -> 29 (34.97, "
        "34.50, 33.53, 32.03, 30.53, 29.48, 29.01).", f0=22, f1=30, for_tr=["Z0", 22, 30])
refit(m, fr(21, 31), 22.5, 29.8, "after the 25/31/33 cycle; block on tones at f029")
measure(m, fr(21, 31))
z5 = m
n = insert(new_move("Z0", "rows", "permutation", 30, 34, [[[30], [34]], [[32, 34], [30, 32]]], R(1, 13),
                    "UNDETERMINED Z0 rows f030-034 on 25:36: gold row 30 -> 34 (30.12 f030, 30.71 f031, 32.22 f032, 33.45 f033, "
                    "33.95 f034) and mauve rows 32,34 -> 30,32 (31.95 33.96 f030; 31.57 33.62 f031; 30.87 32.96 f032; 30.25 32.26 "
                    "f033; 30.02 32.03 f034); the other nine rows on their tones. The user's 'f30-34 missed transition in D5'.",
                    block=R(25, 36), for_tr=["Z0", 30, 34]))
refit(n, fr(29, 35), 29.5, 35.0, "after the 27/29/35 cycle; pulse at f35")
measure(n, fr(29, 35))
drop_undetermined("Z0", 30, 34)
note("3-6: Z0 rows f008-034 rewritten as four moves: 26->36 | 28->26 | 36->28 f008-016 (%.4f); 25->31 | 31->33 | 33->25 f016-022 "
     "(%.4f); 27->35 | 29->27 | 35->29 f022-030 (%.4f); ADDED 30->34 | 32,34->30,32 f030-034 (%.4f)."
     % (z3["mean"], z4["mean"], z5["mean"], n["mean"]))

# ====================================================================== 7. f043-050 X0 and X1 rows (both undetermined): rotation by +9 on one rectangle
n = insert(new_move("X0", "rows", "permutation", 43, 50, [[R(1, 3), R(10, 12)], [R(4, 12), R(1, 9)]], XC,
                    "UNDETERMINED X0 and X1 rows f043-050 (the last resort offered 1:6->7:12 | 7:12->1:6). Both blocks rotate by +9: "
                    "gold outline rows 1:3 -> 10:12 (X0: 1.07-3.70 f044, 2.15-4.58 f045, 4.47-6.48 f046, 6.71-8.80 f047, 8.03-10.65 "
                    "f048, 9.19-11.81 f049, 9.73-12.15 f050) and mauve rows 4:12 -> 1:9 (3.97..11.89 f044, 2.23..10.22 f047, "
                    "1.01..8.98 f050); X1 identical (mauve 4.00..12.01 -> 1.00..9.06, gold 0.98-3.03 -> 9.73-12.28). One rectangle "
                    "over cols 1:26. The user's 'f43-50 missed transition in D1 and 2'.", joins=["X0", "X1"], for_tr=["X0", 43, 50]))
refit(n, fr(42, 52), 43.0, 50.8, "gate instant f43 is not a pulse: block on tones f043; the 4:7->5:8 | 8->4 swap starts f050.5")
measure(n, fr(42, 52))
drop_undetermined("X0", 43, 50); drop_undetermined("X1", 43, 50)
m14 = moves[find("X1", "rows", 51, 57)]
if m14["fa"] < n["fb"]:
    refit(m14, fr(50, 56), n["fb"], 55.3, "after the rotation (its own fit started f49.15, inside it)")
    m14["how"] += " | " + TAG + ": start clipped to f%.2f, after the f043-050 rotation." % m14["fa"]
    measure(m14, fr(50, 56))
note("7: ADDED X0+X1 rows 1:3->10:12 | 4:12->1:9 f043-050 (verified %.4f X0, %s X1); X1+X0 rows 4:7->5:8 | 8->4 start clipped to f%.2f."
     % (n["mean"], n["detail"].get("X1"), m14["fa"]))

# ====================================================================== 8. f055-058 X0 rows: X0 does X1's map; one rectangle
delete("X0", "rows", 55, 61, "the read 1:6->2:7 | 7->1 is wrong: row 4 is static (4.04 on every frame f055-058) and rows 1,2,5,6 "
       "go +1 while 3 and 7 go -2 -- exactly X1's written map (the user: 'f55-58 wrong transition in D1')")
m16 = moves[find("X1", "rows", 55, 60)]
m16["joins"] = ["X1", "X0"]; m16["comb"] = XC
m16["how"] += (" | " + TAG + ": X0 does the same map in the same batch (X0 mauve rows 1,2,5,6 -> 2,3,6,7: 1.13 2.15 5.15 6.14 on "
               "f056, 1.64 2.60 5.33 6.64 on f057, 2.02 3.00 5.91 6.98 on f058; gold rows 3,7 -> 1,5: 2.81 6.80, 2.07 5.8, 0.76-1.25 "
               "4.78-5.27), so the rectangle spans cols 1:26 and X0's wrong 1:6->2:7 | 7->1 is deleted.")
print("\n~ JOINED X0 onto %s" % label(m16))
measure(m16, fr(54, 60))
note("8: X0 rows f055-061 1:6->2:7 | 7->1 DELETED; X1's 3,7->1,5 | 1,2,5,6->2,3,6,7 now carries X0 too (verified %.4f X1, %s X0)."
     % (m16["mean"], m16["detail"].get("X0")))

# ====================================================================== 9. f063-066 X1+X0 rows: 8:9->9:10 | 10->8, not 9<->10
m = moves[find("X1", "rows", 63, 68)]
replace(m, [[R(8, 9), R(9, 10)], [[10], [8]]], R(1, 12),
        "the last-resort 9->10 | 10->9 is wrong: on both blocks row 8 moves too. Mauve rows 8,9 -> 9,10 (X0: 8.02 9.01 f063, 8.32 "
        "9.03 f064, 8.80 9.80 f065, 8.99 10.00 f066) and gold row 10 -> 8 (9.65-10.14 f063, 9.11-9.60 f064, 8.21 f065, 7.72-8.33 "
        "f066); X1 identical. The user's 'f63-66 wrong transition in D1, D2'.")
refit(m, fr(62, 68), 62.8, 66.6, "after the 1:3<->4:6 swap; the 7:9->9:11 rotation starts f66.3")
measure(m, fr(62, 68))
note("9: X1+X0 rows f063-068 REPLACED by 8:9->9:10 | 10->8 (verified %.4f)." % m["mean"])

# ====================================================================== 10. f070-079 Z0 and Z1 cols (FAULT C): the false one-column rests
for sp, blk, dst in (("Z0", R(1, 13), R(-12, 0)), ("Z1", R(14, 26), R(1, 13))):
    z = rests[sp]
    z["transitions"] = [t for t in z["transitions"] if not (t["f0"] in (71, 72) and t["f1"] in (72, 79))]
    z["rests"] = [r for r in z["rests"] if not (r[0] == 72 and r[1] == 72)]
    for r in z["rests"]:
        if r[1] == 71:
            r[1] = 70
    z["transitions"].append(dict(sp=sp, f0=70, f1=79, x0=blk, y0=R(25, 36), x1=dst, y1=R(25, 36), kind="relocation"))
    z["transitions"].sort(key=lambda t: t["f0"])
    print("  rests_full: %s false rest f072 and transitions f071-072/f072-079 replaced by one relocation f070-079 %s -> %s"
          % (sp, rng(blk), rng(dst)))
mz1 = moves[find("Z1", "cols", 72, 81)]
replace(mz1, [[R(14, 26), R(1, 13)]], None,
        "FAULT C: the solver read a false rest one column left (13:25) one frame into the motion and wrote the slide FROM it. "
        "The block leaves 14:26 at the f070 gate: fill 13.07..25.07 on f072 (-0.93), 11.61..23.60 f073, 9.45..21.45 f074, "
        "6.68..18.70 f075, 4.25..16.25 f076, 2.49..14.48 f077, 1.40..13.39 f078, 1.01..13.00 f079 -- a uniform -13 landing on 1:13.",
        f0=70, f1=79, for_tr=["Z1", 70, 79], kind="relocation")
refit(mz1, fr(69, 81), 70.0, 79.6, "gate instant f70; on tones at f079")
measure(mz1, fr(69, 81))
mz0 = moves[find("Z0", "cols", 72, 81)]
replace(mz0, [[R(1, 13), R(-12, 0)]], None,
        "FAULT C: the slide was written from the false rest 0:12; the block leaves 1:13 at the f070 gate (fill 0.08..12.11 on f072, "
        "-0.41..10.61 f073, -0.45..8.37 f074, 5.67 last visible f075 ... 0.01 on f079 and 0.00 from then on: only column 0 stays on "
        "panel). Uniform -13 to the parking cols -12:0, the same batch as Z1's slide.", f0=70, f1=79, for_tr=["Z0", 70, 79],
        kind="relocation")
refit(mz0, fr(69, 81), 70.0, 79.6, "gate instant f70")
fa = round((mz0["fa"] + mz1["fa"]) / 2, 2); fb = round((mz0["fb"] + mz1["fb"]) / 2, 2)
for m in (mz0, mz1):
    set_time(m, fa, fb, "co-timed with its Z twin: one batch")
    measure(m, fr(69, 81))
drop_undetermined("Z0", 71, 72); drop_undetermined("Z1", 71, 72)
note("10: FAULT C -- Z1 cols f072-081 13:25->1:13 REPLACED by 14:26->1:13 f070-079 (verified %.4f); Z0 cols 0:12->-12:0 REPLACED by "
     "1:13->-12:0 (%.4f); the false rests at f072 and the f071-072 relocations dropped." % (mz1["mean"], mz0["mean"]))

# ====================================================================== 11. f071-077 X1 cols (undetermined): the same rotation as X0's
x0c = moves[find("X0", "cols", 72, 79)]
n = insert(new_move("X1", "cols", "permutation", 71, 77, [[R(14, 18), R(22, 26)], [R(19, 26), R(14, 21)]], R(1, 12),
                    "UNDETERMINED X1 cols f071-077 on rows 1:12: the SAME rotation as X0's written 1:5->9:13 | 6:13->1:8. Gold "
                    "outline cols 14:18 -> 22:26 (14.97-18.92 f072, 18.72-22.50 f074, 20.30-24.31 f075, 21.50-25.49 f076, 21.97-26.01 "
                    "f077) and mauve cols 19:26 -> 14:21 (18.42-25.40 f072, 15.01-21.78 f075, 14.01-21.07 f077).",
                    for_tr=["X1", 71, 77]))
set_time(n, x0c["fa"], x0c["fb"], "the same batch as X0's rotation")
measure(n, fr(70, 79))
drop_undetermined("X1", 71, 77)
note("11: ADDED X1 cols 14:18->22:26 | 19:26->14:21 f071-077 (verified %.4f)." % n["mean"])

# ====================================================================== 12-13. f077-096 X0 and X1 rows 1:12 -> 13:24 (FAULT A)
DESC = [[[1, 11], [14, 24]], [[2, 3, 4, 6, 7, 8], [17, 18, 19, 21, 22, 23]], [[5, 12], [13, 20]], [[9, 10], [15, 16]]]
n = insert(new_move("X0", "rows", "relocation", 77, 87, DESC, X0C,
                    "FAULT A: the relocation 1:12 -> 13:24 had no rows move (the last resort's 1:11->14:24 | 12->13 was refused at "
                    "0.166), so the X blocks stayed on rows 1:12 in the rebuild to the end. It is NOT a plain +12 translation (that map "
                    "reads 0.18 with a free error of 0.23; the fill spacing during the move is not one row -- 7.68 9.08 9.84 10.92 11.70 "
                    "12.16 13.24 13.82 14.83 15.68 16.24 17.88 on f082): the block descends in FOUR rigid groups, read from the outline "
                    "classes (logs\\crop_X0_rows_077_088.png): mauve rows 5, 9, 10, 12 (4.96/5.40 8.80/9.26 10.09 11.98/12.43 on f078) "
                    "land on 13, 15, 16, 20 (13.00 15.01 15.68/16.29 19.97 on f086), so 5,12 go +8 and 9,10 go +6; gold rows 1:4, 6:8, "
                    "11 land on 14, 17:19, 21:24 (13.59/14.08 16.61..19.23 20.55..24.06 on f086), so 1,11 go +13 and 2:4, 6:8 go +15. "
                    "The fill on f082 matches this map at p 0.5 to 0.2 site (predicted 7.5 9 9.5 10.5 11.5 12 13 13.5 14.5 15.5 16 17.5).",
                    for_tr=["X0", 77, 87]))
refit(n, fr(76, 89), 76.8, 87.6, "block on tones f077; on 13:24 from f087")
measure(n, fr(76, 89))
drop_undetermined("X0", 77, 87)
a12 = n
n = insert(new_move("X1", "rows", "relocation", 86, 96, DESC, X1C,
                    "FAULT A, X1's half nine frames later, the same four-group descent (logs\\crop_X1_rows_086_097.png: mauve rows 5, 9, "
                    "10, 12 on f087 land on 13, 15, 16, 20 on f096; gold rows 1:4, 6:8, 11 land on 14, 17:19, 21:24). Fill 1.59..12.47 "
                    "f088, 4.46 5.94 7.21 7.96 9.96 10.82 11.47 11.95 14.09 14.56 f090, 9.34..19.35 f092, on 13:24 from f096.",
                    for_tr=["X1", 86, 96]))
refit(n, fr(85, 98), 86.2, 97.0, "block on tones f086; on 13:24 from f096")
measure(n, fr(85, 98))
drop_undetermined("X1", 86, 96)
note("12-13: FAULT A -- ADDED X0 rows 1,11->14,24 | 2:4,6:8->17:19,21:23 | 5,12->13,20 | 9:10->15:16 f077-087 (verified %.4f, free %s) "
     "and the same map for X1 f086-096 (%.4f, free %s)." % (a12["mean"], a12["free_err"], n["mean"], n["free_err"]))

# ====================================================================== 14. f079-084 Z1 rows: rotation by +4 within each half, not +3
m = moves[find("Z1", "rows", 79, 86)]
replace(m, [[R(25, 26), R(29, 30)], [R(27, 30), R(25, 28)], [R(31, 32), R(35, 36)], [R(33, 36), R(31, 34)]], R(25, 36),
        "the last-resort 28,29,30,34,35,36->25,26,27,31,32,33 | 25,26,27,31,32,33->28,29,30,34,35,36 (rotation by 3 within each "
        "half) is one row short: gold rows 25,26 -> 29,30 and 31,32 -> 35,36 (26.06 27.07 32.02 33.05 on f081, 28.83 29.71 34.82 "
        "35.71 on f083), green rows 27:30 -> 25:28 and 33:36 -> 31:34 (26.72..29.87 32.77..35.89 on f080, 25.61..28.63 31.64..34.66 "
        "on f082, 25.15..28.22 31.14..34.28 on f083); on tones at f084.", f1=84, for_tr=["Z1", 79, 84])
refit(m, fr(78, 86), 79.0, 84.6, "block on tones at f079 (after the slide) and f084")
measure(m, fr(78, 86))
note("14: Z1 rows f079-086 REPLACED by 25:26->29:30 | 27:30->25:28 | 31:32->35:36 | 33:36->31:34 (verified %.4f)." % m["mean"])

# ====================================================================== 15. f091-095 Z1 rows: two 3-cycles, rows 29-30 static
m = moves[find("Z1", "rows", 91, 97)]
replace(m, [[[26], [28]], [R(27, 28), R(26, 27)], [[31], [33]], [R(32, 33), R(31, 32)]], R(25, 36),
        "the read 26:31->28:33 | 32:33->26:27 (rotation of 26:33 by 2, fitted f94.5-99.6 = the NEXT move's window) is wrong: rows "
        "29 and 30 sit at 28.99 29.99 on every frame f092-094. Gold rows 26 -> 28 and 31 -> 33 (26.19 31.06 f092, 26.96 32.04 f093, "
        "27.87 32.89 f094) and mauve rows 27,28 -> 26,27 and 32,33 -> 31,32 (27.46 31.91/32.88 f092, 26.43/27.49 31.42/32.11 f093, "
        "26.49 31.52 f094); on tones at f095.", f1=95, for_tr=["Z1", 91, 95])
refit(m, fr(90, 96), 91.0, 95.4, "rest at f091 (after 34->25 | 25:33->26:34) and f095")
measure(m, fr(90, 96))
note("15: Z1 rows f091-097 REPLACED by 26->28 | 27:28->26:27 | 31->33 | 32:33->31:32 f091-095 (verified %.4f)." % m["mean"])

# ====================================================================== 16. f108-114 Z1 rows (undetermined)
n = insert(new_move("Z1", "rows", "permutation", 108, 114, [[[25, 35], [26, 36]], [[26, 27, 28, 30, 31, 32], [29, 30, 31, 33, 34, 35]],
                                                              [[29, 36], [25, 32]], [[33, 34], [27, 28]]], R(1, 13),
                    "UNDETERMINED Z1 rows f108-114 (the candidate 25:30<->31:36 read 0.177). Four rigid groups: the dark-green class "
                    "rows 29,33,34,36 -> 25,27,28,32 (28.79 32.48 33.57 35.65 f109; 26.81 29.75 30.75 34.13 f111; 25.15 27.24 28.35 "
                    "32.14 f113; 24.99 27.00 28.01 31.99 f114) and the other eight rows +1 / +3 (25.07 26.19 27.20 28.29 30.17 31.17 "
                    "32.05 35.00 f109; 25.80 28.46 29.54 30.40 32.28 33.42 34.42 35.82 f112; 26.00 29.02 29.98 30.98 32.99 34.00 35.00 "
                    "35.97 f114). The fill on f113 (25.16 25.96 27.23 28.23 28.89 29.89 30.89 32.15 32.86 33.86 34.86 35.94) matches "
                    "this map at p 0.95 to 0.05 site.", for_tr=["Z1", 108, 114]))
refit(n, fr(107, 116), 107.0, 114.6, "gate instant f107; on tones at f114")
measure(n, fr(107, 116))
drop_undetermined("Z1", 108, 114)
note("16: ADDED Z1 rows 25,35->26,36 | 26:28,30:32->29:31,33:35 | 29,36->25,32 | 33:34->27:28 f108-114 (verified %.4f, free %s)." % (n["mean"], n["free_err"]))

# ====================================================================== 17. f117-120 X1 rows (FAULT E, the silent hole): 22 <-> 23
n = insert(new_move("X1", "rows", "permutation", 117, 120, [[[22], [23]], [[23], [22]]], XC,
                    "FAULT E, the SILENT hole: rows 22 and 23 swap on both X blocks -- X1 fill 22.13 23.02 on f117, 22.52 (the two "
                    "merged) on f118, 22.17 22.87 on f119, on tones at f120; the outline classes cross between f118 and f119 on X1 AND X0 "
                    "(mauve 22.18 -> 22.56-23.17, gold 22.87 -> 21.87-22.30 on both), X0's fill 22.23 22.93 f118, 22.17 22.81 f119. "
                    "Verified on X0's peaks too (0.07).", joins=["X1", "X0"], block=R(13, 24), for_tr=["X1", 117, 120]))
refit(n, fr(116, 121), 117.0, 120.4, "after the 22->24 | 23:24->22:23 cycle; the 14->22 | 15:22->14:21 rotation starts f120.7")
measure(n, fr(116, 121))
delete("X1", "rows", 117, 122, "PHANTOM: 23->14 | 14:22->15:23 fitted to f120.7-122.5 is the OPPOSITE of the real 14->22 | 15:22->14:21 "
       "(X1+X0 rows f120-132) on the same frames, so the atoms were claimed twice (se_sim check4 at t 4.6516); gold row 14 goes DOWN "
       "13.75-14.36 f120, 14.29-14.91 f121, 15.52-16.14 f122, 17.46-18.07 f123, 19.47-19.96 f124")
note("17: ADDED X1+X0 rows 22<->23 f117-120 (verified %.4f X1, %s X0); the phantom X1+X0 rows f117-122 23->14 | 14:22->15:23 DELETED."
     % (n["mean"], n["detail"].get("X0")))

# ====================================================================== 18-20. f126-137 X rows: the 18/19/20 cycle, three pair swaps, one shared rotation
m = moves[find("X1", "rows", 127, 134)]
replace(m, [[[18], [20]], [R(19, 20), R(18, 19)]], R(13, 24),
        "the S2.1 read 14:18->16:20 | 19:20->14:15 fitted to f132.7-134.5 is wrong; what happens at f127-130 on BOTH X blocks is "
        "a 3-cycle of rows 18,19,20: fill 18.19 18.94 19.90 f127, 18.65 19.64 f128 (18->18.65 merged with 19->18.65), 18.27 19.20 "
        "19.70 f129, on tones f130; gold row 18 -> 20 (17.77-18.26, 18.46-18.88, 19.81), mauve rows 19,20 -> 18,19 (18.33 19.60, "
        "18.13 19.16). X0 identical (18.65 19.64 f128; 18.27 19.20 19.70 f129).", f0=127, f1=130, for_tr=["X1", 127, 132],
        comb=XC, joins=["X1", "X0"])
refit(m, fr(125, 131), 126.4, 130.3, "after the 14->22 | 15:22->14:21 rotation (ends f126.5); on tones at f130")
measure(m, fr(125, 131))
c18 = m
n = insert(new_move("X0", "rows", "permutation", 130, 133, [[[14, 16, 20], [15, 17, 21]], [[15, 17, 21], [14, 16, 20]]], XC,
                    "UNDETERMINED X0 rows f130-133 (and X1's, never enumerated): three pair swaps 14<->15, 16<->17, 20<->21. Mauve rows "
                    "14,16,20 -> 15,17,21 (13.96 16.00 20.05 f130; 14.35 16.14 20.39 f131; 15.02 16.82 20.98 f132) and gold rows 15,17,21 "
                    "-> 14,16,20 (14.68 16.69 20.71 f130; 14.90 16.68 20.90 f131; 13.75-14.24 15.76-16.37 19.78-20.39 f132); fill "
                    "14.38 14.83 16.45 20.29 20.82 on f131 = the pairs approaching; on tones f133. X1 identical.",
                    joins=["X0", "X1"], block=R(13, 24), for_tr=["X0", 130, 133]))
refit(n, fr(129, 134), 130.0, 133.3, "rest at f130 and f133")
measure(n, fr(129, 134))
drop_undetermined("X0", 130, 133)
c19 = n
m = moves[find("X0", "rows", 133, 136)]
m["joins"] = ["X0", "X1"]; m["comb"] = XC
m["how"] += (" | " + TAG + ": X1 does the same 14:15->18:19 | 16:19->14:17 in the same batch (X1 gold rows 14,15 -> 18,19: 14.92 16.08 "
             "f134, 16.37-17.28 f135, 17.77 18.48 f136; mauve rows 16:19 -> 14:17: 15.57..18.85 f134, 14.87..17.82 f135, 14.31..17.61 "
             "f136), so X1's 4-part 14->19 | 15->18 | 17:18->14:15 | 19->17 is deleted and this rectangle spans cols 1:26.")
print("\n~ JOINED X1 onto %s" % label(m))
delete("X1", "rows", 132, 136, "the 4-part 14->19 | 15->18 | 17:18->14:15 | 19->17 is X0's 14:15->18:19 | 16:19->14:17 mis-read")
measure(m, fr(132, 138))
note("18: X1 rows f127-134 REPLACED by X1+X0 rows 18->20 | 19:20->18:19 f127-130 (verified %.4f). 19: ADDED X0+X1 rows "
     "14,16,20<->15,17,21 f130-133 (%.4f). 20: X1 rows f132-136 DELETED; X0's 14:15->18:19 | 16:19->14:17 carries X1 (%.4f X0, %s X1)."
     % (c18["mean"], c19["mean"], m["mean"], m["detail"].get("X1")))

# ====================================================================== 21. f138-145 X0 cols (undetermined): the same rotation as X1's, not Z1's
x1c = moves[find("X1", "cols", 139, 147)]
n = insert(new_move("X0", "cols", "permutation", 138, 145, [[R(1, 4), R(10, 13)], [R(5, 13), R(1, 9)]], R(13, 24),
                    "UNDETERMINED X0 cols f138-145 on rows 13:24 (the report guessed X0 rides Z1's 1:9->5:13 | 10:13->1:4). It is the "
                    "OPPOSITE: X0 rotates like X1 (14:17->23:26 | 18:26->14:22): gold cols 1:4 -> 10:13 (2.03-5.04 f139, 5.43-8.48 "
                    "f141, 8.91-12.21 f143, 9.61-13.23 f144) and mauve cols 5:13 -> 1:9 (4.65..12.57 f139, 2.88..10.93 f141, "
                    "1.37..9.67 f143, 1.07..9.08 f144).", for_tr=["X0", 138, 145]))
set_time(n, x1c["fa"], x1c["fb"], "the same batch as X1's rotation")
measure(n, fr(137, 147))
drop_undetermined("X0", 138, 145)
note("21: ADDED X0 cols 1:4->10:13 | 5:13->1:9 f138-145 (verified %.4f)." % n["mean"])

# ====================================================================== 22-26. f145-172 X rows on 13:24
n = insert(new_move("X0", "rows", "permutation", 145, 148, [[R(20, 21), R(21, 22)], [[22], [20]]], XC,
                    "UNDETERMINED X0 and X1 rows f145-148: a 3-cycle of rows 20,21,22 -- mauve rows 20,21 -> 21,22 (20.41 21.71 f146, "
                    "20.96 21.69/22.17 f147) and gold row 22 -> 20 (21.01-21.63 f146, 20.01 20.50 f147); fill 20.34 21.22 f146, 20.36 "
                    "20.88 21.82 f147, on tones f148. X1 identical (20.28 21.28 f146; 20.30 20.86 21.75 f147).",
                    joins=["X0", "X1"], block=R(13, 24), for_tr=["X0", 145, 148]))
refit(n, fr(144, 149), 145.0, 148.4, "rest at f145 and f148")
measure(n, fr(144, 149))
drop_undetermined("X0", 145, 148); drop_undetermined("X1", 145, 148)
c22 = n
delete("X1", "rows", 148, 154, "DUPLICATE of the same batch (22:23->19:20 | 19:21->21:23 is 19:21->21:23 | 22:23->19:20 with the "
       "parts reversed, same window, same comb): the X atoms were claimed twice at t 5.6992", sel=lambda m: m["parts"][0][0] == [22, 23])
n = insert(new_move("X0", "rows", "permutation", 156, 162, [[R(13, 14), R(18, 19)], [R(15, 19), R(13, 17)]], XC,
                    "UNDETERMINED X0 and X1 rows f156-162: a rotation of rows 13:19 -- gold rows 13,14 -> 18,19 (12.82-14.33 f157, "
                    "13.59-15.09 f158, 15.62-16.56 f159, 16.95-18.23 f160, 17.53-18.95 f161) and mauve rows 15:19 -> 13:17 (14.99..18.91 "
                    "f157, 14.40..18.62 f158, 13.28..17.30 f160, 13.13..17.08 f161); rows 20:24 static; on tones f162. X1 identical.",
                    joins=["X0", "X1"], block=R(13, 24), for_tr=["X0", 156, 162]))
refit(n, fr(155, 163), 156.2, 162.3, "rest at f156 (after 15->18 | 16:18->15:17) and f162")
measure(n, fr(155, 163))
drop_undetermined("X0", 156, 162); drop_undetermined("X1", 156, 162)
c24 = n
m = moves[find("X0", "rows", 162, 167)]
replace(m, [[[13, 18], [15, 20]], [[14, 15, 19, 20], [13, 14, 18, 19]]], R(13, 24),
        "the last-resort 13->20 | 14:20->13:19 (rotation of 13:20 by 7) is wrong: rows 16, 17 sit at 16.03 17.03 on every frame. "
        "Two 3-cycles: gold rows 13 -> 15 and 18 -> 20 (13.21 18.27 f163, 14.21-14.83 19.77 f164, 14.67-15.17 19.70-20.32 f165) and "
        "mauve rows 14,15 -> 13,14 and 19,20 -> 18,19 (13.74 14.73 18.80 19.78 f163, 13.28 13.98 18.25 19.27 f164, 13.20 14.04 17.99 "
        "19.04 f165). X1 identical (gold 13.25 18.23 f163, 14.70 15.16 19.70 20.19 f165), so one rectangle over cols 1:26.",
        f1=165, for_tr=["X0", 162, 165], comb=XC, joins=["X0", "X1"])
refit(m, fr(161, 166), 162.0, 165.7, "rest at f162; the whole-block rotation starts f165.7")
measure(m, fr(161, 166))
drop_undetermined("X1", 162, 165)
c25 = m
delete("X1", "rows", 165, 171, "DUPLICATE: the X1-only copy of the X1+X0 row (X1 claimed twice)", sel=lambda m: m["joins"] == ["X1"])
m = moves[find("X1", "rows", 165, 171)]
replace(m, [[R(13, 21), R(16, 24)], [R(22, 24), R(13, 15)]], R(13, 24),
        "the read 22:24->15:17 | 15:21->18:24 holds rows 13, 14 static; they move (13.45 14.48 f167, 13.78 14.91 f168, 14.64 15.64 "
        "f169). The whole block rotates by +3: mauve rows 13:21 -> 16:24 (13.36..21.71 f167, 14.63..22.66 f169, 15.60..23.28 f170, "
        "15.45..23.73 f171) and gold rows 22:24 -> 13:15 (20.63-21.24 22.11-23.25 f167, 19.08-21.22 f168, 16.97-19.12 f169, 14.83-17.25 "
        "f170, 13.44-14.93 f171); on tones at the f172 pulse. X1 identical.")
refit(m, fr(164, 173), 165.4, 172.0, "after the two 3-cycles; pulse at f172")
measure(m, fr(164, 173))
note("22: ADDED X0+X1 rows 20:21->21:22 | 22->20 f145-148 (%.4f). 23: duplicate X1+X0 rows f148-154 DELETED. 24: ADDED X0+X1 rows "
     "13:14->18:19 | 15:19->13:17 f156-162 (%.4f). 25: X0 rows f162-167 REPLACED by X0+X1 13,18->15,20 | 14:15,19:20->13:14,18:19 "
     "f162-165 (%.4f). 26: duplicate X1 rows f165-171 DELETED; X1+X0 rows f165-171 REPLACED by 13:21->16:24 | 22:24->13:15 (%.4f)."
     % (c22["mean"], c24["mean"], c25["mean"], m["mean"]))

# ====================================================================== 27-28. Z1 rows f145-152 (undetermined) and f160-166
n = insert(new_move("Z1", "rows", "permutation", 145, 152, [[[25], [34]], [[34], [35]], [[35], [25]]], R(1, 13),
                    "UNDETERMINED Z1 rows f145-152 on 25:36: mauve row 25 -> 34 (25.48 f146, 26.67 f147, 28.54 f148, 30.66 f149, 32.49 "
                    "f150, 33.66 f151, 34.00 f152), gold row 35 -> 25 (34.92 f145, 34.29 f146, 32.92 f147, 28.46 f149, 26.53 f150, 25.36 "
                    "f151, 25.01 f152) and row 34 -> 35 (34.23, 34.39, 34.62, 34.85, 34.93, 35.00); rows 26:33 static.",
                    block=R(25, 36), for_tr=["Z1", 145, 152]))
refit(n, fr(144, 153), 144.8, 152.4, "rest at f145 (after the cols rotation) and f152")
measure(n, fr(144, 153))
drop_undetermined("Z1", 145, 152)
c27 = n
m = moves[find("Z1", "rows", 160, 168)]
replace(m, [[[26], [32]], [[32], [33]], [[33], [26]]], R(25, 36),
        "the last-resort 26:29->30:33 | 30:33->26:29 is wrong: rows 27:31 sit at 26.98 27.98 28.98 29.99 30.99 on f162-164. Three "
        "rows move: mauve row 26 -> 32 (26.62 f161, 27.85 f162, 29.58 f163, 30.98 f164, 31.80 f165), mauve row 32 -> 33 (32.12, 32.30, "
        "32.60, 32.84, 32.96) and gold row 33 -> 26 (32.85 f160, 32.44 f161, 30.83 f162, 28.66 f163, 27.37 f164, 26.19 f165); on "
        "tones f166.", f1=166, for_tr=["Z1", 160, 166])
refit(m, fr(159, 167), 159.8, 166.3, "rest at f159-160 and f166")
measure(m, fr(159, 167))
note("27: ADDED Z1 rows 25->34 | 34->35 | 35->25 f145-152 (%.4f). 28: Z1 rows f160-168 REPLACED by 26->32 | 32->33 | 33->26 f160-166 (%.4f)."
     % (c27["mean"], m["mean"]))

# ====================================================================== 29. f178-198 X0 rows 13:24 -> 25:36 in two steps (FAULT D)
m = moves[find("X0", "rows", 178, 191)]
replace(m, [[[13], [30]], [[14], [33]], [[15], [35]], [[18], [36]], [[16, 19], [31, 34]]], R(13, 24),
        "FAULT D, step 1: the 8-part read (0.276) had every row moving; six rows stay (17, 20:24 at 17.03 20.05 21.01 21.98 22.98 "
        "23.97 on every frame f180-189) and six descend to 30,31,33,34,35,36. The mauve pair 16,19 -> 31,34 (16.78 19.54 f180, 17.95 "
        "20.63 f181, 24.33 27.17/27.66 f184, 29.85 32.54/33.02 f187, 30.99 34.00 f189) is rigid (+15); the gold rows 13,14,15,18 travel "
        "+17,+19,+20,+18 (22.10-22.59 24.80 25.81-26.42 27.73-28.15 at f184 = p 0.55; 28.43-29.05 31.29-31.71 33.63 34.31-34.80 at "
        "f187 = p 0.92; 29.67-30.16 32.69-33.18 34.70-35.31 35.70-36.32 at f189). The fill cannot tell 16,19->31,34 from 14,16->31,34, "
        "the outline colours can.", f1=189, for_tr=["X0", 178, 189], kind="relocation")
refit(m, fr(177, 191), 178.0, 190.0, "block on tones f176-178; the six rows land f189")
measure(m, fr(177, 191))
c29a = m
n = insert(new_move("X0", "rows", "relocation", 189, 197, [[[17], [27]], [[21], [32]], [[20, 22, 23], [26, 28, 29]]], X0C,
                    "FAULT D, step 2 (the UNDETERMINED relocation 17,20:24,30:31,33:36 -> 24,26:36): five rows descend into the gaps, "
                    "row 24 waits (23.97 on f190-197, it goes 24->25 in the next move). Mauve rows 20,22,23 -> 26,28,29 (19.85/20.33 "
                    "22.15 22.87/23.32 f190, 22.77 24.82 25.50 f193, 25.76 27.75 28.75 f196, 26.10 28.03 29.02 f197: +6 rigid) and gold "
                    "rows 17 -> 27 and 21 -> 32 (16.92/17.41 21.26 f190, 21.40-22.01 25.81-26.30 f193, 26.27/26.76 31.22-31.84 f196, "
                    "26.73/27.15 31.68/32.17 f197: +10 and +11).",
                    block=[17, 20, 21, 22, 23, 24, 30, 31, 33, 34, 35, 36], for_tr=["X0", 189, 197]))
refit(n, fr(188, 199), 189.0, 198.3, "after step 1; on tones at f198")
measure(n, fr(188, 199))
drop_undetermined("X0", 189, 197)
m48 = moves[find("X0", "rows", 199, 206)]
if m48["fa"] < n["fb"]:
    refit(m48, fr(197, 207), n["fb"], 206.5, "after step 2 (its own fit started f196.87, inside it)")
    m48["how"] += " | " + TAG + ": start clipped to f%.2f, after the second descent step." % m48["fa"]
    measure(m48, fr(197, 207))
note("29: FAULT D -- X0 rows f178-191 REPLACED by 13->30 | 14->33 | 15->35 | 18->36 | 16,19->31,34 f178-189 (%.4f); ADDED "
     "17->27 | 21->32 | 20,22,23->26,28,29 f189-197 (%.4f); 24->25 start clipped to f%.2f." % (c29a["mean"], n["mean"], m48["fa"]))

# ====================================================================== 29b. f216-239 Z rows: a phantom swap, a mistimed swap, a 3-part written as 2 groups
delete("Z0", "rows", 216, 224, "PHANTOM 3->2 | 2->3 fitted to f221.6-225.3, inside the written 1:5->8:12 | 6:12->1:7: Z0's rows sit on "
       "their tones f216-222 and then ALL of 1:12 rotate (probe_Z0_rows_214_248: 1.46 2.46 3.47 4.39 5.64..11.65 on f223)")
m = moves[find("Z1", "rows", 228, 233)]
replace(m, [[[21], [22]], [[22], [21]]], R(13, 24),
        "the read 21->20 | 20->21 (fitted to f230.4-235.1, the NEXT move's window) swaps the wrong pair: row 20 sits at 20.00 on f229-230 "
        "while rows 21 and 22 are at 21.18/21.79 (f229) and 21.15/21.86 (f230), on tones at f231; the outline classes cross between f229 "
        "and f230 (mauve 21.82 -> 21.13, gold 21.09 -> 21.90). It is 21<->22, the twin of Z0's written 9<->10 at f228-231.")
refit(m, fr(227, 232), 228.4, 231.2, "the swap is on f229-230; rest at f228 and f231")
measure(m, fr(227, 232))
m = moves[find("Z1", "rows", 235, 239)]
replace(m, [[[18, 20, 24], [17, 19, 23]], [[17, 19, 23], [18, 20, 24]]], R(13, 24),
        "the same map (three pair swaps 17<->18, 19<->20, 23<->24: mauve 18.00 20.01 23.99 -> 16.99 19.00 23.02, gold 17.05 19.00 22.97 "
        "-> 17.93 19.95 23.98 on f235-237) written as TWO rigid groups instead of three (18,20 and 24 share D = -1): one crossed pair less.")
measure(m, fr(234, 238))
note("29b: Z0 rows f216-224 3<->2 phantom DELETED; Z1 rows f228-233 20<->21 REPLACED by 21<->22 (row 20 is static; the twin of Z0's "
     "9<->10) and refitted to f228-231; Z1 rows f235-239 written as two groups.")

# ====================================================================== 30-32. f225-254 X0 on 25:36 (three undetermined windows)
n = insert(new_move("X0", "rows", "permutation", 225, 229, [[[27, 28, 31, 32], [28, 29, 32, 33]], [[29, 33], [27, 31]]], X0C,
                    "UNDETERMINED X0 rows f225-229: two 3-cycles on {27,28,29} and {31,32,33}: mauve rows 27,28,31,32 -> 28,29,32,33 "
                    "(26.81/27.27 28.11 31.17 32.15 f226; 27.40 28.35/28.82 31.37 32.56 f227; 27.99 28.94 31.93 32.75/33.23 f228) and "
                    "gold rows 29,33 -> 27,31 (28.51-29.13 32.53-33.15 f226; 27.84 31.79 f227; 26.89/27.30 30.83/31.32 f228); on tones "
                    "f229.", block=R(25, 36), for_tr=["X0", 225, 229]))
refit(n, fr(224, 230), 225.2, 229.3, "after the 28:29<->30:31 swap; rest at f229")
measure(n, fr(224, 230))
drop_undetermined("X0", 225, 229)
c30 = n
n = insert(new_move("X0", "rows", "permutation", 238, 241, [[[33], [34]], [[34], [33]]], X0C,
                    "UNDETERMINED X0 rows f238-241: rows 33 and 34 swap -- gold row 33 -> 34 (32.84-33.46 f239, 33.94 f240) and mauve "
                    "row 34 -> 33 (33.70-34.15 f239, 33.23 f240); fill 33.15 33.96 f239, 33.19 33.88 f240, on tones f241.",
                    block=R(25, 36), for_tr=["X0", 238, 241]))
refit(n, fr(237, 242), 238.2, 241.3, "after 36->32 | 32:35->33:36; the 25:31->30:36 rotation starts f240.8")
measure(n, fr(237, 242))
drop_undetermined("X0", 238, 241)
c31 = n
zc = moves[find("Z1", "cols", 249, 256)]
n = insert(new_move("X0", "cols", "permutation", 248, 254, [[R(1, 6), R(8, 13)], [R(7, 13), R(1, 7)]], R(25, 36),
                    "UNDETERMINED X0 cols f248-254 on rows 25:36 (the candidate copied Z's 1:7->7:13 | 8:13->1:6). X0 rotates by +7, "
                    "not +6: gold cols 1:6 -> 8:13 (1.79-5.43 f249, 5.65-10.99 f251, 7.59-13.03 f253) and mauve cols 7:13 -> 1:7 "
                    "(6.12..12.08 f249, 2.84..9.08 f251, 0.79..7.29 f253); on tones f254.", for_tr=["X0", 248, 254]))
set_time(n, zc["fa"], zc["fb"], "the same batch as the Z rotation")
measure(n, fr(247, 256))
drop_undetermined("X0", 248, 254)
note("30: ADDED X0 rows 27,28,31,32->28,29,32,33 | 29,33->27,31 f225-229 (%.4f). 31: ADDED X0 rows 33<->34 f238-241 (%.4f). "
     "32: ADDED X0 cols 1:6->8:13 | 7:13->1:7 f248-254 (%.4f)." % (c30["mean"], c31["mean"], n["mean"]))

# ====================================================================== 33. f249-256 Z0 rows: a phantom
delete("Z0", "rows", 249, 256, "PHANTOM 7->3 | 3:6->4:7 fitted to f253.8-255.6: Z0's rows sit on their tones on f252-254 and the "
       "whole 2:12 then starts the written 2:4->10:12 | 5:12->2:9 (probe_Z0_rows_252_264)")

# ====================================================================== 34-36. f254-272 X0 rows on 25:36: the three comb-less moves
m = moves[find("X0", "rows", 254, 263)]
replace(m, [[[27], [31]], [[31], [36]], [[36], [27]]], R(25, 36),
        "the 5-part 27->33 | 31->35 | 34->28 | 28->27 | 32,33,35->31,32,34 with an EMPTY comb is wrong; the block is on cols 1:13 and "
        "three rows move: mauve row 27 -> 31 (27.29 f255, 27.58 f256, 28.52 f257, 29.44 f258, 30.64 f259, 30.90 f260), mauve row 31 -> "
        "36 (31.37, 32.06, 33.46, 34.58, 35.19/35.63, 35.87) and gold row 36 -> 27 (35.08-35.70 f255, 33.77-34.26 f256, 31.84-32.45 "
        "f257, 29.73-30.21 f258, 27.97-28.39 f259, 26.97-27.46 f260); on tones f261.", f0=254, f1=261, for_tr=["X0", 254, 261],
        comb=X0C, joins=["X0"])
refit(m, fr(253, 262), 254.0, 260.9, "rest at f254 and f261")
measure(m, fr(253, 262))
c34 = m
m = moves[find("X0", "rows", 261, 269)]
replace(m, [[[28], [35]], [[33], [28]], [[35], [33]]], R(25, 36),
        "the 4-part 28->35 | 32->28 | 35->33 | 33->32 (EMPTY comb) moves row 32, which sits at 31.97-32.00 on every frame f261-267; "
        "gold row 28 -> 35 (28.12-28.74 f262, 29.21-29.82 f263, 31.26-31.60 f264, 33.04-33.46 f265, 34.58 f266, 34.70-35.31 f267), "
        "mauve row 33 -> 28 (32.69, 31.88, 30.64, 29.32, 28.44, 27.99) and mauve row 35 -> 33 (34.91, 34.65, ~34, 33.61, 33.22, 33.00).",
        f1=267, for_tr=["X0", 261, 267], comb=X0C, joins=["X0"])
refit(m, fr(260, 268), 260.9, 267.4, "between its neighbours")
measure(m, fr(260, 268))
c35 = m
m = moves[find("X0", "rows", 267, 274)]
replace(m, [[[25], [26]], [[26], [29]], [[30], [34]], [[29], [25]], [[32, 34], [30, 32]]], R(25, 36),
        "the 5-part 27->26 | 30->28 | 31->32 | 26,28,29->27,29,30 | 32->31 (EMPTY comb) is wrong: rows 27, 28, 31 sit at 27.08 28.01 "
        "30.97 on every frame f268-272. Gold rows 25 -> 26, 26 -> 29, 30 -> 34 (24.72-26.30 29.90-30.32 f268; 25.34-25.77 27.51-28.00 "
        "32.27 f270; 26.10 28.36-28.97 33.23-33.72 f271; 25.73-26.35 28.67-29.16 33.69-34.31 f272) and mauve rows 29 -> 25, 32,34 -> "
        "30,32 (28.52-29.13 31.90 33.92 f268; 26.44 30.83 32.83 f270; 25.46 30.26 32.22 f271; 25.00 30.03 31.97 f272).",
        f1=272, for_tr=["X0", 267, 272], comb=X0C, joins=["X0"])
refit(m, fr(266, 273), 267.3, 272.4, "between its neighbours; on tones f272-278")
measure(m, fr(266, 273))
note("34-36: X0 rows f254-274 REPLACED by 27->31 | 31->36 | 36->27 f254-261 (%.4f), 28->35 | 33->28 | 35->33 f261-267 (%.4f) and "
     "25->26 | 26->29 | 30->34 | 29->25 | 32,34->30,32 f267-272 (%.4f), all on comb 1:13." % (c34["mean"], c35["mean"], m["mean"]))

# ====================================================================== 37-38. f280-291 the Z relocation 1:13 -> 14:26 and Z0's phantom rows swap
m = moves[find("Z1", "cols", 281, 291)]
replace(m, [[R(1, 10), R(17, 26)], [R(11, 13), R(14, 16)]], None,
        "the 5-part 6->21 | 11:13->14:16 | 1:4->17:20 | 5->22 | 7:10->23:26 swaps cols 5 and 6; the pixels show cols 1:10 travelling "
        "together +16 (1.95..9.92 f281, 8.17..17.19 f284 with 5,6 merged into 11:13's 12.3-14.3, 16.49..24.50 f287, 16.56..25.60 f288, "
        "17.00..26.07 f289) and 11:13 -> 14:16 (11.15-13.16 f281, 12.33-14.33 f284, 13.70-15.71 f287, 14.01-16.01 f289). Both Z "
        "blocks (rows 1:24) on one rectangle.", kind="relocation")
measure(m, fr(279, 292))
c37 = m
delete("Z0", "rows", 281, 291, "PHANTOM 6->7 | 7->6 with an EMPTY comb fitted to f285.8-288.5: Z0's rows sit on their tones on "
       "every frame f281-293 (probe_Z0_rows_279_298)")
note("37: Z1+Z0 cols f281-291 map REPLACED by 1:10->17:26 | 11:13->14:16 (%.4f). 38: Z0 rows f281-291 phantom DELETED." % c37["mean"])

# ====================================================================== 39-40. f289-298 the Z row exchanges (Z1 then Z0)
EXZ1 = [[[13, 22], [15, 24]], [[14, 16, 17, 19], [18, 20, 21, 23]], [[15, 24], [13, 22]], [[18, 20, 21, 23], [14, 16, 17, 19]]]
EXZ0 = [[[1, 10], [3, 12]], [[2, 4, 5, 7], [6, 8, 9, 11]], [[3, 12], [1, 10]], [[6, 8, 9, 11], [2, 4, 5, 7]]]
delete("Z1", "rows", 289, 296, "the 8-part read (0.104, 'suspect') describes the same frames as the 'relocation' 18,24->13,19 | ... "
       "of the same block; both are replaced by one 4-group exchange")
m = moves[find("Z1", "rows", 281, 291)]
replace(m, EXZ1, R(13, 24),
        "Z1's rows exchange in four rigid groups after the columns land (f289): the dark-green class rows 13,14,16,17,19,22 go DOWN "
        "(13.13 14.20 16.26 17.40 19.41 22.24 f290; 14.36 16.64 18.60 19.80 21.71 23.30 f292; 14.74 17.82 19.61 20.70 22.62 23.83 "
        "f293) to 15,18,20,21,23,24 = +2 for 13,22 and +4 for 14,16,17,19; the light-green class rows 15,18,20,21,23,24 go UP "
        "(14.77 17.82 19.87 20.74 22.76 23.83 f290; 13.59 15.25 17.16 18.14 20.37 22.59 f292; 13.17 14.24 16.26 17.38 19.14 22.05 "
        "f293) to 13,14,16,17,19,22. On tones at f294.", f0=289, f1=294, for_tr=["Z1", 289, 294], kind="permutation", comb=R(14, 26))
refit(m, fr(288, 295), 289.4, 294.3, "after the cols relocation; rest at f294")
measure(m, fr(288, 295))
c39 = m
n = insert(new_move("Z0", "rows", "permutation", 294, 298, EXZ0, R(14, 26),
                    "UNDETERMINED Z0 rows f294-298: the same four-group exchange as Z1's, four frames later. Gold class rows 1,2,4,5,7,10 "
                    "go down (1.18 2.25 4.35 5.37 7.36 10.17 f295; 1.74 3.43 5.42 6.48 8.49 10.75 f296; 2.42 4.72 6.89 7.92 9.90 11.45 "
                    "f297) to 3,6,8,9,11,12; mauve rows 3,6,8,9,11,12 go up (2.84 5.80 7.77 8.61 10.74 11.77 f295; 2.43 4.55 7.31 9.53 "
                    "11.36 f296; 1.53 3.20 5.05 6.06 8.28 10.62 f297) to 1,2,4,5,7,10; on tones at the f298 pulse.",
                    for_tr=["Z0", 294, 298]))
refit(n, fr(293, 299), 293.8, 298.0, "rest at f294; pulse at f298")
measure(n, fr(293, 299))
drop_undetermined("Z0", 294, 298)
note("39: Z1 rows f289-296 (8-part) DELETED and the f281-291 'relocation' REPLACED by 13,22->15,24 | 14,16,17,19->18,20,21,23 | "
     "15,24->13,22 | 18,20,21,23->14,16,17,19 f289-294 (%.4f). 40: ADDED Z0 rows 1,10->3,12 | 2,4,5,7->6,8,9,11 | 3,12->1,10 | "
     "6,8,9,11->2,4,5,7 f294-298 (%.4f)." % (c39["mean"], n["mean"]))

# ====================================================================== 41. f300-309 Z0 rows: a phantom
delete("Z0", "rows", 300, 309, "PHANTOM 6->10 | 7:10->6:9 fitted to f307.2-309.1: rows 6, 7 sit at 6.00 7.01 on every frame f300-310; "
       "what moves there is the written 8:9<->10:11")

# ====================================================================== 42-45. f307-326 X1 rows on 25:36: X1 repeats X0's three moves
m = moves[find("X1", "rows", 307, 316)]
replace(m, [[[27], [31]], [[31], [36]], [[36], [27]]], R(25, 36),
        "the last-resort 27:31->32:36 | 32:36->27:31 with an EMPTY comb is wrong (rows 28:30, 32:35 static at 28.01 28.94 29.98 32.01 "
        "33.03 34.12 35.00). X1 on cols 1:13 repeats X0's f254-261 cycle: mauve row 27 -> 31 (27.20 f308, 27.49 f309, 28.67 f310, 29.51 "
        "f311, 30.37 f312, 30.81 f313, 30.97 f314), mauve row 31 -> 36 (31.31, 31.60, 32.61, 34.15, 35.15, 35.78, 36.01) and gold row "
        "36 -> 27 (35.28-35.73 f308, 34.15-34.65 f309, 32.46 f310, 30.02-30.46 f311, 28.63 f312, 27.32 f313, 26.73-27.18 f314).",
        f1=314, for_tr=["X1", 307, 314], comb=X0C, joins=["X1"])
refit(m, fr(306, 315), 307.0, 314.4, "rest at f305-307 and f314")
measure(m, fr(306, 315))
c42 = m
m = moves[find("Z1", "rows", 310, 316)]
replace(m, [[[13, 18], [15, 20]], [[14, 15, 19, 20], [13, 14, 18, 19]]], R(13, 24),
        "the S2.1 read 13:15->18:20 | 16:20->13:17 (rotation of 13:20 by 5) is wrong: rows 16, 17, 21:24 sit at 15.99 16.99 21.00..24.01 "
        "on f311-313. Two 3-cycles, the twin of X0's f162-165: gold rows 13 -> 15 and 18 -> 20 (13.20 18.22 f311, 13.89 19.04 f312, "
        "14.89 19.80 f313) and mauve rows 14,15 -> 13,14 and 19,20 -> 18,19 (14.50 19.43 f311, 13.39 14.47 18.38 19.63 f312, 13.09 "
        "14.01 18.48 f313); on tones f314.", f1=314, for_tr=["Z1", 310, 314])
refit(m, fr(309, 315), 310.3, 314.3, "after the 20:21<->22:23 swap; rest at f314")
measure(m, fr(309, 315))
c43 = m
m = moves[find("X1", "rows", 314, 323)]
replace(m, [[[28], [35]], [[33], [28]], [[35], [33]]], R(25, 36),
        "the read 28->31 | 29:31->28:30 with an EMPTY comb is wrong (rows 29:32 static at 28.94 29.98 30.98 32.01); X1 repeats X0's "
        "f261-267 cycle: gold row 28 -> 35 (28.26 f315, 28.94-29.38 f316, 30.52 f317, 32.53-32.97 f318, 33.92-34.36 f319, 34.62-35.05 "
        "f320), mauve row 33 -> 28 (32.82, 32.16, 30.97, 29.58, 28.60, 27.87/28.36) and mauve row 35 -> 33 (34.91, 34.75, 34.54, "
        "33.43, 33.23, 33.09); on tones f321.", f1=321, for_tr=["X1", 314, 321], comb=X0C, joins=["X1"])
refit(m, fr(313, 322), 314.3, 321.3, "between its neighbours")
measure(m, fr(313, 322))
c44 = m
n = insert(new_move("X1", "rows", "permutation", 321, 326, [[[25], [26]], [[26], [29]], [[30], [34]], [[29], [25]], [[32, 34], [30, 32]]],
                    X0C, "UNDETERMINED X1 rows f321-326: X1 repeats X0's f267-272 move. Gold rows 25 -> 26, 26 -> 29, 30 -> 34 "
                    "(25.11-26.22 29.77-30.24 f321; 25.56 27.53 31.81-32.24 f323; 25.57-26.07 28.63 33.11-33.54 f324; 25.73-26.15 "
                    "28.69-29.13 33.69-34.11 f325) and mauve rows 29 -> 25, 32,34 -> 30,32 (28.94 31.92 34.01 f321; 26.62 31.04 32.99 "
                    "f323; 25.38 30.37 32.37 f324; 24.73-25.21 30.05 32.05 f325); rows 27, 28, 31 static; on tones f326.",
                    block=R(25, 36), for_tr=["X1", 321, 326]))
refit(n, fr(320, 327), 321.2, 326.4, "rest at f321 and f326")
measure(n, fr(320, 327))
drop_undetermined("X1", 321, 326)
note("42: X1 rows f307-316 REPLACED by 27->31 | 31->36 | 36->27 f307-314 (%.4f). 43: Z1 rows f310-316 REPLACED by 13,18->15,20 | "
     "14:15,19:20->13:14,18:19 f310-314 (%.4f). 44: X1 rows f314-323 REPLACED by 28->35 | 33->28 | 35->33 f314-321 (%.4f). 45: ADDED "
     "X1 rows 25->26 | 26->29 | 30->34 | 29->25 | 32,34->30,32 f321-326 (%.4f)." % (c42["mean"], c43["mean"], c44["mean"], n["mean"]))

# ====================================================================== 46. f334-340 Z1 (undetermined) and Z0 cols: the opposite rotation to X1's
x1c = moves[find("X1", "cols", 334, 342)]
n = insert(new_move("Z1", "cols", "permutation", 333, 340, [[R(14, 18), R(22, 26)], [R(19, 26), R(14, 21)]], R(1, 24),
                    "UNDETERMINED Z1 cols f333-340 (Z0's twin was never listed): both Z blocks rotate by -5, the OPPOSITE way to X1's "
                    "written 1:8->6:13 | 9:13->1:5. Gold cols 14:18 -> 22:26 (14.41-18.43 f334, 19.56-23.52 f337, 21.86-25.83 f339) and "
                    "mauve/green cols 19:26 -> 14:21 (19.88-25.72 f334, 15.51-18.53 f337, 14.08-21.04 f339); Z0 identical (14.43-18.40 "
                    "f334 -> 23.85 f339; 18.87-25.72 -> 14.08-21.04). One rectangle over rows 1:24.",
                    joins=["Z1", "Z0"], for_tr=["Z1", 333, 340]))
set_time(n, x1c["fa"], x1c["fb"], "the same batch as X1's rotation")
measure(n, fr(332, 342))
drop_undetermined("Z1", 333, 340)
note("46: ADDED Z1+Z0 cols 14:18->22:26 | 19:26->14:21 f333-340 (verified %.4f Z1, %s Z0)." % (n["mean"], n["detail"].get("Z0")))

# ====================================================================== 47-49. f340-349 the row exchanges on all three blocks
m = moves[find("Z0", "rows", 334, 342)]
replace(m, EXZ0, R(1, 12),
        "the 8-part 4->1 | 8->4 | 9:10->6:7 | 11->10 | 1:2->2:3 | 3->5 | 5:6->8:9 | 7->11 fitted to f339.9-341.5 is wrong; Z0's rows sit "
        "on their tones f334-339 and then do the same four-group exchange as at f294-298: gold rows 1,2,4,5,7,10 down (1.28 2.56 4.56 "
        "5.59 7.60 10.26 f341; 1.87 3.83 6.26 8.77 10.82 f342; 2.56 5.13 7.16 8.22 10.11 11.58 f343; 2.97 5.94 7.92 8.88 10.89 11.92 "
        "f344), mauve rows 3,6,8,9,11,12 up (2.91 5.26 7.23 8.45 10.60 11.70 f341; 1.37 3.01 4.65 5.92 7.72 10.58 f343; 1.02 2.10 4.13 "
        "5.09 7.05 10.04 f344); on tones f345.", f0=340, f1=345, for_tr=["Z0", 340, 345])
refit(m, fr(339, 346), 339.8, 345.3, "after the cols rotation; rest at f345")
measure(m, fr(339, 346))
drop_undetermined("Z0", 340, 345)
c47 = m
n = insert(new_move("X1", "rows", "permutation", 340, 345, [[[25, 33], [28, 36]], [[26, 27, 29, 30], [31, 32, 34, 35]],
                                                              [[28, 36], [25, 33]], [[31, 32, 34, 35], [26, 27, 29, 30]]], X0C,
                    "UNDETERMINED X1 rows f340-345 (the candidate pairwise swap read 0.128): the X version of the Z exchanges, +3/+5 "
                    "and -3/-5. Gold rows 25,26,27,29,30,33 go down (25.09-27.28 29.31-30.74 f341; 26.90 29.21-30.72 32.17-33.65 "
                    "34.82-35.27 f343; 27.98 30.29-31.74 33.79-35.91 f344; 27.74-28.16 30.72-32.17 33.71-36.16 f345) to 28,31,32,34,35,36; "
                    "mauve rows 28,31,32,34,35,36 go up (27.65 30.13 31.47 33.49 34.48 35.62 f341; 25.97 27.51 28.56 31.51 34.09 f343; "
                    "25.28 26.46 27.47 29.43 30.12 33.26 f344; 25.08 26.05 27.04 29.05 30.05 33.01 f345).",
                    for_tr=["X1", 340, 345]))
refit(n, fr(339, 346), 339.8, 345.3, "after the cols rotation; rest at f345")
measure(n, fr(339, 346))
drop_undeterm = drop_undetermined("X1", 340, 345)
c48 = n
n = insert(new_move("Z1", "rows", "permutation", 345, 349, EXZ1, R(14, 26),
                    "UNDETERMINED Z1 rows f345-349 (the candidate 13:18<->19:24 read 0.21): the same exchange Z1 did at f289-294, "
                    "finishing at the f349 pulse. Gold rows 13,14,16,17,19,22 down (13.34 14.71 16.66 17.73 19.66 22.35 f346 = p 0.17 "
                    "for +2/+4; 14.67 17.32 19.81 22.32 23.66 f348), mauve rows 15,18,20,21,23,24 up (14.34 17.26 19.15 20.36 22.00 "
                    "23.64 f346; 13.32 16.56 17.82 19.76 f348); on tones at f349.", for_tr=["Z1", 345, 349]))
refit(n, fr(344, 350), 344.8, 349.0, "rest at f343-345; pulse at f349")
measure(n, fr(344, 350))
drop_undetermined("Z1", 345, 349)
note("47: Z0 rows f334-342 REPLACED by the exchange 1,10->3,12 | 2,4,5,7->6,8,9,11 | 3,12->1,10 | 6,8,9,11->2,4,5,7 f340-345 (%.4f). "
     "48: ADDED X1 rows 25,33->28,36 | 26,27,29,30->31,32,34,35 | 28,36->25,33 | 31,32,34,35->26,27,29,30 f340-345 (%.4f). 49: ADDED Z1 "
     "rows 13,22->15,24 | 14,16,17,19->18,20,21,23 | 15,24->13,22 | 18,20,21,23->14,16,17,19 f345-349 (%.4f)." % (c47["mean"], c48["mean"], n["mean"]))

# ====================================================================== 50. f361-373 Z0 rows 1:12 -> 25:36 (FAULT B)
z1r = moves[find("Z1", "rows", 362, 375)]
n = insert(new_move("Z0", "rows", "relocation", 350, 373, [[R(1, 12), R(25, 36)]], X0C,
                    "FAULT B: the rows half of Z0's return to its seed was missing (the appearance read produced two atoms per site and "
                    "was rejected). After the cols land on 1:13 (f361) all twelve rows descend +24 together: 1.15..12.18 f362, 3.39..14.52 "
                    "f364, 8.64..19.50 f366, 15.91..26.89 f368, 21.55..32.60 f370, 24.62..35.47 f372, 24.97..36.00 f373 -- twelve peaks "
                    "one row apart on every frame. Z1's written 13:24->25:36 (+12) is the same batch.", for_tr=["Z0", 350, 373]))
refit(n, fr(360, 375), 360.5, 374.6, "after the cols land on 1:13 (f361); on 25:36 at f373 (Z1's twin is fitted f360.81-373.63)")
measure(n, fr(360, 375))
note("50: FAULT B -- ADDED Z0 rows 1:12->25:36 f361-373 (verified %.4f, free %s; Z1's twin runs f%.2f-%.2f)." % (n["mean"], n["free_err"], z1r["fa"], z1r["fb"]))

# ====================================================================== 51-52. f373-383 Z0 rows on 25:36
n = insert(new_move("Z0", "rows", "permutation", 373, 379, [[[25], [28]], [[29], [34]], [[27], [25]], [[28, 34], [27, 33]], [[33], [29]]],
                    X0C, "UNDETERMINED Z0 rows f373-379 (the candidate 25:29<->30:34 read 0.104): six rows move in five rigid groups. "
                    "Gold rows 25 -> 28 and 29 -> 34 (25.19 29.15 f374, 25.46 30.29 f375, 26.71 31.59 f376, 27.67 ~33 f377, 27.93 33.88 "
                    "f378) and mauve rows 27 -> 25, 28,34 -> 27,33, 33 -> 29 (26.93 27.93 32.81 33.97 f374; 26.50 27.78 32.10 33.82 f375; "
                    "25.89 27.47 30.84 33.41 f376; 25.30 27.14 29.64 33.17 f377; 25.07 27.00 29.13 32.99 f378); rows 26, 30:32, 35, 36 "
                    "static; on tones f379.", block=R(25, 36), for_tr=["Z0", 373, 379]))
refit(n, fr(372, 380), 373.3, 379.4, "rest at f373 (after the descent) and f379")
measure(n, fr(372, 380))
drop_undetermined("Z0", 373, 379)
c51 = n
m = moves[find("Z0", "rows", 379, 382)]
replace(m, [[[26], [31]], [[30], [26]], [[31], [30]]], R(25, 36),
        "the last-resort 26:28->29:31 | 29:31->26:28 is wrong: rows 27, 28, 29 sit at 26.98 27.98 28.98 on f380-382. A 3-cycle: gold "
        "row 26 -> 31 (26.51 f380, 27.85 f381, 29.62 f382), mauve row 30 -> 26 (29.56, 28.32, 27.08) and mauve row 31 -> 30 (30.87, "
        "30.60, 30.30); on tones at the f383 pulse.", f1=383, for_tr=["Z0", 379, 383])
refit(m, fr(378, 383), 379.4, 383.0, "after the f373-379 move; pulse at f383")
measure(m, fr(378, 383))
note("51: ADDED Z0 rows 25->28 | 29->34 | 27->25 | 28,34->27,33 | 33->29 f373-379 (%.4f). 52: Z0 rows f379-382 REPLACED by 26->31 | "
     "30->26 | 31->30 (%.4f)." % (c51["mean"], m["mean"]))

# ====================================================================== 53. timing hygiene (session 30's item 32): a move ends before the next move of the same block starts
print("\n53. overlaps under 1.5 frames between consecutive moves of one block are split at their midpoint")


def mean_at(m, fa, fb):
    frames = fr(int(min(fa, m["fa"])) - 1, int(max(fb, m["fb"])) + 2)
    PP = sub_peaks(m, frames)
    mean, worst, n_ = sb_compose.verify(PP, m["sp"], AX[m["axis"]], m["src"], m["dst"], fa, fb, frames, M)
    return mean


def remeasure(m):
    frames = fr(int(m["fa"]) - 1, int(m["fb"]) + 2)
    PP = sub_peaks(m, frames)
    axis = AX[m["axis"]]
    mean, worst, n_ = sb_compose.verify(PP, m["sp"], axis, m["src"], m["dst"], m["fa"], m["fb"], frames, M)
    seq = sb_compose.progress_per_frame(PP, m["sp"], axis, m["src"], m["dst"], frames, M)
    free = [s[2] for s in seq if 0.02 < s[1] < 0.98]
    old = m["mean"]
    m["mean"], m["worst"] = round(mean, 4), round(worst, 3)
    m["free_err"] = round(sum(free) / len(free), 4) if free else None
    m["ok"] = bool(m["mean"] <= 0.10)
    print("    re-measured %s: mean %.4f (was %s), free %s" % (label(m), mean, old, m["free_err"]))


# The boundary between two overlapping fits is not necessarily their midpoint: a fast 15-row descent is far more
# sensitive to a 0.4-frame shift than the flat easing tail of the column rotation before it.  So the boundary is
# chosen by MEASUREMENT among the three natural candidates (the earlier fit's end, the later fit's start, their
# midpoint): the one with the smallest sum of the two moves' residuals wins.
clipped = 0
for sp in M.species:
    seq_ = sorted([m for m in moves if sp in m["joins"]], key=lambda m: m["fa"])
    for a, b in zip(seq_, seq_[1:]):
        if b["fa"] < a["fb"] - 1e-6:
            if a["fb"] - b["fa"] >= 1.5:
                print("  !! %s: %s (f%.2f-%.2f) and %s (f%.2f-%.2f) overlap by %.2f frames -- left as they are, CHECK"
                      % (sp, label(a), a["fa"], a["fb"], label(b), b["fa"], b["fb"], a["fb"] - b["fa"]))
                continue
            own_a, own_b = a["fb"], b["fa"]
            cands = sorted({round(own_b, 2), round(own_a, 2), round((own_a + own_b) / 2, 2)})
            scored = [(mean_at(a, a["fa"], bd) + mean_at(b, bd, b["fb"]), bd) for bd in cands]
            best, bd = min(scored)
            print("  %s: %s ends f%.2f, %s starts f%.2f -> boundary f%.2f (candidates %s)"
                  % (sp, label(a), own_a, label(b), own_b, bd, ", ".join("f%.2f: %.3f" % (c, s) for s, c in scored)))
            set_time(a, a["fa"], bd, "end moved to the boundary with the block's next move")
            set_time(b, bd, b["fb"], "start moved to the boundary with the block's previous move")
            a["how"] += " | " + TAG + ": end moved from f%.2f to f%.2f, the boundary with the block's next move (chosen by measurement)." % (own_a, bd)
            b["how"] += " | " + TAG + ": start moved from f%.2f to f%.2f, the boundary with the block's previous move (chosen by measurement)." % (own_b, bd)
            remeasure(a); remeasure(b)
            clipped += 1
print("\n54. twin moves of different blocks in one batch share one window (the AOM count otherwise reads a fit tail as a fifth pair)")
TWINS = [(("X1", "cols", 1, 8), ("X0", "cols", 2, 10)), (("X1", "cols", 71, 77), ("X0", "cols", 72, 79)),
         (("Z0", "cols", 70, 79), ("Z1", "cols", 70, 79)), (("X0", "cols", 138, 145), ("X1", "cols", 139, 147)),
         (("Z1", "cols", 333, 340), ("X1", "cols", 334, 342))]
for ka, kb in TWINS:
    a, b = moves[find(*ka)], moves[find(*kb)]
    fa, fb = max(a["fa"], b["fa"]), min(a["fb"], b["fb"])
    for m in (a, b):
        if abs(m["fa"] - fa) > 1e-6 or abs(m["fb"] - fb) > 1e-6:
            own = "f%.2f-%.2f" % (m["fa"], m["fb"])
            set_time(m, fa, fb, "synchronised with its twin %s" % label(b if m is a else a))
            m["how"] += " | " + TAG + ": window synchronised with its twin in the same batch (own %s)." % own
            remeasure(m)
# (X1's descent fit starts f86.2, half a frame before X0's lands at f86.9; forcing it to f86.91 costs 0.12 site, so the
#  pixels are believed: two different blocks may move at once, and the AOM count reads 6 for that half frame.)
for k in (("X0", "cols", 216, 224), ("Z1", "cols", 216, 224)):
    m = moves[find(*k)]
    if m["fa"] < 214.56:
        own = m["fa"]
        set_time(m, 214.56, m["fb"], "the Z carry-in of extra.json ends f214.55 inside the pulse run; the rotation's fit began at the gate f214.0 and its easing is flat there")
        m["how"] += " | " + TAG + ": start moved from f%.2f to f214.56, after the Z carry-in (flat easing, no measurable change)." % own
        remeasure(m)
_rows = sb_compose.schedule_rows(moves)
_ng, _peak = sb_compose.allocate_aom(_rows)
print("  items 53-54: %d move ends clipped; AOM groups %d, peak %d" % (clipped, _ng, _peak))
note("53-54: timing hygiene -- %d move ends clipped to the next move of the block (boundary chosen by measurement), twin moves of one batch "
     "synchronised, the f216 rotations start after the Z carry-in; AOM groups %d, peak %d (the peak is the half frame f86.2-86.9 where "
     "X1's descent begins before X0's has landed -- two blocks, and the pixels place X1's start there)." % (clipped, _ng, _peak))

# ====================================================================== save + re-emit
mv["notes"] = list(mv.get("notes", [])) + notes
rows = sb_compose.schedule_rows(moves)
ng, peak = sb_compose.allocate_aom(rows)
mv["aom_groups"], mv["aom_peak"] = ng, peak
json.dump(mv, open("moves_full.json", "w", encoding="utf-8"), indent=1, default=str)
json.dump(rests, open("rests_full.json", "w", encoding="utf-8"), indent=1)
print("\nwrote moves_full.json (%d moves, %d undetermined left, AOM groups %d peak %d) and rests_full.json"
      % (len(moves), len(mv["undetermined"]), ng, peak))
print("left UNDETERMINED:", [(u["sp"], u["f0"], u["f1"]) for u in mv["undetermined"]])
over = [m for m in moves if m.get("mean") is not None and m["mean"] > 0.10]
print("moves over 0.10:", len(over))
for m in over:
    print("   %s  mean %.4f free %s" % (label(m), m["mean"], m.get("free_err")))

sb_emit.emit(OUT_XLSX, M, mv, rests, runs, P, 0, M.nf - 1, extra="extra.json",
             scope_note="the WHOLE movie: frames 0-%d, t = 0 .. %.4f ms, all %d pulse runs; the automatic "
                        "se-cycle-blocks book (run_c780, session 28) + the session-31 hand corrections listed in "
                        "Notes (53 items read from the pixels, applied 2026-09-17 on the user's one-time instruction)"
                        % (M.nf - 1, (M.nf - 1) * M.dt, len(runs)))
print("wrote", OUT_XLSX)
