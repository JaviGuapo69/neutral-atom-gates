"""sb_blocks.py -- each species' BLOCK SIZE, measured over the whole movie.  Run this first.

Rule 22.  A block is one rigid size throughout (rule 1), so any view of it can only ever show
FEWER markers than it has -- clipped at the panel edge, or two peaks merged mid-crossing -- never
more.  The largest count observed is therefore the size, and it has to be taken over the WHOLE
movie, because a block can sit off panel for an entire pulse-free interval.

Getting this wrong does not produce an error, it produces a silently incomplete sheet.  Measured
per window with a mode, c150's X0 reads 1 column on 44 frames against 6 on 25, so `rect_at` has no
width with which to complete the clipped rectangle, the parked configuration is never recognised as
a rest, and BOTH of c150's parking slides are never enumerated as transitions at all.  The blocks
then stay on screen in the rebuild while the movie parks them off it, and nothing in the render, the
census or the score says so.

    python sb_blocks.py --calib calib.json --out blocks.json
"""
import argparse, json, os, sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sb_read import Movie

TOL = 0.12              # site: on-tone tolerance; mid-move counts are merged and must be excluded


def measure(M, step=2, verbose=True):
    vc, vr = M.K["visible_col"], M.K["visible_row"]
    win = (vc[0] - 0.45, vc[1] + 0.45, vr[0] - 0.45, vr[1] + 0.45)
    out = {}
    for nm in M.species:
        cx, cy = Counter(), Counter()
        for f in range(0, M.nf, step):
            if f in M.gate:
                continue                    # the pulse tint moves every fill ~40 RGB
            xs = M.peaks(M.fill[nm], win, f, 0)
            ys = M.peaks(M.fill[nm], win, f, 1)
            if not xs or not ys:
                continue
            if not (all(abs(v - round(v)) <= TOL for v in xs) and
                    all(abs(v - round(v)) <= TOL for v in ys)):
                continue                    # only at-rest frames: mid-move peaks are merged
            cx[len(xs)] += 1
            cy[len(ys)] += 1
        if not cx:
            if verbose:
                print("%-3s  never on grid in this movie -- no block size" % nm)
            continue
        # "at least two frames" keeps one noisy frame from inflating it
        w = max([k for k, n in cx.items() if n >= 2] or [max(cx)])
        h = max([k for k, n in cy.items() if n >= 2] or [max(cy)])
        out[nm] = [w, h]
        if verbose:
            print("%-3s  block %dx%d      x counts %s      y counts %s"
                  % (nm, w, h, dict(sorted(cx.items())), dict(sorted(cy.items()))))
            if len(cx) > 1 or len(cy) > 1:
                print("     (more than one count seen -- the smaller ones are the frames where the "
                      "block is clipped or crossing; that is expected, and is why the LARGEST is "
                      "the size)")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--step", type=int, default=2, help="sample every Nth frame")
    ap.add_argument("--out", default="blocks.json")
    a = ap.parse_args()
    M = Movie(a.calib, a.frames)
    out = measure(M, a.step)
    json.dump(out, open(a.out, "w"), indent=1)
    print("\nwrote %s: %s" % (a.out, out))
    print("Pass this to sb_build.py / sb_full.py with --blocks.")


if __name__ == "__main__":
    main()
