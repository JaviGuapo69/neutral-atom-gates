<#
deliver_2aod.ps1 -- render, score, sb_watch and the two side-by-side videos, for any 2-AOD run.

The same chain as run_c780_s31\deliver_s31.ps1, parameterised so one copy serves all eight
movies.  Run it from the 2aod directory, detached, and poll the log:

    Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-Command',
      "Set-Location '<abs>\2aod'; .\deliver_2aod.ps1 -Run run_c150_2aod -Xlsx c150_2aod_s33_blocks.xlsx -Tag c150_2aod_s33 *> run_c150_2aod\deliver.log" -WindowStyle Hidden

-Run      the run directory (holds calib.json and the workbook)
-Xlsx     the workbook to render, relative to -Run
-Tag      goes into the score / watch / video file names
-RDir     the rendered frames directory inside -Run (default rframes)
#>
param(
  [Parameter(Mandatory=$true)][string]$Run,
  [Parameter(Mandatory=$true)][string]$Xlsx,
  [Parameter(Mandatory=$true)][string]$Tag,
  [string]$RDir = "rframes",
  [switch]$SkipVideo
)

$ErrorActionPreference = "Continue"
$TWO  = $PSScriptRoot                       # ...\2aod
$ROOT = Split-Path $TWO                     # the project root
$SB   = Join-Path $ROOT ".claude\skills\se-cycle-blocks\tools"
$SE   = Join-Path $ROOT ".claude\skills\se-cycle-movies\tools"
$env:Path += ";C:\Users\HP\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.1-full_build\bin"
$env:PYTHONIOENCODING = "utf-8"

$D = Join-Path $TWO $Run
Set-Location $D

function Step($name, $block) {
  Write-Output ""
  Write-Output ("=" * 78)
  Write-Output "== $name   $(Get-Date -Format HH:mm:ss)"
  Write-Output ("=" * 78)
  & $block
}

Step "1. se_calibtxt -- the render calibration that matches the movie" {
  python "$SE\se_calibtxt.py" --calib calib.json --out-txt movie_calib.txt `
         --out-json render_calib.json --render-frames "$D\$RDir" --tone-divisor 1
}

Step "2. render.ps1 -- the workbook back to frames" {
  & "$SE\render.ps1" -Xlsx $Xlsx -OutDir "$D\$RDir" `
    -LogCsv "$D\render_log_$Tag.csv" -MatchCalib "$D\movie_calib.txt"
  $n = (Get-ChildItem "$D\$RDir" -Filter "p_*.png" -ErrorAction SilentlyContinue).Count
  $v = (Get-Content "$D\render_log_$Tag.csv" -ErrorAction SilentlyContinue | Measure-Object -Line).Lines
  Write-Output "rendered $n frames; validation log lines (incl. header): $v"
}

Step "3. sb_score -- the profile score against the movie" {
  python "$SB\sb_score.py" --movie-calib calib.json --render-calib render_calib.json `
         --out "score_$Tag.txt" | Select-Object -Last 20
}

Step "3b. sb_watch -- every (frame, species, axis) cell, local runs" {
  python "$SB\sb_watch.py" --movie-calib calib.json --render-calib render_calib.json `
         --thresh 0.35 --min-run 3 > "watch_$Tag.txt"
  Get-Content "watch_$Tag.txt" | Select-Object -Last 12
}

if ($SkipVideo) { Write-Output "`n-SkipVideo: stopping before the mp4s"; exit 0 }

Step "4. sb_video -- the side-by-side comparison videos" {
  # the video shows the movie AS IT IS. Where depaint_legend.py has removed a legend drawn inside
  # the panel, frames\ is the cleaned copy the masks and the score must use and frames_raw\ is the
  # untouched movie -- so the comparison the user watches is against the real thing.
  $MF = if (Test-Path "$D\frames_raw") { "$D\frames_raw" } else { "$D\frames" }
  Write-Output "movie frames: $MF"
  & "$SB\sb_video.ps1" -MovieFrames $MF -RenderFrames "$D\$RDir" `
    -Calib "$D\calib.json" `
    -OutPanels "$D\${Tag}_original_vs_rebuild_panels.mp4" `
    -OutFull   "$D\${Tag}_original_vs_rebuild_full.mp4"
}
Write-Output "DONE $(Get-Date -Format HH:mm:ss)"
