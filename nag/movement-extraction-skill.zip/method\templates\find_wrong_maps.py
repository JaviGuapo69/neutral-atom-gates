"""STEP 1 OF THE HUNT -- narrow sb_watch's runs down to the moves that could be hiding a wrong map.

A same-site permutation (a block rearranging its atoms inside its own rectangle) is invisible to
sb_audit, se_sim, the render validation and sb_score.  The ONLY numerical evidence for a wrong one
is a local sb_watch disagreement run inside that move's own frame window, on its own species and
axis.  This lists every such coincidence, worst first, so you probe ten candidates instead of a
hundred moves.

    python find_wrong_maps.py watch.txt moves_full.json

Then feed the shortlist to `score_maps.py`, which decides each one against the pixels.

A hit is NOT a defect by itself -- a crossing, an occlusion or a block leaving the panel can put a
run inside a move's window too.  It is a shortlist, not a verdict.
"""
import json, re, sys

watch = sys.argv[1] if len(sys.argv) > 1 else 'watch.txt'
movesf = sys.argv[2] if len(sys.argv) > 2 else 'moves_full.json'


def read_text(path):
    """PowerShell 5.1's `>` redirect writes UTF-16LE. Reading that as UTF-8 yields silent
    garbage and an empty result -- a FALSE ALL-CLEAR -- rather than an error. Sniff the BOM."""
    raw = open(path, 'rb').read()
    for bom, enc in ((b'\xff\xfe\x00\x00', 'utf-32-le'), (b'\xff\xfe', 'utf-16-le'),
                     (b'\xfe\xff', 'utf-16-be'), (b'\xef\xbb\xbf', 'utf-8-sig')):
        if raw.startswith(bom):
            return raw.decode(enc, errors='replace')
    return raw.decode('utf-8', errors='replace')


RUN = re.compile(r'^(\w+)\s+(cols|rows)\s+f(\d+)-f(\d+)\s+\((\d+) frames?, worst ([\d.]+)\)')
runs = []
for line in read_text(watch).splitlines():
    m = RUN.match(line.strip())
    if m:
        runs.append({'sp': m.group(1), 'axis': m.group(2), 'f0': int(m.group(3)),
                     'f1': int(m.group(4)), 'n': int(m.group(5)), 'worst': float(m.group(6))})

if not runs:
    raise SystemExit('parsed 0 runs from %s -- check the file is really sb_watch output '
                     'and not an empty or mis-encoded log' % watch)

moves = json.load(open(movesf))['moves']
same_site = [(i, m) for i, m in enumerate(moves)
             if m.get('src') and sorted(m['src']) == sorted(m.get('dst') or []) and m['src'] != m['dst']]

rows = []
for i, mo in same_site:
    hits = [r for r in runs if r['sp'] == mo['sp'] and r['axis'] == mo['axis']
            and not (r['f1'] < mo['f0'] or r['f0'] > mo['f1'])]
    if hits:
        rows.append((max(h['worst'] for h in hits), i, mo, hits))

rows.sort(reverse=True, key=lambda r: r[0])
print('%d sb_watch runs, %d same-site permutations in the book, %d overlap\n'
      % (len(runs), len(same_site), len(rows)))
for worst, i, mo, hits in rows:
    print('worst %6.3f   move[%d]  %-3s %-4s f%03d-f%03d' %
          (worst, i, mo['sp'], mo['axis'], mo['f0'], mo['f1']))
    print('%22s src %s' % ('', mo['src']))
    print('%22s dst %s' % ('', mo['dst']))
    print('%22s parts %s' % ('', mo['parts']))
    for h in hits:
        print('%22s run f%03d-f%03d (%d frames, worst %.3f)' % ('', h['f0'], h['f1'], h['n'], h['worst']))
    print()
print('shortlist for score_maps.py:  CAND = %s' % [i for _, i, _, _ in rows])
