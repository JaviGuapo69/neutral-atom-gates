"""sb_report.py -- moves.json (+ extra.json, + score.txt) -> the per-move evidence report.

Step 10 of SKILL.md's new-movie procedure asks for "a per-move evidence report" alongside the
workbook, and says it "must separate what was MEASURED from what is a CONVENTION".  Session 13
wrote c150's by hand; this generates the same document, so the next movie does not have to.

    python sb_report.py --calib calib.json --moves moves_full.json --out report.txt \
                        [--extra extra.json] [--score score.txt] [--title "c200 ..."] \
                        [--seed "X0 5:8 x 11:20  ..."] [--lattice "12 x 20 ..."]

Everything printed comes from the measurement record, not from a summary: each move's rigid
sub-blocks, the appearance classes and their rigidity residuals (rule 3z's testable prediction),
the cross-species scores that prove which blocks share a rectangle (section 5), the symmetric
verification error, and every note the transcriber refused to sweep under the rug.
"""
import argparse, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sb_read import Movie, comb

RULE = "=" * 100
THIN = "-" * 100


def match_evidence(ev, mv):
    """the evidence entry an emitted move came from.

    `evidence` also holds the candidates `emit` scored and did NOT commit, so it is longer than
    `moves`; match on the identity the move actually kept.
    """
    best = None
    for e in ev:
        if e["sp"] != mv["sp"] or e["axis"] != mv["axis"]:
            continue
        if abs(e["fa"] - mv["fa"]) > 0.35:
            continue
        cl = e.get("classes") or []
        got = sorted(tuple(c["src"]) for c in cl)
        want = sorted(tuple(p[0]) for p in (mv.get("parts") or []))
        score = (0 if got == want else 1, abs(e["fa"] - mv["fa"]))
        if best is None or score < best[0]:
            best = (score, e)
    return best[1] if best else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--moves", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--extra", default=None)
    ap.add_argument("--score", default=None)
    ap.add_argument("--title", default="")
    ap.add_argument("--seed", default="")
    ap.add_argument("--lattice", default="")
    ap.add_argument("--xlsx", default="")
    a = ap.parse_args()

    M = Movie(a.calib, None)
    d = json.load(open(a.moves))
    moves, ev = d["moves"], d.get("evidence", [])
    notes, undet = d.get("notes", []), d.get("undetermined", [])
    extra = json.load(open(a.extra)) if a.extra and os.path.exists(a.extra) else []

    runs, out = [], []
    w = out.append
    w(RULE)
    w(a.title or "per-move evidence")
    w("per-move evidence for %s" % (a.xlsx or "the workbook"))
    w(RULE)
    w("")
    w("geometry   %dx%d, %d frames, cycle %.2f ms, dt %.9f ms"
      % (M.K["image_w"], M.K["image_h"], M.nf, M.nf * M.dt, M.dt))
    if a.lattice:
        w("lattice    %s" % a.lattice)
    if a.seed:
        w("seed       %s" % a.seed)
    gr, cur = [], []
    for f in sorted(M.gate):
        if cur and f == cur[-1] + 1:
            cur.append(f)
        else:
            if cur:
                gr.append(cur)
            cur = [f]
    if cur:
        gr.append(cur)
    w("pulses     %d runs: %s"
      % (len(gr), ", ".join("f%d" % g[0] if len(g) == 1 else "f%d-%d" % (g[0], g[-1]) for g in gr)))
    w("")
    w("TOTALS     %d measured moves -> %d schedule rows"
      % (len(moves), sum(max(1, len(m.get("parts") or [1])) for m in moves)))
    w("           + %d hand-measured readout / load rows (SKILL.md 7)" % len(extra))
    w("           %s AOM groups, peak %s concurrent, over the whole cycle"
      % (d.get("aom_groups"), d.get("aom_peak")))
    w("           %d transitions UNDETERMINED" % len(undet))
    w("")
    w("HOW TO READ A ROW.  `parts` are the rigid sub-blocks: a crossed AOD pair holds a comb and")
    w("shifts it by ONE frequency offset, so each part is one uniform integer displacement and one")
    w("schedule row.  `verified` is the SYMMETRIC peak-matching error of the whole model (partition")
    w("AND easing) against every 1-D colour-profile peak of that species on every frame of the")
    w("window; off-panel predictions are excluded because the movie cannot show them (rule 21).")
    w("`how` says whether the partition was read from the outline colours, from the measured")
    w("displacements, or as a uniform whole-block translation.")
    w("")
    w(THIN)
    w("THE MOVES, in time order")
    w(THIN)

    for i, mv in enumerate(moves, 1):
        e = match_evidence(ev, mv)
        w("")
        w("%2d. %-8s%-5s f%03d-%03d   t %.4f -> %.4f ms   %s"
          % (i, "+".join(mv["joins"]) if mv.get("joins") else mv["sp"], mv["axis"],
             mv["f0"], mv["f1"], mv["t0"], mv["t1"], mv["kind"].upper()))
        w("    rectangle : %s %s   with the other axis on %s"
          % (mv["axis"], comb(mv["src"]), comb(mv["comb"] or [])))
        for j, p in enumerate(mv.get("parts") or [], 1):
            w("    part %-5d: %-16s -> %-16s D = %+d" % (j, comb(p[0]), comb(p[1]), p[1][0] - p[0][0]))
        w("    verified  : %.4f site mean, worst %.3f%s"
          % (mv["mean"], mv["worst"],
             "   *** OVER the 0.10 site guideline ***" if mv["mean"] > 0.10 else ""))
        w("    how       : %s" % mv["how"])
        if e:
            for c in e.get("classes") or []:
                # the complement part (section 3's B = S \ A) carries no measured D or residual --
                # it is a deduction from the marked classes, not a class that was read
                w("      class %-40s %-14s -> %-14s D=%-5s rigid to %s site"
                  % (c["colour"], comb(c["src"]), comb(c["dst"]),
                     "%+d" % c["D"] if c["D"] is not None else "n/a",
                     c["rigid_residual"] if c["rigid_residual"] is not None else "n/a (deduced)"))
            if e.get("displacement_read"):
                r = e["displacement_read"]
                w("      per-tone D %s ; rank-1 residual %s, monotone penalty %s, %d candidate(s) "
                  "scored" % (r["per_tone_D"], r["rank1_residual"], r["monotone_penalty"],
                              r.get("candidates_considered", 0)))
            if e.get("uniform_read"):
                r = e["uniform_read"]
                w("      uniform displacement measured %s site over %d frames, member spread %s "
                  "(rule 19 k=1: measured, NOT taken from the endpoints)"
                  % (r["measured_D"], r["n_frames"], r["member_spread"]))
        if len(mv.get("joins") or []) > 1:
            w("    the SAME rectangle carries %s -- species belongs to the atom, not the row, so one"
              % " and ".join(mv["joins"]))
            w("    rectangle spans blocks of different colours (SKILL.md 5). Cross-species scores: %s"
              % mv.get("detail"))
        if mv["kind"] == "permutation":
            w("    NOTE: a SAME-SITE permutation. The block ends on the rectangle it started on, so")
            w("    no render and no positional score can check it -- only the outline colours and")
            w("    the mid-move profile can. It is in the sheet because the movie shows it happen.")

    if extra:
        w("")
        w(THIN)
        w("THE HAND-MEASURED ROWS -- readouts and loads (SKILL.md 7)")
        w("Nothing automatic sees these: a readout carries no outline and no solid fill, and a")
        w("load's stock is faded until the instant it joins the cycle. READ THE NOTES: they say")
        w("which numbers are MEASURED and which are CONVENTIONS.")
        w(THIN)
        for x in extra:
            w("")
            w("  %-7s %-6s t %.4f -> %.4f   x %s -> %s   y %s -> %s"
              % (x["event"], x.get("species", ""), x["t_start"], x["t_finish"],
                 x["x_start"], x["x_finish"], x["y_start"], x["y_finish"]))
            for line in _wrap(x.get("note", ""), 96):
                w("      %s" % line)

    w("")
    w(THIN)
    w("EVERY NOTE THE TRANSCRIBER RAISED -- reported, not swept under the rug")
    w(THIN)
    for n in notes:
        for k, line in enumerate(_wrap(n, 96)):
            w(("  " if k == 0 else "      ") + line)

    if undet:
        w("")
        w(THIN)
        w("UNDETERMINED -- the movie shuffles a block and the sheet does not say so")
        w(THIN)
        for t in undet:
            w("  %s %s f%03d..f%03d  x %s -> %s  y %s -> %s"
              % (t["sp"], t["kind"], t["f0"], t["f1"], comb(t["x0"]), comb(t["x1"]),
                 comb(t["y0"]), comb(t["y1"])))
    else:
        w("")
        w("UNDETERMINED: none. Every transition enumerated from the occupancy record is described.")

    if a.score and os.path.exists(a.score):
        w("")
        w(THIN)
        w("THE SCORE (see the score file for the per-frame detail)")
        w(THIN)
        for line in open(a.score, encoding="utf-8", errors="replace").read().splitlines()[:40]:
            w("  " + line)

    open(a.out, "w", encoding="utf-8").write("\n".join(out) + "\n")
    print("wrote %s (%d lines)" % (a.out, len(out)))


def _wrap(s, n):
    words, line, out = s.split(), "", []
    for wd in words:
        if len(line) + len(wd) + 1 > n:
            out.append(line)
            line = wd
        else:
            line = (line + " " + wd).strip()
    if line:
        out.append(line)
    return out or [""]


if __name__ == "__main__":
    main()
