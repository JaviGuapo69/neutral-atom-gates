"""make_list_s31.py -- write s31_correction_list.md: every correction applied to the automatic c780 book, in FRAMES,
with the pixel evidence (the `how` of each corrected/added move record), the Schedule rows the automatic book had
in that window, the rows the s31 book has, and the measured residuals (handmade correction method.md, sections 2-3).
Run after apply_s31.py.  Section A is generated from moves_full.json; sections B-D are written here."""
import json, re, openpyxl

DT = 0.03854166666666667
OLD, NEW = r"..\run_c780\c780_blocks.xlsx", "c780_s31_blocks.xlsx"
TAG = "HAND CORRECTION (session 31, 2026-09-17, read from the pixels; applied on the user's one-time instruction)"


def sched(xlsx):
    ws = openpyxl.load_workbook(xlsx, data_only=True)["Schedule"]
    rows = list(ws.iter_rows(values_only=True))
    h = rows[0]
    return [dict(zip(h, r)) for r in rows[1:] if r[h.index("t_start")] is not None]


old, new = sched(OLD), sched(NEW)
mv = json.load(open("moves_full.json", encoding="utf-8"))
mv_old = json.load(open(r"..\run_c780\moves_full.json", encoding="utf-8"))


def fr(t):
    return "f%.2f" % (float(t) / DT)


def rg(a):
    a = list(a)
    return "%d:%d" % (a[0], a[-1]) if len(a) > 1 and a == list(range(a[0], a[-1] + 1)) else ",".join(map(str, a))


def table(rows, t0, t1, species):
    # the Schedule's `species` cell is empty on move rows; the label in front of the first ';' of `note` names the block(s)
    sel = [r for r in rows if float(r["t_finish"]) > t0 + 1e-6 and float(r["t_start"]) < t1 - 1e-6
           and any(s in (str(r["species"]) + " " + str(r["note"]).split(";")[0]) for s in species)]
    if not sel:
        return "_(no rows)_\n"
    s = "| move | slot | species | frames | t_start | t_finish | x_start | y_start | x_finish | y_finish |\n|---|---|---|---|---|---|---|---|---|---|\n"
    for r in sel:
        s += "| %s | %s | %s | %s-%s | %.4f | %.4f | %s | %s | %s | %s |\n" % (
            r["move"], r["slot"], r["species"] or str(r["note"]).split(";")[0], fr(r["t_start"]), fr(r["t_finish"]), float(r["t_start"]), float(r["t_finish"]),
            r["x_start"], r["y_start"], r["x_finish"], r["y_finish"])
    return s


def mlabel(m):
    return "%s %s f%03d-%03d `%s`%s" % ("+".join(m["joins"]), m["axis"], m["f0"], m["f1"],
                                        " \\| ".join("%s->%s" % (rg(a), rg(b)) for a, b in m["parts"]),
                                        (" on %s" % rg(m["sub_comb_lines"])) if m.get("sub_comb_lines") else "")


out = []
out.append("# c780 -- the mistakes of the automatic book, in FRAMES, and the corrections APPLIED (session 31, 2026-09-17)\n")
out.append("Written for: Javier, checking the c780 movie against the run_c780_s31 rebuild video.\n")
out.append("Automatic book: `run_c780\\c780_blocks.xlsx` (video `run_c780\\c780_original_vs_rebuild_panels.mp4`, session 28, the "
           "\"delivering the rest of videos\" session). Frame = t_ms / 0.038541667. Every item below was read from the pixels "
           "(`run_c780_s31\\logs\\probe_*.txt`, 61 probes, and the frame crops `logs\\crop_*.png`) and applied to "
           "`run_c780_s31\\c780_s31_blocks.xlsx` by `apply_s31.py`, on the user's one-time instruction of 2026-09-17 (\"apply the "
           "solutions to the problems that you find right away without consulting me, but only for this one time\"). Each move "
           "carries a measured residual from the skill's own `verify` ('free' = the per-frame free-progress error, the statistic "
           "the last resort ranks on; the smoothstep mean over-reads on fast wraps). The s31 video is the starting point for the "
           "ordinary hand-correction dialogue: name a wrong movement between frames A and B and it is checked against the pixels.\n")
out.append("## A. The corrections, in frame order (one entry per corrected or added move)\n")
out.append("Recurring patterns, as on c630: (i) the third block of a batch rotating its columns the OPPOSITE way to the other two "
           "(items at f001-008, f138-145, f248-254, f334-340) or the SAME way where the report guessed the inverse (f001-008 X1, "
           "f071-077 X1); (ii) small permutations of one block read as whole-block rotations, 3-cycles read as 4-cycles with a static "
           "row dragged in (Z0 f008-034, X rows f063-066, f162-165, Z1 f079-084, f091-095, f160-166, f310-314, Z0 f379-383); "
           "(iii) the same movement done by two blocks written for one of them only (X0/X1 rows f043-050, f055-058, f127-137, "
           "f145-172, Z cols f070-079, f333-340); (iv) the FOUR-GROUP EXCHANGES (+2/+4 with -2/-4, or +3/+5 with -3/-5) that every "
           "block does once its columns have landed (Z1 f108-114, f289-294, f345-349; Z0 f294-298, f340-345; X1 f340-345) -- the "
           "solver never described one; (v) the descent of X0 to its parking rows in TWO scrambled steps (f178-198) where X1 "
           "descends as a plain translation.\n")

corr = [m for m in mv["moves"] if TAG in str(m.get("how"))]
corr.sort(key=lambda m: (m["fa"], m["sp"]))
for k, m in enumerate(corr, 1):
    sp = list(m["joins"])
    t0, t1 = (m["f0"] - 1) * DT, (m["f1"] + 1) * DT
    out.append("### A%d. frames %03d-%03d -- %s\n" % (k, m["f0"], m["f1"], mlabel(m)))
    how = str(m["how"]).replace(TAG + ":", "").replace(TAG, "").strip(" :")
    how = re.sub(r"\s*\|\s*:", " |", how)
    out.append(how + "\n")
    out.append("Measured: smoothstep mean %.4f (worst %.3f), moving-frame mean %s, free per-frame %s, monotone %s; window f%.2f-f%.2f "
               "(t %.4f-%.4f ms); per species %s.\n" % (m["mean"], m["worst"], m.get("mean_moving"), m.get("free_err"), m.get("mono"),
                                                       m["fa"], m["fb"], m["t0"], m["t1"], m.get("detail")))
    out.append("**Rows the automatic book had for %s in f%03d-%03d:**\n" % ("+".join(sp), m["f0"], m["f1"]))
    out.append(table(old, t0, t1, sp))
    out.append("**Rows the s31 book has:**\n")
    out.append(table(new, t0, t1, sp))

out.append("## A'. Moves DELETED from the automatic book\n")
out.append("| automatic move | why |\n|---|---|\n")
for lab, why in [
    ("X0 rows f055-061 `1:6->2:7 \\| 7->1`", "row 4 is static; X0 does X1's `3,7->1,5 \\| 1,2,5,6->2,3,6,7` (one rectangle now)"),
    ("X1 rows f132-136 `14->19 \\| 15->18 \\| 17:18->14:15 \\| 19->17`", "X1 does X0's `14:15->18:19 \\| 16:19->14:17` (one rectangle now)"),
    ("X1+X0 rows f148-154 `22:23->19:20 \\| 19:21->21:23`", "duplicate of the same batch (X atoms claimed twice)"),
    ("X1 rows f165-171 `22:24->15:17 \\| 15:21->18:24`", "duplicate of the X1+X0 row (and both maps replaced)"),
    ("Z0 rows f249-256 `7->3 \\| 3:6->4:7`", "phantom: rows on tones f252-254"),
    ("Z0 rows f281-291 `6->7 \\| 7->6` (empty comb)", "phantom: rows on tones f281-293"),
    ("Z1 rows f289-296 8-part", "replaced, with the f281-291 'relocation', by one four-group exchange"),
    ("Z0 rows f300-309 `6->10 \\| 7:10->6:9`", "phantom: rows 6, 7 on tones f300-310"),
]:
    out.append("| %s | %s |\n" % (lab, why))

out.append("\n## B. Moves over the 0.10 guideline in the s31 book -- check the map by eye\n")
out.append("Rule from c540: 29 of 31 over-guideline moves there were right. Only name the ones the movie contradicts. The fast "
           "whole-block wraps (Z0 cols f350-361, 24 columns in 12 frames) and the four-frame moves are over the bar on the smoothstep "
           "fit while their free per-frame error is small.\n")
out.append("| species | axis | frames | t (ms) | comb | map | mean | free | origin |\n|---|---|---|---|---|---|---|---|---|\n")
for m in mv["moves"]:
    if m["mean"] is not None and m["mean"] > 0.10:
        cs = rg(m["sub_comb_lines"]) if m.get("sub_comb_lines") else (rg(m["comb"]) if m["comb"] else "(empty)")
        mp = " \\| ".join("%s->%s" % (rg(a), rg(b)) for a, b in m["parts"])
        origin = ("HAND s31" if TAG in str(m.get("how")) else "last resort" if "LAST-RESORT" in str(m.get("how")) else
                  "S2.1" if "S2.1" in str(m.get("how")) else "")
        out.append("| %s | %s | f%03d-%03d | %.3f-%.3f | %s | %s | %.4f | %s | %s |\n" % (
            "+".join(m["joins"]), m["axis"], m["f0"], m["f1"], m["t0"], m["t1"], cs, mp, m["mean"], m.get("free_err", ""), origin))

out.append("\n## C. Checked on the pixels and found CORRECT (no change)\n")
for s in [
    "X0 cols f002-010 `1:2->12:13 | 3:13->1:11`; X1+X0 rows f008-034 (all seven moves incl. the two over-guideline ones: "
    "`1->3 | 3->1 | 4->6 | 6->4` f026-030 and the involution `1:6<->7:12` f030-035 -- gold 7:12 up, mauve 1:6 down frame by frame).",
    "X0, X1 and Z0 cols f037-045: X rotate by -4 (`5:13->1:9 | 1:4->10:13`, `14:17->23:26 | 18:26->14:22`), Z0 by +4 "
    "(`1:9->5:13 | 10:13->1:4`) -- the directions are right as written.",
    "X1+X0 rows f051-055 `4:7->5:8 | 8->4`, f058-063 `1:3<->4:6`, f066-070 `7:9->9:11 | 10:11->7:8`; X0 cols f072-079 "
    "`1:5->9:13 | 6:13->1:8`.",
    "Z1 rows f084-091 `34->25 | 25:33->26:34`, f095-099 `28:31->30:33 | 32:33->28:29`, f100-104 `33:35->34:36 | 36->33`, "
    "f104-107 `31:32->34:35 | 33:35->31:33`.",
    "X1+X0 rows f109-116 `13:18<->19:24`, f114-119 `22->24 | 23:24->22:23`, f120-132 `14->22 | 15:22->14:21`; X0 rows f133-137 "
    "`14:15->18:19 | 16:19->14:17` (now carrying X1 too).",
    "X1 cols f139-147 and Z1 cols f139-146 (X by +9, Z1 by +4 -- opposite, as written); X1+X0 rows f148-154 `19:21->21:23 | "
    "22:23->19:20` (one copy), f152-158 `15->18 | 16:18->15:17`; Z1 rows f152-161 `27->36 | 31->27 | 36->31`, f166-171 `30->28 | "
    "28:29->29:30`; X1 rows f197-207 `13:24->25:36`.",
    "X0 cols f216-224 `1:3->11:13 | 4:13->1:10` and Z1+Z0 cols `1:10->4:13 | 11:13->1:3` (opposite, as written); X0 rows f222-227 "
    "`28:29<->30:31`, f229-235 `30:31->26:27 | 26:29->28:31`, f234-240 `36->32 | 32:35->33:36`, f241-246 `25:31->30:36 | "
    "32:36->25:29` (the last-resort rotation by 5 is right); Z1+Z0 cols f249-256 `1:7->7:13 | 8:13->1:6`; Z0 rows f254-262 "
    "`2:4->10:12 | 5:12->2:9`, Z1 rows f254-262 `14:16->22:24 | 17:24->14:21`; Z0 rows f261-269 `1:7->5:11 | 8:11->1:4`, Z1 rows "
    "`13:19->17:23 | 20:23->13:16`.",
    "X1 cols f281-290 `14:26->1:13` and f288-297 `1:12->2:13 | 13->1`; Z rows f307-312, f310-316 (Z0 `1->3 | 3->1 | 6->8 | 8->6` "
    "is two real pair swaps), f314-321, f319-326, f324-329, f327-332 -- all confirmed; Z0 cols f350-375 `14:24->3:13 | 25:26->1:2`; "
    "Z1 rows f362-375 `13:24->25:36`.",
]:
    out.append("* " + s + "\n")
out.append("\n## D. Not defects\n")
out.append("* The 8 readout/load/carry-in rows of `extra.json` (Z readout f174-178 descending +9 rows, Z loads f174 at cols -12:0, Z "
           "carry-in f205-214.5, X readout f350-355, X loads f350 at rows -11:0, X carry-in f372-382): destinations of the descents "
           "and the integer staging are CONVENTIONS (report section 3), unchanged.\n")
out.append("* Not verified frame by frame (no doubt raised, no probe): X0 cols f281-290 `1:13->-12:0` (the parking slide), the "
           "readout windows.\n")
open("s31_correction_list.md", "w", encoding="utf-8").write("\n".join(out))
print("wrote s31_correction_list.md with %d corrected/added moves" % len(corr))
