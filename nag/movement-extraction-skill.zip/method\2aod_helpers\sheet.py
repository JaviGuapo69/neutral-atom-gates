"""Contact sheet of panel crops, for reading a stretch of a movie by eye.

Usage:
  python sheet.py <run dir> <out.png> f1,f2,f3,...   [--cols N] [--scale S]
  python sheet.py <run dir> <out.png> --range f0,f1,step
  python sheet.py <run dir> <out.png> f1,f2 --win c0,c1,r0,r1      (crop to tones)

Frames are labelled with their number.  `--win` crops to a lattice window so a single
block can be read marker by marker (the montage step of `handmade correction method.md` 2b).
"""
import argparse, json, os
from PIL import Image, ImageDraw


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("out")
    ap.add_argument("frames", nargs="?", default=None)
    ap.add_argument("--range", dest="rng", default=None)
    ap.add_argument("--cols", type=int, default=0)
    ap.add_argument("--scale", type=float, default=0.0)
    ap.add_argument("--win", default=None, help="c0,c1,r0,r1 in tone units")
    ap.add_argument("--rframes", action="store_true", help="read rframes/ instead of frames/")
    a = ap.parse_args()

    K = json.load(open(os.path.join(a.run, "calib.json")))
    ox, px, oy, py = K["origin_x"], K["pitch_x"], K["origin_y"], K["pitch_y"]
    x0, x1, y0, y1 = K["panel"]
    if a.win:
        c0, c1, r0, r1 = [float(v) for v in a.win.split(",")]
        x0, x1 = int(ox + (c0 - 1) * px), int(ox + (c1 - 1) * px)
        y0, y1 = int(oy + (r0 - 1) * py), int(oy + (r1 - 1) * py)

    if a.rng:
        f0, f1, st = [int(v) for v in a.rng.split(",")]
        fs = list(range(f0, f1 + 1, st))
    else:
        fs = [int(v) for v in a.frames.split(",")]

    d = os.path.join(a.run, "rframes" if a.rframes else "frames")
    tiles = []
    for f in fs:
        im = Image.open(os.path.join(d, "p_%03d.png" % f)).convert("RGB").crop((x0, y0, x1, y1))
        tiles.append((f, im))

    w, h = tiles[0][1].size
    ncol = a.cols or max(1, min(len(tiles), int(round((len(tiles) * h / float(w)) ** 0.5))))
    nrow = (len(tiles) + ncol - 1) // ncol
    sc = a.scale or min(1.0, 1500.0 / (ncol * w), 1500.0 / (nrow * (h + 18)))
    tw, th = int(w * sc), int(h * sc)
    sheet = Image.new("RGB", (ncol * (tw + 4), nrow * (th + 18)), (235, 235, 235))
    dr = ImageDraw.Draw(sheet)
    for i, (f, im) in enumerate(tiles):
        cx, cy = (i % ncol) * (tw + 4), (i // ncol) * (th + 18)
        sheet.paste(im.resize((tw, th), Image.LANCZOS), (cx + 2, cy + 16))
        dr.text((cx + 4, cy + 3), "f%03d" % f, fill=(0, 0, 0))
    sheet.save(a.out)
    print("%s  %d tiles  %dx%d" % (a.out, len(tiles), *sheet.size))


if __name__ == "__main__":
    main()
