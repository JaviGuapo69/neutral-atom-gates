"""apply_c150_2aod.py -- the FIRST-PASS hand corrections to the automatic c150 (2-AOD) book.

`handmade correction method.md` section 0/2: the session reads the whole rebuild against the
movie's pixels, finds every mistake it can, MEASURES the correction for each, applies them all
without waiting, re-emits through the skill's own emitter and renders once.  The skill's tools/
are not touched.  This script always starts from the untouched automatic move list
(moves_full_auto_original.json / rests_full_auto_original.json), so re-running it re-applies
every item from scratch and cmp_tol against the automatic book shows the whole intended set.

The movie (see 2AOD_SETUP.md): 568 frames, 24 gate runs of 4 frames, four 6x5 blocks on a 12x15
lattice, Z phase then X phase.  Z0 1:6x1:5, Z1 1:6x6:10 at t=0; the X blocks do not exist on
screen until f279; Z0 leaves left at f218-230, Z1 downward at f279-283, X0 left at f481-493;
X1 is still on the panel when the movie ends.

    python -u apply_c150_2aod.py > apply_c150_2aod.log 2>&1      # from run_c150_2aod
"""
import json, os, sys

sys.path.insert(0, os.path.join("..", "..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_build, sb_compose, sb_emit
from sb_read import Movie

OUT_XLSX = "c150_2aod_s33_blocks.xlsx"
TAG = ("HAND CORRECTION (2-AOD session, 2026-09-18, first pass, read from the pixels and applied "
       "without waiting per handmade correction method.md 0)")

M = Movie("calib.json")
dt = M.dt
mv = json.load(open("moves_full_auto_original.json", encoding="utf-8"))
rests = json.load(open("rests_full_auto_original.json", encoding="utf-8"))
moves = mv["moves"]
print("start: %d moves, %d undetermined, %d readouts" % (len(moves), len(mv["undetermined"]),
                                                         len(mv["readouts"])))

print("measuring every species' peaks once (sb_compose.Peaks) ...")
runs = sb_compose.pulse_runs(M)
wins = sb_compose.species_windows(M, 0, M.nf - 1)
P = sb_compose.Peaks(M, wins, 0, M.nf - 1)
AX = {"cols": 0, "rows": 1}
R = lambda a, b: list(range(a, b + 1))


# ====================================================================== helpers (run_c780_s31\apply_s31.py)
def find(sp, axis, f0, f1):
    ix = [i for i, m in enumerate(moves) if (sp in m["joins"] or m["sp"] == sp)
          and m["axis"] == axis and m["f0"] == f0 and m["f1"] == f1]
    assert len(ix) == 1, (sp, axis, f0, f1, ix)
    return ix[0]


def rng(t):
    t = list(t)
    if len(t) > 1 and t == list(range(t[0], t[-1] + 1)):
        return "%d:%d" % (t[0], t[-1])
    return ",".join(str(x) for x in t)


def label(m):
    return "%s %s f%03d-%03d %s" % ("+".join(m["joins"]), m["axis"], m["f0"], m["f1"],
                                    " | ".join("%s->%s" % (rng(a), rng(b)) for a, b in m["parts"]))


def measure(m, frames):
    axis = AX[m["axis"]]
    detail = {}
    for nm in M.species:
        mean, worst, n = sb_compose.verify(P, nm, axis, m["src"], m["dst"], m["fa"], m["fb"],
                                           frames, M)
        detail[nm] = round(mean, 4) if n else None
    mean, worst, n = sb_compose.verify(P, m["sp"], axis, m["src"], m["dst"], m["fa"], m["fb"],
                                       frames, M)
    seq = sb_compose.progress_per_frame(P, m["sp"], axis, m["src"], m["dst"], frames, M)
    free = [s[2] for s in seq if 0.02 < s[1] < 0.98]
    m["mean"] = round(mean, 4)
    m["worst"] = round(worst, 3)
    m["detail"] = detail
    m["free_err"] = round(sum(free) / len(free), 4) if free else None
    m["ok"] = bool(m["mean"] <= 0.10)
    print("  %s: f%.2f-%.2f  smoothstep mean %.4f worst %.3f over %d peaks; FREE per-frame err %s"
          % (label(m), m["fa"], m["fb"], mean, worst, n, m["free_err"]))
    return seq


def set_time(m, fa, fb, why):
    m["fa"], m["fb"] = round(fa, 2), round(fb, 2)
    m["t0"], m["t1"] = round(fa * dt, 6), round(fb * dt, 6)
    print("  timing set to f%.2f-f%.2f (%s)" % (fa, fb, why))


def refit(m, frames, lo_fr, hi_fr, why):
    best = sb_build.fit_timing(P, M, m["sp"], AX[m["axis"]], m["src"], m["dst"], frames,
                               float(lo_fr), float(hi_fr))
    if best is None:
        print("  !! fit_timing found nothing in [f%.2f, f%.2f] for %s" % (lo_fr, hi_fr, label(m)))
        set_time(m, lo_fr, hi_fr, "fit failed; bounds used")
        return
    _, a, b = best
    set_time(m, a, b, why)


def fr(a, b):
    return [f for f in range(max(0, a), min(M.nf - 1, b) + 1)]


def hold_back(sp, f0, f1, why):
    """move a transition from 'covered by a move' to the READOUT / LOAD list sb_audit tolerates"""
    t = [t for t in rests[sp]["transitions"] if t["f0"] == f0 and t["f1"] == f1]
    assert len(t) == 1, (sp, f0, f1, [(x["f0"], x["f1"]) for x in rests[sp]["transitions"]])
    mv["readouts"].append(t[0])
    print("  held back as READOUT/LOAD: %s %s f%03d-%03d (%s)" % (sp, t[0]["kind"], f0, f1, why))


def delete(sp, axis, f0, f1, why):
    i = find(sp, axis, f0, f1)
    print("\n- DELETED %s  (%s)" % (label(moves[i]), why))
    del moves[i]


notes = []


def note(s):
    notes.append("[%s] %s" % (TAG, s))


extra = []


def unload(species, x_start, y_start, x_finish, y_finish, t0, t1, why):
    extra.append(dict(event="unload", species=species,
                      t_start=round(t0, 6), t_finish=round(t1, 6),
                      x_start=x_start, y_start=y_start, x_finish=x_finish, y_finish=y_finish,
                      note=TAG + ": " + why))
    print("\n+ EXTRA unload %-5s x %s -> %s  y %s -> %s  t %.6f-%.6f (f%.1f-f%.1f)"
          % (species, x_start, x_finish, y_start, y_finish, t0, t1, t0 / dt, t1 / dt))


def load(species, x, y, t, why):
    extra.append(dict(event="load", species=species, t_start=round(t, 6), t_finish=round(t, 6),
                      x_start=x, y_start=y, x_finish=x, y_finish=y, note=TAG + ": " + why))
    print("\n+ EXTRA load   %-5s x %s  y %s  t %.6f (f%.2f)" % (species, x, y, t, t / dt))


# ======================================================================================
# 1. THE X BLOCKS DO NOT EXIST ON SCREEN BEFORE f279
# ======================================================================================
# sb_watch: X0 and X1 cols AND rows f004-f274, 231 frames each, worst 10.8 / 15.0 -- "movie 0
# peaks, render 6".  The workbook format seeds every species that has a rest, and the X blocks'
# first rest is the source of their carry-in (cols 1:6 / 7:12, rows -4:0), so render.ps1 draws
# their row 0 -- twelve markers along the top edge -- for the whole Z phase, where the movie
# draws nothing at all (X0/X1 solid area is 0 px on every frame f004-f278, sb_events --full).
# The atoms are BORN at f279: X1 solid 0 -> 1008 px and X0 0 -> 864 px at f279, one row at
# row 0.09 / 0.10, with no faded stock anywhere beforehand.
# So: retire the seeded stock at t = 0 (it is bookkeeping the format forces, and it is stated),
# create the blocks for real with `load` rows a hair before f279, and let the solver's own
# measured carry-in move carry them in.  sb_extra's D-scan pins that carry-in at D = +5 exactly:
# X0 0.0313 site at +5 against 0.1666 at +4 and 0.2305 at +6; X1 0.0264 against 0.1695 / 0.2243.
unload("X0", "1:6", "-4:0", "1:6", "-4:0", 0.0, 0.0,
       "the X0 stock is NOT on screen before f279 (solid area 0 px on every frame f004-f278). "
       "sb_emit seeds every species that has a rest, so X0 is seeded at its staging rectangle and "
       "retired in the same instant; the block is created for real by the load row at f278.4. "
       "Bookkeeping, not physics: net census zero, and it is what makes the rebuild show nothing "
       "where the movie shows nothing (sb_watch X0 cols/rows f004-f274, worst 10.5 / 14.0).")
unload("X1", "7:12", "-4:0", "7:12", "-4:0", 0.0, 0.0,
       "the same for X1 (sb_watch X1 cols/rows f004-f274, worst 10.8 / 15.0).")
# The load has to sit in a STRICTLY EARLIER batch than the move that carries the block in
# (render.ps1 applies a batch's moves and only then creates that batch's atoms), so it is placed a
# tenth of a frame before the carry-in's OWN fitted start.  Clipping the MOVE to the load instead
# was tried and rejected: it costs 1.0-1.5 frames on five windows and takes their smoothstep means
# from 0.026-0.054 to 0.107-0.259, i.e. a visible mid-move lag, for one frame of shade.
xc = moves[find("X0", "rows", 279, 289)]
load("X0", "1:6", "-4:0", (xc["fa"] - 0.1) * dt,
     "X LOAD. X0's atoms appear at f279 (solid 0 -> 864 px, one row at row 0.10) with no faded "
     "stock beforehand, so they are created a tenth of a frame before the carry-in's own fitted "
     "start f%.2f, at the staging rectangle the carry-in is measured from. D = +5 is pinned by "
     "sb_extra's scan: 0.0313 site at +5 against 0.1666 at +4 and 0.2305 at +6, fitted "
     "f277.64-f289.30 over f279-289. The one frame this shows early, f278, is a GATE frame."
     % xc["fa"])
load("X1", "7:12", "-4:0", (xc["fa"] - 0.1) * dt,
     "X LOAD, second block (solid 0 -> 1008 px at f279, row 0.09). D = +5: 0.0264 site against "
     "0.1695 at +4 and 0.2243 at +6, fitted f277.56-f289.40. Same instant as X0: the two blocks "
     "ride one rectangle in.")
note("1: the X blocks are born at f%.2f, not at t = 0 -- the seeded stock is retired at t = 0 and "
     "the blocks created by load rows (carry-in D = +5 measured, 0.031 / 0.026 site). Removes 462 "
     "frames of phantom markers (sb_watch X0/X1 cols and rows f004-f274, worst 10.5-15.0)."
     % (xc["fa"] - 0.1))

# ======================================================================================
# 2-5. THE FOUR IN-PLACE READOUT / LOAD PAIRS
# ======================================================================================
# In this 2-AOD movie an ancilla block that has finished a group of CZ rounds DESATURATES IN
# PLACE and a fresh block appears solid on exactly the same tones some frames later -- the
# signature sb_events.py itself calls READOUT? and LOAD? (rule 3: faded means not in use).  No
# block travels and no stock is ever visible, so the occupancy test either bridges the dark run
# as a same-site permutation that does not exist (Z1 f136-152, held back in events.json) or sees
# nothing at all.  MEASURED, per dark run, on the faded track through a window on the block:
#   Z1 f137-151  cols 7.05 8.05 9.05 10.05 11.05 12.05, rows 5.94 6.95 7.94 8.95 9.94,
#                mask area 6492/6493 on EVERY frame -- frozen to the pixel; solid returns at
#                f152 on 7.00 7.99 9.01 10.00 11.04 12.00 x 6.07 6.99 8.04 9.04 10.03
#   Z1 f172-217  rows 11.00 12.00 13.00 14.00 14.99, area 6966-6972 on every frame
#   X1 f399-409  rows 6.01 6.99 8.02 8.99 9.96, area 6686-6688 on every frame
#   X1 f421-480  the same, at rows 11:15
# The CZ-firing footers say why: Z1 has no gate between f133 (Z1->D4) and f247 (Z1->D5), and X1
# none between f395 (X1->D4) and f513 (X1->D5).  The alternative reading is that the block is
# merely IDLE and the atoms persist; the movie cannot distinguish them, and this one is chosen
# because it is the skill's own reading of those pixels and because render.ps1 has no idle state
# -- modelled as idle, the rebuild would draw a solid block through 132 frames where the movie
# shows a faded one.  Positions are identical either way.
for sp, x, y, f_out, f_in, mk in (
        ("Z1", "7:12", "6:10", 137, 152, ("Z1", "rows", 152, 167)),
        ("Z1", "7:12", "11:15", 172, 218, ("Z1", "cols", 218, 230)),
        ("X1", "7:12", "6:10", 399, 410, ("X1", "rows", 410, 421)),
        ("X1", "7:12", "11:15", 421, 481, ("X1", "cols", 481, 493))):
    # the fresh block must be born before the batch of the move that first drives it, so the load
    # sits a tenth of a frame before that move's OWN fitted start and the old atoms die there.
    nxt = moves[find(*mk)]
    t_in = (nxt["fa"] - 0.1) * dt
    unload(sp, x, y, x, y, f_out * dt, t_in,
           "IN-PLACE READOUT: %s desaturates on its own tones at f%d and the faded block is then "
           "frozen to the pixel (identical peaks, mask area constant to 1-2 px) until f%d, when a "
           "fresh block appears solid on exactly those tones. Nothing travels and no stock is "
           "ever visible. The row fades the atoms at f%d and retires them at f%.2f, where the "
           "fresh block is born -- a tenth of a frame before the move that first drives it, so "
           "that move keeps its own measured window. The %d - %d frames this shows solid early "
           "are the cost; clipping the move to f%d instead costs 0.10-0.26 site of mid-move lag."
           % (sp, f_out, f_in, f_out, t_in / dt, f_in, int(t_in / dt), f_in))
    load(sp, x, y, t_in,
         "the fresh %s block, on the tones the old one occupied (cols %s, rows %s); solid in the "
         "movie from f%d." % (sp, x, y, f_in))
note("2-5: four IN-PLACE readout/load pairs written as extra rows -- Z1 f137->f152 and "
     "f172->f218 (cols 7:12, rows 6:10 then 11:15), X1 f399->f410 and f421->f481. Each is a block "
     "desaturating on its own tones with the faded image frozen to the pixel and a fresh block "
     "appearing solid on exactly those tones. No move's window was changed for them.")

# ======================================================================================
# 6-7. THE TWO DEPARTURES THE SOLVER WROTE AS ORDINARY MOVES ARE READOUTS
# ======================================================================================
# Z0 cols f218-230 1:6 -> -5:0 and X0 cols f481-493 1:6 -> -5:0 are real, measured translations
# (0.0308 and 0.0263 site) -- but the block DESATURATES as it goes (Z0 solid 3544 px at f221
# falling to 548 at f229 and 0 at f230, faded 50 -> 1454; X0 the same at f493) and never comes
# back.  Written as plain moves the atoms stay alive and solid at cols -5:0 for the rest of the
# movie, and every later move on those sites picks up two atoms per trap: se_sim reported ELEVEN
# check3 failures from f420 on ("picked up 24 of 12 sites"), and sb_watch has Z0 rows f230-f563
# and X0 cols/rows f532-f535 as pure phantoms.  An `unload` row carries the same measured travel
# AND fades and retires the atoms, which is what the movie shows.
for sp, key, tr, gone in (("Z0", ("Z0", "cols", 218, 230), (218, 228), 230),
                          ("X0", ("X0", "cols", 481, 493), (481, 491), 493)):
    m = moves[find(*key)]
    t0, t1, mean = m["t0"], m["t1"], m["mean"]
    delete(*key, why="rewritten as an unload row: the block fades as it leaves and never returns")
    unload(sp, "1:6", "11:15", "-5:0", "11:15", t0, t1,
           "%s READOUT. The solver's own measured translation (cols 1:6 -> -5:0 on rows 11:15, "
           "fitted f%.2f-f%.2f, mean %s site) rewritten as an unload so the atoms FADE and RETIRE "
           "instead of living on at cols -5:0. The movie: the solid area collapses to 0 px while "
           "the faded area jumps, at f%d." % (sp, t0 / dt, t1 / dt, mean, gone))
    hold_back(sp, tr[0], tr[1],
              "the departure is a readout, hand-measured in extra.json, not a fitted move")

# ======================================================================================
# 8. Z1'S DEPARTURE AT f279-283 WAS NEVER ENUMERATED (rule 36)
# ======================================================================================
# Z1 finishes its last D5 gate at f275-278 and descends off the bottom of the panel: at f279 its
# five rows read 11.30 12.30 13.30 14.40 15.30, at f282 only one row is left at 16.29, and the
# solid area is 0 from f283.  Occupancy never saw a rest on the far side, so NO transition was
# enumerated and the move appears in no list at all -- not the undetermined one either.  Z1's
# atoms therefore sat at cols 1:6 rows 11:15 for the rest of the movie, which is where X0 lands
# at f410-421 and X1 at f481-493: that is the other half of se_sim's eleven check3 failures and
# of sb_watch's Z1 rows f279-f563.
# sb_extra's D-scan is monotone (0.1339 at +4, 0.0774 at +5, 0.0371 at +6, 0.0249 at +9, 0.0162
# at +15) because only the leading row is ever on the panel, so THE DESTINATION IS A CONVENTION:
# +5 rows is adopted -- one block height, to match Z0's and X0's exits, which are exactly one
# block width (-6 columns) -- and the fit that goes with it, f277.78-f283.66, is the one whose
# arrival coincides with the frame the movie loses the block (f283).
unload("Z1", "1:6", "11:15", "1:6", "16:20", 277.78 * dt, 283.66 * dt,
       "Z1 READOUT, NEVER ENUMERATED by the solver (no rest on the far side, so no transition). "
       "Z1 descends off the bottom: rows 11.30 12.30 13.30 14.40 15.30 at f279, one row at 16.29 "
       "at f282, solid 0 px from f283. Fitted f277.78-f283.66 at D = +5, mean 0.0774 site over 26 "
       "comparisons. THE DESTINATION IS A CONVENTION -- the scan is monotone (0.0774 at +5, "
       "0.0249 at +9, 0.0162 at +15) because only the leading row is ever on panel -- chosen as "
       "one block height for consistency with Z0's and X0's one-block-width exits.")
note("6-8: the three departures are unload rows now. Z0 f218-230 and X0 f481-493 keep the "
     "solver's measured cols 1:6 -> -5:0 travel but fade and retire; Z1's f279-283 descent, which "
     "the solver NEVER ENUMERATED, is added at D = +5 (a convention: the scan is monotone). "
     "These three together are the eleven se_sim check3 failures and every 9.99 run in sb_watch "
     "after f230.")

# ======================================================================================
# 9. Z0 cols f137-152 FINISHES A FRAME AND A HALF TOO EARLY
# ======================================================================================
# The only move in the book over the guideline (mean 0.1935, ok=false), and sb_mapcheck passes
# its MAP (0.020 / 0.019 site): the fault is the window.  sb_watch has Z0 cols f141-f148 at a
# worst of 0.959 with the rebuild consistently AHEAD of the movie.  Reading the progress off the
# pixels frame by frame -- the map is 7->4 | 8:9->1:2 | 10:11->5:6 | 12->3, so the predicted
# peaks are 7-3p, 8-7p, 9-7p, 10-5p, 11-5p, 12-9p -- gives p = 0.22 at f141 (measured 6.39 7.45
# 8.89 10.00 against 6.40 7.46 8.90 9.96 predicted), 0.67 at f145 (3.29 4.20 4.96 5.85 6.60 7.59
# against 3.31 4.31 4.99 5.97 6.65 7.65), 0.93 at f148 and 0.97 at f149, and the block is on its
# tones to 0.12 at f150 and to 0.04 at f151.  The rebuild was at p = 0.74 at f145.  The block's
# ROWS are still dead on 1:5 through f151 and start at f152 (1.11 2.08 3.05 4.08 5.07), so the
# column move has until f151.5 and the row move that follows must start there, not at f150.43.
m13 = moves[find("Z0", "cols", 137, 152)]
own = (m13["fa"], m13["fb"])
refit(m13, fr(136, 152), 133.0, 150.40,
      "boundary scanned over f150.30-f151.50 (alt_boundary.py): the sum of this move and the two "
      "row descents it hands over to is least at f150.40")
measure(m13, fr(136, 152))
# WHAT THIS MOVE'S RESIDUAL ACTUALLY IS, because it is the one the user will see in the video and
# it is NOT a wrong map.  Reading the progress off the pixels frame by frame gives p = 0.00, 0.04,
# 0.08, 0.145, 0.22 on f137-f141, 0.67 at f145, 0.93 at f148, 0.97 at f149, 0.99 at f150 and 1.00
# at f151; inverting the quintic, du/df is a steady 0.055-0.065, so the movie's own window is
# f135.0-f152.2.  The Z0 ROW descent that follows, read the same way (p = 0.008, 0.033, 0.074,
# 0.125, 0.197, 0.282, 0.382, 0.499, 0.617 on f152-f160), has its own window f150.35-f167.6 -- and
# f167.6 is already hard against the f168 gate, so it cannot be moved later.  The two therefore
# overlap by ~1.8 frames in the movie, and on a 2-AOD machine one crossed pair cannot drive the
# columns and the rows of the same block at once: allowing the overlap takes the AOM peak to 4
# (aom_where.py: Z0 cols on two pairs + Z0 rows + Z1 rows at f151.0).  So the three moves share one
# boundary, placed where they cost least -- f150.40, scanned in alt_boundary.py (sum 0.2661 there
# against 0.2777 at f150.30 and 0.4747 at f151.50).  The price is this move's mid-move lag, up to
# 0.4 site over f141-f148 (sb_watch Z0 cols f141-f148, worst 0.959): it is the movie overrunning
# the batch boundary, not a wrong map, and sb_mapcheck confirms the map at 0.020 site.
note("9: Z0 cols f137-152 refitted f%.2f-f%.2f (was f%.2f-f%.2f), mean 0.1935 -> %s. The MAP is "
     "confirmed (sb_mapcheck 0.020 site) and the residual is a boundary, not an error: the "
     "movie's own column travel runs to f152.2 while its row descent starts at f150.35 and cannot "
     "be moved later (the f168 gate pins its finish), and one crossed pair cannot do both, so the "
     "shared boundary is placed at the scanned minimum f150.40. Up to 0.4 site of mid-move lag at "
     "f141-f148 remains and is the price of that." % (m13["fa"], m13["fb"], own[0], own[1],
                                                      m13["mean"]))

# ====================================================================== save + re-emit
mv["notes"] = list(mv.get("notes", [])) + notes
json.dump(extra, open("extra.json", "w", encoding="utf-8"), indent=1)
print("\nwrote extra.json (%d rows)" % len(extra))
rows = sb_compose.schedule_rows(moves)
ng, peak = sb_compose.allocate_aom(rows)
mv["aom_groups"], mv["aom_peak"] = ng, peak
json.dump(mv, open("moves_full.json", "w", encoding="utf-8"), indent=1, default=str)
json.dump(rests, open("rests_full.json", "w", encoding="utf-8"), indent=1)
print("wrote moves_full.json (%d moves, %d undetermined, %d held back, AOM groups %d peak %d)"
      % (len(moves), len(mv["undetermined"]), len(mv["readouts"]), ng, peak))
over = [m for m in moves if m.get("mean") is not None and float(m["mean"]) > 0.10]
print("moves over 0.10:", len(over))
for m in over:
    print("   %s  mean %s free %s" % (label(m), m["mean"], m.get("free_err")))

sb_emit.emit(OUT_XLSX, M, mv, rests, runs, P, 0, M.nf - 1, extra="extra.json",
             scope_note="the WHOLE movie: frames 0-%d, t = 0 .. %.4f ms, all %d pulse runs; the "
                        "automatic se-cycle-blocks book (2-AOD session 2026-09-18) plus the nine "
                        "first-pass hand corrections listed in Notes, read from the pixels and "
                        "applied per handmade correction method.md 0"
                        % (M.nf - 1, (M.nf - 1) * M.dt, len(runs)))
print("wrote", OUT_XLSX)
