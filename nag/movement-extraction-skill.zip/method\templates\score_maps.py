"""STEP 2 OF THE HUNT -- decide a shortlisted move against the movie's own pixels.

For each candidate cyclic permutation, scores EVERY rotation k with the skill's own fit_timing /
verify / progress_per_frame.  If the rotation the book has is not the winner, the book is wrong
there.  Built on method/templates/alt_s30.py, which is the general form (arbitrary maps, not just
rotations) -- use that one when the candidate is not a rotation.

    # edit CAND to the shortlist find_wrong_maps.py printed, then:
    python score_maps.py > score_maps.txt

Run it from the session folder (the one holding calib.json and moves_full.json).

READING THE RESULT -- the trap that produced three false alarms in testing:

    A rotation by k and a rotation by n-k are THE SAME MOTION RUN BACKWARDS, and the free
    per-frame fit CANNOT separate them: they score identically.  The documentation mentions this
    only for the involution k = n/2; it is true for EVERY k.  When the winner and the book's value
    sum to n, that is the direction degeneracy, not a defect -- break the tie on `mean` and
    `worst`, which do see it, or on the outline classes in the movie.

    A real wrong map looks different: the true k beats every other by an order of magnitude on
    BOTH mean and worst.  In testing, the true rotation read mean 0.0209 / worst 0.099 while the
    book's wrong one read 0.1190 / 0.845, and every other k was worse still.
"""
import json, os, sys

sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
import sb_build, sb_compose
from sb_read import Movie

CAND = []                     # <- the shortlist from find_wrong_maps.py
MOVES = "moves_full.json"

if not CAND:
    raise SystemExit("edit CAND at the top of this file with the shortlist from find_wrong_maps.py")

M = Movie("calib.json")
wins = sb_compose.species_windows(M, 0, M.nf - 1)
P = sb_compose.Peaks(M, wins, 0, M.nf - 1)
moves = json.load(open(MOVES))["moves"]


def rot_k(src, dst):
    n = len(src)
    for k in range(1, n):
        if all(dst[i] == src[(i + k) % n] for i in range(n)):
            return k
    return None


for idx in CAND:
    mo = moves[idx]
    sp, axis = mo["sp"], (0 if mo["axis"] == "cols" else 1)
    src, n = list(mo["src"]), len(mo["src"])
    book_k = rot_k(src, mo["dst"])
    if book_k is None:
        print("move[%d] %s %s f%03d-f%03d is not a plain rotation -- use alt_s30.py on it\n"
              % (idx, sp, mo["axis"], mo["f0"], mo["f1"]))
        continue
    frames = list(range(max(0, mo["f0"] - 1), min(M.nf - 1, mo["f1"] + 2) + 1))
    lo, hi = float(mo["lo"]), float(mo["hi"])
    print("=" * 100)
    print("move[%d]  %s %s  f%03d-f%03d   book rotation k=%d  (n=%d)"
          % (idx, sp, mo["axis"], mo["f0"], mo["f1"], book_k, n))
    rows = []
    for k in range(1, n):
        dst = [src[(i + k) % n] for i in range(n)]
        best = sb_build.fit_timing(P, M, sp, axis, src, dst, frames, lo, hi)
        if best is None:
            print("   k=%-2d  no fit" % k)
            continue
        _, a, b = best
        mean, worst, _ = sb_compose.verify(P, sp, axis, src, dst, a, b, frames, M)
        seq = sb_compose.progress_per_frame(P, sp, axis, src, dst, frames, M)
        free = [s[2] for s in seq if 0.02 < s[1] < 0.98]
        fr = (sum(free) / len(free)) if free else float("nan")
        rows.append((mean, worst, fr, k))
        print("   k=%-2d %s mean %.4f  worst %.3f  FREE %.4f (%d frames)"
              % (k, "<-- BOOK" if k == book_k else "        ", mean, worst, fr, len(free)))
    rows.sort()
    if rows:
        best_k = rows[0][3]
        if best_k == book_k:
            verdict = "ok -- the book agrees with the pixels"
        elif best_k + book_k == n:
            verdict = "DIRECTION DEGENERACY (k + book = n) -- check the outline classes, not the fit"
        else:
            verdict = "*** MISMATCH -- the book is probably wrong here ***"
        print("   --> best on mean is k=%d (mean %.4f, worst %.3f);  book has k=%d\n       %s"
              % (best_k, rows[0][0], rows[0][1], book_k, verdict))
