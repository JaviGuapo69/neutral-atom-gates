"""sb_audit.py -- PROVE the transcription is complete, instead of trusting "0 undetermined".

SKILL.md rule 27 and rule 36.  "0 undetermined" is NOT evidence of completeness: on c200 a buggy
guard silently emptied that list while four real moves were missing, and on c300 a whole block
exchange was half-written with its missing half never ENUMERATED at all, so it appeared in no list
of any kind.  Neither the census (atoms are conserved), nor the score (both blocks are where the
sheet says), nor render validation (the sheet is self-consistent) can see either failure.

So do the accounting explicitly.  Three checks, none of which existed before session 15:

  1. EVERY TRANSITION IS EXPLAINED.  For each transition enumerated from occupancy, there must be
     a move that JOINS that species and whose MIDPOINT lies inside the transition's frames --
     rule 29's test, not mere frame overlap.

  2. TRANSITIONS AND MOVES ACCOUNT FOR EACH OTHER, BOTH WAYS.  Every hole must be NAMED -- either
     reported undetermined or held back as a hand-measured readout/load -- and every move must
     explain at least one transition.  An unnamed hole is c300's failure (a move never enumerated);
     an IDLE move is how a duplicate or an invented one shows up, which is what c150 produced in
     f123-165 before `sb_full --events` stopped the solver fitting its readout transitions.
     (Rule 36 states this as "the transitions-minus-moves gap equals the cross-species joins,
     exactly", i.e. `gap == extra + holes`.  That arithmetic assumes each transition needs at most
     ONE move.  It holds on c150 and cannot hold in general: a transition whose block moves on both
     axes needs two moves, one per axis, and c540 has eleven -- so the formula reported an
     11-transition mismatch on a sheet with nothing missing at all.)

  3. NO TWO SPECIES CLAIM THE SAME SITE AT REST.  One trap holds one atom.  This is the check c200
     lacked -- it is what catches one half of a block exchange being written without the other,
     and it runs on the MEASURED rests, independently of what was emitted.

    python sb_audit.py --moves moves_full.json --rests rests_full.json

Exit status is 1 if any check fails, so it can gate a delivery.
"""
import argparse, json, sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--moves", required=True, help="moves_full.json from sb_full.py")
    ap.add_argument("--rests", required=True, help="rests_full.json from sb_full.py")
    a = ap.parse_args()

    rests = json.load(open(a.rests))
    mv = json.load(open(a.moves))
    moves = mv["moves"]
    undet = mv.get("undetermined", [])

    # A READOUT / LOAD transition is accounted for by a HAND-MEASURED row (section 7), not by a
    # fitted move: the departing block and its replacement are not one rigid motion.  `sb_full
    # --events` holds those back so the solver cannot invent a move for them, and they must count
    # as EXPLAINED here or the audit fails on the one thing it is not the judge of.  They are still
    # printed, because an unexplained readout is exactly as bad as any other hole -- the evidence
    # for it just lives in extra.json rather than in moves_full.json.
    readouts = mv.get("readouts", [])
    ro_keys = {(r["sp"], r["f0"], r["f1"]) for r in readouts}

    trs = sorted((t for v in rests.values() for t in v["transitions"]),
                 key=lambda t: (t["f0"], t["sp"]))
    und_keys = {(u["sp"], u["f0"], u["f1"]) for u in undet}
    print("%d transitions, %d moves, %d reported undetermined, %d readout/load held back\n"
          % (len(trs), len(moves), len(undet), len(readouts)))

    bad = 0

    # ---- 1. every transition explained (rule 29: the MIDPOINT must lie inside it)
    # Two ways a move explains a transition, and the first is exact.  `for_tr` is the transition
    # the move was FITTED for, recorded by `sb_build.emit` -- provenance, not inference.  The
    # midpoint test is still needed for the other kind of explanation, a rectangle that carries a
    # SECOND species (section 5), where the move was fitted for someone else's transition; that is
    # the case rule 29's guard exists for, and the midpoint is the right test for it.
    hits = {}
    for i, t in enumerate(trs):
        key = [t["sp"], t["f0"], t["f1"]]
        hits[i] = [m for m in moves
                   if m.get("for_tr") == key
                   or (t["sp"] in m["joins"]
                       and t["f0"] <= (m["fa"] + m["fb"]) / 2.0 <= t["f1"])]
    print("=== 1. transitions with no move that joins them and whose midpoint is inside them")
    holes = nro = nund = 0
    for i, t in enumerate(trs):
        if hits[i]:
            continue
        key = (t["sp"], t["f0"], t["f1"])
        holes += 1
        if key in ro_keys:
            nro += 1
            print("   %-22s %-3s %-12s f%03d..f%03d  x %s -> %s  y %s -> %s"
                  % ("readout/load (hand)", t["sp"], t["kind"], t["f0"], t["f1"],
                     t["x0"], t["x1"], t["y0"], t["y1"]))
            continue                    # explained by extra.json, not by a fitted move
        known = key in und_keys
        if known:
            nund += 1
        print("   %-22s %-3s %-12s f%03d..f%03d  x %s -> %s  y %s -> %s"
              % ("UNDETERMINED (reported)" if known else "*** SILENT HOLE",
                 t["sp"], t["kind"], t["f0"], t["f1"], t["x0"], t["x1"], t["y0"], t["y1"]))
        if not known:
            bad += 1
    if not holes:
        print("   (none)")

    # ---- 1b. every RELOCATING axis covered by a move on that axis
    print("\n=== 1b. every relocating axis of every transition covered by a move on that axis")
    axholes = 0
    for i, t in enumerate(trs):
        if (t["sp"], t["f0"], t["f1"]) in ro_keys:
            continue                           # hand-measured (section 7), not a fitted move
        for axis, k0, k1 in ((0, "x0", "x1"), (1, "y0", "y1")):
            if t[k0] == t[k1]:
                continue                       # this axis does not move: nothing to explain
            want = "cols" if axis == 0 else "rows"
            if not [m for m in hits[i] if m["axis"] == want]:
                axholes += 1; bad += 1
                print("   *** %-3s %-12s f%03d..f%03d  %s %s -> %s has no %s move"
                      % (t["sp"], t["kind"], t["f0"], t["f1"], want, t[k0], t[k1], want))
    if not axholes:
        print("   all covered")

    # ---- 2. transitions and moves account for each other, both ways
    #
    # Rule 36 asks that "the transitions-minus-moves gap equal the cross-species joins, exactly".
    # Its arithmetic form, `gap == extra + holes`, assumed each transition needs at most ONE move,
    # and that happens to hold on c150.  It cannot hold in general: a transition whose block moves
    # on BOTH axes legitimately needs two moves, one per axis, and c540 has eleven of those -- so
    # the formula read as an 11-transition mismatch on a sheet with nothing missing.  State the two
    # substantive facts instead, which are what rule 36 is actually after and are both exact:
    #
    #   * no transition is unexplained without being NAMED -- either reported undetermined or held
    #     back as a hand-measured readout/load.  A silent hole is the c300 failure;
    #   * no move is IDLE.  A move explaining no transition is a move fitted to nothing, which is
    #     how a duplicate or an invented move shows up (c150's two spurious f123-165 moves were
    #     exactly this before `--events` held those transitions back).
    per_move = {}
    for i in hits:
        for m in hits[i]:
            per_move.setdefault(id(m), 0)
            per_move[id(m)] += 1
    extra = sum(n - 1 for n in per_move.values() if n > 1)
    multi = sum(1 for n in per_move.values() if n > 1)
    idle = [m for m in moves if id(m) not in per_move]
    two_axis = sum(1 for i in hits if len(hits[i]) > 1)
    print("\n=== 2. do the transitions and the moves account for each other, both ways?")
    print("   %d transitions: %d explained by a move, %d holes (%d reported undetermined, "
          "%d held-back readout/load, %d SILENT)"
          % (len(trs), len(trs) - holes, holes, nund, nro, holes - nund - nro))
    print("   %d moves: %d explain at least one transition, %d IDLE" % (len(moves),
                                                                        len(per_move), len(idle)))
    print("   %d move(s) carry more than one transition (%d extra credits -- cross-species "
          "rectangles); %d transition(s) need more than one move (both axes move)"
          % (multi, extra, two_axis))
    for m in idle:
        bad += 1
        print("   *** IDLE MOVE, fitted to no transition: %s %s f%03d-%03d %s"
              % (m["sp"], m["axis"], m["f0"], m["f1"], m.get("for_tr")))
    if not idle:
        print("   no idle moves; every hole is named")

    # ---- 3. one trap holds one atom, on the MEASURED rests
    print("\n=== 3. do two species ever claim the same site AT REST?")
    occ, clash = {}, 0
    for nm, v in rests.items():
        for f0, f1, xs, ys in v["rests"]:
            for f in range(f0, f1 + 1):
                for x in xs:
                    for y in ys:
                        prev = occ.get((f, x, y))
                        if prev is not None and prev != nm:
                            clash += 1; bad += 1
                            if clash <= 20:
                                print("   *** f%03d site (%d,%d) claimed by %s and %s"
                                      % (f, x, y, prev, nm))
                        occ[(f, x, y)] = nm
    print("   %d clash(es) over %d species-frame-site claims" % (clash, len(occ)))

    print("\n%s  (AOM groups %s, peak %s)"
          % ("AUDIT CLEAN" if not bad else "*** AUDIT FAILED: %d problem(s)" % bad,
             mv.get("aom_groups"), mv.get("aom_peak")))
    if not bad and (undet or nro):
        print("   NOTE: clean means nothing is SILENTLY missing. %d transition(s) are still "
              "undetermined and %d are held back as readout/load -- those are known gaps, and the "
              "sheet is not complete until each has a row." % (len(undet), nro))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
