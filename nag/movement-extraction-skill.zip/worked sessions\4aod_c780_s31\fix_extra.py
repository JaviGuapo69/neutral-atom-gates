"""fix_extra.py -- the two hand-measured READOUT rows of extra.json name cols 14:26 for the departing Z1 / X1 block, but
both blocks had slid to cols 1:13 before their readout (Z1 at f070-079, X1 at f281-290).  With 14:26 the readout row
picked up 156 of its 312 sites (se_sim check3) and the stale atoms stayed at 1:13 x 25:36, so every later X0 move on
that block claimed two atoms per site.  Run once; idempotent."""
import json
ev = json.load(open("extra.json", encoding="utf-8"))
for e in ev:
    if e["event"] == "unload" and e["x_start"] == "-12:0,14:26":
        e["x_start"] = e["x_finish"] = "-12:0,1:13"
        e["note"] = ("[s31 CORRECTION: the departing block is on cols 1:13, not 14:26 -- Z1 slid 14:26->1:13 at f070-079 and X1 at "
                     "f281-290; with 14:26 the readout row picked up 156 of 312 sites (se_sim check3) and the stale atoms stayed at "
                     "1:13 x 25:36, so every later X0 move there claimed two atoms per site] ") + e["note"]
json.dump(ev, open("extra.json", "w", encoding="utf-8"), indent=1)
print("\n".join("%-6s %-5s x %s -> %s" % (e["event"], e["species"], e["x_start"], e["x_finish"]) for e in ev))
