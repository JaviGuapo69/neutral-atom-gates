# Session 26 (2026-09-15, afternoon) — the PATCH DETECTOR feeding the production solver

**Written for: the user (Javier).** Follows `SESSION_25_C540_ROOT_CAUSE.md` (same day, morning).
Read that first for why the production skill fails on c540; this document is about the second
change, the one that recovers the sub-comb batches.

---

## 0. Where everything is

| | |
|---|---|
| **production skill** | `.claude/skills/se-cycle-blocks/` — UNTOUCHED |
| **backup of production, made this session** | `.claude/skill_archive/se-cycle-blocks-PRODUCTION-BACKUP-2026-09-15/` (identical hash on `sb_build.py`; `WHY_THIS_BACKUP_EXISTS.md` inside) |
| **the candidate skill** | `.claude/skills/se-cycle-blocks-s25/` = production + S2.1 competition (session 25) + **`tools/sb_gaps.py`** (this session), wired into `tools/sb_full.py` behind `--gaps on|off` (default on) |
| **detector source** | `tools/sb_patch.py`, copied from the session-23 test fork; only `patch_movements` is used |
| **c540 result** | `run_c540_s26/` (see §3) |

---

## 1. What was built, and the corrections that make it different from the session-23 hybrid

The user's idea: the patch method as an alternative for the rest-frame method where the latter
fails. Kept as the architecture, with the division of labour narrowed:

* **the patch route answers WHERE and on WHICH LINES** — `sb_patch.patch_movements` reads, per
  species and outline colour, the moving axis, the comb on the static axis (rule 44: the outline
  colour names the column pair the batch drives) and a rough frame range;
* **the production machinery answers WHAT and WHEN** — peaks restricted to the detected comb
  (`sb_build.SubPeaks`), the transition read rest-to-rest ON THE SUB-COMB, the production candidate
  routes (`partition`, `measured_partition`, counted `rotation_candidates`, the S2.1 rotations of
  the measured moving run), the production `fit_timing` and `verify`.

So none of the hybrid's defects can recur by construction: the window comes from the easing fit
on the sub-comb, not from the ring's visibility; the score is the production score; there is no
patch-side map to commit.

**Four gates**, each of which is what keeps c150/c200/c300 unchanged (they have no sub-comb move):

1. the detected comb must be a STRICT subset of the block's extent on the static axis;
2. during the motion window nothing OUTSIDE the comb may leave its tones (rule 40, measured with
   `sb_build.sub_comb`), with the read window clamped to the neighbouring moves of the same species
   so a chained batch is not read through its predecessor;
3. a whole-block move of the species containing the detection's midpoint explains it — not a gap.
   A sub-comb move production already wrote on the same comb is **competed against** on the same
   peaks and frames (rule 42) and replaced only if the detector's read is under 0.10 and better by
   0.01;
4. the winning candidate must score ≤ 0.10 on the MOVING frames; otherwise the gap stays
   undetermined and says so.

Plus one post-pass: two sub-comb moves of one species on one comb with overlapping windows are one
batch fitted twice (`c540_faults_vs_shayne.md` §2.4); the better-scoring one is kept.

Every gap move carries `from_patch_detector=True` and `sub_comb_lines`, and a synthetic transition
is appended to the rest record so `sb_audit` accounts for it.

## 2. Segment 6 — the development target (frames 189–247, six column-pair batches × 3 species)

Iterated three times on this segment, each time against the hand book (the user's instruction:
fix a known failure before analysing more movements with it):

| | production | S25 (S2.1 only) | detector v1 | detector v2 | **detector v3 (final code)** |
|---|---|---|---|---|---|
| moves | 10 | 10 | 19 | 19 | **19** |
| undetermined | 0 | 0 | 0 | 0 | 0 |
| hand-book movements matched (of 19) | ~9 | ~9 | 15 | 17 | **18** |

Recovered by the detector: X1 on {14,20}, {15,21}, {16,22}, {17,23}; Z0 on {15,21}, {17,23},
{18,24}; Z1 on {14,20}, {15,21}, {16,22}, {17,23}, {18,24} — all at 0.03–0.05 site, all the hand
book's maps. Two production maps were REPLACED after competing on the same peaks: Z0 {17,23}
`1:4→6:9 | 5:9→1:5` (0.33 on the moving frames) → `1:6→4:9 | 7:9→1:3` (0.05); X1 {17,23}
`19:22→24:27 | 23:27→19:23` (0.18) → `24:27→19:22 | 19:23→23:27` (0.045). Production's duplicate
fit of the X1 {17,23} batch was dropped.

What each iteration fixed:

* **v1 → v2**: Z1 on {14,20} was refused by gate 2 because its read window reached into the
  previous whole-block move; the window is now clamped to the neighbouring moves of the same
  species. And a detection "explained" by an existing SUB-COMB move now competes with it instead
  of being dismissed (a whole-block explanation still ends it).
* **v2 → v3**: X1 on {17,23} scored 0.20 because production's duplicate fit of the same batch was
  treated as a neighbour and cut the window to four frames; moves on the same comb are now
  competitors, not neighbours.

Still wrong in segment 6 after v3 — one movement:

* **Z1 rows f200-208**, whole block on cols 13:24. Production's appearance read
  `10:13→14:17 | 15→18 | 14→10 | 16:18→11:13` against the hand book's rotation by +4
  (`10:14→14:18 | 15:18→10:13`): rows 14 and 15 have their destinations transposed. It scores
  0.078 on the moving frames — UNDER the guideline — because the two maps predict nearly the same
  peak positions mid-flight (rule 31's dilution over the correspondence, the M2 mechanism of
  `c540_v3_diagnosis.md`). The S2.1 competition cannot fire (no tone is held static) and the
  detector leaves whole-block moves alone. **Added for the final run, untested on this segment when
  the run started**: a same-site read in 3+ parts competes against the two-group rotations of its
  comb and is kept only if it beats the best rotation by more than 0.03 site (`ROTATION_NOISE`),
  the rule `c540_faults_vs_shayne.md` §2.1 fix 2 proposed. Whether it fires here is in §3.

## 3. Whole movie — `run_c540_s26\c540_s26_blocks.xlsx`

Compared with Shayne's hand book on **start and end place per line** (displacement sets at a
shared time boundary, `run_c540_v3\cmp_full.py`, ±0.12 ms), blind to AOM numbering and to how a
movement is split across rectangles — the criterion the user set.

| | production (session 16) | S25 (S2.1, this morning) | **S26 (S2.1 + detector + rotation-noise rule)** |
|---|---|---|---|
| moves / undetermined | 78 / 7 | 76 / 8 | **88 / 8** |
| sheet movements matching the hand book | 61 of 82 | 69 of 80 | **86 of 92** |
| hand-book events fully / partly / not accounted for (53) | 34 / 12 / 7 | 37 / 9 / 7 | **47 / 4 / 2** |
| hand-book displacement entries accounted (217) | 162 | 170 | **200** |
| `se_sim` census | conserved; check3 ×2 at the f315 hole | same | same |

(Final numbers, after the S2.1 gate was widened to 0.13 on the user's instruction — §5.1 — which
brought `X0 rows f140-146` back to the hand book's rotation.)

**The 6 sheet movements the hand book "does not have"** are not errors of the same kind:
4 are the readouts/loads (+9 descents and the −8:0→1:9 carry-in) which the hand book omits (its
known M4 gap); `X0+X1 rows f104-114 1:2→8:9 | 3:9→1:7` is a comparator artefact (Shayne writes
that move across two batch rows with a blank between, `c540_faults_vs_shayne.md` §1.2); leaving
**one genuine disagreement**: `X0+X1 rows f152-154` (wrong in every book so far; the hand book
has +2 on rows 10, 13, 16 — to adjudicate on the pixels).

**The hand-book movements still missing (2 events not at all, 4 partly)** are all of one class —
whole-block transitions production reports UNDETERMINED and this change was not aimed at:

| hand book | what it is | why still missing |
|---|---|---|
| t 0.24 `13:18↔19:24` on y 19:27 | Z0 f001-007 rotation +6 | no appearance read; the last-resort rotation (session 25) recovers it but must move after the "carried" filter |
| t 7.85 `14:24→13:23 | 13→24` | X1 f247-256 rotation −1 | same class |
| t 10.02 `13:22→3:12 | 23:24→1:2` | Z0/Z1 f315-328 relocation+wrap | `MAX_SPAN = 16` cannot express |D| = 22 |
| t 10.26 rotations +5/+5/+7 | Z0, Z1, X0 f329-336 | undetermined; the counted-rotation route on the whole block |
| t 10.85 `13:18↔19:24` on y 1:9 | f348-355 six-frame rotation | lost to rest detection |
| t 11.71 `19,22,25→21,24,27` | Z0 f380-383 | undetermined |

**Against this morning's S25 book** (`s26_vs_s25.txt`): 68 identical; 4 maps changed — Z1 f200-208
and X1 {17,23} to the hand book's (rotation-noise rule and detector), X0 f140-146 and X0+X1
f152-154 back to production's (the 0.10 gate, §5); 4 gone (X0 and X1 f081-088 merged into one
X0+X1 rotation = the hand book's, the X1 {17,23} duplicate, the replaced Z0 {17,23}); 16 new — 15
detector moves on the column pairs plus the joined f081-088.

**Audit** (`audit_s26.txt`, delivered book): 122 transitions, 109 explained, 0 idle moves, 0 rest
clashes over 87,696 claims; **3 problems**: the two known f315-328 relocation holes (as in every
book) and ONE bookkeeping "silent hole", `X1 permutation f236-238` — the transition of production's
duplicate fit of the X1 {17,23} batch, which the dedupe pass dropped without its transition. The
batch itself is in the book (`X1 rows f232-238 24:27→19:22 | 19:23→23:27`, the hand book's map).
Fixed in `sb_gaps.py` for future runs (the dropped duplicate's transition goes with it); not worth
another 45-minute solve for the delivered file. The earlier replace-bookkeeping defect (transition
swapped with the move) is also fixed and verified on this book: 0 idle moves.

## 4. Regressions (the fork's `sb_full.py --events`, detector ON, all three closed movies)

Compared with `tools/cmp_tol.py` (maps identical, ≤1 frame window shift tolerated):

| movie | reference | result |
|---|---|---|
| c150 | `reg_c150\fix\moves_full.json` (55) | **55/55 identical, maps and windows.** Detector: 0 moves added (one refusal at 2.48 site, gate 4). S2.1 and the 3-part rule: 0 firings |
| c300 | `reg_c300_fix\moves_full.json` (64) | **64/64 identical.** Detector 0, S2.1 0, 3-part rule 0 |
| c200 | `reg_c200\moves_full.json` (production's own 2026-09-14 run, 69) | **69/69 identical.** The 3-part rule fired 3 times and KEPT the appearance read each time (rotations 0.18–0.23 against reads 0.03–0.11); S2.1 fired once and its winner is production's own map |
| c200 | `reg_c200\accepted_moves_full.json` (session 14, 69) | 68 identical + 1 window shift of one frame (`Z0+Z1 cols f276-287` → `f276-288`), the documented pulse-bound convention change production itself shows |

The detector fired on all three movies (partial-colour patches) and every detection was dismissed
by gate 3 as explained by the whole-block move, which is exactly the inertness the design claims.
The regressions ran with the S2.1 gate at 0.10; the final code has 0.13 (§5.1). That cannot change
them: the gate only decides where S2.1 fired and was refused, and that happened 0 times on c150 and
c300 and 0 times on c200 (its one firing won under 0.10).

## 5. Open items and questions

1. **The S2.1 gate was knife-edge in one place and was widened on the user's instruction.** On
   `X0 rows f140-144` the S2.1 candidate `13:17→14:18 | 18→13` (the hand book's map, and X1's)
   scored **0.1004** against a 0.10 bar and was refused. The bar is now `ACCEPT + ROTATION_NOISE`
   = 0.13 — the same crossing-noise tolerance the 3-part rule uses, so it is one rule rather than
   a constant tuned to one case. `f093-095`'s 0.2193 is still refused by a wide margin. The
   detector's own gate 4 stays at 0.10 (widening it would admit a spurious Z1 detection at 0.1066
   on a 10-of-12 comb in segment 7).
2. **The last-resort rotation after the "carried" filter** (session 25, tested on segment 0) would
   recover Z0 f001-007 and probably X1 f247-256, f329-336 and f380-383 — the rest of the missing
   list except the relocation. Needs the ordering fix and a regression.
3. **`MAX_SPAN`** for the f315-328 relocation+wrap. Everything after f328 is still twelve columns
   out in every book.
4. `X0+X1 rows f152-154`: adjudicate on the pixels; no book has the hand book's +2 on rows 10, 13, 16.
5. Speed: the whole movie now takes ~45 min as two halves. `sb_full` still writes only at the end.
