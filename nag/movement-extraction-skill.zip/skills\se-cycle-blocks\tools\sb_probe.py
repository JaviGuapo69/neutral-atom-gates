"""sb_probe.py -- LOOK AT THE PIXELS.  The tool that found every defect in session 13.

Two modes.  Use them whenever `sb_full` reports a transition UNDETERMINED, or emits a move whose
map looks odd, or scores one badly.  Do not reason about what the tool "should" have done -- read
what is actually on the frames, by hand, and only then decide which rule is being broken.

  --peaks    per-frame FILL peaks and, separately, every OUTLINE colour's peaks, for one species on
             one axis in one window.  This is the ground truth: each outline colour profiled on its
             own is an appearance class (3z), and the two sub-blocks of a move carry different
             colours, so they stay resolved right through a crossing where the shared fill merges.
             Read src at the first frame and dst at the last, and the displacements fall out.

  --classes  replay `sb_build`'s own partition read for ONE transition and print every step: the
             candidate classes, each one's measured src/dst/D, its rigidity residual, whether it
             passed the arrival test, and what `partition()` finally returned.  This is how you see
             WHY a move was rejected rather than guessing.

    python sb_probe.py --calib calib.json --peaks   --sp X0 --axis 0 --f0 167 --f1 180 \
                       --win=0.45,6.55,10.43,15.60
    python sb_probe.py --calib calib.json --classes --sp X0 --axis 0 --seg 190,223 --tr 192,203

For --classes, `--seg` must be the SEGMENT sb_full solved (so the windows and the discovered
outline palette match exactly what it used) and `--tr` the transition's frame range as sb_full
printed it.  Get the window for --peaks from the segment's printed windows, and keep it TIGHT: a
window that reaches into another species' territory picks up that species' outline, because the
outline mask is shared across the panel.

WHAT THE ANSWERS USUALLY MEAN, from the nine defects this found on c150:

  * classes read correctly but `partition()` returned fewer than two, or nothing
        -> a class was rejected. Look at which: `rigid=False` on a class whose members travel
           DIFFERENT distances means it is two sub-blocks and must be SPLIT (rule 19), not dropped.
           `rigid=False` with one bad frame among many good ones is a crossing contaminating the
           spread (rule 26).
  * classes read correctly and the move is still rejected
        -> a THIRD part is colliding with them. A colour on a handful of frames is a blend; a
           colour whose peak count wanders reads its src/dst off dropout frames; a colour that is a
           strict subset of another with the same displacement is the anti-aliased twin (rule 24).
  * the fill shows NO motion at all over the transition's frames
        -> you are looking at the wrong axis. A same-site permutation on columns leaves the rows
           dead still, and vice versa.
  * peak count is 6, 6, 6, 4, 4, 6, 6 across the window
        -> the frames after the count recovers are POST-crossing and their peak order is scrambled;
           the correspondence is only free on the leading run (rule 20).
  * the species' fill area is 0 in its own window
        -> the block is not there. Anything the outline reports in that window belongs to a
           different species (rule 23).
"""
import argparse, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sb_read, sb_compose, sb_rigid, sb_build
from sb_read import Movie, comb


def peaks_mode(M, sp, axis, f0, f1, win):
    frames = list(range(f0, f1 + 1))
    outs = sb_read.discover_outlines(M, [f for f in frames if f not in M.gate], win)
    print("window %s" % (win,))
    print("outline colours here: %s"
          % ", ".join("rgb(%.0f,%.0f,%.0f)" % c for c in outs))
    print("(profile each ON ITS OWN -- that is the appearance class. The fill merges at a crossing;")
    print(" colour-separated profiles do not, because the crossing partners carry different colours)")
    fmt = lambda v: " ".join("%6.2f" % x for x in v)
    for f in frames:
        print("f%03d%s" % (f, "  [pulse]" if f in M.gate else ""))
        print("    fill            a%6d  %s"
              % (M.area(M.fill[sp], win, f), fmt(M.peaks(M.fill[sp], win, f, axis))))
        fa = M.area(M.faded[sp], win, f)
        if fa >= 200:
            print("    faded fill      a%6d  %s   <- stock or a readout descending (rule 3)"
                  % (fa, fmt(M.peaks(M.faded[sp], win, f, axis))))
        for c in outs:
            ar = M.area(c, win, f)
            if ar < 60:
                continue
            print("    rgb(%3.0f,%3.0f,%3.0f) a%6d  %s"
                  % (c[0], c[1], c[2], ar, fmt(M.peaks(c, win, f, axis))))


def classes_mode(M, sp, axis, seg, tr, blocks=None):
    f0, f1 = seg
    tf0, tf1 = tr
    wins = sb_compose.species_windows(M, f0, f1)
    frames_all = [f for f in range(f0, f1 + 1) if f not in M.gate]
    outlines = sb_read.discover_outlines(M, frames_all[:40], (0.4, M.K["data_cols"] + 0.6,
                                                              0.4, M.K["data_rows"] + 0.6))
    ivs = sb_compose.free_intervals(sb_compose.pulse_runs(M), M.nf)
    iv = sb_rigid.interval_of(ivs, tf0, tf1)
    if iv is None:
        print("that transition does not lie inside any pulse-free interval -- check --tr")
        return
    frames = [f for f in range(max(tf0, iv[0]), min(tf1, iv[1]) + 1) if f not in M.gate]
    print("segment f%d..f%d   window for %s: %s" % (f0, f1, sp,
                                                    tuple(round(v, 2) for v in wins[sp])))
    print("outlines: %s" % ", ".join("rgb(%.0f,%.0f,%.0f)" % c for c in outlines))
    print("interval %s -> partition read on frames %s" % (iv, frames))

    # The transition's DESTINATION SET, from the settled configuration on the far side.  `partition`
    # uses it as rule 18's adjudicator when the arrival test fails because the move finishes AT the
    # pulse (sb_build.arrived), so the diagnostic must have it too -- otherwise this tool reports
    # fewer parts than `build` actually found, which is the opposite of its job.
    S2 = None
    if blocks:
        P0 = sb_compose.Peaks(M, wins, f0, f1)
        bl = {k: tuple(v) for k, v in blocks.items() if k in wins}
        rests = sb_build.settled(P0, M, f0, f1, bl, wins, outlines, verbose=False)
        for t in rests.get(sp, {}).get("transitions", []):
            if t["f0"] == tf0 and t["f1"] == tf1:
                S2 = sorted(t["x1"] if axis == 0 else t["y1"])
        print("destination set from the settled configuration: %s"
              % (comb(S2) if S2 else "NOT FOUND -- check --tr against the printed transitions"))
    else:
        print("no --blocks given: rule 18's destination set is unavailable, so the arrival test")
        print("below has no escape hatch and this may show FEWER parts than sb_full found.")

    cls = sb_build.classes(M, sp, wins[sp], frames, outlines)
    usable = [f for f in frames if f not in M.gate]
    print("\n%d candidate class(es) passed the coverage bar (>= %d of %d frames -- rule 24)"
          % (len(cls), max(2, int(sb_build.CLASS_COVERAGE * len(usable))), len(usable)))
    for c in cls:
        got = sorted(c["per"])
        print("  rgb(%6.1f,%6.1f,%6.1f)  on %d frames, peak counts %s"
              % (c["colour"] + (len(got),
                                sorted({len(c["per"][f][axis]) for f in got}))))
        r = sb_rigid.rigid_displacement(c, axis, frames)
        if r is None:
            print("      -> None: fewer than two frames at the modal peak count")
            continue
        if r.get("bad"):
            print("      -> members travel DIFFERENT distances: %s"
                  % [d - s for s, d in zip(r["src"], r["dst"])])
            print("         src %s dst %s -- rule 19 says SPLIT this class, do not drop it"
                  % (comb(r["src"]), comb(r["dst"])))
            parts = sb_build.split_class(c, axis, frames, r["src"], r["dst"])
            print("         split -> %s"
                  % ("; ".join("%s->%s (D=%+d, rigid %.3f)"
                               % (comb(p[0]), comb(p[1]), p[2], p[3]) for p in parts)
                     if parts else "REFUSED: a group was not rigid on its own"))
            continue
        print("      -> src %-14s dst %-14s D=%+d   rigid=%s"
              % (comb(r["src"]), comb(r["dst"]), r["D"], r["rigid"]))
        print("         residual %.3f (robust, rule 26)  worst %.3f on f%s  over %d frames"
              % (r["rigid_residual"], r.get("rigid_residual_worst", r["rigid_residual"]),
                 r.get("worst_frame"), r.get("n_frames", 0)))
        last = [f for f in frames if f in c["per"]][-1]
        pk = c["per"][last][axis]
        off = max(abs(v - round(v)) for v in pk) if pk else float("nan")
        print("         arrival test on f%d: %d peaks (need %d), worst off-tone %.3f (need <= %.2f)"
              "%s"
              % (last, len(pk), len(r["src"]), off, sb_build.ARRIVED,
                 "" if off <= sb_build.ARRIVED else
                 "  -- FAILED, so rule 18 decides: dst %s %s the destination set"
                 % (comb(r["dst"]),
                    "is inside" if sb_build.arrived(pk, r["src"], r["dst"], S2)
                    else "is NOT inside")))

    notes = []
    part, sub = sb_build.partition(M, sp, wins[sp], axis, frames, outlines, notes, S2)
    print("\npartition() -> %d part(s), read on f%d..f%d" % (len(part), sub[0], sub[-1]))
    for p in part:
        print("   %-14s -> %-14s  D=%s  resid=%s  from %s"
              % (comb(p[0]), comb(p[1]), p[2], p[3], p[4]))
    if len(part) < 2:
        print("   fewer than two parts, so the appearance read fails here and sb_full falls back")
        print("   to the measured displacements (3a). Check the peak counts above: the")
        print("   correspondence is only free on the LEADING run at full count (rule 20).")
    for n in notes:
        print("   note: %s" % n)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--sp", required=True)
    ap.add_argument("--axis", type=int, required=True, help="0 = cols, 1 = rows")
    ap.add_argument("--peaks", action="store_true")
    ap.add_argument("--classes", action="store_true")
    ap.add_argument("--f0", type=int)
    ap.add_argument("--f1", type=int)
    ap.add_argument("--win", default="", help="c0,c1,r0,r1 -- use --win=-0.6,13.6,0.4,5.6 for "
                                              "negatives, or PowerShell eats the leading dash")
    ap.add_argument("--seg", default="", help="f0,f1 of the segment sb_full solved")
    ap.add_argument("--tr", default="", help="f0,f1 of the transition")
    ap.add_argument("--blocks", default=None, help="blocks.json -- pass it for --classes, so the "
                                                   "replay sees rule 18's destination set")
    a = ap.parse_args()

    M = Movie(a.calib, a.frames)
    if a.peaks:
        if a.win:
            win = tuple(float(v) for v in a.win.split(","))
        else:
            vc, vr = M.K["visible_col"], M.K["visible_row"]
            win = (vc[0] - 0.45, vc[1] + 0.45, vr[0] - 0.45, vr[1] + 0.45)
            print("no --win given: using the whole visible panel. Fine for a fill, but the OUTLINE")
            print("mask is shared across the panel, so tighten it before trusting outline peaks.")
        peaks_mode(M, a.sp, a.axis, a.f0, a.f1, win)
    elif a.classes:
        classes_mode(M, a.sp, a.axis,
                     [int(v) for v in a.seg.split(",")], [int(v) for v in a.tr.split(",")],
                     json.load(open(a.blocks)) if a.blocks else None)
    else:
        print("pass --peaks or --classes")


if __name__ == "__main__":
    main()
