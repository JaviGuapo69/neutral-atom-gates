"""lineprof.py -- the fill profile of ONE species taken line by line (rule 40: a move may ride a sub-comb of
the block's lines on the non-moving axis).  For every frame and every line of the block on the OTHER axis it
prints the peaks along `axis` restricted to that line's half-pitch strip, and flags the lines whose peaks are
off their tones (moving).  This is the reading the whole-window profile cannot give: the static majority
swamps the moving minority there.

    python lineprof.py SP AXIS F0 F1 C0 C1 R0 R1 [L0 L1]
      AXIS 0 = peaks along columns, one line per ROW (lines default r0+0.5..r1-0.5)
      AXIS 1 = peaks along rows, one line per COLUMN
"""
import os, sys
sys.path.insert(0, os.path.join("..", ".claude", "skills", "se-cycle-blocks", "tools"))
from sb_read import Movie

sp, axis, f0, f1 = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
c0, c1, r0, r1 = [float(v) for v in sys.argv[5:9]]
if len(sys.argv) > 10:
    L0, L1 = int(sys.argv[9]), int(sys.argv[10])
else:
    L0, L1 = (int(r0 + 0.6), int(r1 - 0.6)) if axis == 0 else (int(c0 + 0.6), int(c1 - 0.6))
M = Movie("calib.json")
win = (c0, c1, r0, r1)
other = 1 - axis
print("%s axis %d (%s), window %s, lines %d..%d" % (sp, axis, "cols per row" if axis == 0 else "rows per col", win, L0, L1))
for f in range(f0, f1 + 1):
    tag = "  [pulse]" if f in M.gate else ""
    print("f%03d%s" % (f, tag))
    moving = []
    for L in range(L0, L1 + 1):
        pk = M.peaks(M.fill[sp], win, f, axis, keep=(other, [L]))
        if not pk:
            print("   %s%2d: (none)" % ("r" if axis == 0 else "c", L))
            continue
        off = max(abs(v - round(v)) for v in pk)
        flag = " <-- MOVING" if off > 0.15 else ""
        if off > 0.15:
            moving.append(L)
        print("   %s%2d: %s%s" % ("r" if axis == 0 else "c", L, " ".join("%6.2f" % v for v in pk), flag))
    print("   moving lines: %s" % (moving if moving else "none"))
