﻿<#
deliver_s31.ps1 -- render, score, sb_watch and side-by-side videos for the session-31 c780 book
(the automatic run_c780 book + the hand corrections of apply_s31.py).

Run from run_c780_s31.  Same chain as run_c780\deliver_c780.ps1 / run_c630_s30\deliver_s30.ps1.
The movie frames are run_c780\frames (calib.json's frames_dir points there too).

    .\deliver_s31.ps1
#>
param([switch]$SkipVideo, [string]$Xlsx = "c780_s31_blocks.xlsx", [string]$Tag = "s31", [string]$RDir = "rframes")

$ErrorActionPreference = "Continue"
$ROOT = Split-Path $PSScriptRoot
$SB   = Join-Path $ROOT ".claude\skills\se-cycle-blocks\tools"
$SE   = Join-Path $ROOT ".claude\skills\se-cycle-movies\tools"
$env:Path += ";C:\Users\HP\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.1-full_build\bin"
$env:PYTHONIOENCODING = "utf-8"
Set-Location $PSScriptRoot

function Step($name, $block) {
  Write-Output ""
  Write-Output ("=" * 78)
  Write-Output "== $name   $(Get-Date -Format HH:mm:ss)"
  Write-Output ("=" * 78)
  & $block
}

Step "1. se_calibtxt -- the render calibration that matches the movie" {
  python "$SE\se_calibtxt.py" --calib calib.json --out-txt movie_calib.txt `
         --out-json render_calib.json --render-frames "$PSScriptRoot\$RDir" --tone-divisor 1
}

Step "2. render.ps1 -- workbook back to 384 frames" {
  & "$SE\render.ps1" -Xlsx $Xlsx -OutDir "$PSScriptRoot\$RDir" `
    -LogCsv "$PSScriptRoot\render_log_$Tag.csv" -MatchCalib "$PSScriptRoot\movie_calib.txt"
  $n = (Get-ChildItem "$PSScriptRoot\$RDir" -Filter "p_*.png" -ErrorAction SilentlyContinue).Count
  $v = (Get-Content "$PSScriptRoot\render_log_$Tag.csv" -ErrorAction SilentlyContinue | Measure-Object -Line).Lines
  Write-Output "rendered $n frames; validation log lines (incl. header): $v"
}

Step "3. sb_score -- the profile score against the movie" {
  python "$SB\sb_score.py" --movie-calib calib.json --render-calib render_calib.json `
         --out "score_$Tag.txt" | Select-Object -Last 20
}

Step "3b. sb_watch -- every (frame, species, axis) cell, local runs" {
  python "$SB\sb_watch.py" --movie-calib calib.json --render-calib render_calib.json `
         --thresh 0.35 --min-run 3 > "watch_$Tag.txt"
  Get-Content "watch_$Tag.txt" | Select-Object -Last 12
}

if ($SkipVideo) { Write-Output "`n-SkipVideo: stopping before the mp4s"; exit 0 }

Step "4. sb_video -- the side-by-side comparison videos" {
  & "$SB\sb_video.ps1" -MovieFrames "$ROOT\run_c780\frames" -RenderFrames "$PSScriptRoot\$RDir" `
    -Calib "$PSScriptRoot\calib.json" `
    -OutPanels "$PSScriptRoot\c780_${Tag}_original_vs_rebuild_panels.mp4" `
    -OutFull   "$PSScriptRoot\c780_${Tag}_original_vs_rebuild_full.mp4"
}
Write-Output "DONE $(Get-Date -Format HH:mm:ss)"


