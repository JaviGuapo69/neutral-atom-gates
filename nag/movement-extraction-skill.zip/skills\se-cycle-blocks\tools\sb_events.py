"""sb_events.py -- FIND the readouts and the loads.  SKILL.md section 7, procedure step 6.

Nothing automatic transcribes a readout or a load: a readout has no outline and no solid fill (the
block desaturates and descends or ascends off panel) and a load's stock is FADED until the instant
it joins the cycle, so neither the outline reader nor the occupancy test sees them, and `sb_full`
never emits them.  Step 6 says "find them first" and, until session 15, left you to do that by
eye across 384 frames.

This is that search, done on the pixels:
  * a READOUT is where a species' SOLID area collapses while its FADED area jumps, and the faded
    block then travels off panel;
  * a LOAD is where FADED stock turns SOLID -- the frame the stock joins the cycle (rule 3);
  * the STOCK itself shows up as a small, motionless faded (or solid) area parked outside the
    array, often at HALF-INTEGER tones (see the reservoir note).

    python sb_events.py --calib calib.json                  # the summary: candidate events
    python sb_events.py --calib calib.json --full           # every frame, for reading by hand

Feed what you find to sb_extra.py as a jobs file, then hand-write the unload / load / move rows.
Read the areas, not just the flags: a pulse frame's tint makes the faded mask meaningless, so gate
frames are skipped throughout.
"""
import argparse, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sb_read import Movie

JUMP = 3.0              # x: an area ratio that counts as a jump rather than drift
FLOOR = 300             # px: below this there is effectively nothing of that colour


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--full", action="store_true", help="print every frame, not just the events")
    a = ap.parse_args()

    M = Movie(a.calib, a.frames)
    K = json.load(open(a.calib))
    vc, vr = K["visible_col"], K["visible_row"]
    win = (vc[0] - 0.5, vc[1] + 0.5, vr[0] - 0.5, vr[1] + 0.5)
    names = [s["name"] for s in K["species"]]
    frames = [f for f in range(M.nf) if f not in M.gate]

    A = {}
    for nm in names:
        for f in frames:
            A[(nm, "solid", f)] = M.area(M.fill[nm], win, f)
            A[(nm, "faded", f)] = M.area(M.faded[nm], win, f)

    if a.full:
        print("frame  " + "  ".join("%-17s" % (n + " solid/faded") for n in names))
        for f in frames:
            print("f%03d   " % f + "  ".join("%7d/%7d " % (A[(n, "solid", f)], A[(n, "faded", f)])
                                             for n in names))
        print()

    print("=== candidate events (read them, then confirm with sb_probe.py --peaks)\n")
    for nm in names:
        prev = None
        for f in frames:
            s, d = A[(nm, "solid", f)], A[(nm, "faded", f)]
            if prev is not None:
                ps, pd = prev
                # READOUT: solid collapses and faded jumps in the same step
                if ps > FLOOR and s < ps / JUMP and d > max(FLOOR, pd * JUMP):
                    print("  %-3s f%03d  READOUT?  solid %6d -> %-6d   faded %6d -> %-6d"
                          % (nm, f, ps, s, pd, d))
                # LOAD: faded stock turns solid
                if pd > FLOOR and s > max(FLOOR, ps * JUMP) and d < pd / JUMP:
                    print("  %-3s f%03d  LOAD?     faded %6d -> %-6d   solid %6d -> %-6d"
                          % (nm, f, pd, d, ps, s))
                # stock appearing solid with no faded precursor (c200's X stock did this)
                if ps <= FLOOR and s > FLOOR * 2:
                    print("  %-3s f%03d  APPEARS   solid %6d -> %-6d (stock, or a block entering "
                          "the panel)" % (nm, f, ps, s))
                if ps > FLOOR * 2 and s <= FLOOR:
                    print("  %-3s f%03d  VANISHES  solid %6d -> %-6d (off panel, occluded, or "
                          "read out)" % (nm, f, ps, s))
            prev = (s, d)
        print()

    print("=== parked stock: frames where a species' faded area is small, steady and non-zero")
    for nm in names:
        runs, cur = [], None
        for f in frames:
            d = A[(nm, "faded", f)]
            ok = FLOOR < d < 4000
            if ok and cur is None:
                cur = [f, f]
            elif ok:
                cur[1] = f
            elif cur is not None:
                runs.append(tuple(cur)); cur = None
        if cur is not None:
            runs.append(tuple(cur))
        for r in runs:
            if r[1] - r[0] >= 8:
                print("  %-3s f%03d-f%03d  faded ~%d px  -- probe its peaks: the reservoir usually "
                      "sits at HALF-INTEGER tones" % (nm, r[0], r[1], A[(nm, "faded", r[0])]))


if __name__ == "__main__":
    main()
