"""merge_halves.py -- two (or more) partial sb_full runs (--only ...) -> one moves_full.json,
rests_full.json and workbook, using sb_full.merge exactly as a single run would.

    python merge_halves.py --calib calib.json --blocks blocks.json --extra extra.json \
        --out OUTDIR --xlsx OUTDIR/book.xlsx  partA_dir partB_dir ...
"""
import argparse, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "prod_s21"))
import sb_read, sb_compose, sb_emit, sb_full            # noqa: E402
from sb_read import Movie                                # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--blocks", required=True)
    ap.add_argument("--extra", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--xlsx", default="")
    ap.add_argument("parts", nargs="+")
    a = ap.parse_args()

    per = []
    for i, d in enumerate(a.parts):
        # `dir@f0-f1` drops that part's moves/undetermined whose window lies inside [f0, f1] --
        # used to replace one segment of a run with a re-solved copy of it.  Rests and transitions
        # are left in: settled() is identical between the two and merge() dedups them exactly.
        drop = None
        if "@" in d:
            d, rng = d.split("@", 1)
            drop = tuple(int(v) for v in rng.split("-"))
        mv = json.load(open(os.path.join(d, "moves_full.json")))
        rs = json.load(open(os.path.join(d, "rests_full.json")))
        if drop:
            keep = lambda m: not (drop[0] <= m["f0"] and m["f1"] <= drop[1])
            n0 = len(mv["moves"])
            mv["moves"] = [m for m in mv["moves"] if keep(m)]
            mv["undetermined"] = [t for t in mv["undetermined"] if keep(t)]
            # the TRANSITIONS of the dropped segment too: the re-solved part carries its own (the
            # detector swaps a replaced move's transition), and merge() unions the two lists
            nt = 0
            for sp, v in rs.items():
                before_n = len(v.get("transitions", []))
                v["transitions"] = [t for t in v.get("transitions", []) if keep(t)]
                nt += before_n - len(v["transitions"])
            print("part %d: dropped %d moves and %d transitions inside f%03d-f%03d"
                  % (i, n0 - len(mv["moves"]), nt, drop[0], drop[1]))
        f0 = min([m["f0"] for m in mv["moves"]] or [0])
        f1 = max([m["f1"] for m in mv["moves"]] or [0])
        per.append(((f0, f1), (rs, mv["moves"], mv["undetermined"], mv["evidence"],
                               mv["notes"], mv.get("readouts", []))))
        print("part %d: %s  %d moves, %d undetermined" % (i, d, len(mv["moves"]),
                                                          len(mv["undetermined"])))
    rests, moves, undet, evidence, notes, readouts = sb_full.merge(per)
    rows = sb_compose.schedule_rows(moves)
    ng, peak = sb_compose.allocate_aom(rows)
    blocks = json.load(open(a.blocks))
    print("merged: %d moves, %d undetermined, %d readout/load, %d rows, %d AOM groups peak %d"
          % (len(moves), len(undet), len(readouts), len(rows), ng, peak))
    mv = dict(moves=moves, undetermined=undet, readouts=readouts, aom_groups=ng, aom_peak=peak,
              blocks={k: list(v) for k, v in blocks.items()}, evidence=evidence, notes=notes)
    os.makedirs(a.out, exist_ok=True)
    json.dump(mv, open(os.path.join(a.out, "moves_full.json"), "w"), indent=1, default=str)
    json.dump(rests, open(os.path.join(a.out, "rests_full.json"), "w"), indent=1, default=str)
    if a.xlsx:
        M = Movie(a.calib, None)
        runs = sb_compose.pulse_runs(M)
        sb_emit.emit(a.xlsx, M, mv, rests, runs,
                     sb_compose.Peaks(M, sb_compose.species_windows(M, 0, M.nf - 1), 0, M.nf - 1),
                     0, M.nf - 1, extra=a.extra,
                     scope_note="the WHOLE movie, PRODUCTION se-cycle-blocks + the S2.1 "
                                "competition (session 25 experiment), merged from partial runs")
        print("wrote", a.xlsx)


if __name__ == "__main__":
    main()
