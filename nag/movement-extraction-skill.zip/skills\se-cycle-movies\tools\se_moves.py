"""se_moves.py -- stage 3 of movie -> workbook.  Marker positions in, the four sheets out.

Two halves, and they fail in different ways, so keep them apart in your head.

TRANSCRIPTION (what moved, when) -- solid, unchanged since session 5
-------------------------------------------------------------------
Every motion in these movies is a rigid translation of a set of traps, eased by
s(u) = 10u^3 - 15u^4 + 6u^5, and the batches are back-to-back: one batch's t_finish is the next
one's t_start.  Because s'(0) = s'(1) = 0, every atom is momentarily still AND on a whole tone at
each batch boundary.  That gives the segmentation for free:

  1. a candidate boundary is a frame where NO marker inside the array is off the tone grid.  The
     count matters, not the fraction: late in a cycle only two columns of 24 move at a time, and a
     fraction is still 0.92 in the middle of such a move -- indistinguishable from noise.
  2. between two boundaries the start and finish configurations are both known exactly, so the only
     unknowns are which source goes to which destination, and the two boundary times.
  3. timing and assignment are fitted TOGETHER and scored SYMMETRICALLY -- every prediction near a
     marker and every marker near a prediction.
  4. if the fitted model still cannot explain the intermediate frames, the window holds more than
     one batch and is split at its flattest interior frame, recursively.

A permutation that occupancy alone cannot see -- a block landing back on its own site set -- is
recovered here, because at half progress its atoms are half a tone off their sites.

COMPOSITION (rows a renderer can execute from the seed forward) -- rewritten
---------------------------------------------------------------------------
This is the half that used to be wrong, and it was wrong architecturally, not by a threshold.  The
old version carried a `dict` of trap -> species as its state, resolved every shortfall locally, and
"repaired" a missed detection by writing a `load` row.  A load creates an atom permanently, so
three markers lost under c540's D2/D5 label watermarks on frame 0 became three injected atoms, the
next window found atoms it could not account for and injected more, and the sheet ended up with 961
atoms against the 864 that exist and 201 of 382 rows failing the renderer's own `check3`.

So composition is now built on three rules, in this order:

  * ATOMS HAVE IDENTITY.  `Model` holds a list of atoms, each created exactly once (by the seed or
    by a `load`) and retired at most once (by an `unload`).  Conservation is a property of that
    list and is checked globally, not inferred from a shortfall in one window.
  * THE SIMULATED STATE IS THE ONLY SOURCE OF TRUTH FOR A ROW'S START.  Every window is fitted with
    its sources taken from what the schedule has actually delivered -- `se_sim.py`, which is a line
    by line transcription of render.ps1 -- and only its destinations taken from the movie.  A row
    can then never reach for a trap the schedule left empty, which is what `check3` measures.
  * A MISSED DETECTION IS NOT AN EVENT.  Where the movie shows fewer atoms than the schedule has,
    the default is to leave the atom alone and say so.  Retiring atoms needs positive evidence (a
    block-sized set, drawn faded, tracked while it leaves); creating atoms needs positive evidence
    (reservoir stock, visible off the data lattice, turning from faded to solid).  Anything else is
    reported in the notes and changes nothing.

Rows are emitted per batch and then checked against `se_sim` before the model advances, so
`check3 = 0` holds by construction instead of being chased.

Reservoir geometry.  These movies generate a fresh batch on the AOD's own comb, which sits HALF A
PITCH off the data lattice: c540's side stock is measured at x = 24.50 and 25.46 and its top stock
at y = -0.47 and +0.51.  Only two rows or columns of each are ever on screen; the rest of the
batch is outside the panel and its position is therefore not observable at all.  The convention
here -- documented, flagged in the `note` column, and the only invented geometry in the output -- is
to round such a block ONTO THE INTEGER GRID AWAY FROM THE ARRAY and extend it off-screen to the
width the carrying move needs.  On c540 that yields columns 25:36 for the side reservoir and rows
-8:0 for the top one, which is what the hand-written reference workbook says.
"""
import argparse, collections, csv, json, os, sys
import numpy as np
from scipy import ndimage
from scipy.optimize import linear_sum_assignment

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import se_sim
from se_sim import compact, rectangles, smoothstep


MIN_BLOCK = 8          # fewer atoms than this is never a transport; it is the detector blinking


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--marks", required=True)
    ap.add_argument("--out-prefix", required=True)
    ap.add_argument("--tone-divisor", type=int, default=0, help="0 = measure it")
    ap.add_argument("--grid-tol", type=float, default=0.13, help="on-grid radius, in tones")
    ap.add_argument("--noise", type=int, default=3,
                    help="markers allowed off-grid at a boundary frame (detector noise budget)")
    ap.add_argument("--cap", type=float, default=0.8, help="distance cap in the assignment cost")
    ap.add_argument("--accept", type=float, default=0.10,
                    help="mean per-atom per-frame error, in tones, that a window must reach before "
                         "it is accepted rather than split")
    ap.add_argument("--max-span", type=int, default=0,
                    help="a window with more mid frames than this is SPLIT ON SUSPICION, even if "
                         "its single-batch fit looks acceptable.  Batch boundaries in these movies "
                         "usually fall BETWEEN frames -- c540's move 14 starts at frame 66.9 -- so "
                         "there is often no frame at which every atom reads as being on the grid, "
                         "and a run of four short permutation batches can be swallowed by one "
                         "window whose end-to-end fit still scores well.  The split is only kept "
                         "if it does not make the fit worse.")
    ap.add_argument("--res", type=int, default=8, help="distance-map resolution, cells per tone")
    ap.add_argument("--exit-tol", type=float, default=0.35,
                    help="how well a block must be tracked by its own markers, in tones, before it "
                         "is believed to be leaving the panel.  A block that really is on its way "
                         "out sits within a fraction of a tone of its markers on every frame it is "
                         "still visible; a fit that has merely mislaid some atoms does not.")
    ap.add_argument("--explain", default="", help="a1,b0 -- print the fit internals for one window")
    ap.add_argument("--probe", default="", help="with --explain: 'a,b;a,b' timings to cost directly")
    args = ap.parse_args()

    K = json.load(open(args.calib, encoding="utf-8"))
    NF, dt = K["n_frames"], K["dt_ms"]
    gate = set(K.get("gate_frames", []))
    names = [s["name"] for s in K["species"]]
    vcol, vrow = K["visible_col"], K["visible_row"]
    dcol, drow = K["data_cols"], K["data_rows"]

    per = [[] for _ in range(NF)]
    with open(args.marks, encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            per[int(r["frame"])].append((r["species"], r["state"], float(r["x"]), float(r["y"])))

    def in_array(x, y):
        return 0.5 <= x <= dcol + 0.5 and 0.5 <= y <= drow + 0.5

    # ---------------------------------------------------------------- tone divisor
    def offgrid_count(d, f):
        n = 0
        for sp, st, x, y in per[f]:
            if st != "solid" or not in_array(x, y):
                continue
            tx, ty = (x - 1) * d, (y - 1) * d
            if abs(tx - round(tx)) > args.grid_tol or abs(ty - round(ty)) > args.grid_tol:
                n += 1
        return n

    rest = [f for f in range(NF) if offgrid_count(1, f) <= args.noise]
    D = args.tone_divisor
    if not D:
        for d in (1, 2, 3, 4):
            bad = sum(offgrid_count(d, f) for f in rest)
            tot = sum(1 for f in rest for sp, st, x, y in per[f] if st == "solid" and in_array(x, y))
            print("tone divisor %d: %d of %d rest-frame markers off the grid" % (d, bad, tot))
            if bad <= 0.01 * max(1, tot):
                D = d
                break
        D = D or 1
    print("tone divisor      : %d" % D)

    # ---- does the chosen divisor explain the markers OUTSIDE the data array too?
    #
    # The measurement above deliberately looks only inside the array, because that is where the
    # empty-site rings pin the grid.  But these movies PARK blocks in staging areas just outside
    # it, half a data pitch off the lattice, and those positions are then unrepresentable: the
    # schedule silently loses every move that starts or ends in one.  On c150 that is 15.8 % of all
    # on-screen markers and it is the largest known defect in this direction.
    #
    # This does not change D -- forcing a finer grid has its own costs (guide, "Open problem") --
    # it just refuses to let the failure be silent.  Act on it with --tone-divisor.
    def offgrid_all(d, f):
        n = t = 0
        for sp, st, x, y in per[f]:
            if st != "solid" or in_array(x, y):
                continue
            t += 1
            tx, ty = (x - 1) * d, (y - 1) * d
            if abs(tx - round(tx)) > args.grid_tol or abs(ty - round(ty)) > args.grid_tol:
                n += 1
        return n, t

    out_bad = out_tot = 0
    for f in rest:
        a, b = offgrid_all(D, f)
        out_bad += a; out_tot += b
    if out_tot:
        frac = 100.0 * out_bad / out_tot
        print("outside the data array: %d of %d at-rest markers are off this grid (%.1f %%)"
              % (out_bad, out_tot, frac))
        if frac > 5.0:
            print("  *** WARNING: this movie parks blocks off the data lattice and tone_divisor"
                  " %d cannot express where they are." % D)
            print("  *** Every move that starts or ends in a staging area will be lost, and the"
                  " workbook will look clean while doing it.")
            # Report the residual for every divisor rather than pass/fail: a staging area is
            # rarely at an exact half-pitch (c150's sit at -0.44, 0.49, 0.50), so "explains them
            # perfectly" is the wrong question.  "Which is least bad, and by how much" is not.
            scores = []
            for d in (1, 2, 3, 4):
                a2 = sum(offgrid_all(d, f)[0] for f in rest)
                scores.append((a2, d))
                print("  ***   tone_divisor %d would leave %d of %d off the grid (%.1f %%)"
                      % (d, a2, out_tot, 100.0 * a2 / max(1, out_tot)))
            a2, best = min(scores)
            if best != D and a2 < out_bad:
                print("  *** BEST is tone_divisor %d. Re-run with --tone-divisor %d and compare"
                      " the two with se_score.py before choosing." % (best, best))
                print("  *** Note the residual: if it is not near zero the staging areas are not"
                      " on ANY uniform grid, and those positions stay approximate.")
            else:
                print("  *** No finer divisor helps; the staging areas are not on a uniform grid."
                      " Their positions will be approximate whatever you choose.")

    def tone(v):
        return (v - 1.0) * D + 1.0
    tvc = (tone(vcol[0]), tone(vcol[1]))
    tvr = (tone(vrow[0]), tone(vrow[1]))
    tdc, tdr = tone(dcol), tone(drow)

    def in_window(x, y):
        return tvc[0] - 0.6 <= x <= tvc[1] + 0.6 and tvr[0] - 0.6 <= y <= tvr[1] + 0.6

    def in_data(x, y):
        return 0.5 <= x <= tdc + 0.5 and 0.5 <= y <= tdr + 0.5

    OGC = np.array([offgrid_count(D, f) for f in range(NF)])

    # ---------------------------------------------------------------- boundaries
    bset = set(f for f in range(NF) if OGC[f] <= args.noise) | set(gate) | {0, NF - 1}
    bl = sorted(bset)
    runs, i = [], 0
    while i < len(bl):
        j = i
        while j + 1 < len(bl) and bl[j + 1] == bl[j] + 1:
            j += 1
        runs.append((bl[i], bl[j]))
        i = j + 1
    print("boundary runs     : %d   (off-grid markers: median %d, at boundaries %d)"
          % (len(runs), int(np.median(OGC)), int(np.median([OGC[a] for a, b in runs]))))

    # ---------------------------------------------------------------- configurations
    fills = [0]

    def config(r0, r1, data_only=True):
        """Snapped solid configuration over a boundary run.  Gate-tinted frames lose contrast, so a
        non-gate frame in the run is preferred; the run is pooled by majority vote."""
        fr = [f for f in range(r0, r1 + 1) if f not in gate] or list(range(r0, r1 + 1))
        vote, state = collections.Counter(), collections.defaultdict(collections.Counter)
        for f in fr:
            seen = set()
            for sp, st, x, y in per[f]:
                if st != "solid":
                    continue        # faded means stock not in play, or a block being read out
                tx, ty = tone(x), tone(y)
                if max(abs(tx - round(tx)), abs(ty - round(ty))) > args.grid_tol * 1.7:
                    continue
                if data_only and not in_window(tx, ty):
                    continue
                k = (int(round(tx)), int(round(ty)))
                if k in seen:                       # two blobs on one trap: one atom
                    continue
                seen.add(k)
                vote[(k, sp)] += 1
                state[k][st] += 1
        half = max(1, len(fr)) / 2.0
        cfg = {}
        for (k, sp), n in sorted(vote.items(), key=lambda t: -t[1]):
            if n >= half and k not in cfg:
                cfg[k] = sp
        return complete_rectangles(cfg, vote)

    def complete_rectangles(cfg, vote, fill_min=0.80, sure=0.92):
        """Fill single-trap holes in a block.

        A block is a Cartesian product of two frequency combs -- that is the whole data model -- so
        a species occupying 99 traps of a 12 x 9 box is 108 atoms with 9 of them missed by the
        detector, not a block with a bite out of it.  These movies draw faint D1..D5 labels across
        the array and merge adjacent markers while a block translates, so misses are routine, and
        every one of them propagates: the window fit cannot pair the missing atoms, they become
        leftovers, and a leftover is one bad decision away from an invented `load`.

        A hole is filled only when the evidence is there: the bounding box of a connected same-species
        component is at least `fill_min` full, no other species holds the trap, and either the trap
        was seen carrying that species on at least one frame of the run, or the box is `sure` full.
        A genuinely L-shaped configuration -- two rectangles at different rows, which is common --
        has a bounding box well under `fill_min` and is left alone.
        """
        occupied = set(cfg)
        bysp = collections.defaultdict(set)
        for p, sp in cfg.items():
            bysp[sp].add(p)
        added = 0
        for sp, pts in bysp.items():
            seen = set()
            for p0 in sorted(pts):
                if p0 in seen:
                    continue
                comp, stack = set(), [p0]
                while stack:                       # 8-connected component of this species
                    q = stack.pop()
                    if q in comp or q not in pts:
                        continue
                    comp.add(q)
                    for dx in (-1, 0, 1):
                        for dy in (-1, 0, 1):
                            r = (q[0] + dx, q[1] + dy)
                            if r in pts and r not in comp:
                                stack.append(r)
                seen |= comp
                xs = [q[0] for q in comp]; ys = [q[1] for q in comp]
                box = [(x, y) for x in range(min(xs), max(xs) + 1)
                       for y in range(min(ys), max(ys) + 1)]
                if len(box) < 4 or len(comp) == len(box):
                    continue
                frac = len(comp) / float(len(box))
                if frac < fill_min:
                    continue
                miss = [q for q in box if q not in occupied]
                if len(comp) + len(miss) != len(box):
                    continue                        # another species is standing in the way
                for q in miss:
                    if not in_window(q[0], q[1]):
                        continue
                    if vote.get((q, sp), 0) >= 1 or frac >= sure:
                        cfg[q] = sp; occupied.add(q); added += 1
        if added:
            fills[0] += added
        return cfg

    # ---------------------------------------------------------------- distance maps
    RES = args.res
    lo_x = int(np.floor(tvc[0] - 40)); hi_x = int(np.ceil(tvc[1] + 40))
    lo_y = int(np.floor(tvr[0] - 40)); hi_y = int(np.ceil(tvr[1] + 40))
    WX = (hi_x - lo_x) * RES + 1
    WY = (hi_y - lo_y) * RES + 1
    dmap_cache = {}

    def dmap(f, nm, want="any"):
        """Distance to the nearest marker of species `nm` in state `want` ("any"/"solid"/"faded")."""
        key = (f, nm, want)
        if key in dmap_cache:
            return dmap_cache[key]
        seed = np.ones((WY, WX), bool)
        for sp, st, x, y in per[f]:
            if sp != nm or (want != "any" and st != want):
                continue
            ix = int(round((tone(x) - lo_x) * RES)); iy = int(round((tone(y) - lo_y) * RES))
            if 0 <= ix < WX and 0 <= iy < WY:
                seed[iy, ix] = False
        d = ndimage.distance_transform_edt(seed) / float(RES)
        if len(dmap_cache) > 900:
            dmap_cache.clear()
        dmap_cache[key] = d
        return d

    def lookup(f, nm, xs, ys, want="any"):
        ix = np.clip(np.round((np.asarray(xs) - lo_x) * RES).astype(int), 0, WX - 1)
        iy = np.clip(np.round((np.asarray(ys) - lo_y) * RES).astype(int), 0, WY - 1)
        return dmap(f, nm, want)[iy, ix]

    # ---------------------------------------------------------------- fit one window
    def obs(f, nm):
        return np.array([[tone(x), tone(y)] for sp, st, x, y in per[f] if sp == nm], float) \
            if any(sp == nm for sp, st, x, y in per[f]) else np.zeros((0, 2))

    def fit(a1, b0, S, E, mid):
        """Returns (pairs, a, b, err, unsrc, undst, tmap).  Unchanged from session 5 -- this is the
        part that measures 0.092 tone mean error on c540 and must not be tinkered with.

        Three stages, in this order for a reason:

        (1) the batch timing, scored WITHOUT any assignment.  At the true timing every marker on
            screen is explained; at a wrong one many are not.  Doing this first matters: with the
            timing wrong every displacement scores well, because at small p everything sits near
            where it started.
        (2) the candidate displacements, read off the frames rather than enumerated.  For each
            marker and each source, (o-s)/p is what the displacement would have to be; rounding and
            histogramming that leaves a handful of sharp peaks.
        (3) the cover, per (atom, displacement) and each destination trap claimable once.
        """
        Sk, Ek = sorted(S), sorted(E)
        spset = sorted(set(S.values()) | set(E.values()))
        by_s = {nm: [p for p in Sk if S[p] == nm] for nm in spset}
        by_e = {nm: [q for q in Ek if E[q] == nm] for nm in spset}
        Eset = {nm: set(by_e[nm]) for nm in spset}

        if not mid:
            # adjacent boundaries: no frame shows the motion.  Nearest destination is the only
            # defensible choice, and the note file says so.
            pairs = []
            for nm in spset:
                si, ei = by_s[nm], by_e[nm]
                if not si or not ei:
                    continue
                C = (np.abs(np.array([p[0] for p in si])[:, None] - np.array([q[0] for q in ei])[None, :])
                     + np.abs(np.array([p[1] for p in si])[:, None] - np.array([q[1] for q in ei])[None, :]))
                n = max(len(si), len(ei))
                big = np.full((n, n), 1e6)
                big[:len(si), :len(ei)] = C
                ri, ci = linear_sum_assignment(big)
                for r, c in zip(ri, ci):
                    if r < len(si) and c < len(ei):
                        pairs.append((si[r], ei[c], nm))
            us = [p for p in Sk if p not in set(x for x, y, z in pairs)]
            ud = [q for q in Ek if q not in set(y for x, y, z in pairs)]
            return (pairs, float(a1), float(b0), 0.0, us, ud,
                    {p: (float(a1), float(b0)) for p, q, nm in pairs})

        tolp = args.grid_tol
        RCAP = args.grid_tol * 2.2      # residual beyond this tells us nothing more
        MAXD = 42 * D
        Eocc = {}
        tlo_x = min([p[0] for p in Sk] + [q[0] for q in Ek]) - MAXD - 2
        tlo_y = min([p[1] for p in Sk] + [q[1] for q in Ek]) - MAXD - 2
        thi_x = max([p[0] for p in Sk] + [q[0] for q in Ek]) + MAXD + 2
        thi_y = max([p[1] for p in Sk] + [q[1] for q in Ek]) + MAXD + 2
        EW = int(thi_x - tlo_x + 1); EH = int(thi_y - tlo_y + 1)
        for nm in spset:
            g = np.zeros((EH, EW), bool)
            for q in by_e[nm]:
                g[int(q[1] - tlo_y), int(q[0] - tlo_x)] = True
            Eocc[nm] = g

        OBS = {(f, nm): obs(f, nm) for f in mid for nm in spset}
        SRC = {nm: (np.array([p[0] for p in by_s[nm]], float),
                    np.array([p[1] for p in by_s[nm]], float)) for nm in spset}
        mf = np.asarray(mid, float)

        def progress(a, b):
            return smoothstep_arr((mf - a) / max(1e-6, b - a))

        def candidates(pf):
            hist = collections.Counter()
            for fi in range(len(mid)):
                pv = pf[fi]
                if pv < 0.10 or pv > 0.95:
                    continue
                for nm in spset:
                    O = OBS[(mid[fi], nm)]
                    sx, sy = SRC[nm]
                    if not len(O) or not len(sx):
                        continue
                    dx = (O[:, 0][:, None] - sx[None, :]) / pv
                    dy = (O[:, 1][:, None] - sy[None, :]) / pv
                    rx = np.round(dx); ry = np.round(dy)
                    m = ((np.abs(dx - rx) * pv < tolp) & (np.abs(dy - ry) * pv < tolp)
                         & (np.abs(rx) <= MAXD) & (np.abs(ry) <= MAXD))
                    if not m.any():
                        continue
                    tx = np.clip((sx[None, :] + rx - tlo_x).astype(int), 0, EW - 1)
                    ty = np.clip((sy[None, :] + ry - tlo_y).astype(int), 0, EH - 1)
                    m = m & Eocc[nm][ty, tx]
                    ii, jj = np.nonzero(m)
                    for k in range(len(ii)):
                        hist[(int(rx[ii[k], jj[k]]), int(ry[ii[k], jj[k]]))] += 1
            out = [d for d, n in hist.most_common(20)]
            if (0, 0) not in out:
                out.append((0, 0))
            return out, hist

        def cover(pf, cands):
            """Each atom takes the displacement that best explains ITS OWN track, resolved
            highest-score-first with one claim per destination trap."""
            cand_pts = []
            for d in cands:
                dpf = pf if isinstance(pf, np.ndarray) else pf[d]
                for nm in spset:
                    pts = [p for p in by_s[nm] if (p[0] + d[0], p[1] + d[1]) in Eset[nm]]
                    if not pts:
                        continue
                    px = np.array([p[0] for p in pts], float)
                    py = np.array([p[1] for p in pts], float)
                    resid = np.zeros(len(pts))
                    for fi, f in enumerate(mid):
                        resid += np.minimum(lookup(f, nm, px + d[0] * dpf[fi],
                                                   py + d[1] * dpf[fi]), RCAP)
                    good = 1.0 - resid / (len(mid) * RCAP)
                    for i, p in enumerate(pts):
                        if good[i] > 0.0:
                            cand_pts.append((good[i] + (1e-4 if d == (0, 0) else 0.0), d, p, nm))
            cand_pts.sort(key=lambda t: -t[0])
            prs, sf, df = [], set(Sk), set(Ek)
            scored = collections.Counter()
            for s0, d, p, nm in cand_pts:
                if s0 < 0.45:
                    break
                q = (p[0] + d[0], p[1] + d[1])
                if p in sf and q in df:
                    prs.append((p, q, nm))
                    sf.discard(p); df.discard(q)
                    scored[d] += 1
            for p in list(sf):                      # still standing on its own trap: it did not move
                if p in df and E.get(p) == S[p]:
                    prs.append((p, p, S[p]))
                    sf.discard(p); df.discard(p)
            return prs, scored, sorted(sf), sorted(df)

        def sym_cost(prs, pf):
            """Mean of (prediction -> nearest marker) and (marker -> nearest prediction), capped."""
            if not prs:
                return args.cap
            px = np.array([p[0] for p, q, nm in prs], float)
            py = np.array([p[1] for p, q, nm in prs], float)
            qx = np.array([q[0] for p, q, nm in prs], float)
            qy = np.array([q[1] for p, q, nm in prs], float)
            nmv = np.array([nm for p, q, nm in prs])
            tot, cnt = 0.0, 0
            for fi, f in enumerate(mid):
                hx = px + (qx - px) * pf[fi]; hy = py + (qy - py) * pf[fi]
                for nm in spset:
                    sel = nmv == nm
                    O = OBS[(f, nm)]
                    k = int(sel.sum()); m = len(O)
                    if not k and not m:
                        continue
                    if not k or not m:
                        tot += args.cap * (k + m); cnt += k + m
                        continue
                    dd = np.sqrt((hx[sel][:, None] - O[:, 0][None, :]) ** 2
                                 + (hy[sel][:, None] - O[:, 1][None, :]) ** 2)
                    tot += np.minimum(dd.min(axis=1), args.cap).sum()
                    tot += np.minimum(dd.min(axis=0), args.cap).sum()
                    cnt += k + m
            return tot / max(1, cnt)

        dbg = args.explain == "%d,%d" % (a1, b0)
        if dbg and args.probe:
            print("\n== probe, window %d-%d  mid=%s" % (a1, b0, mid))
            for spec in args.probe.split(";"):
                pa, pb = [float(v) for v in spec.split(",")]
                ppf = progress(pa, pb)
                pc, _h = candidates(ppf)
                ppr, psc, _sf, _df = cover(ppf, pc)
                got = collections.Counter((q[0] - p[0], q[1] - p[1]) for p, q, nm in ppr)
                print("   a=%.2f b=%.2f  cost %.4f" % (pa, pb, sym_cost(ppr, ppf)))
                print("      classes: %s" % got.most_common(8))
        best = None
        for a in np.round(np.arange(a1 - 1.5, a1 + 1.01, 0.25), 3):
            for b in np.round(np.arange(b0 - 1.0, b0 + 1.51, 0.25), 3):
                if b - a < 0.4:
                    continue
                pf = progress(a, b)
                cands, _h = candidates(pf)
                prs, _sc, _sf, _df = cover(pf, cands)
                c = sym_cost(prs, pf)
                if best is None or c < best[0]:
                    best = (c, float(a), float(b))
        a, b = best[1], best[2]
        pf = progress(a, b)
        cands, hist = candidates(pf)
        prs, scored, sf, df = cover(pf, cands)
        for _ in range(2):
            fine = None
            for aa in np.round(np.arange(a - 0.3, a + 0.31, 0.05), 3):
                for bb in np.round(np.arange(b - 0.3, b + 0.31, 0.05), 3):
                    if bb - aa < 0.4:
                        continue
                    c = sym_cost(prs, progress(aa, bb))
                    if fine is None or c < fine[0]:
                        fine = (c, float(aa), float(bb))
            if fine is None:
                break
            a, b = fine[1], fine[2]
            pf = progress(a, b)
            cands, hist = candidates(pf)
            prs, scored, sf, df = cover(pf, cands)

        # Per-displacement timing, used ONLY to get the assignment right.  Different AODs act
        # independently, so one batch's blocks need not start and stop together: c540's Z0 halves
        # swap 6 tones while the X blocks move 5 and 7, and a progress difference of 0.05 across a
        # 6-tone displacement is 0.33 tone of position error -- enough to reject the correct
        # displacement outright.  Only displacements that already won atoms get their own timing,
        # and only within half a frame of the shared one.
        keepd = [d for d, n in scored.items() if n >= 6 or d == (0, 0)]
        tim = {}
        for d in keepd:
            if d == (0, 0):
                tim[d] = (a, b); continue
            plaus = [(p, nm) for nm in spset for p in by_s[nm]
                     if (p[0] + d[0], p[1] + d[1]) in Eset[nm]]
            if not plaus:
                tim[d] = (a, b); continue
            bx = {}
            for nm in spset:
                pts = [p for p, n2 in plaus if n2 == nm]
                if pts:
                    bx[nm] = (np.array([p[0] for p in pts], float),
                              np.array([p[1] for p in pts], float))
            bestd = None
            for aa in np.round(np.arange(a - 0.8, a + 0.81, 0.1), 3):
                for bb in np.round(np.arange(b - 0.8, b + 0.81, 0.1), 3):
                    if bb - aa < 0.4:
                        continue
                    q = progress(aa, bb)
                    hit = 0.0
                    for nm, (px, py) in bx.items():
                        g = np.zeros(len(px))
                        for fi, f in enumerate(mid):
                            g += np.minimum(lookup(f, nm, px + d[0] * q[fi],
                                                   py + d[1] * q[fi]), RCAP)
                        g = 1.0 - g / (len(mid) * RCAP)
                        hit += float(g[g > 0.55].sum())     # only well-tracked atoms vote
                    if bestd is None or hit > bestd[0]:
                        bestd = (hit, float(aa), float(bb))
            tim[d] = (bestd[1], bestd[2]) if bestd else (a, b)
        pfd = {d: progress(*tim[d]) for d in keepd}
        prs2, scored2, sf2, df2 = cover(pfd, keepd)
        tmap = {}
        for p, q, nm in prs2:
            tmap[p] = tim.get((q[0] - p[0], q[1] - p[1]), (a, b))
        if len(prs2) >= len(prs):
            prs, scored, sf, df = prs2, scored2, sf2, df2
        else:
            tmap = {p: (a, b) for p, q, nm in prs}
        err = sym_cost(prs, pf)

        if dbg:
            print("\n== window %d-%d  mid=%s" % (a1, b0, mid))
            print("   |S|=%d |E|=%d  species %s" % (len(Sk), len(Ek), spset))
            print("   timing a=%.2f b=%.2f  symmetric error %.4f tone" % (a, b, err))
            print("   displacement histogram: %s" % hist.most_common(8))
            got = collections.Counter((q[0] - p[0], q[1] - p[1]) for p, q, nm in prs)
            for d, n in got.most_common(10):
                print("      d=(%+d,%+d)  n=%-4d timing %s" % (d[0], d[1], n, tim.get(d)))
        return prs, a, b, err, sf, df, tmap

    def smoothstep_arr(u):
        u = np.clip(u, 0.0, 1.0)
        return 10 * u ** 3 - 15 * u ** 4 + 6 * u ** 5

    # ================================================================ PASS 1: segmentation only
    # The windows and their split points are all this pass is kept for.  Its pairs are discarded:
    # they were fitted with each window's start read straight from the movie, which makes each fit
    # as good as it can be alone but does not compose into a schedule.
    windows = []
    notes = []

    # How long a window may be before it is split on suspicion.  Measured from the movie rather than
    # assumed: the boundary runs that ARE detectable set the scale of a batch in this cycle, and
    # anything more than a couple of times that is holding several.  c540 lands on 13, which is
    # comfortably above the 10-frame longest batch of the reference workbook.
    raw = [runs[i + 1][0] - runs[i][1] - 1 for i in range(len(runs) - 1)]
    raw = [v for v in raw if v > 0]
    MAXSPAN = [args.max_span if args.max_span > 0
               else max(8, int(round(2.2 * float(np.median(raw)))) if raw else 13)]
    print("window length     : median %d mid frames; splitting any window longer than %d"
          % (int(np.median(raw)) if raw else 0, MAXSPAN[0]))

    cfg_cache = {}

    def cfg(r0, r1):
        if (r0, r1) not in cfg_cache:
            cfg_cache[(r0, r1)] = config(r0, r1)
        return cfg_cache[(r0, r1)]

    err_cache = {}

    def window_err(a1, b0, S, E, mid):
        key = (a1, b0)
        if key in err_cache:
            return err_cache[key]
        errs = []
        for nm in sorted(set(S.values()) | set(E.values())):
            Ss = {p: s for p, s in S.items() if s == nm}
            Es = {q: s for q, s in E.items() if s == nm}
            if not Ss and not Es:
                continue
            pr, aa, bb, er, u1, u2, tm = fit(a1, b0, Ss, Es, mid)
            if pr:
                errs.append((er, len(pr)))
        e = (sum(x * n for x, n in errs) / sum(n for x, n in errs)) if errs else 0.0
        err_cache[key] = e
        return e

    def segment(A, B, depth=0):
        a0, a1 = A
        b0, b1 = B
        S, E = cfg(a0, a1), cfg(b0, b1)
        mid = [f for f in range(a1 + 1, b0) if f not in gate]
        if S == E and not mid:
            return
        err = window_err(a1, b0, S, E, mid)
        too_long = len(mid) > MAXSPAN[0]
        if (err > args.accept or too_long) and depth < 8 and len(mid) >= 4:
            inner = mid[1:-1] or mid
            m = min(inner, key=lambda f: (OGC[f], abs(f - 0.5 * (a1 + b0))))
            if a1 < m < b0:
                Mc = cfg(m, m)
                eL = window_err(a1, m, S, Mc, [f for f in range(a1 + 1, m) if f not in gate])
                eR = window_err(m, b0, Mc, E, [f for f in range(m + 1, b0) if f not in gate])
                # An OVER-LONG WINDOW IS SPLIT UNCONDITIONALLY.  It is tempting to keep the split
                # only when it improves the fit, and that is wrong: cutting a window that holds
                # five batches at ONE of its four internal boundaries leaves two windows still
                # holding two or three each, so the halves fit no better and the test rejects the
                # cut.  c540's frames 59-93 -- five of the reference workbook's batches -- survived
                # exactly that way, and 108 atoms had to be paired by distance because no single
                # displacement could explain them.  Length is the more reliable signal, and the
                # recursion re-tests each half, so a wrong cut costs one extra boundary and no
                # accuracy.  Below the length limit the improvement test still guards against
                # cutting a genuine single batch.
                if too_long or max(eL, eR) <= err * 1.10 or err > args.accept:
                    notes.append("frames %d-%d: split at frame %d (%d mid frames, error %.3f tone "
                                 "as one batch, %.3f / %.3f as two)%s"
                                 % (a1, b0, m, len(mid), err, eL, eR,
                                    "; longer than the %d-frame limit" % MAXSPAN[0] if too_long else ""))
                    segment(A, (m, m), depth + 1)
                    segment((m, m), B, depth + 1)
                    return
        windows.append(dict(A=A, B=B, a1=a1, b0=b0, mid=mid, E=E))

    for wi in range(len(runs) - 1):
        segment(runs[wi], runs[wi + 1])
    windows.sort(key=lambda w: w["a1"])
    print("windows segmented : %d   (%d single-trap holes filled in observed configurations)"
          % (len(windows), fills[0]))

    # ================================================================ reservoir stock (observable)
    # A fresh batch is not created out of nothing: it is already on screen, drawn FADED, outside the
    # data lattice, and it turns SOLID at the moment the schedule loads it (guide III.7, handover
    # 4.3).  That transition is the only positive evidence for a `load`, and finding it here -- once,
    # globally, from the pixels -- is what stops a missed detection from being mistaken for one.
    def off_lattice(tx, ty):
        """Is this marker somewhere no data qubit can be?

        Not "outside the data extent" -- that was the old test and it is off by exactly the amount
        that matters.  A reservoir sits HALF A PITCH off the lattice, so c540's side stock is at
        x = 24.50 while the array runs to column 24, and `0.5 <= x <= dcol + 0.5` calls 24.50 an
        array position.  Half of every stock block was thrown away by that, which is why the
        recovered reservoir came out as columns 26:36 instead of 25:36 and rows -3:-1 instead of
        -8:0.  A trap is off the lattice if it is not NEAR A WHOLE TONE, or if the tone it is near
        lies outside the data extent.
        """
        near = max(abs(tx - round(tx)), abs(ty - round(ty))) <= 0.25
        inside = (1 <= round(tx) <= tdc) and (1 <= round(ty) <= tdr)
        return not (near and inside)

    def stock_frames():
        """species -> {frame: [positions]} where off-lattice stock is on screen."""
        out = collections.defaultdict(dict)
        for f in range(NF):
            for sp, st, x, y in per[f]:
                tx, ty = tone(x), tone(y)
                if not off_lattice(tx, ty) or not in_window(tx, ty):
                    continue
                out[sp].setdefault(f, []).append((tx, ty, st))
        return out

    STOCK = stock_frames()
    loads_avail = []          # a stock block that is on screen, AT REST, and solid
    for sp, byf in STOCK.items():
        # A stock block must be STATIONARY.  Without this a block merely passing through the
        # reservoir zone on its way out of the panel -- c540 parks a Z block at column 25 by an
        # ordinary move -- is read as a fresh batch, and the frames while it is still travelling
        # each give a different position set.  Keying the run on the position set makes a moving
        # block into a chain of one-frame runs, which the length test then discards.
        keyed = {}
        for f, pts in byf.items():
            solid = [(x, y) for x, y, st in pts if st == "solid"]
            if len(solid) >= MIN_BLOCK:
                keyed[f] = (frozenset((round(x, 1), round(y, 1)) for x, y in solid), solid)
        fs = sorted(keyed)
        i = 0
        while i < len(fs):
            j, cur = i, keyed[fs[i]][0]
            # A run continues while the block STAYS PUT.  Compared by overlap, not equality: a
            # marker at the panel edge drops in and out of detection from frame to frame, and
            # demanding an identical position set chopped one resting block into four runs.
            while j + 1 < len(fs) and fs[j + 1] == fs[j] + 1:
                nxt = keyed[fs[j + 1]][0]
                if len(cur & nxt) < 0.7 * max(len(cur), len(nxt)):
                    break
                j += 1
            if j - i + 1 >= 3:
                best = max(range(i, j + 1), key=lambda t: len(keyed[fs[t]][1]))
                loads_avail.append(dict(sp=sp, f0=fs[i], f1=fs[j], pts=keyed[fs[best]][1],
                                        used=False))
            i = j + 1
    for L in loads_avail:
        xs = sorted(set(round(x, 2) for x, y in L["pts"]))
        ys = sorted(set(round(y, 2) for x, y in L["pts"]))
        print("stock live        : %-3s frames %d..%d  %d markers at x %s y %s"
              % (L["sp"], L["f0"], L["f1"], len(L["pts"]),
                 xs if len(xs) < 6 else "%s..%s" % (xs[0], xs[-1]),
                 ys if len(ys) < 6 else "%s..%s" % (ys[0], ys[-1])))

    def reservoir_rect(pts, need):
        """Round an off-lattice stock block onto the integer grid AWAY FROM THE ARRAY and extend it
        off-screen until it holds `need` atoms.

        The block is generated on the AOD's own comb, half a pitch off the data lattice, and only
        one or two of its rows/columns are ever on screen; the rest is outside the panel and simply
        is not observable.  Rounding away from the array is the convention (documented, and flagged
        in the note column): on c540 it turns a stock measured at x = 24.50, 25.46 into columns
        25:36, and one at y = -0.47, +0.51 into rows -8:0, which is what the reference workbook
        says.  Returns (xs, ys, how) or None.
        """
        xs = sorted(set(x for x, y in pts))
        ys = sorted(set(y for x, y in pts))
        # which edge is it beyond?
        beyond_right = min(xs) > tdc - 0.5
        beyond_left = max(xs) < 1.5
        beyond_bottom = min(ys) > tdr - 0.5
        beyond_top = max(ys) < 1.5
        if beyond_right or beyond_left:
            ry = [int(round(v)) for v in ys]
            ny = len(set(ry))
            nx = max(1, int(round(need / max(1, ny))))
            if beyond_right:
                c0 = int(np.ceil(min(xs) - 1e-6))
                rx = list(range(c0, c0 + nx))
            else:
                c1 = int(np.floor(max(xs) + 1e-6))
                rx = list(range(c1 - nx + 1, c1 + 1))
            return sorted(set(rx)), sorted(set(ry)), ("right" if beyond_right else "left")
        if beyond_bottom or beyond_top:
            rx = [int(round(v)) for v in xs]
            nx = max(1, len(set(rx)))
            ny = max(1, int(round(need / nx)))
            if beyond_top:
                r1 = int(np.floor(max(ys) + 1e-6))
                ry = list(range(r1 - ny + 1, r1 + 1))
            else:
                r0 = int(np.ceil(min(ys) - 1e-6))
                ry = list(range(r0, r0 + ny))
            return sorted(set(rx)), sorted(set(ry)), ("top" if beyond_top else "bottom")
        return None

    # ================================================================ PASS 2: composition
    class Model(object):
        """Atoms with identity.  Created once, retired at most once, counted globally."""

        def __init__(self):
            self.atoms = []            # dict(sp, born, dies, motions)
            self.state = {}            # trap -> atom index

        def create(self, sp, trap, born):
            self.atoms.append(dict(sp=sp, born=float(born), dies=float("inf"), motions=[]))
            k = len(self.atoms) - 1
            self.state[trap] = k
            return k

        def sp(self, trap):
            return self.atoms[self.state[trap]]["sp"]

        def cfg(self):
            return {t: self.atoms[k]["sp"] for t, k in self.state.items()}

        def sanitize(self, moved):
            """Drop motions that would stack two atoms on one trap, to a fixed point.

            Two ways that can happen, and both mean the fit for this window is imperfect rather
            than that the movie is: two motions claiming one destination, and a motion aiming at a
            trap whose atom this batch leaves alone (which is what the "leave a lost atom where it
            is" policy can produce).  Dropping a motion returns its source to the set of atoms
            standing still, which can invalidate another motion, so it has to iterate.  Returns
            (kept, dropped).
            """
            # One motion per SOURCE and one per DESTINATION.  An atom cannot go to two places, and
            # two atoms cannot arrive on one trap.  The source half matters as much as the
            # destination half: a carrying move added alongside an ordinary one can name the same
            # origin twice, and the model then tries to lift the same atom off its trap twice.
            kept, seen_q, seen_p, dropped = [], set(), set(), []
            for p, q in moved:
                if q in seen_q or p in seen_p or p not in self.state:
                    dropped.append((p, q)); continue
                seen_q.add(q); seen_p.add(p); kept.append((p, q))
            while True:
                still = set(self.state) - set(p for p, q in kept)
                bad = [(p, q) for p, q in kept if q in still]
                if not bad:
                    return kept, dropped
                bs = set(bad)
                kept = [m for m in kept if m not in bs]
                dropped.extend(bad)

        def apply(self, moved, t0, t1, retire=()):
            """moved: [(p, q)].  All of them see the pre-batch state, exactly as render.ps1 does."""
            ks = {p: self.state[p] for p, q in moved if p in self.state}
            moved = [(p, q) for p, q in moved if p in ks]
            for p, q in moved:
                self.state.pop(p, None)
            for p, q in moved:
                k = ks[p]
                self.atoms[k]["motions"].append((t0, t1, p[0], p[1], q[0], q[1]))
                self.state[q] = k
            for q in retire:
                if q in self.state:
                    self.atoms[self.state.pop(q)]["dies"] = t1

        def alive(self):
            return len(self.state)

    M = Model()
    seed_cfg = config(*windows[0]["A"]) if windows else config(*runs[0])
    for trap, sp in sorted(seed_cfg.items()):
        M.create(sp, trap, 0.0)
    COMPLEMENT = M.alive()
    print("seed              : %d atoms  (%s)"
          % (COMPLEMENT, ", ".join("%s %d" % (sp, sum(1 for v in seed_cfg.values() if v == sp))
                                   for sp in names if sp in seed_cfg.values())))

    batches = []              # dict(t0f, t1f, moves=[(p,q)], unloads=[(pts,d)], loads=[...])
    departed = []             # (species, frame) for every block carried off the panel

    for wi, W in enumerate(windows):
        a1, b0, mid, E = W["a1"], W["b0"], W["mid"], W["E"]
        # Only ON-SCREEN atoms take part in the fit.  An atom parked outside the panel -- in a
        # reservoir, or a block moved out of the window by an ordinary move -- has no destination in
        # the observed configuration, because the movie cannot show one.  Leaving it in the source
        # set would make it a leftover in every window from then on.  Off-screen atoms stand still
        # unless a displacement this batch already owns brings them back in (case 3 below).
        full = M.cfg()
        S = {p: sp for p, sp in full.items() if in_window(p[0], p[1])}
        S_off = {p: sp for p, sp in full.items() if not in_window(p[0], p[1])}
        pairs, unsrc, undst = [], [], []
        tw, errs = [], []
        for nm in sorted(set(S.values()) | set(E.values())):
            Ss = {p: s for p, s in S.items() if s == nm}
            Es = {q: s for q, s in E.items() if s == nm}
            if not Ss and not Es:
                continue
            pr, aa, bb, er, u1, u2, tm = fit(a1, b0, Ss, Es, mid)
            pairs += pr; unsrc += u1; undst += u2
            nmv = len([1 for p, q, n2 in pr if p != q])
            if pr:
                errs.append((er, len(pr)))
                if nmv:
                    tw.append((aa, bb, nmv))
        err = (sum(e * n for e, n in errs) / sum(n for e, n in errs)) if errs else 0.0
        # ONE timing for the whole batch, atom-weighted.  The per-species timings above are what
        # made the assignment come out right and must not reach the sheet: a move row picks its
        # atoms up by POSITION and not by species, so two rows a hundredth of a millisecond apart
        # get sequenced and the later one sweeps up the atoms the earlier one just delivered.
        if tw:
            a = sum(x * n for x, y, n in tw) / sum(n for x, y, n in tw)
            b = sum(y * n for x, y, n in tw) / sum(n for x, y, n in tw)
        else:
            a, b = float(a1), float(b0)

        # ---- leftovers, in order of how much evidence each resolution needs -------------------
        # (1) same-species surplus on both sides is ONE MOTION THE FIT DID NOT NAME.  Pair it:
        #     retiring the one and creating the other would duplicate the block.
        us_by = collections.defaultdict(list); ud_by = collections.defaultdict(list)
        for p in unsrc:
            us_by[S[p]].append(p)
        for q in undst:
            ud_by[E[q]].append(q)
        for nm in sorted(set(us_by) | set(ud_by)):
            k1, k2 = us_by.get(nm, []), ud_by.get(nm, [])
            if not k1 or not k2:
                continue
            cx = np.array([p[0] for p in k1], float)[:, None]
            cy = np.array([p[1] for p in k1], float)[:, None]
            dx = np.array([q[0] for q in k2], float)[None, :]
            dy = np.array([q[1] for q in k2], float)[None, :]
            C = np.abs(cx - dx) + np.abs(cy - dy)
            n = max(len(k1), len(k2))
            big = np.full((n, n), 1e6); big[:len(k1), :len(k2)] = C
            ri, ci = linear_sum_assignment(big)
            ts, td = set(), set()
            for r0, c0 in zip(ri, ci):
                if r0 < len(k1) and c0 < len(k2):
                    pairs.append((k1[r0], k2[c0], nm))
                    ts.add(k1[r0]); td.add(k2[c0])
            if ts:
                notes.append("frames %d-%d: the fit did not name a motion for %d %s atom(s); "
                             "paired source to destination by distance so the atoms are neither "
                             "lost nor duplicated" % (a1, b0, len(ts), nm))
            us_by[nm] = [p for p in k1 if p not in ts]
            ud_by[nm] = [q for q in k2 if q not in td]

        moved = [(p, q) for p, q, nm in pairs if p != q]
        owned = collections.Counter((q[0] - p[0], q[1] - p[1]) for p, q in moved)

        # (1b) DEPARTURE: a block carried out of the visible window by an ordinary move.
        # c540 does this at move 54, parking a Z block in the side reservoir at column 25: only the
        # one column inside the panel is observable, so the fit pairs 9 of the 108 atoms and the
        # other 99 look lost.  They are not lost -- they are off screen, still solid (a readout
        # would be drawn faded), and they come back or are retired later.  The evidence is that the
        # atoms the fit DID pair share a displacement which, applied to the rest of the block,
        # takes them outside the panel.  Nothing new is fitted; the batch's own displacement is
        # extended, and the whole group must agree or none of it is accepted.
        def fade_evidence(nm, pts):
            """Faded markers that belong to THESE atoms, not to anything else on screen.

            Counting every faded marker of the species is wrong, and wrong in a way that fires
            constantly: the reservoir stock waiting to be loaded is drawn faded too, and it sits
            there for a third of the cycle.  On c540 that meant Z0 and Z1 always had eighteen faded
            markers on screen, so every window in which the fit mislaid a few atoms passed the
            readout test, and the composer wrote twenty-four unload rows where the movie has four --
            retiring atoms that were still in the array.  A readout is a BLOCK MOVING AWAY, so only
            faded markers that start near the atoms in question count.
            """
            if not pts:
                return 0
            px = np.array([p[0] for p in pts], float)
            py = np.array([p[1] for p in pts], float)
            w = max(3.0, 0.35 * max(px.max() - px.min(), py.max() - py.min()))
            lo_bx, hi_bx = px.min() - w, px.max() + w
            lo_by, hi_by = py.min() - w, py.max() + w
            n, cents = 0, []
            for f in list(mid) + [b0]:
                here = []
                for s, st, x, y in per[f]:
                    if s != nm or st != "faded":
                        continue
                    tx, ty = tone(x), tone(y)
                    if in_window(tx, ty) and lo_bx <= tx <= hi_bx and lo_by <= ty <= hi_by:
                        here.append((tx, ty))
                n += len(here)
                if here:
                    cents.append((float(np.mean([p[0] for p in here])),
                                  float(np.mean([p[1] for p in here]))))
            # AND THEY MUST BE MOVING.  Reservoir stock waiting to be loaded is drawn faded too and
            # sits perfectly still for a third of the cycle; counting it made every window in which
            # the fit mislaid a few atoms look like a readout.  A block being carried away travels.
            if len(cents) >= 2:
                dx = max(c[0] for c in cents) - min(c[0] for c in cents)
                dy = max(c[1] for c in cents) - min(c[1] for c in cents)
                if max(dx, dy) < 0.8:
                    return 0
            return n

        nsp = collections.Counter(S.values())

        def obs_count(nm, r0, r1):
            """How many markers of `nm` the MOVIE shows on screen over a boundary run.

            The max over the run, not the mean: a single frame can lose markers to merging, and an
            undercount here would be read as atoms having left.
            """
            best = 0
            for f in range(r0, r1 + 1):
                n = sum(1 for s, st, x, y in per[f] if s == nm and st == "solid"
                        and in_window(tone(x), tone(y)))
                best = max(best, n)
            return best

        n_before = {}
        n_after = {}
        for nm in set(list(S.values()) + list(E.values())):
            n_before[nm] = obs_count(nm, W["A"][0], W["A"][1])
            n_after[nm] = obs_count(nm, W["B"][0], W["B"][1])

        def exit_fit(nm, pts, a0, b1, want, cands=None, prefer=()):
            """Which rigid displacement carries `pts` out of the panel, judged on the pixels?

            Shared by the two ways a block can leave: an ordinary move to an off-screen parking
            place (`want="solid"`) and a readout (`want="faded"`).  Two rules make it honest:

              * only predictions still INSIDE the panel are scored, and the score is their MEAN.
                Summing rewards a displacement for leaving early -- an off-screen prediction has no
                marker near it, takes the constant cap, and a bigger displacement simply buys more
                of those.
              * ties break towards the smallest displacement.

            Inheriting a displacement the batch happens to own is not good enough: c540 parks an X1
            block at column 25 (a shift of +12), but the batch also carried a +13, and taking +13
            put the block at 26:37 -- so the stock the movie shows at column 25 looked unclaimed
            and was loaded a second time.
            """
            px = np.array([p[0] for p in pts], float)
            py = np.array([p[1] for p in pts], float)
            # Include the ARRIVAL boundary, not just the frames in between.  Where the block comes
            # to rest is the sharpest evidence there is about how far it went, and leaving it out
            # is why c540's X1 block fitted as +13 (landing entirely off the panel, so nothing
            # could contradict it) when the movie shows it resting on column 25, i.e. +12.  The
            # block was then never properly retired and reappeared later from the wrong edge.
            fr = list(mid) + [b0]
            if cands is None:
                R = 16 * D
                cands = [(dx, dy) for dx in range(-R, R + 1) for dy in range(-R, R + 1)
                         if dx or dy]
            best = None
            for dx, dy in cands:
                tot, cnt = 0.0, 0
                for f in fr:
                    pr0 = smoothstep((f - a0) / max(1e-6, b1 - a0))
                    hx = px + dx * pr0; hy = py + dy * pr0
                    vis = np.array([in_window(x2, y2) for x2, y2 in zip(hx, hy)])
                    if not vis.any():
                        continue
                    tot += float(np.minimum(lookup(f, nm, hx[vis], hy[vis], want), args.cap).sum())
                    cnt += int(vis.sum())
                if cnt < max(3, 0.15 * len(pts) * len(fr)):
                    continue
                # Once the block is off the panel its displacement is under-determined -- every
                # value beyond the edge fits the visible frames equally well -- so the tie has to be
                # broken on something other than the pixels.  The rest of the batch is the right
                # thing: c540's X1 block leaves with 9 of its atoms still landing on the visible
                # column 25, which pins those at +12, while the 99 that end up wholly off screen
                # admit +12 and +13 alike.  Preferring the displacement its own batch already uses
                # keeps the block together, and it is what puts the block back at 25:36 -- where
                # the movie rests it, and where it can then be retired properly.
                sc = (tot / cnt + (0.0 if (dx, dy) in prefer else 0.02)
                      + 1e-4 * (abs(dx) + abs(dy)))
                if best is None or sc < best[0]:
                    best = (sc, (dx, dy), tot / cnt)
            return best

        for nm in sorted(us_by):
            pts = us_by[nm]
            # A DEPARTURE IS A WHOLE BLOCK LEAVING, not a few atoms at the edge.  Without the
            # fraction test, nine unmatched markers in the rightmost column of c540 were carried
            # off screen under whatever displacement the batch happened to own (+7) and then found
            # their way back three windows later at (-29), which is nonsense in both directions.
            # A real departure takes most of the species with it.
            if len(pts) < MIN_BLOCK or len(pts) < 0.25 * nsp.get(nm, len(pts)):
                continue
            # A block being READ OUT also leaves the panel, so this test must not fire on one:
            # it would write an ordinary move and the atoms would never be retired.  A readout is
            # drawn desaturated, an ordinary transport is not, so the faded markers decide.
            if fade_evidence(nm, pts) >= 0.4 * len(pts) * max(1, len(mid) + 1):
                continue
            # THE MOVIE MUST ACTUALLY SHOW THEM GO.  If 108 atoms leave the panel then the number
            # of that species' markers on screen has to fall by about 108, and it is worth checking
            # because the displacement fit alone is not enough: early in a batch every prediction
            # is still sitting among the block's own markers, so a bogus exit scores well.  On c540
            # this test is what stops both X blocks being flung off the panel at frame 69 and
            # retrieved at frame 73 while the movie shows them moving quietly inside the array.
            if n_after.get(nm, 0) > n_before.get(nm, 0) - 0.6 * len(pts):
                notes.append("frames %d-%d: %d %s atom(s) are unaccounted for, but the movie still "
                             "shows %d %s markers on screen at the end of this window against %d "
                             "at the start -- they did not leave the panel, so they are LEFT WHERE "
                             "THEY ARE and nothing is written"
                             % (a1, b0, len(pts), nm, n_after.get(nm, 0), nm, n_before.get(nm, 0)))
                continue
            # Candidates: the displacements this batch already carries, plus a small neighbourhood,
            # and each is then CHECKED AGAINST THE PIXELS rather than trusted.
            cset = set()
            for d, _n in owned.most_common(6):
                for ex in range(-2, 3):
                    for ey in range(-2, 3):
                        if d[0] + ex or d[1] + ey:
                            cset.add((d[0] + ex, d[1] + ey))
            cset = [d for d in cset
                    if all(not in_window(p[0] + d[0], p[1] + d[1]) for p in pts)]
            if not cset:
                continue
            own_nm = set((q[0] - p[0], q[1] - p[1]) for p, q in moved if S.get(p) == nm)
            # A BLOCK MOVES AS ONE.  If some of this species' atoms in this batch have already been
            # paired with a displacement, and they are physically adjacent to the unaccounted ones,
            # then they are the same block and it went where they went.  Fitting the leftovers on
            # their own is hopeless when they all end up off the panel: c540's X1 block leaves with
            # 9 of its 108 atoms landing on the still-visible column 25, which pins the block at
            # +12, while the other 99 clear the edge entirely and score +11, +12 and +13 alike.
            # Fitted alone they chose +13, the block was then parked one column too far out, never
            # retired, and came back later through the wrong edge.
            pick = None
            for d0 in sorted(own_nm):
                if not all(not in_window(p[0] + d0[0], p[1] + d0[1]) for p in pts):
                    continue
                srcs = [p for p, q in moved
                        if S.get(p) == nm and (q[0] - p[0], q[1] - p[1]) == d0]
                if not srcs:
                    continue
                gap = min(abs(p[0] - s[0]) + abs(p[1] - s[1]) for p in pts for s in srcs)
                if gap <= 1.5 * D and (pick is None or gap < pick[0]):
                    pick = (gap, d0, len(srcs))
            if pick is not None:
                d, merr = pick[1], 0.0
                notes.append("frames %d-%d: %d %s atoms leave the panel with the rest of their "
                             "block, at the displacement (%+d,%+d) that %d neighbouring atoms of "
                             "the same block were fitted to.  Their own final position is off the "
                             "panel and so carries no information; the block is rigid, so it is "
                             "the neighbours that decide"
                             % (a1, b0, len(pts), nm, pick[1][0], pick[1][1], pick[2]))
                for p in pts:
                    moved.append((p, (p[0] + d[0], p[1] + d[1])))
                departed.append((nm, b0, [(p[0] + d[0], p[1] + d[1]) for p in pts]))
                us_by[nm] = []
                continue
            bf = exit_fit(nm, pts, a, b, "solid", cset, prefer=own_nm)
            if bf is None:
                continue
            # AND THE PIXELS MUST AGREE.  Without a threshold on the fit error this test fires
            # whenever the fit mislays a block anywhere in the array: c540's X0 was sent off the
            # panel at frames 59-62 and 67-69 and brought back at 64-67 and 69-73, bouncing in and
            # out four times while the movie shows it moving quietly inside the array the whole
            # while.  A block that really is leaving is tracked by its own markers as it crosses
            # the edge, and scores far better than that.
            if bf[2] > args.exit_tol:
                notes.append("frames %d-%d: %d %s atom(s) are unaccounted for and a displacement "
                             "of (%+d,%+d) would take them off the panel, but their markers do not "
                             "follow it (mean error %.3f tone, limit %.2f) -- so they are LEFT "
                             "WHERE THEY ARE and nothing is written"
                             % (a1, b0, len(pts), nm, bf[1][0], bf[1][1], bf[2], args.exit_tol))
                continue
            d = bf[1]
            tgt = set(q for p, q in moved)
            if any((p[0] + d[0], p[1] + d[1]) in tgt for p in pts):
                continue
            for p in pts:
                moved.append((p, (p[0] + d[0], p[1] + d[1])))
            departed.append((nm, b0, [(p[0] + d[0], p[1] + d[1]) for p in pts]))
            notes.append("frames %d-%d: %d %s atoms leave the panel under the displacement "
                         "(%+d,%+d), fitted to their own markers as they cross the edge (mean "
                         "error %.3f tone).  They stay solid, so this is an ordinary move to an "
                         "off-screen parking place and not a readout; where they sit beyond the "
                         "edge is not observable"
                         % (a1, b0, len(pts), nm, d[0], d[1], bf[2]))
            us_by[nm] = []

        # (1c) RETURN: atoms arriving from a trap outside the panel that the schedule DOES hold.
        # The mirror image of a departure -- the carrying move that brings a reservoir batch in.
        for nm in sorted(ud_by):
            pts = ud_by[nm]
            if not pts or not S_off:
                continue
            offn = [p for p, s2 in S_off.items() if s2 == nm]
            if not offn:
                continue
            # ... and the mirror of the departure test: atoms coming back on screen must show up as
            # MORE markers of that species than the window started with.
            if n_after.get(nm, 0) < n_before.get(nm, 0) + 0.6 * min(len(pts), len(offn)):
                notes.append("frames %d-%d: %d %s atom(s) appear that the schedule cannot supply "
                             "from inside the panel, but the movie shows %d %s markers at the end "
                             "against %d at the start -- no block came back on screen here, so "
                             "nothing is moved in" % (a1, b0, len(pts), nm, n_after.get(nm, 0),
                                                      nm, n_before.get(nm, 0)))
                continue
            cnt = collections.Counter()
            offset = set(offn)
            MAXRET = 2 * max(tdc, tdr)          # nothing travels further than twice the array
            for q in pts:
                for p in offn:
                    d0 = (q[0] - p[0], q[1] - p[1])
                    if abs(d0[0]) <= MAXRET and abs(d0[1]) <= MAXRET:
                        cnt[d0] += 1
            for d, _n in cnt.most_common(6):
                ok = [((q[0] - d[0], q[1] - d[1]), q) for q in pts
                      if (q[0] - d[0], q[1] - d[1]) in offset]
                if len(ok) < min(MIN_BLOCK, len(pts)):
                    continue
                used = set()
                acc = []
                for p, q in ok:
                    if p in used:
                        continue
                    used.add(p); acc.append((p, q))
                moved.extend(acc)
                notes.append("frames %d-%d: %d %s atoms arrive from off screen at the "
                             "displacement (%+d,%+d); the schedule already holds them outside the "
                             "panel, so this is the carrying move and nothing is created"
                             % (a1, b0, len(acc), nm, d[0], d[1]))
                ud_by[nm] = [q for q in pts if q not in set(y for x, y in acc)]
                break

        # (2) a surplus of SOURCES: either a block leaving the array, or the detector blinking.
        unloads = []
        for nm in sorted(us_by):
            pts = us_by[nm]
            if not pts:
                continue
            # NOTE, for whoever picks this up.  Only on-screen atoms take part in the fit, so when a
            # block is parked half outside the panel a readout retires just its visible edge and the
            # off-screen remainder stays alive.  On c540 that leaves 99 X1 atoms in the model after
            # the t = 10.30 readout, and they are then used to refill the array at the end of the
            # cycle instead of the fresh batch the movie shows arriving from the top.  Extending the
            # retired set to the off-screen remainder of the same block was tried and is NOT in
            # here: it retires the right atoms but the displacement fit then has almost nothing
            # visible to work with and picks a destination through the opposite edge, which is worse
            # than the problem it solves.  The real fix is to fit the departure and the readout of
            # one block together, which is a larger change than tonight allowed.
            vis_pts = list(pts)
            fadecnt = fade_evidence(nm, vis_pts)
            need = 0.4 * len(vis_pts) * max(1, len(mid) + 1)
            if len(vis_pts) < MIN_BLOCK or fadecnt < need:
                # NOT an event.  Leave the atoms where they are and say so.  An `unload` retires
                # atoms permanently and needs positive evidence; without this test every fit
                # shortfall became a readout -- 173 of them on c540 against the four that exist.
                notes.append("frames %d-%d: %d %s atom(s) at %s are not in the next observed "
                             "configuration, and the movie shows only %d faded %s marker(s) in "
                             "that window -- too little to call it a readout, so they are LEFT "
                             "WHERE THEY ARE and nothing is written"
                             % (a1, b0, len(pts), nm, compact_pts(pts), fadecnt, nm))
                continue
            # WHEN the block was taken is directly observable: it is the frame its markers stop
            # being drawn solid.  Reading it off the pixels beats inheriting the batch's fitted
            # t_start, which can be half a frame early -- and half a frame early means the whole
            # block is desaturated one frame before the movie desaturates it, which is 216 markers
            # disagreeing on that frame.
            fade_start = None
            box = (min(p[0] for p in vis_pts) - 1.5, max(p[0] for p in vis_pts) + 1.5,
                   min(p[1] for p in vis_pts) - 1.5, max(p[1] for p in vis_pts) + 1.5)
            for f in range(max(0, a1 - 2), min(NF, b0 + 2)):
                k = sum(1 for s, st, x, y in per[f] if s == nm and st == "faded"
                        and box[0] <= tone(x) <= box[1] and box[2] <= tone(y) <= box[3])
                if k >= 0.5 * len(vis_pts):
                    fade_start = f
                    break

            px = np.array([p[0] for p in pts], float)
            py = np.array([p[1] for p in pts], float)
            fr = list(mid) or [b0]
            # Score ONLY the predictions that are still inside the panel, and take their MEAN.
            # Summing over all of them rewards a displacement for leaving the screen early: an
            # off-screen prediction has no marker anywhere near it, scores the constant cap, and a
            # bigger displacement simply buys more of those.  On c540 that is exactly what happened
            # -- the readout descent fitted as +10 rows when the pixels say +9, and being one row
            # per batch too fast is visible on screen for the whole descent.  A mean over the
            # on-screen predictions is scale-free, and the tiny |d| penalty breaks ties towards the
            # smallest displacement that explains what can actually be seen.
            best = None
            for ddx in range(-14 * D, 14 * D + 1):
                for ddy in range(-14 * D, 14 * D + 1):
                    if ddx == 0 and ddy == 0:
                        continue
                    tot, cnt = 0.0, 0
                    for f in fr:
                        pr0 = smoothstep((f - a) / max(1e-6, b - a))
                        hx = px + ddx * pr0; hy = py + ddy * pr0
                        vis = np.array([in_window(x2, y2) for x2, y2 in zip(hx, hy)])
                        if not vis.any():
                            continue
                        # FADED markers only.  A block being read out is the desaturated one, and
                        # scoring against every marker of the species lets the 108 SOLID atoms
                        # still standing in the array explain any displacement that keeps the
                        # prediction near them: c540's descent then fitted as +10 rows with a
                        # reported error of exactly 0.000, when the pixels say +9.
                        tot += float(np.minimum(lookup(f, nm, hx[vis], hy[vis], "faded"),
                                                args.cap).sum())
                        cnt += int(vis.sum())
                    if cnt < max(3, 0.15 * len(pts) * len(fr)):
                        continue                      # too little of it was ever on screen to judge
                    sc = tot / cnt + 1e-4 * (abs(ddx) + abs(ddy))
                    if best is None or sc < best[0]:
                        best = (sc, (ddx, ddy), tot / cnt)
            if best is None:
                notes.append("frames %d-%d: %d %s atoms vanish but no displacement could be fitted "
                             "-- too little of the block stays on screen; left where they were"
                             % (a1, b0, len(pts), nm))
                continue
            d, merr = best[1], best[2]
            ua = float(fade_start) if fade_start is not None else a
            unloads.append((nm, pts, d, merr, ua))
            notes.append("frames %d-%d: %d %s atoms are carried out of the array for measurement "
                         "(they are drawn faded).  Fitted to the faded markers as (%+d,%+d) over "
                         "this batch, mean error %.3f tone against the part of the descent that is "
                         "still on screen.  NOTE THAT THE DISPLACEMENT ITSELF IS NOT DETERMINED: "
                         "the block leaves the panel part way through, so several (displacement, "
                         "duration) pairs describe the visible motion equally well and only the "
                         "on-screen trajectory is a measurement.  The destination written below is "
                         "the convention -- far enough to clear the panel -- not an observation"
                         % (a1, b0, len(pts), nm, d[0], d[1], merr))

        # (3) a surplus of DESTINATIONS: either a batch carried in from the reservoir, or noise.
        loads = []
        for nm in sorted(ud_by):
            pts = sorted(ud_by[nm])
            if not pts:
                continue
            cand = [L for L in loads_avail
                    if L["sp"] == nm and not L["used"] and L["f0"] <= b0 + 1]
            if len(pts) < MIN_BLOCK or not cand:
                notes.append("frames %d-%d: the movie shows %d %s atom(s) at %s that the schedule "
                             "cannot supply, and there is no off-lattice %s stock on screen to "
                             "carry in -- NOTHING IS CREATED; this is reported, not invented"
                             % (a1, b0, len(pts), nm, compact_pts(pts), nm))
                continue
            # SIZE THE BATCH TO THE ARRIVAL'S BOUNDING RECTANGLE, NOT TO THE NUMBER OF ARRIVALS.
            # A batch is a Cartesian product like any other block, and the detector rarely sees all
            # of it land: c540's fresh Z batch was observed as 99 traps of the 12 x 9 it occupies,
            # which sized the reservoir at 11 columns, left the carrying move nine atoms short, and
            # put 180 markers per frame beyond anything the schedule could explain.  The bounding
            # rectangle of what WAS seen recovers the whole batch.
            bx = sorted(set(q[0] for q in pts)); by = sorted(set(q[1] for q in pts))
            dest = [(x, y) for x in range(bx[0], bx[-1] + 1) for y in range(by[0], by[-1] + 1)]
            need = len(dest)          # the WHOLE rectangle: a batch does not arrive with holes

            # Stock the schedule ALREADY HOLDS is not fresh.  c540 parks a Z block outside the
            # panel at column 25 with an ordinary move and leaves it there for 22 frames; that is a
            # resting off-lattice block by every pixel test, but loading it would create a second
            # copy of atoms the model is already tracking.
            best_c = None
            for z in cand:
                # A BLOCK THAT HAS JUST LEFT THE ARRAY IS NOT FRESH STOCK.  c540 parks an X1 block
                # outside the panel at column 25 and leaves it resting there for twenty-two frames;
                # by every pixel test that is a stationary off-lattice block, indistinguishable
                # from a reservoir batch, and loading it created a second copy of 108 atoms the
                # schedule was already tracking -- which is what "picked up 18 of 9 sites" means.
                # The model knows the difference: it watched the block leave.
                # ... but only where it actually went.  Matching on species and time alone is too
                # blunt: c540's X1 leaves by the right edge at frame 314 and a genuinely fresh X1
                # batch appears above the array at frame 337, and rejecting that one costs a real
                # load row.  Compare positions.
                zc = (float(np.mean([p[0] for p in z["pts"]])),
                      float(np.mean([p[1] for p in z["pts"]])))
                if any(s2 == nm and f2 <= z["f0"] + 2
                       and min(abs(zc[0] - q[0]) + abs(zc[1] - q[1]) for q in dst) < 6 * D
                       for s2, f2, dst in departed):
                    continue
                rc = reservoir_rect(z["pts"], need)
                if rc is None:
                    continue
                traps = [(x, y) for x in rc[0] for y in rc[1]]
                if sum(1 for t in traps if t in M.state) > 0.5 * len(traps):
                    continue
                # the stock must map onto the arrivals by ONE rigid displacement
                dxs = collections.Counter()
                dset = set(dest)
                for q in dest:
                    for p in traps:
                        dxs[(q[0] - p[0], q[1] - p[1])] += 1
                if not dxs:
                    continue
                d0, _ = dxs.most_common(1)[0]
                ok0 = [(p, (p[0] + d0[0], p[1] + d0[1])) for p in traps
                       if (p[0] + d0[0], p[1] + d0[1]) in dset]
                if len(ok0) < 0.6 * len(dest):
                    continue          # this stock does not line up with where the atoms appear
                if best_c is None or len(ok0) > len(best_c[0]):
                    best_c = (ok0, rc, z, d0)
            if best_c is None:
                notes.append("frames %d-%d: %d %s atom(s) arrive that the schedule cannot supply, "
                             "and no off-lattice %s stock on screen lines up with where they "
                             "appear (either it is already held by the schedule, or no single "
                             "rigid displacement carries it there) -- NOTHING IS CREATED"
                             % (a1, b0, len(pts), nm, nm))
                continue
            ok, rect, L, d = best_c
            rx, ry, edge = rect
            L["used"] = True
            loads.append((nm, rx, ry, edge, ok, L))
            notes.append("frames %d-%d: %d %s atoms arrive from the %s reservoir.  Its stock is "
                         "visible on screen from frame %d at %s (half a pitch off the data lattice), "
                         "rounded AWAY FROM THE ARRAY onto columns %s rows %s and extended "
                         "off-screen to hold the whole batch -- only the on-screen edge was measured"
                         % (a1, b0, len(pts), nm, edge, L["f0"],
                            compact_pts([(round(x, 2), round(y, 2)) for x, y in L["pts"]][:4]),
                            compact(rx), compact(ry)))

        # ---- advance the model ----------------------------------------------------------------
        # unload atoms travel too, drawn faded, and die at t_finish
        unload_disp = {}
        allmoved = list(moved)
        for nm, pts, d, e, ua in unloads:
            for p in pts:
                allmoved.append((p, (p[0] + d[0], p[1] + d[1])))
                unload_disp[(p[0] + d[0], p[1] + d[1])] = True
        # A load takes effect BEFORE this batch -- render.ps1 creates a batch's loaded atoms after
        # its moves, so the row has to sit in an earlier batch -- and the carrying move belongs to
        # THIS one.  Creating the atoms here, before sanitising, lets the carry be checked for
        # collisions like any other motion.
        for nm, rx, ry, edge, ok, L in loads:
            for p in [(x, y) for x in rx for y in ry]:
                if p not in M.state:
                    M.create(nm, p, a * dt)
            allmoved.extend([(p, q) for p, q in ok if p in M.state])
        allmoved, dropped = M.sanitize(allmoved)
        if dropped:
            notes.append("frames %d-%d: %d motion(s) would have stacked two atoms on one trap and "
                         "were dropped (%s); the fit for this window is imperfect, and the atoms "
                         "involved are left where the schedule already had them"
                         % (a1, b0, len(dropped), compact_pts([q for p, q in dropped][:6])))
        keep = set(allmoved)
        carry = set()
        for nm, rx, ry, edge, ok, L in loads:
            carry |= set(ok)
        moved = [m for m in moved if m in keep] + [m for m in allmoved if m in carry]
        unloads = [(nm, [p for p in pts
                         if (p, (p[0] + d[0], p[1] + d[1])) in keep], d, e, ua)
                   for nm, pts, d, e, ua in unloads]
        unloads = [u for u in unloads if u[1]]
        retire = [q for q in set(q for p, q in allmoved) if q in unload_disp]
        batches.append(dict(wi=wi, a=a, b=b, err=err, moved=moved, unloads=unloads, loads=loads,
                            a1=a1, b0=b0))
        M.apply(allmoved, a * dt, b * dt, retire=retire)

    print("windows composed  : %d   (mean fit error %.3f tone, worst %.3f)"
          % (len(batches), float(np.mean([w["err"] for w in batches]) if batches else 0),
             float(np.max([w["err"] for w in batches]) if batches else 0)))
    print("atoms             : %d ever alive, %d alive at the end (complement %d)"
          % (len(M.atoms), M.alive(), COMPLEMENT))

    # ================================================================ batch times
    # Strictly increasing t_start, with enough separation that no two windows collapse into one
    # batch: render.ps1 groups rows by t_start, and two windows sharing one would have the second
    # window's rows reach for atoms the first has only just delivered.
    MINSEP = 0.34
    prev = None
    for B in batches:
        if prev is not None and B["a"] < prev + MINSEP:
            B["a"] = prev + MINSEP
        if B["b"] < B["a"] + 0.4:
            B["b"] = B["a"] + 0.4
        prev = B["a"]

    # ================================================================ rows
    sched = []

    def add(ev, sp, t0f, t1f, xs, ys, fxs, fys, note, move, slot):
        sched.append(dict(move=move, slot=slot, event=ev, species=sp,
                          t_start=round(t0f * dt, 4), t_finish=round(t1f * dt, 4),
                          x_start=compact(xs), y_start=compact(ys),
                          x_finish=compact(fxs), y_finish=compact(fys), note=note))

    for B in batches:
        mv = B["wi"] + 1
        slot = 0
        by_d = collections.defaultdict(list)
        for p, q in B["moved"]:
            by_d[(q[0] - p[0], q[1] - p[1])].append(p)
        for d in sorted(by_d):
            for xs, ys in rectangles(by_d[d]):
                slot += 1
                add("move", "", B["a"], B["b"], xs, ys,
                    [v + d[0] for v in xs], [v + d[1] for v in ys], "", mv, slot)
        for nm, pts, d, e, ua in B["unloads"]:
            dd = list(d)
            # push the block clear of the panel: where it lands after that is unobservable, and the
            # user's own rule is that only on-screen motion has to match
            for kk, (lo, hi) in enumerate(((tvc[0], tvc[1]), (tvr[0], tvr[1]))):
                if dd[kk] > 0:
                    need = int(np.ceil(hi + 0.6 - max(p[kk] for p in pts)))
                    if 0 < dd[kk] < need:
                        dd[kk] = need
                elif dd[kk] < 0:
                    need = int(np.floor(lo - 0.6 - min(p[kk] for p in pts)))
                    if need < dd[kk] < 0:
                        dd[kk] = need
            # t_start is the frame the movie actually desaturates the block, not the batch's fitted
            # start: `unload` sets fadeFrom = t_start, so half a frame early desaturates the whole
            # block one frame before the movie does.  The duration is kept from the fit.
            ua2 = ua if ua is not None else B["a"]
            ub2 = ua2 + max(0.4, B["b"] - B["a"])
            for xs, ys in rectangles(pts):
                slot += 1
                add("unload", "", ua2, ub2, xs, ys,
                    [v + dd[0] for v in xs], [v + dd[1] for v in ys],
                    "read out; taken at the frame the movie first draws this block faded, and "
                    "tracked by those faded markers until it leaves the panel.  The destination "
                    "beyond the edge is the convention, not a measurement -- the displacement "
                    "itself is not determined once the block is off screen",
                    mv, slot)

    # loads go into a STRICTLY EARLIER batch than the move that carries them in: render.ps1 applies
    # a batch's moves and only then creates that batch's loaded atoms, so a load sharing its
    # t_start with the carry is applied too late and the carry picks up nothing.
    starts = sorted(set(B["a"] for B in batches))
    for B in batches:
        if not B["loads"]:
            continue
        earlier = [s for s in starts if s < B["a"] - 1e-9]
        for nm, rx, ry, edge, ok, L in B["loads"]:
            # Put the load where the MOVIE says the batch came alive -- the frame its stock stops
            # being drawn faded -- rather than merely one batch before the carry.  Both render
            # identically (the atoms sit still in the reservoir either way), but the observed frame
            # is the honest answer and it is what the reference workbook records.
            fit_t = [s for s in earlier if s <= L["f0"] + 0.5]
            tl = fit_t[-1] if fit_t else (earlier[-1] if earlier else B["a"] - 1.0)
            add("load", nm, tl, tl, rx, ry, rx, ry,
                "fresh batch; its stock is visible on screen from frame %d, half a pitch off the "
                "data lattice, and is rounded away from the array and extended off-screen to hold "
                "the whole batch" % L["f0"], 0, 0)

    sched.sort(key=lambda r: (r["t_start"], 0 if r["event"] == "load" else 1))
    for i, r in enumerate(sched):
        if not r["move"]:
            r["move"] = i + 1
        r["slot"] = i + 1

    # ================================================================ seed / gates / constants
    seed = collections.defaultdict(list)
    for p, sp in seed_cfg.items():
        seed[sp].append(p)

    graw = sorted(gate)
    gruns, i = [], 0
    while i < len(graw):
        j = i
        while j + 1 < len(graw) and graw[j + 1] == graw[j] + 1:
            j += 1
        gruns.append((graw[i], graw[j]))
        i = j + 1
    gaterows = []
    for a, b in gruns:
        gaterows.append(dict(move=len(gaterows) + 1,
                             t_start=round(max(0.0, (a - 0.45) * dt), 4),
                             t_finish=round((b + 0.45) * dt, 4)))

    ring = set(tuple(int(v) for v in s.split(",")) for s in K.get("ring_sites", []))
    nod = np.zeros((dcol + 2, drow + 2), bool)
    if ring:
        for c in range(1, dcol + 1):
            for r in range(1, drow + 1):
                nod[c, r] = (c, r) not in ring
        # a lone site with no ring is a site that happened to be covered every time it was sampled;
        # a parking zone is a solid rectangle.  Opening removes the specks and keeps the zone.
        nod = ndimage.binary_opening(nod, structure=np.ones((3, 3)))
    nodata = [(c, r) for c in range(1, dcol + 1) for r in range(1, drow + 1) if nod[c, r]]
    parking = "; ".join("%s x %s" % (compact([tone(c) for c in xs]), compact([tone(r) for r in ys]))
                        for xs, ys in rectangles(nodata)) if nodata else ""

    cons = [("lattice_cols", int(tone(dcol)), "tone positions across"),
            ("lattice_rows", int(tone(drow)), "tone positions down; row 1 is topmost"),
            ("data_qubits", dcol * drow - len(nodata), "data sites that carry a qubit"),
            ("cycle_ms", K["cycle_ms"] if K["cycle_ms"] else float(NF), "from the movie header"),
            ("frames", NF, ""),
            ("dt_ms", dt, "cycle_ms / frames; frame(t) = round(t / dt_ms)"),
            ("easing", "s(u) = 10u^3 - 15u^4 + 6u^5", "fitted to the frames"),
            ("visible_col_min", int(tone(vcol[0])), "the panel's own extent"),
            ("visible_col_max", int(tone(vcol[1])), ""),
            ("visible_row_min", int(tone(vrow[0])), ""),
            ("visible_row_max", int(tone(vrow[1])), "")]
    if D != 1:
        cons += [("tone_divisor", D, "a data site every Dth tone"),
                 ("data_cols", dcol, ""), ("data_rows", drow, "")]
    if parking:
        cons.append(("block_parking", parking,
                     "no empty-site ring is ever drawn here, so there are no data qubits"))

    # ================================================================ self-check
    # The whole point of the rewrite: before writing anything, run the sheet through the same
    # simulator that mirrors render.ps1 and refuse to claim a clean workbook if it is not one.
    cons_rows = [dict(key=k, value=v, note=n) for k, v, n in cons]
    seed_rows = []
    for sp in names:
        for xs, ys in rectangles(seed.get(sp, [])):
            seed_rows.append(dict(species=sp, x_tones=compact(xs), y_tones=compact(ys),
                                  note="position at t = 0"))
    chk = se_sim.Sim(cons_rows, seed_rows, sched)
    counts = chk.counts()
    print("self-check        : %d rows -> %d atoms ever alive, %d motions, validation %s"
          % (len(sched), len(chk.atoms), sum(len(a["moves"]) for a in chk.atoms),
             dict(counts) if counts else "CLEAN"))
    for kind, detail in chk.log[:16]:
        print("   %-7s %s" % (kind, detail))
    if counts:
        notes.append("SELF-CHECK NOT CLEAN: %s -- see the log above" % dict(counts))
        for kind, detail in chk.log:
            notes.append("  %s %s" % (kind, detail))

    # ================================================================ write
    pfx = args.out_prefix
    with open(pfx + "_constants.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["key", "value", "note"])
        for k, v, n in cons:
            w.writerow([k, v, n])
    with open(pfx + "_seed.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["species", "x_tones", "y_tones", "note"])
        for r in seed_rows:
            w.writerow([r["species"], r["x_tones"], r["y_tones"], r["note"]])
    with open(pfx + "_schedule.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, ["move", "slot", "event", "species", "t_start", "t_finish",
                                "x_start", "y_start", "x_finish", "y_finish", "note"])
        w.writeheader()
        for r in sched:
            w.writerow(r)
    with open(pfx + "_gates.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, ["move", "t_start", "t_finish"])
        w.writeheader()
        for r in gaterows:
            w.writerow(r)
    with open(pfx + "_notes.txt", "w", encoding="utf-8") as fh:
        fh.write("\n".join(notes) + "\n")

    print("seed rows         : " + ", ".join("%s %d" % (sp, len(seed.get(sp, []))) for sp in names))
    print("schedule rows     : %d  (%d move, %d unload, %d load)"
          % (len(sched), sum(1 for r in sched if r["event"] == "move"),
             sum(1 for r in sched if r["event"] == "unload"),
             sum(1 for r in sched if r["event"] == "load")))
    print("distinct batches  : %d" % len(set(r["t_start"] for r in sched)))
    print("gates             : %d" % len(gaterows))
    print("no-data sites     : %s" % (parking or "none"))
    print("open notes        : %d  (all of them in %s_notes.txt)" % (len(notes), pfx))
    for n in notes[:12]:
        print("   " + n)
    print("wrote %s_constants.csv, _seed.csv, _schedule.csv, _gates.csv, _notes.txt" % pfx)


def compact_pts(pts):
    """A short readable rendering of a point set, for the notes."""
    pts = list(pts)
    if not pts:
        return "(none)"
    if len(pts) <= 4:
        return ", ".join("(%s,%s)" % (p[0], p[1]) for p in pts)
    xs = sorted(set(p[0] for p in pts)); ys = sorted(set(p[1] for p in pts))
    return "%d traps spanning x %s..%s y %s..%s" % (len(pts), xs[0], xs[-1], ys[0], ys[-1])


if __name__ == "__main__":
    main()
