"""sb_read.py -- read blocks and movements from an SE-cycle movie by 1-D colour profiles,
rest-frame occupancy, and marker OUTLINE colour.

See SKILL.md.  The three things this does that se_moves.py / se_waypoints.py cannot:

  * it measures with PROFILES, so two markers approaching each other stay two peaks down to about
    0.3 of a pitch instead of being suppressed as one detection;
  * it discovers OUTLINE colours the species palette does not contain, and uses the outline's peak
    set to name which sub-block of a block is moving;
  * it therefore recovers SUB-BLOCK moves -- two halves of one block going to different places in
    one batch -- including permutations of a block onto its own site set.

Modes:
    --palette             list fill, faded and discovered outline colours
    --rest                per-frame occupancy and rest test, per species
    --solve               solve one window: moves, timings, verification, AOM packing, table
"""
import argparse, collections, json, math, os, sys
import numpy as np
from PIL import Image


# ----------------------------------------------------------------- geometry / masks
class Movie:
    def __init__(self, calib, frames_dir=None):
        self.K = json.load(open(calib, encoding="utf-8"))
        self.dir = frames_dir or self.K["frames_dir"]
        self.ox, self.px = self.K["origin_x"], self.K["pitch_x"]
        self.oy, self.py = self.K["origin_y"], self.K["pitch_y"]
        self.moff = self.K.get("marker_offset", [0.0, 0.0])
        self.dt = float(self.K["dt_ms"])
        self.nf = int(self.K["n_frames"])
        self.gate = set(self.K.get("gate_frames", []))
        self.species = [s["name"] for s in self.K["species"]]
        self.fill = {s["name"]: tuple(s["solid"]) for s in self.K["species"]}
        self.faded = {s["name"]: tuple(s["faded"]) for s in self.K["species"]}
        self._img = {}
        self._mask = {}

    def img(self, f):
        if f not in self._img:
            if len(self._img) > 40:
                self._img.clear()
            self._img[f] = np.asarray(
                Image.open(os.path.join(self.dir, "p_%03d.png" % f)).convert("RGB")
            ).astype(np.float32)
        return self._img[f]

    def box(self, win):
        c0, c1, r0, r1 = win
        return (int(self.ox + (c0 - 1) * self.px), int(self.ox + (c1 - 1) * self.px),
                int(self.oy + (r0 - 1) * self.py), int(self.oy + (r1 - 1) * self.py))

    def mask(self, colour, win, f, tol=34.0, keep=None):
        """the colour's mask inside `win`, optionally restricted to a COMB of lines.

        `keep` is `(axis, tones)`: keep only the strips within half a pitch of those tones on that
        axis, and blank everything else.  A crossed AOD pair holds two independent frequency combs
        and NOTHING requires the one on the axis that is not moving to span the whole block, so a
        move can be carried on a proper subset of the block's lines -- see `sb_build.sub_comb`.
        Measuring such a move needs a profile of just those lines: taken over the bounding box the
        static majority sits exactly on its tones and swamps the moving minority.
        """
        key = (tuple(colour), tuple(win), f, tol,
               None if keep is None else (keep[0], tuple(keep[1])))
        if key in self._mask:
            return self._mask[key]
        if len(self._mask) > 400:
            self._mask.clear()
        X0, X1, Y0, Y1 = self.box(win)
        a = self.img(f)[Y0:Y1, X0:X1]
        m = np.sqrt(((a - np.asarray(colour, np.float32)) ** 2).sum(axis=2)) < tol
        if keep is not None:
            ax, tones = keep[0], list(keep[1])
            base = X0 if ax == 0 else Y0
            n = m.shape[1] if ax == 0 else m.shape[0]
            t = self.to_tone(np.arange(n, dtype=float) + base, ax)
            live = np.zeros(n, bool)
            for v in tones:
                live |= np.abs(t - v) <= 0.5
            m = m & (live[None, :] if ax == 0 else live[:, None])
        self._mask[key] = (m, X0, Y0)
        return self._mask[key]

    def to_tone(self, v, axis):
        o, p = (self.ox, self.px) if axis == 0 else (self.oy, self.py)
        return (v - o) / p + 1.0 - self.moff[axis]

    def peaks(self, colour, win, f, axis, tol=34.0, minfrac=0.20, minsep=0.28, keep=None):
        """peak positions of the colour's 1-D profile, in continuous tone units.

        `keep` restricts the profile to a comb of lines on the other axis -- see `mask`.
        """
        m, X0, Y0 = self.mask(colour, win, f, tol, keep)
        prof = m.sum(axis=0 if axis == 0 else 1).astype(float)
        if prof.max() <= 0:
            return []
        p = prof / prof.max()
        raw, n, i = [], len(p), 1
        while i < n - 1:
            if p[i] >= minfrac and p[i] >= p[i - 1] and p[i] >= p[i + 1]:
                j = i
                while j + 1 < n and p[j + 1] == p[i]:
                    j += 1
                c = (i + j) / 2.0
                k = int(c)
                if 0 < k < n - 1:                       # parabolic refinement
                    a, b, cc = p[k - 1], p[k], p[k + 1]
                    den = a - 2 * b + cc
                    if den:
                        c = k + 0.5 * (a - cc) / den
                raw.append(c)
                i = j + 1
            else:
                i += 1
        pitch = self.px if axis == 0 else self.py
        sep = minsep * pitch
        groups = []
        for c in raw:
            if groups and c - groups[-1][-1] < sep:
                groups[-1].append(c)
            else:
                groups.append([c])
        base = X0 if axis == 0 else Y0
        return [self.to_tone(float(np.mean(g)) + base, axis) for g in groups]

    def area(self, colour, win, f, tol=34.0, keep=None):
        return int(self.mask(colour, win, f, tol, keep)[0].sum())


def clear_frame(M, f, direction, lo, hi):
    """the nearest frame to f, moving `direction`, that is NOT a global-pulse frame.
    A pulse tints the whole panel and every fill colour with it, so a configuration read on one
    comes back empty or wrong.  This is the single most common way to lose a whole move."""
    g = f
    while lo <= g <= hi and g in M.gate:
        g += direction
    if not (lo <= g <= hi):
        g = f
        while lo <= g <= hi and g in M.gate:
            g -= direction
    return max(lo, min(hi, g))


def smoothstep(u):
    u = np.clip(np.asarray(u, float), 0.0, 1.0)
    return 10 * u ** 3 - 15 * u ** 4 + 6 * u ** 5


# ----------------------------------------------------------------- palette discovery
def discover_outlines(M, frames, win, min_px=300, tol=34.0):
    """Saturated colours that are NOT within tol of any known fill / faded / background.
    These are the marker outlines -- rule 7.  se_moves.py throws them away as noise."""
    known = [np.asarray(c, np.float32) for c in list(M.fill.values()) + list(M.faded.values())]
    known += [np.asarray([255., 255., 255.]), np.asarray(M.K.get("background", [255, 255, 255]),
                                                         np.float32)]
    hits = collections.Counter()
    rep = {}
    X0, X1, Y0, Y1 = M.box(win)
    for f in frames:
        if f in M.gate:
            continue                                    # the gate tint moves every colour
        a = M.img(f)[Y0:Y1, X0:X1].reshape(-1, 3)
        chroma = a.max(axis=1) - a.min(axis=1)
        a = a[chroma > 45]
        if not len(a):
            continue
        d = np.stack([np.sqrt(((a - k) ** 2).sum(axis=1)) for k in known]).min(axis=0)
        a = a[d > tol * 1.6]
        if not len(a):
            continue
        q = (a // 16 * 16).astype(int)
        for key, cnt in collections.Counter(map(tuple, q.tolist())).items():
            hits[key] += cnt
            if key not in rep:
                rep[key] = []
            rep[key].append(a[(q == np.asarray(key)).all(axis=1)].mean(axis=0))
    out = []
    for key, n in hits.most_common():
        if n < min_px * len(frames) / 4.0:
            break
        c = np.mean(rep[key], axis=0)
        if any(np.sqrt(((c - np.asarray(o)) ** 2).sum()) < 40 for o in out):
            continue
        out.append(tuple(float(v) for v in c))
    return out


def colours_on_frame(M, win, f, min_px=200):
    """Every marker colour actually present in `win` ON frame `f`, measured on that frame.

    Rule 15 reads a pulse-frame configuration from the OUTLINE colours because the tint spoils the
    fill mask.  But the fill is not gone -- it has MOVED, and by more than the palette tolerance:
    c300's Z0 renders at rgb(87,120,151) while a pulse is on, 77 RGB from the rgb(41,119,213) the
    calibration holds, so a 34 RGB mask catches 63 pixels of the ~7800 that are there and resolves
    nine of the block's ten columns.  Neither the palette nor `discover_outlines` can supply that
    colour: discovery skips gate frames precisely because the tint moves everything, so a colour
    that exists ONLY while a pulse is on is invisible to it.  On c300 that lost `Z0 1:10 -> -9:0`
    entirely -- the configuration exists on no other frame, because Z0's rows arrive exactly AT the
    pulse and its columns leave one frame after it -- and Z1's half of the same exchange went into
    the sheet alone, which is the two-blocks-on-one-another's-sites failure of rule 35.

    So measure the colours on the frame instead of assuming them: cluster the saturated pixels in
    the window and return every cluster, largest first.  This is deliberately unfiltered -- the
    species' own tinted fill is normally the largest cluster, but a tinted outline is a legitimate
    candidate too, and the caller's guards decide.  Those guards are unchanged and are what makes
    this safe: an accepted read must be an exact w x h rectangle on tones, and `drop_pulse_collisions`
    still enforces one trap holding one atom (rule 23).
    """
    X0, X1, Y0, Y1 = M.box(win)
    a = M.img(f)[Y0:Y1, X0:X1].reshape(-1, 3)
    chroma = a.max(axis=1) - a.min(axis=1)
    a = a[chroma > 45]
    if not len(a):
        return []
    q = (a // 16 * 16).astype(int)
    keys = collections.Counter(map(tuple, q.tolist()))
    out = []
    for key, n in keys.most_common():
        if n < min_px:
            break
        c = tuple(float(v) for v in a[(q == np.asarray(key)).all(axis=1)].mean(axis=0))
        if any(math.sqrt(sum((u - v) ** 2 for u, v in zip(c, o))) < 40 for o in out):
            continue
        out.append(c)
    return out


# ----------------------------------------------------------------- rest test (rule 2)
def block_state(M, name, win, f, outline=None, tol=0.12):
    """(xs, ys, n_markers, at_rest) for one species in one window."""
    xs = M.peaks(M.fill[name], win, f, 0)
    ys = M.peaks(M.fill[name], win, f, 1)
    if outline:                                          # fill+outline: the whole marker
        pass
    if not xs or not ys:
        return xs, ys, 0, False
    on = all(abs(v - round(v)) <= tol for v in xs) and all(abs(v - round(v)) <= tol for v in ys)
    # rule 2: the zone must be a FULL rectangle, not a partly occupied one
    npix = M.area(M.fill[name], win, f)
    unit = npix / float(max(1, len(xs) * len(ys)))
    full = True                                          # profile peaks already imply the product
    return xs, ys, len(xs) * len(ys), (on and full)


# ----------------------------------------------------------------- move solving
def fit_ab(track, p0, p1, lo=-3.0, hi=None, span_max=None, step=0.01):
    """least squares (t_start, t_finish) in frames for value = p0 + (p1-p0)*s((f-a)/(b-a))"""
    fs = np.array([t[0] for t in track], float)
    vs = np.array([t[1] for t in track], float)
    hi = hi if hi is not None else fs.max() + 6.0
    span_max = span_max or (fs.max() - fs.min() + 14.0)
    best = None
    for a in np.arange(lo, fs.max(), step * 4):
        for b in np.arange(a + 2.0, min(hi, a + span_max), step * 4):
            e = float(np.sqrt(((p0 + (p1 - p0) * smoothstep((fs - a) / (b - a)) - vs) ** 2).mean()))
            if best is None or e < best[0]:
                best = (e, a, b)
    return best


def complement(S, A, S2, A2):
    """rule: B = S \\ A, B' = S' \\ A', paired in increasing order (guide I.2)."""
    B = sorted(set(S) - set(A))
    B2 = sorted(set(S2) - set(A2))
    if len(B) != len(B2):
        return None
    return B, B2


def verify(M, name, win, axis, subs, frames):
    """predict every fill peak on every frame; return (mean err, worst, detail lines)"""
    lines, tot, n, worst = [], 0.0, 0, 0.0
    for f in frames:
        pred = []
        for st, en, a, b in subs:
            pr = float(smoothstep((f - a) / (b - a)))
            pred += [p + (q - p) * pr for p, q in zip(st, en)]
        pred = sorted(pred)
        meas = sorted(M.peaks(M.fill[name], win, f, axis))
        errs = [min(abs(m - p) for p in pred) for m in meas] if pred and meas else []
        if errs:
            tot += sum(errs); n += len(errs); worst = max(worst, max(errs))
        lines.append("      f%03d pred %s | meas %s | worst %.3f"
                     % (f, " ".join("%6.2f" % v for v in pred),
                        " ".join("%6.2f" % v for v in meas),
                        max(errs) if errs else float("nan")))
    return (tot / n if n else float("nan")), worst, lines


# ----------------------------------------------------------------- AOM packing (rule 8)
def increasing(pairs):
    p = sorted(pairs)
    return all(p[i][1] < p[i + 1][1] for i in range(len(p) - 1))


def can_share(r1, r2):
    """two rows on ONE crossed pair: the merged map on each axis must stay strictly increasing"""
    for ax in (0, 1):
        m1 = list(zip(r1["s"][ax], r1["e"][ax]))
        m2 = list(zip(r2["s"][ax], r2["e"][ax]))
        merged = dict(m1)
        for k, v in m2:
            if k in merged and merged[k] != v:
                return False
            merged[k] = v
        if not increasing(merged.items()):
            return False
    return True


def disjoint(r1, r2, tol=0.05):
    """Do these two rows never run at the same time?  A crossed AOD pair is REPROGRAMMED between
    batches, so a group that has finished one move is free for the next.  Without this the packer
    hands every later move a brand-new group and reports a peak far above what the machine needs."""
    return r1["b"] <= r2["a"] + tol or r2["b"] <= r1["a"] + tol


def pack(rows):
    """Interval colouring: a row joins a group when, for every row already there, either the two
    never overlap in time, or they can legitimately ride one crossed pair.

    For rows that DO overlap, `can_share` alone is not enough -- merging two combs creates traps at
    the full product of the unions, and an atom of another group standing on one of those would be
    held twice (guide's atom-capture rule, which needs the simulator).  So overlapping rows are
    merged only when they already share an IDENTICAL comb on one axis, which adds no new traps on
    that axis and is the only case that arises in practice: the same motion applied to two blocks
    side by side."""
    def ok(r, o):
        if disjoint(r, o):
            return True
        if not can_share(r, o):
            return False
        return (list(r["s"][0]) == list(o["s"][0]) and list(r["e"][0]) == list(o["e"][0])) or \
               (list(r["s"][1]) == list(o["s"][1]) and list(r["e"][1]) == list(o["e"][1]))

    groups = []
    for r in sorted(rows, key=lambda r: (r["a"], r["b"])):
        for g in groups:
            if all(ok(r, o) for o in g):
                g.append(r); break
        else:
            groups.append([r])
    return groups


def comb(v):
    """tone list -> compact string.  Contiguous runs collapse: [1..5,11..15] -> '1:5,11:15'.
    A comb with a constant stride other than 1 stays explicit: [1,3,5] -> '1,3,5'."""
    v = sorted(set(int(x) for x in v))
    if not v:
        return ""
    runs, cur = [], [v[0]]
    for x in v[1:]:
        if x == cur[-1] + 1:
            cur.append(x)
        else:
            runs.append(cur); cur = [x]
    runs.append(cur)
    if all(len(r) == 1 for r in runs) and len(runs) > 1:
        return ",".join(str(x) for x in v)
    return ",".join("%d:%d" % (r[0], r[-1]) if len(r) > 1 else str(r[0]) for r in runs)


# ----------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", required=True)
    ap.add_argument("--frames", default=None)
    ap.add_argument("--f0", type=int, default=0)
    ap.add_argument("--f1", type=int, default=None)
    ap.add_argument("--tol", type=float, default=0.12, help="on-tone radius, in tones")
    ap.add_argument("--accept", type=float, default=0.10, help="mean verification error limit")
    ap.add_argument("--palette", action="store_true")
    ap.add_argument("--rest", action="store_true")
    ap.add_argument("--solve", action="store_true")
    ap.add_argument("--out-prefix", default="")
    ap.add_argument("--xlsx", default="", help="write Shayne's Combined layout to this .xlsx")
    ap.add_argument("--t-max", type=float, default=0.0,
                    help="keep only moves STARTING before this time in ms (0 = keep all)")
    ap.add_argument("--reconcile", type=float, default=1.5,
                    help="frames: merge a species' move end with its own next move's start")
    ap.add_argument("--windows", default="",
                    help="species windows, e.g. 'X0=0.5,6.6,0.4,11;Z0=0.5,6.6,10.3,16'. "
                         "Default: each species' own bounding box at --f0, padded half a site.")
    a = ap.parse_args()

    M = Movie(a.calib, a.frames)
    f1 = a.f1 if a.f1 is not None else M.nf - 1
    frames = list(range(a.f0, f1 + 1))
    print("movie: %d frames, dt %.9f ms, cycle %.4f ms" % (M.nf, M.dt, M.nf * M.dt))
    print("gate (pulse) frames in window: %s"
          % sorted(f for f in frames if f in M.gate))

    full = (M.K["visible_col"][0] - 0.4, M.K["visible_col"][1] + 0.4,
            M.K["visible_row"][0] - 0.4, M.K["visible_row"][1] + 0.4)

    # ---- windows, one per species, from a rest frame
    wins = {}
    for tok in a.windows.split(";"):
        if "=" in tok:
            k, v = tok.split("=")
            wins[k.strip()] = tuple(float(x) for x in v.split(","))
    # A window must be measured on a NON-pulse frame, and must be wide enough to hold the block
    # wherever it travels in this segment -- so take the union of its extent over the segment.
    ref = clear_frame(M, a.f0, +1, a.f0, f1)
    for nm in M.species:
        if nm in wins:
            continue
        ext = []
        for f in [ref] + [g for g in frames[::max(1, len(frames) // 6)] if g not in M.gate]:
            xs = M.peaks(M.fill[nm], full, f, 0)
            ys = M.peaks(M.fill[nm], full, f, 1)
            if xs and ys:
                ext.append((min(xs), max(xs), min(ys), max(ys)))
        if not ext:
            continue
        wins[nm] = (min(e[0] for e in ext) - 0.55, max(e[1] for e in ext) + 0.55,
                    min(e[2] for e in ext) - 0.55, max(e[3] for e in ext) + 0.55)
    print("windows (cols lo,hi / rows lo,hi), measured off non-pulse frames:")
    for nm in sorted(wins):
        print("   %-3s  %.2f..%.2f  x  %.2f..%.2f" % (nm, wins[nm][0], wins[nm][1],
                                                      wins[nm][2], wins[nm][3]))

    if a.palette:
        print("\n== fills and faded fills (from the calibration)")
        for nm in M.species:
            print("   %-3s solid rgb%-20s faded rgb%s"
                  % (nm, str(tuple(int(v) for v in M.fill[nm])),
                     str(tuple(int(v) for v in M.faded[nm]))))
        print("\n== discovered OUTLINE colours (rule 7) -- not in the species palette")
        outs = discover_outlines(M, frames[::max(1, len(frames) // 8)], full)
        if not outs:
            print("   none")
        for c in outs:
            print("   rgb(%3d,%3d,%3d)   nearest known is %.0f RGB away"
                  % (c[0], c[1], c[2],
                     min(np.sqrt(((np.asarray(c) - np.asarray(k)) ** 2).sum())
                         for k in list(M.fill.values()) + list(M.faded.values()))))
        return

    outs = discover_outlines(M, frames[::max(1, len(frames) // 8)], full)

    OUT = outs[0] if outs else None
    if a.rest:
        print("\n== occupancy and rest, per species (rule 2)")
        for f in frames:
            parts = []
            for nm in M.species:
                if nm not in wins:
                    continue
                xs, ys, n, ok = block_state(M, nm, wins[nm], f, tol=a.tol)
                parts.append("%s %dx%d%s" % (nm, len(xs), len(ys), " REST" if ok else " ....."))
            print("   f%03d t=%.4f  %s%s" % (f, f * M.dt, "  ".join(parts),
                                             "   [pulse]" if f in M.gate else ""))
        return

    if not a.solve:
        print("nothing to do: pass --palette, --rest or --solve")
        return

    # ------------------------------------------------------------- solve the window
    if not outs:
        print("\n== NO OUTLINE COLOUR FOUND -- sub-block moves are unrecoverable from this movie")
    else:
        print("\n== outline candidates, each tried in turn:")
        for c in outs:
            print("     rgb(%3d,%3d,%3d)" % tuple(int(v) for v in c))
    moves = []
    for OUT in outs:
      for nm in M.species:
        if nm not in wins:
            continue
        win = wins[nm]
        # frames where this species carries the outline -> the frames it is being moved
        act = [f for f in frames if OUT and M.area(OUT, win, f) > 200 and f not in M.gate]
        if not act:
            print("\n-- %s: no outline anywhere in the window -> not moved" % nm)
            continue
        # split into runs of consecutive active frames: one run = one move
        runs, cur = [], [act[0]]
        for f in act[1:]:
            if f == cur[-1] + 1:
                cur.append(f)
            else:
                runs.append(cur); cur = [f]
        runs.append(cur)
        # a run whose outline tone-set CHANGES on an axis part-way is really two moves;
        # detect by the outline's peak COUNT changing on either axis
        split = []
        for run in runs:
            sig = [(len(M.peaks(OUT, win, f, 0)), len(M.peaks(OUT, win, f, 1))) for f in run]
            cutpts = [i for i in range(1, len(run)) if sig[i] != sig[i - 1]]
            prev = 0
            for c in cutpts + [len(run)]:
                if c - prev >= 3:
                    split.append(run[prev:c])
                prev = c
        for run in split:
            fa, fb = run[0], run[-1]
            for axis, label in ((1, "rows"), (0, "cols")):
                A = [round(v) for v in M.peaks(OUT, win, fa, axis)]
                A2 = [round(v) for v in M.peaks(OUT, win, fb, axis)]
                if len(A) != len(A2) or A == A2:
                    continue
                # The block's own tone set before and after.  NEVER read a configuration on a
                # pulse frame: the global tint moves every fill colour by ~40 RGB and the mask
                # comes back empty.  Step away from the pulse instead.
                fr0 = clear_frame(M, fa, -1, a.f0, f1)
                fr1 = clear_frame(M, fb, +1, a.f0, f1)
                S = [round(v) for v in M.peaks(M.fill[nm], win, fr0, axis)]
                S2 = [round(v) for v in M.peaks(M.fill[nm], win, fr1, axis)]
                cm = complement(S, A, S2, A2)
                if cm is None:
                    continue
                B, B2 = cm
                track = [(f, M.peaks(OUT, win, f, axis)[0]) for f in run
                         if M.peaks(OUT, win, f, axis)]
                if len(track) < 4:
                    continue
                e, ta, tb = fit_ab(track, float(A[0]), float(A2[0]))
                subs = [(A, A2, ta, tb), (B, B2, ta, tb)]
                mer, worst, lines = verify(M, nm, win, axis, subs, run)
                moves.append(dict(sp=nm, axis=axis, label=label, win=win, A=A, A2=A2, B=B, B2=B2,
                                  a=ta, b=tb, rms=e, mean=mer, worst=worst, lines=lines,
                                  frames=run, outline=OUT,
                                  other=[round(v) for v in M.peaks(M.fill[nm], win, fr0, 1 - axis)]))

    # one physical move may be found via more than one outline colour; keep the best-verified
    keep = {}
    for m in moves:
        if m["mean"] > a.accept:
            continue
        k = (m["sp"], m["axis"], m["frames"][0] // 3)
        if k not in keep or m["mean"] < keep[k]["mean"]:
            keep[k] = m
    moves = sorted(keep.values(), key=lambda m: m["a"])

    # ---- A MOVE'S RECTANGLE IS NOT CONFINED TO ONE SPECIES.
    # Species is a property of the ATOM, not of the row -- a row picks up by POSITION -- so one
    # rectangle routinely spans two blocks of different colours.  Reading each species in its own
    # window therefore cuts such a rectangle in half and reports the other half as static, or
    # (worse) misses it entirely when the outline colour happens to mark only one half.
    # So: take each fitted tone map and test it against EVERY other species over the same frames.
    # Where it verifies, that species is on the same rectangle and its tones join the comb.
    # A static block fails this badly -- at half progress the prediction is half a tone off every
    # marker -- so there are no cheap false positives.
    for m in moves:
        ax, oax = m["axis"], 1 - m["axis"]
        subs = [(m["A"], m["A2"], m["a"], m["b"]), (m["B"], m["B2"], m["a"], m["b"])]
        also = []
        for nm2 in M.species:
            if nm2 == m["sp"] or nm2 not in wins:
                continue
            mer, _w, _l = verify(M, nm2, wins[nm2], ax, subs, m["frames"])
            if mer <= a.accept:
                o2 = [round(v) for v in M.peaks(M.fill[nm2], wins[nm2], m["frames"][0], oax)]
                if o2:
                    also.append((nm2, o2, mer))
        if also:
            m["other"] = sorted(set(m["other"]) | {t for _n, o2, _e in also for t in o2})
            m["also"] = also
            m["sp_all"] = [m["sp"]] + [n for n, _o, _e in also]

    # two species' readings of ONE rectangle are one move, not two
    uniq = {}
    for m in moves:
        k = (m["axis"], tuple(m["A"]), tuple(m["A2"]), tuple(m["B"]), tuple(m["B2"]),
             tuple(m["other"]), m["frames"][0] // 3)
        if k not in uniq or m["mean"] < uniq[k]["mean"]:
            uniq[k] = m
    moves = sorted(uniq.values(), key=lambda m: m["a"])

    # ---- reconcile: ONE BLOCK CANNOT DO TWO THINGS AT ONCE.  Where a species' move finishes
    # within --reconcile frames of its own next move starting, the two fitted endpoints are one
    # boundary measured twice; the easing is flat there so each is individually soft.  Put both on
    # their midpoint and re-verify.  Without this the AOM packing counts a spurious overlap and
    # reports a higher peak than the hardware actually needs.
    for nm in {m["sp"] for m in moves}:
        mine = sorted([m for m in moves if m["sp"] == nm], key=lambda m: m["a"])
        for p, q in zip(mine, mine[1:]):
            if abs(q["a"] - p["b"]) <= a.reconcile:
                mid = 0.5 * (p["b"] + q["a"])
                for m, which in ((p, "b"), (q, "a")):
                    old = m[which]
                    m[which] = mid
                    subs = [(m["A"], m["A2"], m["a"], m["b"]), (m["B"], m["B2"], m["a"], m["b"])]
                    mer, worst, lines = verify(M, m["sp"], m["win"], m["axis"], subs, m["frames"])
                    m["reconciled"] = "%s %.2f -> %.2f fr; verification %.4f -> %.4f site" % (
                        which, old, mid, m["mean"], mer)
                    m["mean"], m["worst"], m["lines"] = mer, worst, lines
    if a.t_max:
        # keep a move if it STARTS inside the requested span; its finish may fall outside, and is
        # reported as measured rather than truncated
        moves = [m for m in moves if m["a"] * M.dt < a.t_max]
        print("\n(--t-max %.4f ms: keeping moves that start inside the span)" % a.t_max)

    print("\n== moves found (%d)" % len(moves))
    for i, m in enumerate(moves, 1):
        ax = "y" if m["axis"] == 1 else "x"
        print("\n-- move %d  %s, %s, frames %d..%d" % (i, m["sp"], m["label"],
                                                       m["frames"][0], m["frames"][-1]))
        print("     outline sub-block : %s %s -> %s" % (ax, comb(m["A"]), comb(m["A2"])))
        print("     complement        : %s %s -> %s" % (ax, comb(m["B"]), comb(m["B2"])))
        print("     t_start %.2f fr = %.4f ms      t_finish %.2f fr = %.4f ms"
              % (m["a"], m["a"] * M.dt, m["b"], m["b"] * M.dt))
        print("     fit rms %.4f site;  verification against every fill peak: mean %.4f, worst %.3f  %s"
              % (m["rms"], m["mean"], m["worst"],
                 "OK" if m["mean"] <= a.accept else "*** REJECT ***"))
        bij = sorted(m["A"] + m["B"]) == sorted(m["A2"] + m["B2"])
        print("     bijection on the block's own sites: %s" % ("yes" if bij else "no (it relocates)"))
        if m.get("also"):
            print("     THE SAME RECTANGLE ALSO CARRIES: %s -- the comb on the other axis is %s"
                  % (", ".join("%s (verified %.3f site)" % (n, e) for n, _o, e in m["also"]),
                     comb(m["other"])))
        for ln in m["lines"]:
            print(ln)

    # ------------------------------------------------------------- AOM packing
    print("\n== AOM packing (rule 8)")
    rows = []
    for i, m in enumerate(moves, 1):
        for tag, (st, en) in (("a", (m["A"], m["A2"])), ("b", (m["B"], m["B2"]))):
            if m["axis"] == 1:
                s = (m["other"], st); e = (m["other"], en)
            else:
                s = (st, m["other"]); e = (en, m["other"])
            rows.append(dict(mv=i, sp=m["sp"], tag=tag, s=s, e=e, a=m["a"], b=m["b"]))
    groups = pack(rows)
    for gi, g in enumerate(groups, 1):
        for r in g:
            print("   AOM%d  move %d %-3s  x %-12s -> %-12s   y %-12s -> %-12s"
                  % (gi, r["mv"], r["sp"], comb(r["s"][0]), comb(r["e"][0]),
                     comb(r["s"][1]), comb(r["e"][1])))
    edges = sorted(set([r["a"] for r in rows] + [r["b"] for r in rows]))
    peak = 0
    for i in range(len(edges) - 1):
        mid = (edges[i] + edges[i + 1]) / 2.0
        live = set()
        for gi, g in enumerate(groups):
            if any(r["a"] < mid < r["b"] for r in g):
                live.add(gi)
        peak = max(peak, len(live))
    print("   groups used %d, peak concurrent %d" % (len(groups), peak))

    # ------------------------------------------------------------- table
    print("\n== Combined-format table")
    ng = len(groups)
    hdr = ["Move", "", "Rydberg?", "Start time", "Finish time"]
    for i in range(1, ng + 1):
        hdr += ["AOM%d x tones" % i, "AOM%d y tones" % i]
    hdr += ["event", "species", "note"]
    out = [hdr]
    gate_runs = []
    gs = sorted(f for f in frames if f in M.gate)
    for f in gs:
        if gate_runs and f == gate_runs[-1][-1] + 1:
            gate_runs[-1].append(f)
        else:
            gate_runs.append([f])
    idx = {id(r): gi for gi, g in enumerate(groups) for r in g}
    n = 0
    for run in gate_runs:
        n += 1
        # read the held configuration off the nearest NON-pulse frame (see clear_frame)
        rf = clear_frame(M, run[0], -1, a.f0, f1)
        if rf in M.gate:
            rf = clear_frame(M, run[-1], +1, a.f0, f1)
        cfg = {}
        for nm in M.species:
            if nm not in wins:
                continue
            xs = [round(v) for v in M.peaks(M.fill[nm], wins[nm], rf, 0)]
            ys = [round(v) for v in M.peaks(M.fill[nm], wins[nm], rf, 1)]
            if xs and ys:
                cfg.setdefault(comb(xs), set()).update(ys)
        # rule 8 applies to a held configuration too: two groups holding the SAME y comb are one
        # group with the union of their x combs.
        byy = {}
        for xk, yv in cfg.items():
            byy.setdefault(comb(sorted(yv)), set()).update(
                int(t) for part in xk.split(",") for t in
                (range(int(part.split(":")[0]), int(part.split(":")[1]) + 1)
                 if ":" in part else [int(part)]))
        cells = []
        for yk, xv in sorted(byy.items()):
            cells += [comb(sorted(xv)), yk]
        cells = (cells + [""] * (2 * ng))[:2 * ng]
        out.append([n, "%.4f" % (run[0] * M.dt), "Rydberg", "%.4f" % (run[0] * M.dt), ""]
                   + cells + ["gate", "", "global pulse; the columns are the configuration held"])
        out.append([n, "%.4f" % (run[-1] * M.dt), "Rydberg", "", "%.4f" % (run[-1] * M.dt)]
                   + cells + ["", "", ""])
    for mi, m in enumerate(moves, 1):
        n += 1
        s_cells = [""] * (2 * ng)
        e_cells = [""] * (2 * ng)
        for r in rows:
            if r["mv"] != mi:
                continue
            gi = idx[id(r)]
            s_cells[2 * gi] = comb(r["s"][0]); s_cells[2 * gi + 1] = comb(r["s"][1])
            e_cells[2 * gi] = comb(r["e"][0]); e_cells[2 * gi + 1] = comb(r["e"][1])
        # The easing is flat at both ends, so the first and last ~10 % of a move is sub-pixel and
        # the fitted endpoints run past the frames where motion is actually visible.  Clamp to the
        # cycle and say so rather than quoting a negative time.
        ta, tb = m["a"] * M.dt, m["b"] * M.dt
        note = "%s %s; verified %.3f site against every frame in %d..%d" % (
            m["sp"], m["label"], m["mean"], m["frames"][0], m["frames"][-1])
        if ta < 0 or tb > M.nf * M.dt:
            note += "; fitted endpoints %.4f..%.4f clamped (easing is flat at both ends)" % (ta, tb)
        ta = max(0.0, ta); tb = min(M.nf * M.dt, tb)
        out.append([n, "%.4f" % ta, "", "%.4f" % ta, ""] + s_cells + ["", m["sp"], note])
        out.append([n, "%.4f" % tb, "", "", "%.4f" % tb] + e_cells + ["", m["sp"], ""])
    w = [max(len(str(r[i])) for r in out) for i in range(len(hdr))]
    for r in out:
        print("   " + " | ".join(str(r[i]).ljust(w[i]) for i in range(len(hdr))))
    if a.out_prefix:
        import csv
        p = a.out_prefix + "_combined.csv"
        with open(p, "w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerows(out)
        print("\nwrote %s" % p)

    if a.xlsx:
        write_shayne(M, a, moves, groups, idx, rows, gate_runs, wins, f1)


def write_shayne(M, a, moves, groups, idx, rows, gate_runs, wins, f1):
    """Shayne's hand-written layout, exactly: one sheet `Combined`, 21 columns, one ROW PAIR per
    event (start row then finish row), events in TIME ORDER, column A the move number carried by
    `=A{r-2}+1`, column B the sort key `=MIN(Dr,Er)`."""
    import openpyxl
    NAOM = 8
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Combined"
    hdr = ["Move", "", "Rydberg?", "Start time", "Finish time"]
    for i in range(1, NAOM + 1):
        hdr += ["AOM%d x tones" % i, "AOM%d y tones" % i]
    ws.append(hdr)

    events = []
    for run in gate_runs:
        rf = clear_frame(M, run[0], -1, a.f0, f1)
        if rf in M.gate:
            rf = clear_frame(M, run[-1], +1, a.f0, f1)
        cfg = {}
        for nm in M.species:
            if nm not in wins:
                continue
            xs = [round(v) for v in M.peaks(M.fill[nm], wins[nm], rf, 0)]
            ys = [round(v) for v in M.peaks(M.fill[nm], wins[nm], rf, 1)]
            if xs and ys:
                cfg.setdefault(tuple(sorted(ys)), set()).update(xs)
        pairs = [(i, comb(sorted(xv)), comb(yk))                 # numeric order, not lexical
                 for i, (yk, xv) in enumerate(sorted(cfg.items()))]
        events.append(dict(t0=run[0] * M.dt, t1=(run[-1] + 1) * M.dt, ryd=True,
                           start=pairs, finish=pairs,
                           note="global pulse held over frames %d-%d" % (run[0], run[-1])))
    for mi, m in enumerate(moves, 1):
        st, fi = [], []
        for r in rows:
            if r["mv"] != mi:
                continue
            gi = idx[id(r)]
            st.append((gi, comb(r["s"][0]), comb(r["s"][1])))
            fi.append((gi, comb(r["e"][0]), comb(r["e"][1])))
        st.sort(); fi.sort()
        note = "%s %s, frames %d-%d; verified %.3f site against every fill peak" % (
            m["sp"], m["label"], m["frames"][0], m["frames"][-1], m["mean"])
        if m.get("reconciled"):
            note += "; reconciled " + m["reconciled"]
        events.append(dict(t0=max(0.0, m["a"] * M.dt), t1=m["b"] * M.dt, ryd=False,
                           start=[(g, x, y) for g, x, y in st],
                           finish=[(g, x, y) for g, x, y in fi], note=note))

    events.sort(key=lambda e: (e["t0"], e["t1"]))
    notes = []
    r = 2
    for n, ev in enumerate(events, 1):
        for is_start in (True, False):
            ws.cell(row=r, column=1,
                    value=(n if r <= 3 else "=A%d+1" % (r - 2)))
            ws.cell(row=r, column=2, value="=MIN(D%d,E%d)" % (r, r))
            if ev["ryd"]:
                ws.cell(row=r, column=3, value="Rydberg")
            ws.cell(row=r, column=4 if is_start else 5,
                    value=round(ev["t0"] if is_start else ev["t1"], 4))
            for gi, x, y in (ev["start"] if is_start else ev["finish"]):
                if gi < NAOM:
                    ws.cell(row=r, column=6 + 2 * gi, value=x)
                    ws.cell(row=r, column=7 + 2 * gi, value=y)
            r += 1
        notes.append((n, round(ev["t0"], 4), round(ev["t1"], 4), ev["note"]))

    ws.freeze_panes = "A2"
    for c, w in ((1, 7), (2, 10), (3, 10), (4, 11), (5, 11)):
        ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width = w
    for c in range(6, 6 + 2 * NAOM):
        ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width = 15

    ns = wb.create_sheet("Notes")
    ns.append(["Move", "Start time", "Finish time", "how this row was measured"])
    for row in notes:
        ns.append(list(row))
    ns.column_dimensions["D"].width = 120
    for c, w in (("A", 7), ("B", 11), ("C", 11)):
        ns.column_dimensions[c].width = w
    wb.save(a.xlsx)
    print("\nwrote %s  (%d events, %d rows)" % (a.xlsx, len(events), r - 2))


if __name__ == "__main__":
    main()
